#ifndef _JBLEN
# define _JBLEN	36

typedef char jmp_buf[_JBLEN];

#endif	/* _JBLEN */
