/*	PERFORM RANDOM INTEGER MATH TESTS    */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "test.h"

#define  NITER 3000

main ()
{
  int    i1,tmp;
  int    a0,a1,b1,c1;
  long   a2,b2,c2;
  double d0,d1,d2,d3;
  float  f0,f1,f2,f3;
  char   buf[20];

  /* integer tests */

  printf("Performing %d random integer Multiply/Divide tests\n",NITER);
  srand(1);
  for (i1 = 1; i1 < NITER ; i1++) {
    a0 = rand();			/* Pick a divadend		*/
    a1 = rand();			/* Pick a divisor		*/
    if (a1 == 0) a1++;			/* Prevent Div by 0 condition	*/
    if (a1 > a0) {			/* Oops, need to fix modulus fn */
      tmp = a1; a1=a0 ; a0 = tmp;	/*  on sparc sim.		*/
      }
    b1 = a0/a1;				/* Compute quotient.		*/
    c1 = a0%a1;				/* Compute modulus		*/
#if 0
      printf ("%d/%d = %d, ^ = %d\n", a0, a1, b1, c1);
#endif   
    if ((c1 + (a1 * b1)) != a0) {	/* Recombine and check for error*/
      printf ("%d/%d = %d, ^ = %d    ", a0, a1, b1, c1);
      sprintf (buf, "div %d by %d", a0, a1);
      fail (buf);
      }
    else
      if (i1%80 == 0) printf(".");
    fflush(stdout);
    }
    printf("\n");

/* float tests */

  printf("Performing %d random dbl float Multiply/Divide tests\n",NITER);
  srand(1);
  for (i1 = 1; i1 < NITER ; i1++)
    {
    d0 = rand();
    d1 = rand();
    d2 = d0/d1;
    d3 = abs(d1*d2 - d0);
#if 0
      printf ("%f/%f = %f, Chk = %f\n", d0, d1, d2, d3);
#endif
    if (f3 > .00000001) {
      printf ("%f/%f = %f, chk = %f    ", d0, d1, d2, d3);
      sprintf (buf, "fdiv %f by %f", d0, d1);
      fail (buf);
      }
    else
      if (i1%80 == 0) printf(".");
    fflush (stdout);
    }
    printf("\n");
}


