/** SPECS for libgloss test i/o support  **/

#define  pass(str) printf("PASS: %s\n",str)
#define  fail(str) printf("FAIL: %s\n",str)

