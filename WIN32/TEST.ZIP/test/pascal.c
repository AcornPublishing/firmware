/****************************************************************
 *
 *	Module		: pascal.c
 *	Description	: Writes out a Pascal's triangle using
 *			  semi-hosting and non-embedded libraries
 *
 * 	History		: From ARM Development Group Examples set.
 *
 *	Notes		:
 *
 *			  Limited to a depth of 6, since the
 *			  output routines only work with single 
 *                        digit numbers... 
 *
 ****************************************************************/

/****************************************************************
 * IMPORT
 ****************************************************************/

#include <stdio.h>

/****************************************************************
 * ROUTINES
 ****************************************************************/

/* -- pascal_generator ------------------------------------------
 *
 * Description	: Generates the PASCAL triangle numbers
 *
 * Parameters	: int n - level 
 *		  int i - row
 * Return	: int - calculated PASCAL triangle number...
 * Notes	: A recursive function. Note recursive functions
 *		  are dangerous in embedded systems which require
 *		  deterministic stack...
 *
 */

int pascal_generator (int n, int i)
{
    	if (i == 1 || i == n) return 1;
	
    	return pascal_generator(n-1,i-1) + pascal_generator(n-1,i);
}

/* -- pascal_triangle ------------------------------------------
 * 
 * Descriptions	: Builds the complete PASCAL's triangle.
 *
 * Parameters	: int d - depth
 * Return	: none...
 * Notes	: 
 *
 */

void pascal_triangle (int depth)
{
int 	i,j,s;

	for (j = 1; j < depth; j++) {
        	printf("\n\t\t");

        	for ( s = depth-j; s > 0; s-- ) {
			putchar (' ');
		}

        	for (i = 1; i <= j; i++) {
        	printf("%d ", pascal_generator(j, i));
        	}        
    	}

	putchar ('\n');

}
   
/* -- pascal_init ----------------------------------------------
 *
 * Description	: initialize the LED on the AEB-1 board
 *
 * Parameters	: none...
 * Return	: none...
 * Notes	: none...
 *
 */

void pascal_init (void)
{
}

/* -- main -----------------------------------------------------
 *
 * Description	: entry point
 * 
 * Parameters	: none...
 * Return	: int
 * Notes	: none...
 *
 */

int main (void)
{
	pascal_init();


        printf ("\n\t*** Pascal's Triangle *** \n\n");
        pascal_triangle (6);

	return 1;
}

/****************************************************************
 * End of Pascal.c
 ****************************************************************/

