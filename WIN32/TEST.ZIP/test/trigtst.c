#include <stdio.h>
#include <float.h>
#include <math.h>

const float deg2rad = 1/57.29578;
const float rad2deg = 57.29578;
const float pi      = 355./113.;

main()
  {
  int i,j9;			/* Angle Tst Vect steps 0 - 360 */
  float theta,theta2;		/* (float)angle in radians	*/
  float dX, dY;			/* X,Y unity test vectors	*/
  float err; 
  int	quadrnt;		/* X/Y Quadrant of test vector  */
  

  for(i=0 ; i<= 359 ; i++)	/* Generate 360 test vectors	*/
    {
    j9 = i;
    theta = i * deg2rad;	/* Get input angle		*/

    dX = cos(theta);		/* Call Math Lib cos routine	*/
    dY = sin(theta);


/*	---  Process Special cases and determine quadrant 	----	   */

    quadrnt = 0;		/* Initialize result to no tan-1 needed    */
  
    if ((dX == 0.)&&(dY == 0.))	theta2  = -999.; /* Indeterminate angle    */
    if ((dX == 0.)&&(dY > 0.))	theta2  =  90.0;
    if ((dX == 0.)&&(dY < 0.))	theta2  = 180.0;
    if ((dY == 0.)&&(dX > 0.))	theta2  =   0.0;
    if ((dY == 0.)&&(dX < 0.))	theta2  = 270.0;
    if ((dX >  0.)&&(dY > 0.))	quadrnt = 1;	/* Quadrant =  1  0-90	   */
    if ((dX <  0.)&&(dY > 0.))	quadrnt = 2;	/* Quadrant =  2 90-180	   */
    if ((dX <  0.)&&(dY < 0.))	quadrnt = 3;	/* Quadrant =  3 180-270   */
    if ((dX >  0.)&&(dY < 0.))	quadrnt	= 4;	/* Quadrant =  4 270-360   */
  
  
    switch (quadrnt)
      {
      case 0:					/* No atan needed.	   */
        break;
      
      case 1:					/*   0. -  90. Degrees     */
        theta2 = atan(dY/dX) * rad2deg;	
        break;

      case 2:					/*  90. - 180. Degrees	   */
        theta2 = atan(-dX/dY) * rad2deg + 90.;	
        break;

      case 3:					/* 180. - 270. Degrees	   */
        theta2 = atan(-dY/-dX) * rad2deg + 180.;
        break;

      case 4:					/* 270. - 359. Degreest	   */
        theta2 = atan(dX/-dY) * rad2deg + 270.;
        break;
      }

/* ----	  PRINT TEST VECTOR AND VALUES SUMMARY			----	   */
    
    err = abs(i - theta2);
    if (err > .001)
      printf("%3d %10f %10f %10f %10f - Error\n",i,theta,dX,dY,theta2);
    }
  exit(0);
  }
  
