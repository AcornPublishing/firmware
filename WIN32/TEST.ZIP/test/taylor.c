// Demonstrate some floating point stuff 
//
// This  program shows the inaccuracy of a taylor series 
// approximation for sin(x) when x is large. Dynamic C's
// library sin function (and most computers in general) 
// uses a rational approximation that is faster and more
// accurate. 

#include <math.h>


float taylor_sine(float);
float factorial(int);

main()
{
 int i;
 float x,y,z;

 i=120;
 x = 4.0; 
 while (i--)
 {
  y = taylor_sine(x);
  z = sin(x);
  printf("x = %8.4f, y = %8.4f, z = %8.4f\n", x, y,z);
  x = x * .9 ; 
 
  // as x gets smaller the approximations converge 
 }
}

float taylor_sine(float x)
{
 float sum, num, denom; 
 int i,sign;
 sum = 0.0;
 
 // if i is given a larger initial value then
 // the approximation becomes more accurate but
 // at i=36, a floating point overflow occurs
 // in the factorial 
 sign = -1;
 for( i = 1 ; i < 10 ; i += 2)
 {
  sign = -sign;
  // add the  ith term of the taylor series
  sum += sign * pow(x, (float)i ) / factorial(i);
 }
 return sum; 
}

float factorial(int n)
{
 float prod;
 prod = 1.0;
 while(n > 1)
 {
  prod = prod * n--;   
 } 
 return prod;
}

