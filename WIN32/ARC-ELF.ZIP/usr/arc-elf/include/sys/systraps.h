/* trap numbers for arc syscalls (STUB) */

#define INCHR	0x0000
#define OUTCHR	0x0020
#define RETURN	0x0063

#define SYSTRAP(x)

/* end of systraps.h */
