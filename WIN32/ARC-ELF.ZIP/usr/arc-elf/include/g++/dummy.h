#ifdef __GNUG__
#pragma interface
#endif
  struct filebuf {
      virtual int foo();
  };
