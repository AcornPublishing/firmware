// -*- C++ -*- forwarding header.

#ifndef __NEW_H__
#define __NEW_H__

#include <new>

#if 0
using std::new_handler;
using std::set_new_handler;
#endif

#endif // __NEW_H__
