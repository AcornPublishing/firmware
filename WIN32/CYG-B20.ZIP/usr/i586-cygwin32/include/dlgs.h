/* dlgs.h
   Definitions are in a different layout than MS headers
   This file includes our windows.h which in turn should include the
   normal contents of this header file (and the other Win32 headers).
*/

#ifndef _PLACEHOLDER_DLGS_H
#define _PLACEHOLDER_DLGS_H

#include <windows.h>

#endif /* _PLACEHOLDER_DLGS_H */
