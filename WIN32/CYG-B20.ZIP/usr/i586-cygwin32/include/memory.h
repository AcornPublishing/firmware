#ifndef _MEMORY_H
#define _MEMORY_H

/* This allows more things to compile. */
#include <string.h>

#endif /* _MEMORY_H */
