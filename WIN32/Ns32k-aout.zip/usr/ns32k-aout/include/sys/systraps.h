/* 	TRAP DEFINITION STUB FILE  for libc/sys  - NS32k		*/

/*	----    DEFINE TRAP CODES FOR THE OS INTERFACE		----	*/

#define INCHR	0x0000
#define OUTCHR	0x0020
#define RETURN	0x0063

/*	----	DEFINE MACRO for the Asm Trap Sequence		----	*/
/*  Example:
#define SYSTRAP(x) {	asm("or r9,r0,%0" : : "i" (x) : "r9"); \
			asm("tb0 0,r0,496");			\
		   }
*/
#define SYSTRAP(x)

/* end of systraps.h */
