//	prefmdlg.h:	Header for prefModalDialog class
//=======================================================================

#ifndef toolsMDLG_H
#define toolsMDLG_H

#include <v/vmodald.h>
#include "videcmdw.h"

    class toolsModalDialog : public vModalDialog
      {
      public:		//---------------------------------------- public
	toolsModalDialog(vBaseWindow* bw, char* title = "Tool Command Definitions");
	virtual ~toolsModalDialog();		// Destructor
	virtual void DialogCommand(ItemVal,ItemVal,CmdType); // action selected
	virtual void DialogDisplayed();
	virtual int setTools(char* msg);

      protected:	//--------------------------------------- protected

      private:		//--------------------------------------- private
	videCmdWindow* cmdWin;

      };

    class helpModalDialog : public vModalDialog
      {
      public:		//---------------------------------------- public
	helpModalDialog(vBaseWindow* bw, char* title = "Help File Definitions");
	virtual ~helpModalDialog();		// Destructor
	virtual void DialogCommand(ItemVal,ItemVal,CmdType); // action selected
	virtual void DialogDisplayed();
	virtual int setupHelp(char* msg);

      protected:	//--------------------------------------- protected

      private:		//--------------------------------------- private
	videCmdWindow* cmdWin;

      };

#endif

