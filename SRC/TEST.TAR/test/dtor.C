#include <stdio.h>

class foo
{
public:
   foo () { printf ("Constructor called\n"); }
  ~foo () { printf ("Destructor called\n"); }
};

foo x;

main ()
{
  printf ("Tesing C++ constructors and destructor\n");
  fflush(stdout);
}
