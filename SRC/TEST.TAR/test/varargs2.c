/* Oki bug report [OKI013] 

   Variable argments test failed.

   Execution result.
   val1, val2 = 1, 0
   val1, val2 = 2, 0
   val1, val2 = 3, 0

   Note, this test case for for traditional style C code.

 */

#include <stdio.h>
#include <varargs.h>
#include "test.h"

int     func();
int	gp;		/* Global STATIC pointer to return values  */

main()
{
        func(1, 2, 3);
}

func(va_alist)
     va_dcl
{
        va_list p;
	int val1, val2;
        int j;

        va_start(p);
        for (j = 1; j <= 3; ++j){
                dequals((int)j, va_arg(p, int));
        }
        va_end(p);
	gp = (int)(p);
        return (gp);
}

dequals(int val1, int val2)
{
        printf ("val1 is %d, val2 is %d\n", (int)val1, (int)val2);
        if (val1 == val2)
                pass ("varargs2 [OKI013]");
        else
                fail ("varargs2 [OKI013]");

        fflush (stdout);
        return;
}
