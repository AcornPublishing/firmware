#include <paths.h>
#include <string.h>
#include <stdio.h>

#define SIZE 40
     
static char buffer[SIZE];
          
const char path[] = "/bin:/usr/bin:/sbin";
          
int
main (void)
  {
  char *wr_path = strdup (path);
  char *cp = strtok (wr_path, ":");
          
  while (cp != NULL)
    {
    puts (cp);
    cp = strtok (NULL, ":");
    }

  strncpy (buffer, "hello", SIZE);
  puts (buffer);
  strncat (buffer, ", world", SIZE - strlen (buffer) - 1);
  puts (buffer);
  }

