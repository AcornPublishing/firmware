/*****************************************************************************
**
**	TEST-PRINTF Functions
**
*****************************************************************************/


#include <stdio.h>
#include <limits.h>
#include <float.h>
#include "test.h"

main ()
  {
  int   i,j,k;
  float x,y,z;
  
  printf ("Printf Test for String Values\n");
  printf ("These strings are Equal : %s\n","These strings are Equal");
  pass   ("printf - strings");
	
  printf ("\nPrintf Test for integer values\n");
  printf ("VALUE\\FORMAT        %%15d             %%015d                %%d\n");

  i = (INT_MIN) ;
  j = (INT_MAX)/2 ;
  k = (INT_MAX) ;

  printf (" INT_MIN       %14d      %014d       $d\n",-i,-i,-i);
  printf (" INT_MIN/2     %14d      %014d       %d\n",-j,-j,-j);
  printf (" 00000         %14d      %014d       %d\n", 0, 0, 0);
  printf (" INT_MAX/2     %14d      %014d       %d\n", j, j, j);
  printf (" INT_MAX       %14d      %014d       %d\n", k, k, k);

  printf ("\nPrintf Test for float  values\n");
  printf ("VALUE\\FORMAT        %%15e             %%015e                %%e\n");
  x =  FLT_MAX;
  y =  FLT_MAX/2;
  z =  FLT_MIN;

  printf ("-FLT_MAX       %14e      %014e       %e\n",-x,-x,-x);
  printf ("-FLT_MAX/2     %14e      %014e       %e\n",-y,-y,-y);
  printf ("-FLT_MIN       %14e      %014e       %e\n",-z,-z,-z);
  printf (" 0.00000       %14e      %014e       %e\n",0.,0.,0.);
  printf (" FLT_MIN       %14e      %014e       %e\n",z,z,z);
  printf (" FLT_MAX/2     %14e      %014e       %e\n",y,y,y);
  printf (" FLT_MAX       %14e      %014e       %e\n",x,x,x);
  
  printf ("\r\nDemo Program Start\r\n");
  printf ("Value = %d, %d\r\n", 2, 1);
  pass ("iprintf [OKI007]");
  fflush (stdout);

  exit(0);
  }
