#include <paths.h>
#include <string.h>
#include <stdio.h>
          
const char path[] = "/bin:/usr/bin:/sbin";
          
int
main (void)
  {
  char *wr_path = strdup (path);
  char *cp = strtok (wr_path, ":");

  printf("strtok() test\n");
  printf("tokenizing string %s\n\n",path);
          
  while (cp != NULL)
    {
    puts (cp);
    cp = strtok (NULL, ":");
    }
  return 0;
  }

