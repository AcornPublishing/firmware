/*
 io.c -- Test the serial I/O.
 */

#define BUFSIZE 80
#include <stdio.h>
#include <sys/errno.h>
#include "test.h"


main()
{
  char buf[100];
  char *tmp;
  int result;

/*	Test the isatty() function		*/

  result = isatty(fileno(stdin));		/* Get isatty result	  */
  if (result)
    printf("isatty(stdin) returned TRUE\n");
  else
    printf("isatty(stdin) returned FALSE\n");
  
  /* test the lowest level output function */
  printf("\nPutchar test : ");
  result = putchar('&');
  if (result != 0x0) {
    pass ("outbyte");
  } else {
    fail ("outbyte");
  }
  fflush(stdout);  			/* Need to flush b4 write test */


  /* try writing a string */
  result = write (fileno(stdout),"Write Test: ", 12);
  printf ("result was %d ,", result);
  if (result == 12) {
    pass ("write");
  } else {
    fail ("write");
  }

  /* try the printf() function too */
  result = printf ("Printf Test:   ");
  printf ("result was %d ,",result);
  if (result == 15) {
    pass ("print");
  } else {
    fail ("print");
  }


  /* try to read a string */
  printf ("Type 5 characters -> ");

  fflush(stdout);
  result = 0;
  result = read (0, buf, 5);
  buf[result] = '\0';
  puts (buf);
  if (result == 5) {
    pass ("read");
  } else {
    fail ("read");
  }  

  /* clear everything out */
  fflush (stdout);
  }

/**	===  If running Native, trick up isatty so it always returns  ===  **/
/**	     1, because the cross libs can only do the same.		   **/

#if defined(linux) || defined (__CYGWIN__)

int isatty(fd)
  int fd;
  {
  return 1;
  }
#endif








