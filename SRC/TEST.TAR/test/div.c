/* WinBond bug report

   Please don't use "gcc -O3 -S hello.c" command, because it
   will optimize "i/5" to be "2" in compile time.

 */
/*	16Bit targets can't hanble FP so we degenerate double, float	*/
/*	data to integer.						*/

#if (defined(__MC6811__) || defined(__MN10200__) ||		\
     defined(NOFLOAT))
#warning  Regressing to integer data on 16bit target
#define double int
#define float  int
#endif


#include <stdio.h>
#include "test.h"
#define TESTSEED 10

main ()
{
  int    a1,b1,c1;
  long   a2,b2,c2;
  double a3,b3,c3;
  float  a4,b4,c4;
  char   buf[20];

  /* integer tests */
  for (a1 = 1; a1 < 16; a1++) {
    b1 = TESTSEED/a1;
    c1 = TESTSEED%a1;
    printf ("%6d/%6d = %6d, ^ = %6d   ", TESTSEED, a1, b1, c1);
    if ((c1 + (a1 * b1)) == TESTSEED) {
      sprintf (buf, "div %d by %d", TESTSEED, a1);
      pass (buf);      
    } else {
      sprintf (buf, "div %d by %d", TESTSEED, a1);
      fail (buf);
    }
    fflush (stdout);
  }
}


