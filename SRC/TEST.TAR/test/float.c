/*	16Bit targets can't hanble FP so we degenerate double, float	*/
/*	data to integer.						*/

#if (defined(__MC6811__) || defined(__MN10200__) ||		\
     defined(NOFLOAT))
#warning  Regressing to integer data on 16bit target
#define double int
#define float  int
#define NOFLOAT 1
#endif

#include <stdio.h>
#include "test.h"

main()
{
#if (defined(NOFLOAT))
  printf("float: test bypassed because of 16 bit target\n");
#else
  float a,b,c;

  a = 0.11;
  b = 3.12;
  c = a+b;

  printf ("Print float, result with 'f' = %f\n", c);
  printf ("Print float, result with 'e' = %e\n", c);
  printf ("Print float, result with 'E' = %E\n", c);
  printf ("Print float, result with 'g' = %g\n", c);
  printf ("Print float, result with 'G' = %G\n", c);

  pass ("float");
  fflush (stdout);
#endif
}

