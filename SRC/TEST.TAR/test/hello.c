#include <stdio.h>

main(void)
{
  int i;

  for(i=1;i<=10;i++)
    {
/*    putdec(i); */
    puts("hello world");
	}
  }


