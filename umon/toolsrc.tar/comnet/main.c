/* main.c:
 *
 * This program provides a connection between a remote machine and a
 * COM port on a PC.
 * Example:
 * Run "comnet 1", then on some other machine run "telnet IP 8200".
 * That telnet session will then be a direct connection to COM1.
 * This is useful for the monitor so that if a target is tied to a PC's
 * comport, this tool will support remote access of the com port.
 */
#define WIN32_LEAN_AND_MEAN
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wtypes.h>
#include <ctype.h>
#include <io.h>
#include <conio.h>
#include <fcntl.h>
#include <errno.h>
#include <setjmp.h>
#include <stdarg.h>
#include <direct.h>
#include <fcntl.h>
#include <math.h>
#include <malloc.h>
#include <process.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <mapiwin.h>
#include <wincon.h>
#include <winsock.h>
#include <tlhelp32.h>
#include "server.h"
#include "comport.h"
#include "utils.h"

extern int comport_write(char *buffer, int len);

HANDLE comHandle;
int	consoleEcho;
int	consoleConnect;

char *description_txt[] = {
	" comnet:",
	" This tool, running as a server on a PC, provides a virtual connection",
	" between the network side of the PC and one of the serial ports on that",
	" PC.  This allows the user to connect any serial port to the network.",
	" After startup on a PC, the network side is a server on TCP port 8200",
	" This server can be connected to with a telnet client that can override",
	" the default telnet TCP port of 23.  The serial port of the device",
	" should be tied to the PC's COM port.",
	" With the client attached to the server, the client then has a",
	" bi-directional connection to the COM port on the PC.",
	"",
	0,
};

char *errmsg[] = {
	"Usage: comnet [options] {comport #}",
	" Options:",
	"  -b#    override default baudrate of 19200",
	"  -c     connect console to com port also",
	"  -e     echo telnet-to-comport interaction to console",
	"  -h     generate a more verbose description of tool",
	"  -p#    override default tcp port number of 8200",
	"  -V     show version (build date) of tool",
	0,
};

void
description(void)
{
	int	i;

	for(i=0;description_txt[i];i++)
		fprintf(stderr,"%s\n",description_txt[i]);
	for(i=0;errmsg[i];i++)
		fprintf(stderr,"%s\n",errmsg[i]);
	exit(0);
}

void
usage(char *error)
{
	int	i;

	if (error)
		fprintf(stderr,"ERROR: %s\n",error);
	for(i=0;errmsg[i];i++)
		fprintf(stderr,"%s\n",errmsg[i]);
	exit(1);
}

void
showVersion(void)
{
	printf(" Built: %s @ %s\n",__DATE__,__TIME__);
	exit(1);
}

BOOL
ConsCtrlHdlr(DWORD ctrltype)
{
	switch(ctrltype) {
	case CTRL_CLOSE_EVENT:
	case CTRL_LOGOFF_EVENT:
	case CTRL_SHUTDOWN_EVENT:
		Die("Shutdown/Close/Logoff Event");
		return(FALSE);
	case CTRL_BREAK_EVENT:
	case CTRL_C_EVENT:
		servercleanup();
		Die("Terminating comnet!");
		return(FALSE);
	default:
		fprintf(stderr,"Unexpected Console Ctrl type: %ld\n",ctrltype);
		return(TRUE);
	}
}

DWORD WINAPI
conReaderThread(LPVOID id)
{
	char	c;

	while(1) {
		c = getch();
		if (c == 0x03) {
			servercleanup();
			Die("Terminating comnet!");
		}
		comport_write(&c,1);
	}
	return(0);
}

DWORD
conRdrThreadCreate(void)
{
	DWORD	tid;
	HANDLE	hConRdr;

	hConRdr = CreateThread(NULL,0,conReaderThread,
		(LPVOID)0,CREATE_SUSPENDED,&tid);
	if (hConRdr == INVALID_HANDLE_VALUE) {
		ShowLastError("CreatThread()");
		return(0);
	}
	ResumeThread(hConRdr);
	return(tid);
}

int 
main(int argc,char *argv[])
{
	int	opt;
	int	serialport = 1;
	int	tcpport = 8200;
	int baud = 19200;

	consoleEcho = 0;
	consoleConnect = 0;
	while((opt=getopt(argc,argv,"b:cehp:V")) != EOF) { 
		switch(opt) {
		case 'b':
			baud = atoi(optarg);
			break;
		case 'c':
			consoleConnect = 1;
			consoleEcho = 1;
			break;
		case 'e':
			consoleEcho = 1;
			break;
		case 'h':
			description();
			break;
		case 'p':
			tcpport = atoi(optarg);
			break;
		case 'V':
			showVersion();
			break;
		default:
			usage("bad option");
		}
	}

	if (argc != (optind +1)) {
		description();
	}

	if (SetConsoleCtrlHandler((PHANDLER_ROUTINE)ConsCtrlHdlr,TRUE) != TRUE) {
		ShowLastError("Can't establish ctrl-c restart handler");
		exit(1);
	}

	// Call comInit() just to initialize the com stuff...
	comInit();

	// Open the com port
	comHandle = comOpen(serialport,baud);
	if (comHandle == INVALID_HANDLE_VALUE)
		exit(1);

	comRdrThreadCreate(comHandle);

	if (consoleConnect)
		conRdrThreadCreate();

	if (server((short)tcpport) < 0)
		return(1);

	return(0);
}

