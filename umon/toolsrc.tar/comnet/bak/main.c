/* main.c:
*/
#define WIN32_LEAN_AND_MEAN
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wtypes.h>
#include <ctype.h>
#include <io.h>
#include <conio.h>
#include <fcntl.h>
#include <errno.h>
#include <setjmp.h>
#include <stdarg.h>
#include <direct.h>
#include <fcntl.h>
#include <math.h>
#include <malloc.h>
#include <process.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <mapiwin.h>
#include <wincon.h>
#include <winsock.h>
#include <tlhelp32.h>
#include "server.h"
#include "comport.h"
#include "utils.h"

BOOL
ConsCtrlHdlr(DWORD ctrltype)
{
	switch(ctrltype) {
	case CTRL_CLOSE_EVENT:
	case CTRL_LOGOFF_EVENT:
	case CTRL_SHUTDOWN_EVENT:
		Die("Shutdown/Close/Logoff Event");
		return(FALSE);
	case CTRL_BREAK_EVENT:
	case CTRL_C_EVENT:
		servercleanup();
		Die("Terminating comnet!");
		return(FALSE);
	default:
		fprintf(stderr,"Unexpected Console Ctrl type: %ld\n",ctrltype);
		return(TRUE);
	}
}

static HANDLE comHandle;

int
comport_write(char *buffer, int len)
{
	return(comWrite(comHandle,buffer,len));
}

int 
main(int argc,char *argv[])
{
	int	port = 1;
	int baud = 19200;

	if (SetConsoleCtrlHandler((PHANDLER_ROUTINE)ConsCtrlHdlr,TRUE) != TRUE) {
		ShowLastError("Can't establish ctrl-c restart handler");
		exit(1);
	}

	// Call comInit() just to initialize the com stuff...
	comInit();

	// Open the com port
	comHandle = comOpen(port,baud);
	if (comHandle == INVALID_HANDLE_VALUE)
		exit(1);

	comRdrThreadCreate(comHandle);

	if (server((short)atoi(argv[1])) < 0)
		return(1);

	return(0);
}
