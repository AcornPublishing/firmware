/* server.c:
*/
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <winsock.h>
#include <wsipx.h>
#include "server.h"
#include "utils.h"

extern int comport_write(char *buffer, int len);
static SOCKET	Socket;

void
servercleanup(void)
{
	closesocket(Socket);
}

int
net_write(char *buffer, int len)
{
	return(send(Socket,buffer,len,0));
}

int
server(short port)
{
	INT	err;
	WSADATA WsaData;
	SOCKET	listener;
	SOCKADDR_IN localAddr;

	err = WSAStartup (0x0101, &WsaData);
	if (err == SOCKET_ERROR) {
		fprintf (stdout, "WSAStartup Failed\n");
		return(-1);
	}

	// Open a socket to listen for incoming connections.
	listener = socket (AF_INET, SOCK_STREAM, 0);
	if (listener == INVALID_SOCKET) {
		fprintf (stdout, "Socket Create Failed\n");
		return(-1);
	}

	// Bind our server to the agreed some port number.
	ZeroMemory (&localAddr, sizeof (localAddr));
	localAddr.sin_port = htons (port);
	localAddr.sin_family = AF_INET;

	err = bind (listener, (PSOCKADDR) & localAddr, sizeof (localAddr));
	if (err == SOCKET_ERROR) {
		fprintf (stderr,"Socket Bind Failed\n");
		if (WSAGetLastError () == WSAEADDRINUSE)
			fprintf (stderr,"The port number may already be in use.\n");
		return(-1);
	}

	printf("Bound to port %d\n",port);

	// Prepare to accept client connections.  Allow up to 5
	// pending connections.
	err = listen (listener, 5);
	if (err == SOCKET_ERROR) {
		fprintf (stdout, "Socket Listen Failed\n");
		return(-1);
	}

	while(1) {
		Socket = accept (listener, NULL, NULL);
		if (Socket == INVALID_SOCKET) {
			fprintf (stderr,"accept() failed\n");
			return(-1);
		}
		
		while(1) {
			int		len;
			char	buffer[1024];
	
			len = recv(Socket,buffer,sizeof(buffer),0);
			if (len <= 0)
				break;
			comport_write(buffer,len);
		}
		closesocket(Socket);
		printf("Connection dropped\n");
	}
	return(0);
}
