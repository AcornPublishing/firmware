extern int server(short);
extern void servercleanup(void);
extern void socket_write(char *buffer, int len);
