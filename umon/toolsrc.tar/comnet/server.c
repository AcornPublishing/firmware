/* server.c:
*/
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <winsock.h>
#include <wsipx.h>
#include "server.h"
#include "utils.h"

extern int comport_write(char *buffer, int len);
static int cleanup = 0;
static SOCKET	Socket;
static SOCKET	listener;

void
servercleanup(void)
{
	cleanup = 1;
	closesocket(Socket);
	closesocket(listener);
}

int
net_write(char *buffer, int len)
{
	return(send(Socket,buffer,len,0));
}

int
server(short port)
{
	INT	err;
	WSADATA WsaData;
	SOCKADDR_IN localAddr;

	err = WSAStartup (0x0101, &WsaData);
	if (err == SOCKET_ERROR) {
		fprintf (stdout, "WSAStartup Failed\n");
		return(-1);
	}

	// Open a socket to listen for incoming connections.
	listener = socket (AF_INET, SOCK_STREAM, 0);
	if (listener == INVALID_SOCKET) {
		fprintf (stdout, "Socket Create Failed\n");
		return(-1);
	}

	// Bind our server to the agreed some port number.
	ZeroMemory (&localAddr, sizeof (localAddr));
	localAddr.sin_port = htons (port);
	localAddr.sin_family = AF_INET;

	err = bind (listener, (PSOCKADDR) & localAddr, sizeof (localAddr));
	if (err == SOCKET_ERROR) {
		fprintf (stderr,"Socket Bind Failed\n");
		if (WSAGetLastError () == WSAEADDRINUSE)
			fprintf (stderr,"The port number may already be in use.\n");
		return(-1);
	}

	printf("Bound to TCP port %d\n",port);

	// Prepare to accept client connections.  Allow up to 5
	// pending connections.
	err = listen (listener, 5);
	if (err == SOCKET_ERROR) {
		fprintf (stdout, "Socket Listen Failed\n");
		return(-1);
	}

	while(1) {
		int fromlen;
		struct sockaddr_in	from;

		fromlen = sizeof(from);
		Socket = accept (listener, (struct sockaddr *)&from, &fromlen);
		if (cleanup)
			break;
		if (Socket == INVALID_SOCKET) {
			fprintf (stderr,"accept() failed\n");
			return(-1);
		}
		printf("\n<COMNET STATUS: accepted connection from %s, port %d>\n", 
					inet_ntoa(from.sin_addr),
					htons(from.sin_port)) ;
		while(1) {
			int		len;
			char	buffer[1024];
	
			len = recv(Socket,buffer,sizeof(buffer),0);
			if (len <= 0)
				break;
			comport_write(buffer,len);
		}
		closesocket(Socket);
		printf("\n<COMNET STATUS: connection dropped remotely.>\n");
	}
	return(0);
}
