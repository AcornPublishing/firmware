//
// comport.c:
// This is a subset of the comport.c that is part of the "com" tool.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wtypes.h>
#include <ctype.h>
#include <io.h>
#include <conio.h>
#include <fcntl.h>
#include <errno.h>
#include <setjmp.h>
#include <stdarg.h>
#include <direct.h>
#include <fcntl.h>
#include <math.h>
#include <malloc.h>
#include <process.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <mapiwin.h>
#include <wincon.h>
#include <winsock.h>
#include <tlhelp32.h>
#include "utils.h"
#include "comport.h"

extern	HANDLE comHandle;
extern	int		consoleEcho;

int		rdrOffRqst, rdrOffRqstAck;
HANDLE	hComRdr;

int
comport_write(char *buffer, int len)
{
	return(comWrite(comHandle,buffer,len));
}

void
comInit(void)
{
	rdrOffRqst = rdrOffRqstAck = 0;
	hComRdr = (HANDLE)NULL;
}

HANDLE
comOpen(int portnum, int baud)
{
	DCB dcb;
	HANDLE hCom;
	char portname[16];

	sprintf(portname,"COM%d",portnum);
	hCom = CreateFile(portname,
		GENERIC_READ | GENERIC_WRITE,		// Open for read/write.
		0,									// Sharing flags.
		NULL,								// Security attributes.
		OPEN_EXISTING,						// Required for serial port.
		0,									// File attributes (NA).
		NULL);								// Required for serial port.
	if (hCom == INVALID_HANDLE_VALUE) {
		ShowLastError("comOpen() CreatFile()");
		return(INVALID_HANDLE_VALUE);
	}

	// Fill in the DCB...
	if (!GetCommState(hCom,&dcb)) {
		ShowLastError("comOpen() GetCommState()");
		return(INVALID_HANDLE_VALUE);
	}
	dcb.BaudRate = baud;
	dcb.ByteSize = 8;
	dcb.Parity = NOPARITY;
	dcb.StopBits = ONESTOPBIT;
	dcb.fDtrControl = DTR_CONTROL_ENABLE;
	dcb.fDsrSensitivity = FALSE;
	dcb.fOutX = FALSE;
	dcb.fInX = FALSE;
	dcb.fNull = FALSE;
	if (!SetCommState(hCom,&dcb)) {
		ShowLastError("comOpen() SetCommState()");
		return(INVALID_HANDLE_VALUE);
	}

	printf("Connected to COM%d at %d\n",portnum,baud);
	return(hCom);
}

void
comClose(HANDLE hCom)
{
	CloseHandle(hCom);
}

// comwrite():
// Send a block of characters to the specified com port.
// If the reader is active, then shut it down while the write is in
// progress.  This is done because apparently you can't write to a port
// if a thread is actively reading from that port.  I have no documentation
// stating this, but that's what I've found to be true.
//
int
comWrite(HANDLE hCom, char *buffer,int count)
{
	DWORD	byteswritten;

	stopComReader();
	if (WriteFile(hCom,buffer,(DWORD)count,&byteswritten,NULL) != TRUE) {
		byteswritten = -1;
	}
	resumeComReader();
	return((int)byteswritten);
}

DWORD
WINAPI
comReaderThread(LPVOID id)
{
	char	buf[0x8000];
	DWORD	bytesread;
	HANDLE	hCom;
	COMMTIMEOUTS tout;
	extern int net_write(char *,int);

	hCom = (HANDLE)id;

	GetCommTimeouts(hCom,&tout);
	tout.ReadIntervalTimeout = MAXDWORD;
	tout.ReadTotalTimeoutMultiplier = MAXDWORD;
	tout.ReadTotalTimeoutConstant = 50;
	SetCommTimeouts(hCom,&tout);

	while(1) {
		if (ReadFile(hCom,buf,(DWORD)(sizeof(buf)),
			&bytesread,NULL) != TRUE) {
				ShowLastError("comReaderThread ReadFile()");
				exit(1);
		}

		/* Send data to telnet connection... */
		net_write(buf,bytesread);

		/* If consoleEcho is set, then send data to console... */
		if (consoleEcho)
			write(1,buf,bytesread);

		if (rdrOffRqst) {
			rdrOffRqstAck = rdrOffRqst;
			while(rdrOffRqstAck) {
				if (rdrOffRqstAck != rdrOffRqst)
					rdrOffRqstAck = rdrOffRqst;
				Sleep(10);
			}
		}
	}
	return(0);
}

DWORD
comRdrThreadCreate(HANDLE hCom)
{
	DWORD	tid;

	hComRdr = CreateThread(NULL,0,comReaderThread,
		(LPVOID)hCom,CREATE_SUSPENDED,&tid);
	if (hComRdr == INVALID_HANDLE_VALUE) {
		ShowLastError("CreatThread()");
		return(0);
	}
	ResumeThread(hComRdr);
	return(tid);
}

void
comRdrThreadKill(void)
{
	if (hComRdr == (HANDLE)NULL)
		return;
	TerminateThread(hComRdr,1);
}

//
// stopComReader() & resumeComReader()
// These two functions interface with the reader thread to coordinate the
// stoppage and resumption of the reader thread calling ReadFile().
// This is necessary because apparently if ReadFile is blocked on a COM port
// waiting for characters, then a WriteFile destined for that same COM port
// will not work. I can't say that I've seen that documented anywhere, but it
// certainly seems to be the case.
//
// stopComReader...
// If reader is active, then increment the "reader-off-request" flag
// and wait for the reader to acknowledge that it has received the
// request (it will increment the "reader-off-request-ack" flag).
// resumeComReader...
// If reader is active, then decrement the "reader-off-request" flag
// and wait for the reader to acknowledge that it has received the
// request (it will decrement the "reader-off-request-ack" flag).
//

void
stopComReader()
{
	int	waitcnt;

	// If reader isn't active, return immediately...
	if (hComRdr == (HANDLE)NULL)
		return;

	waitcnt = 0;

	// Modify the request level...
	rdrOffRqst++;

	// Wait for the reader to acknowledge the change in the request level...
	while(rdrOffRqstAck != rdrOffRqst) {
		if (++waitcnt >= 100) {
			fprintf(stderr,"s");
			waitcnt = 0;
		}
		Sleep(10);
	}
}

void
resumeComReader()
{
	int	waitcnt;

	// If reader isn't active, return immediately...
	if (hComRdr == (HANDLE)NULL)
		return;

	waitcnt = 0;

	// Modify the request level...
	rdrOffRqst--;

	// Wait for the reader to acknowledge the change in the request level...
	while(rdrOffRqstAck != rdrOffRqst) {
		if (++waitcnt >= 100) {
			fprintf(stderr,"r");
			waitcnt = 0;
		}
		Sleep(10);
	}
}
