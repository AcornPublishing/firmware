/* TTFTP:
	An optional replacement for tftp on sun and pc.

	General notice:
	This code is part of a boot-monitor package developed as a generic base
	platform for embedded system designs.  As such, it is likely to be
	distributed to various projects beyond the control of the original
	author.  Please notify the author of any enhancements made or bugs found
	so that all may benefit from the changes.  In addition, notification back
	to the author will allow the new user to pick up changes that may have
	been made by other users after this version of the code was distributed.

	Author:	Ed Sutter
	email:	esutter@lucent.com		(home: lesutter@worldnet.att.net)
	phone:	908-582-2351			(home: 908-889-5161)
*/
#define WIN32_LEAN_AND_MEAN

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#include <time.h>
#if HOST_IS_WINNT | HOST_IS_WIN95
#include <io.h>
#include <winsock2.h>
typedef unsigned long ulong;
typedef unsigned short ushort;
#else
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define O_BINARY 0
#endif

#include "ttftp.h"

extern	void err(char *);
extern	void usage(char *);
char	consoleTitle[256];
int		tftpVerbose, tftpQuiet, RetryCount, tftpSrvrTimeout, tftpPpd;
int		tftpRFC2349TsizeEnabled;

void
tick(void)
{
	static char *hand[] = { "|\b", "/\b", "-\b", "\\\b" };
	static int tock;
	
	if (!tftpQuiet) {
		if (tock > 3)
			tock = 0;
		write(1,hand[tock++],2);
	}
}

void
showerr(msg,len)
int	len;
uchar *msg;
{
	ushort	errnum;

	errnum = ntohs(*(ushort *)(msg+2));
	if (len > 5)
		printf("\nTFTP ERROR %d: %s\n",errnum,&msg[4]);
	else 
		printf("\nTFTP ERROR %d\n",errnum);
}

#if HOST_IS_SOLARIS | HOST_IS_UNIXWARE | HOST_IS_LINUX
void
RetryInt(int sig)
{
	signal(SIGALRM,SIG_IGN);
	if (++RetryCount >= RETRY_MAX) {
		printf("Retries exhausted, giving up!\n");
		exit(EXIT_ERROR);
	}
	tick();
	return;
}
#endif

void
SendTo(sfd,msg,len,flags,to,tolen,desc,pass)
int	sfd, len, flags, tolen, pass;
char	*msg, *desc;
struct sockaddr *to;
{
	static	int	Sfd, MsgLen, Flags, ToLen;
	static	char 	Msg[1024], Desc[128];
	static	struct sockaddr	Saddr;

	/* If this is pass zero, then copy the data to static space in */
	/* case it is needed for retry. */
	if (pass == 0) {
		RetryCount = 0;
		Sfd = sfd;
		MsgLen = len;
		Flags = flags;
		ToLen = tolen;
		if ((len > 1024) || (strlen(desc) > 128)) {
			fprintf(stderr,"too big\n");
			exit(EXIT_ERROR);
		}
		memcpy(Msg,msg,len);
		strcpy(Desc,desc);
		Saddr = *to;
	}
	if (tftpVerbose)
		fprintf(stderr,"Sending %s...\n",Desc);

	if (sendto(Sfd,Msg,MsgLen,Flags,&Saddr,sizeof(Saddr)) < 0)
		err("sendto failed");
}

#if HOST_IS_SOLARIS | HOST_IS_UNIXWARE | HOST_IS_LINUX
void
(*signal(signum, func))()
int signum;
void (*func)();
{
	struct sigaction	act, oact;

	act.sa_handler = func;
	sigemptyset(&act.sa_mask);
	act.sa_flags = 0;
#ifdef SA_INTERRUPT
	act.sa_flags |= SA_INTERRUPT;
#endif
	if (sigaction(signum, &act, &oact) < 0) {
		perror("signal");
		return(SIG_ERR);
	}
	return(oact.sa_handler);
}
#endif

char *
strtolower(char *string)
{
	char *cp;

	cp = string;
	while(*cp) {
		*cp = tolower(*cp);
		cp++;
	}
	return(string);
}

#if HOST_IS_WINNT | HOST_IS_WIN95
// ShowLastError():
// Implementation of a discussion in VC++ documentation for displaying
// the error string that corresponds to the return value of GetLastError().
// A win32 implementation of perror()...
//
void
ShowLastError(char *msg)
{
	LPVOID	lpMessageBuffer;
	int		err;

	err = GetLastError();
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, err, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR) &lpMessageBuffer, 0, NULL);
	if (!msg)
		msg = "";
	fprintf(stderr,"Error:\t %s: %s",msg,lpMessageBuffer);
	LocalFree(lpMessageBuffer);
}
#endif

int
ttftp(char *sysname, char *getorput, char *srcfile,
	char *destfile, char *xfermode)
{
	int		i, xferlen, sfd, filemode, ffd, done, len;
	char	*openfile;
	char	rcvmsg[1024], sndmsg[1024];
	ushort	opcode;
	unsigned long inaddr;
	struct	sockaddr_in server, resp;
	struct	hostent	*hp, host_info;
	struct	stat mstat;
	ushort	blockno, lastblockno;
#if HOST_IS_UNIXWARE
	size_t	msglen;
#else
	int	msglen;
#endif
#if HOST_IS_WINNT | HOST_IS_WIN95
	WSADATA WsaData;
#endif

	if (strcmp(strtolower(getorput),"get") == 0) {
		opcode = htons(TFTP_RRQ);
		filemode = O_WRONLY | O_BINARY | O_CREAT | O_TRUNC;
		openfile = destfile; 
	}
	else if (strcmp(strtolower(getorput),"put") == 0) {
		opcode = htons(TFTP_WRQ);
		filemode = O_RDONLY | O_BINARY;
		openfile = srcfile; 
	}
	else
		usage("specify 'get or put'");

	ffd = open(openfile,filemode,0664);
	if (ffd == -1) {
		perror(openfile);
		exit(EXIT_ERROR);
	}

	fstat(ffd,&mstat);
	if (opcode == htons(TFTP_WRQ))
		printf("File %s size: %d bytes\n",openfile,mstat.st_size);

	xferlen = mstat.st_size;

#if HOST_IS_WINNT | HOST_IS_WIN95
	if (WSAStartup (0x0101, &WsaData) == SOCKET_ERROR)
		err("WSAStartup Failed");
#endif

	/* Accept server name as string or internet dotted-decimal address: */
	memset((char *)&server,0,sizeof(struct sockaddr));
	if ((inaddr = inet_addr(sysname)) != INADDR_NONE) {
		memcpy((char *)&server.sin_addr,(char *)&inaddr,sizeof(inaddr));
		host_info.h_name = NULL;
	}
	else {
		hp = gethostbyname(sysname);
		if (hp == NULL)
			err("gethostbyname failed");
		host_info = *hp;
		memcpy((char *)&server.sin_addr,hp->h_addr,hp->h_length);
	}
	server.sin_family = AF_INET;
	server.sin_port = htons(IPPORT_TFTP);

	sfd = socket(AF_INET,SOCK_DGRAM,0);
#if HOST_IS_WINNT | HOST_IS_WIN95
	if (sfd == INVALID_SOCKET)
#else
	if (sfd < 0)
#endif
		err("socket failed");

	/* Build the TFTP request: */
	memcpy(sndmsg,&opcode,2);
	
	if (opcode == htons(TFTP_WRQ)) {
		strcpy(&sndmsg[2],destfile);
		msglen = strlen(destfile) + 2;
	}
	else {
		strcpy(&sndmsg[2],srcfile);
		msglen = strlen(srcfile) + 2;
	}
	strcpy(&sndmsg[msglen+1],xfermode);
	msglen += (strlen(xfermode) + 2);
	
	if ((tftpRFC2349TsizeEnabled) && (opcode == htons(TFTP_WRQ))) {
		strcpy(sndmsg+msglen,"tsize");
		msglen += 6;
		msglen += sprintf(sndmsg+msglen,"%d",mstat.st_size);
		msglen++;
	}

	/* Start off the transfer... */
	SendTo(sfd,sndmsg,msglen,0,&server,sizeof(server),"RRQ/WRQ",0);

	done = 0;
	blockno = lastblockno = 0;
	while(!done) {
		ulong	bio;
		int		timeout;
		time_t	start;

		/* Set up a retry timer... */
		errno = 0;
#if HOST_IS_SOLARIS | HOST_IS_UNIXWARE | HOST_IS_LINUX
		signal(SIGALRM,RetryInt);
		alarm(1);

		msglen = sizeof(struct sockaddr);
		i = recvfrom(sfd,rcvmsg,sizeof(rcvmsg),0,
			(struct sockaddr *)&resp,&msglen);
		alarm(0);

		if (errno == EINTR) {
			SendTo(0,0,0,0,0,0,0,1);
			continue;
		}
#else
		bio = 1;
		ioctlsocket(sfd, FIONBIO,&bio);		// Non-blocking
		start = time(0);
		timeout = 0;
		while(!timeout) {
			msglen = sizeof(struct sockaddr);
			i = recvfrom(sfd,rcvmsg,sizeof(rcvmsg),0,
				(struct sockaddr *)&resp,&msglen);
			if (i != SOCKET_ERROR)
				break;
			if (WSAGetLastError() == WSAEWOULDBLOCK) {
				if ((time(0) - start) >= 2)
					timeout = 1;	
			}
			else {
				err("recvfrom: SOCKET_ERROR");
			}
		}
		if (timeout) {
			if (++RetryCount >= RETRY_MAX) {
				printf("Retries exhausted, giving up!\n");
				close(sfd);
				exit(EXIT_ERROR);
			}
			tick();
			SendTo(0,0,0,0,0,0,0,1);
			continue;
		}
		bio = 0;
		ioctlsocket(sfd, FIONBIO,&bio);		// Blocking
#endif
		opcode = ntohs(*(ushort *)rcvmsg);

		if (tftpVerbose)
			printf("Opcode = 0x%x\n",opcode);
		switch(opcode) {
		case TFTP_DAT:
			if (tftpVerbose)
				printf("Rcvd TFTP_DAT\n");
			else if (!tftpQuiet)
				write(1,".",1);
			i -= 4;
			if (i) {
				if (write(ffd,&rcvmsg[4],i) < 0)
					err("write failed");
			}
			*(ushort *)sndmsg = htons(TFTP_ACK);
			sndmsg[2] = rcvmsg[2];
			sndmsg[3] = rcvmsg[3];
#if HOST_IS_WINNT | HOST_IS_WIN95
			testTftp(TFTP_DAT,sndmsg,4);
#endif
			SendTo(sfd,sndmsg,4,0,&resp,sizeof(server),"ACK",0);
			if (i < TFTP_DATAMAX)
				done = 1;
			break;
		case TFTP_ACK:
			blockno = ntohs((*(ushort *)(rcvmsg+2)));
			if (tftpVerbose)
				printf("Rcvd TFTP_ACK blk#%d\n",blockno);
#if HOST_IS_WINNT | HOST_IS_WIN95
			if (tftpPpd)
				Sleep(tftpPpd);
#endif
			
			if (xferlen == -1) {
				done = 1;
				break;
			}
			*(ushort *)sndmsg = htons(TFTP_DAT);
			if (!blockno || (blockno == lastblockno + 1)) {
				if ((!tftpQuiet) && (!tftpVerbose))
					write(1,".",1);
				if (xferlen > TFTP_DATAMAX) {
					len = TFTP_DATAMAX;
					xferlen -= TFTP_DATAMAX;
				}
				else if (xferlen == TFTP_DATAMAX) {
					len = TFTP_DATAMAX;
					xferlen = 0;
				}
				else {
					if (xferlen > 0)
						len = xferlen;
					else
						len = 0;
					xferlen = -1;
				}
				*(ushort *)(sndmsg+2) = htons((ushort)(blockno+1));
				if (len) {
					int n;
					n = read(ffd,&sndmsg[4],len);
					if (n != len) {
						fprintf(stderr,"read=%d,not%d\n",n,len);
						err("read failed");
					}
				}
			}
			else {
				if (tftpVerbose) {
					fprintf(stderr,"retry blkno=%d\n",
					blockno);
				}
			}
#if HOST_IS_WINNT | HOST_IS_WIN95
			testTftp(TFTP_ACK,sndmsg,len+4);
#endif
			SendTo(sfd,sndmsg,len+4,0,&resp,sizeof(server),"DAT",0);
			lastblockno = blockno;
			break;
		case TFTP_ERR:
			showerr(rcvmsg,i);
			done = -1;
			break;
		case TFTP_WRQ:
			if (tftpVerbose)
				fprintf(stderr,"Rcvd TFTP_WRQ\n");
			break;
		case TFTP_RRQ:
			if (tftpVerbose)
				fprintf(stderr,"Rcvd TFTP_RRQ\n");
			break;
		default:
			if (tftpVerbose)
				fprintf(stderr,"Rcvd 0x%x ????\n",opcode);
			done = 1;
			break;
		}
	}
	if ((tftpVerbose) || (!tftpQuiet))
		printf("\n");
	close(sfd);
	close(ffd);
	if (done == -1)
		return(EXIT_ERROR);
	else
		return(EXIT_SUCCESS);
}
