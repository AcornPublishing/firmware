#if HOST_IS_WINNT | HOST_IS_WIN95
#define sleep(i) Sleep(i*1000)
#endif

#ifndef INADDR_NONE
#define INADDR_NONE	0xffffffff
#endif

/* Exit codes... */
#define EXIT_SUCCESS	0
#define EXIT_TIMEOUT	1
#define EXIT_ERROR		2

/* TFTP opcodes (see Stevens pg 466) */
#define TFTP_RRQ	1
#define TFTP_WRQ	2
#define TFTP_DAT	3
#define TFTP_ACK	4
#define TFTP_ERR	5

#define TFTP_OCTET			1
#define TFTP_NETASCII		2
#define TFTP_DATAMAX		512
#define TFTP_FULLDATABLOCK	562	/* 512 + overhead */
#define TFTP_PKTOVERHEAD	(TFTP_FULLDATABLOCK-TFTP_DATAMAX)

#define RETRY_MAX	10000	/* Give up after RETRY_MAX xmit retries */

typedef unsigned char uchar;

extern char	consoleTitle[256];
extern int	tftpVerbose, tftpQuiet, RetryCount, tftpSrvrTimeout, tftpPpd;
extern int	tftpRFC2349TsizeEnabled;
extern void	RetryInt();

extern int ttftp(char *,char *,char *,char *,char *);

#if HOST_IS_WINNT | HOST_IS_WIN95
extern int	tftpsrvr();
extern int	testSetup(char *msg);
extern void testTftp(int,char *,int);
#endif

extern int	getopt(), optind;
extern char	*optarg;

