#define WIN32_LEAN_AND_MEAN

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#include <io.h>
#include <winsock2.h>
typedef unsigned long ulong;
typedef unsigned short ushort;

/* TFTP opcodes (see Stevens pg 466) */
#define TFTP_RRQ	1
#define TFTP_WRQ	2
#define TFTP_DAT	3
#define TFTP_ACK	4
#define TFTP_ERR	5

#define TFTPTEST_SLEEP		1
#define TFTPTEST_CORRUPT	2
#define TFTPTEST_QUIT		3

#define TFTP_BUSY		1
#define TFTP_IDLE		2
#define TFTP_GETLASTACK	3

/* Exit codes... */
#define EXIT_SUCCESS	0
#define EXIT_TIMEOUT	1
#define EXIT_ERROR		2

int		test_Opcode = 0, test_OpcodePassCount = 0;
int		test_CorruptByte, test_OpcodePass, test_Type, test_SleepTime;
int		test_OpcodePassCount;

int		TftpState, msgCount, RRQfd, WRQfd;
char	WRQfile[128], RRQfile[128];
HANDLE	hdlTimer;
void	stopTimer(void);
DWORD	startTimer(void);
char	*ServerTitleBar="TFTP SERVER";
extern	int tftpSrvrTimeout, tftpVerbose;
extern	void ShowLastError(char *);

/* testTftp():
	This function is called at the top of each opcode reception to
	support the ability to insert various errors into the protocol
	and/or data.
*/
void
testTftp(int opcode,char *msg,int len)
{
	int	i;

	if (opcode != test_Opcode)
		return;

	if (++test_OpcodePassCount != test_OpcodePass)
		return;

	if (test_Type == TFTPTEST_QUIT) {
		exit(1);
	}
	else if (test_Type == TFTPTEST_SLEEP) {
		fprintf(stderr,"TEST: sleeping...");
		for(i=0;i<test_SleepTime;i++) {
			Sleep(1000);
			fprintf(stderr,".");
		}
		fprintf(stderr,"\n");
	}
	else if (test_Type == TFTPTEST_CORRUPT) {
		fprintf(stderr,"TEST: corruption...");
		msg[test_CorruptByte] = 0;
	}
}

/* testSetup():
	Called at startup to setup tests that are carried out by testTftp().
	The incoming line is formatted...
		OPCODE,OPCODE_PASS,TESTTYPE,ARG1,ARG2
	where...
		OPCODE is RRQ, WRQ, ACK, DAT or ERR;
		OPCODE_PASS indicates what opcode to apply this to, for example,
			if OPCODE_PASS is 3 and OPCODE is DAT, the apply this test to
			the third TFTP_DAT;
		TESTTYPE is SLEEP or CORRUPT
			if SLEEP, then ARG1 is sleep time, ARG2 is not used;
			if CORRUPT, then ARG1 is byte number, ARG2 is not used; 

*/
int
testSetup(char *setupline)
{
	int	 ccnt;
	char *commas[5], *cp;

	/* Determin the opcode: */
	if (!strncmp(setupline,"RRQ,",4))
		test_Opcode = TFTP_RRQ;
	else if (!strncmp(setupline,"WRQ,",4))
		test_Opcode = TFTP_WRQ;
	else if (!strncmp(setupline,"ACK,",4))
		test_Opcode = TFTP_ACK;
	else if (!strncmp(setupline,"DAT,",4))
		test_Opcode = TFTP_DAT;
	else if (!strncmp(setupline,"ERR,",4))
		test_Opcode = TFTP_ERR;
	else {
		fprintf(stderr,"Bad opcode.\n");
		return(-1);
	}

	ccnt = 0;
	cp = setupline;
	while(*cp) {
		if (*cp == ',')
			commas[ccnt++] = cp;
		cp++;
	}
	if ((ccnt < 2) || (ccnt > 4)) {
		fprintf(stderr,"Bad comma count.\n");
		return(-1);
	}
	
	test_OpcodePass = atoi(commas[0] + 1);
	if (test_OpcodePass <= 0) {
		fprintf(stderr,"Bad opcode pass (out of range).\n");
		return(-1);
	}
	if (((test_Opcode == TFTP_RRQ) || (test_Opcode == TFTP_WRQ)) &&
		(test_OpcodePass != 1)) {
		fprintf(stderr,"Bad opcode pass (NA for opcode).\n");
		return(-1);
	}

	if (!strncmp(commas[1]+1,"SLEEP,",6))  {
		test_Type = TFTPTEST_SLEEP;
		test_SleepTime = atoi(commas[2]+1);
		if (test_SleepTime <= 0) {
			fprintf(stderr,"Bad sleep time.\n");
			return(-1);
		}
	}
	else if (!strncmp(commas[1]+1,"QUIT,",5))  {
		test_Type = TFTPTEST_QUIT;
	}
	else if (!strncmp(commas[1]+1,"CORRUPT,",8)) {
		test_Type = TFTPTEST_CORRUPT;
		test_CorruptByte = atoi(commas[2]+1);
		if (test_CorruptByte <= 0) {
			fprintf(stderr,"Bad byte number.\n");
			return(-1);
		}
	}
	else {
		fprintf(stderr,"Bad testtype.\n");
		return(-1);
	}
	
	return(0);
}

tftpsrvr(void)
{
	char		rcvmsg[1024], sndmsg[1024], title[256];
	char		*WRQmode, *errmsg;
	INT			err, msglen, i, len, rcvtot;
	WSADATA		WsaData;
	SOCKET		listener;
	SOCKADDR_IN localAddr;
	ushort		opcode, blockno, errcode;
	char		RRQmode[32];

	err = WSAStartup (0x0101, &WsaData);
	if (err == SOCKET_ERROR) {
		fprintf (stdout, "WSAStartup Failed\n");
		return(-1);
	}

	SetConsoleTitle(ServerTitleBar);

	// Open a socket to listen for incoming connections.
	listener = socket (AF_INET, SOCK_DGRAM, 0);
	if (listener == INVALID_SOCKET) {
		fprintf (stdout, "Socket Create Failed\n");
		return(-1);
	}

	// Bind our server to the TFTP port number.
	ZeroMemory (&localAddr, sizeof (localAddr));
	localAddr.sin_port = htons (IPPORT_TFTP);
	localAddr.sin_family = AF_INET;

	err = bind (listener, (PSOCKADDR) & localAddr, sizeof (localAddr));
	if (err == SOCKET_ERROR) {
		fprintf (stderr,"Socket Bind Failed\n");
		if (WSAGetLastError () == WSAEADDRINUSE)
			fprintf (stderr,"The port number may already be in use.\n");
		return(-1);
	}
	TftpState = TFTP_IDLE;
	RRQfd = WRQfd = msgCount = 0;

	while(1) {
		msglen = sizeof(struct sockaddr);
		i = recvfrom(listener,rcvmsg,sizeof(rcvmsg),0,
			(struct sockaddr *)&localAddr,&msglen);
		msgCount++;
		opcode = ntohs(*(ushort *)rcvmsg);
		switch(opcode) {
		case TFTP_RRQ:
			test_OpcodePassCount = 0;
			strcpy(RRQfile,&rcvmsg[2]);
			strcpy(RRQmode,&rcvmsg[strlen(RRQfile)+3]);
			if (TftpState == TFTP_BUSY) {
				printf("TFTP_RRQ rqst: %s (%s) failed, srvr busy\n",
					RRQfile,RRQmode);
				*(ushort *)sndmsg = htons(TFTP_ERR);
				*(ushort *)&sndmsg[2] = htons(2);
				strcpy(&sndmsg[4],"Server is busy");
				len = 19;
				blockno = 0;
				goto tag1;
			}
			RRQfd = open(RRQfile,O_RDONLY | O_BINARY);
			if (RRQfd == -1) {
				printf("TFTP_RRQ rqst: %s (%s) failed, file not found\n",
					RRQfile,RRQmode);
				*(ushort *)sndmsg = htons(TFTP_ERR);
				*(ushort *)&sndmsg[2] = htons(1);
				strcpy(&sndmsg[4],"File not found");
				len = 19;
				blockno = 0;
			}
			else {
				printf("TFTP transferring: %s (%s)\n",RRQfile,RRQmode);
				sprintf(title,"TFTP_RRQ: %s",RRQfile);
				SetConsoleTitle(title);

				blockno = 1;
				*(ushort *)sndmsg = htons(TFTP_DAT);
				*(ushort *)&sndmsg[2] = htons(blockno);
				len = read(RRQfd,&sndmsg[4],512);
				if (len < 512) {
					close(RRQfd);
					RRQfd = 0;
					printf("TFTP %s transfer complete\n",RRQfile);
					SetConsoleTitle(ServerTitleBar);
					TftpState = TFTP_GETLASTACK;
				}
				else {
					TftpState = TFTP_BUSY;
					startTimer();
				}
				if (len >= 0)
					len += 4;
				else
					len = 4;
			}
tag1:
			testTftp(TFTP_RRQ,sndmsg,len);
			if (sendto(listener,sndmsg,len,0,(struct sockaddr *)&localAddr,
			  sizeof(struct sockaddr)) < 0) {
				perror("sendto failed");
				return(EXIT_ERROR);
			}
			break;
		case TFTP_ACK:
			if (RRQfd == -1)
				break;
			if (TftpState == TFTP_GETLASTACK) {
				TftpState = TFTP_IDLE;
				break;
			}
			if (tftpVerbose)
				printf("Rcvd TFTP_ACK blk#%d\n",htons(*(ushort *)&rcvmsg[2]));
			if (*(ushort *)&rcvmsg[2] == htons(blockno)) {
				blockno++;
				*(ushort *)sndmsg = htons(TFTP_DAT);
				*(ushort *)&sndmsg[2] = htons(blockno);
				len = read(RRQfd,&sndmsg[4],512);
				if (len < 512) {
					close(RRQfd);
				}
				if (len >= 0)
					len += 4;
				else {
					TftpState = TFTP_IDLE;
					printf("TFTP %s transfer completed\n",RRQfile);
					SetConsoleTitle(ServerTitleBar);
					RRQfd = 0;
					stopTimer();
					continue;
				}
			}
			else {
				*(ushort *)sndmsg = htons(TFTP_ERR);
				*(ushort *)&sndmsg[2] = htons(2);
				strcpy(&sndmsg[4],"Ack confused");
				len = 17;
			}
			testTftp(TFTP_ACK,sndmsg,len);
			if (sendto(listener,sndmsg,len,0,(struct sockaddr *)&localAddr,
			  sizeof(struct sockaddr)) < 0) {
				perror("sendto failed");
				return(EXIT_ERROR);
			}
			break;
		case TFTP_WRQ:
			test_OpcodePassCount = 0;
			strcpy(WRQfile,&rcvmsg[2]);
			WRQmode = &rcvmsg[2];
			while(*WRQmode) WRQmode++;
			WRQmode++;
			if (TftpState == TFTP_BUSY) {
				printf("TFTP_WRQ rqst: %s (%s) failed, srvr busy\n",
					WRQfile,WRQmode);
				*(ushort *)sndmsg = htons(TFTP_ERR);
				*(ushort *)&sndmsg[2] = htons(2);
				strcpy(&sndmsg[4],"Server is busy");
				len = 19;
				blockno = 0;
				goto tag2;
			}
			if (strcmp(WRQmode,"octet")) {
				fprintf(stderr,"%s: %s mode not supported\n",WRQfile,WRQmode);
				break;
			}
			printf("TFTP receiving: '%s'\n",WRQfile);
			unlink(WRQfile);
			if ((WRQfd = open(WRQfile,O_WRONLY|O_BINARY|O_TRUNC|O_CREAT,0777))==-1) {
				perror(WRQfile);
				break;
			}
			TftpState = TFTP_BUSY;
			sprintf(title,"TFTP_WRQ: %s",WRQfile);
			SetConsoleTitle(title);
			startTimer();
			rcvtot = 0;
			*(ushort *)sndmsg = htons(TFTP_ACK);
			*(ushort *)&sndmsg[2] = 0;
			len = 4;
tag2:
			testTftp(TFTP_WRQ,sndmsg,len);
			if (sendto(listener,sndmsg,len,0,(struct sockaddr *)&localAddr,
			  sizeof(struct sockaddr)) < 0) {
				perror("sendto (TFTP_ACK) failed");
				return(EXIT_ERROR);
			}
			break;
		case TFTP_DAT:
			if (tftpVerbose)
				printf("Rcvd TFTP_DAT\n");
			if ((i-4) > 0) {
				if (write(WRQfd,&rcvmsg[4],i-4) != i - 4) {
					perror("write (TFTP_DAT) failed");
					return(EXIT_ERROR);
				}
				rcvtot += (i-4);
				if ((i-4) != 512) {
					TftpState = TFTP_IDLE;
					close(WRQfd);
					printf("Receive completed (%d bytes).\n",rcvtot);
					SetConsoleTitle(ServerTitleBar);
					stopTimer();
				}
			}
			*(ushort *)sndmsg = htons(TFTP_ACK);
			sndmsg[2] = rcvmsg[2];	/* Copy blockno for ack. */
			sndmsg[3] = rcvmsg[3];
			len = 4;
			testTftp(TFTP_DAT,sndmsg,len);
			if (sendto(listener,sndmsg,len,0,(struct sockaddr *)&localAddr,
			  sizeof(struct sockaddr)) < 0) {
				perror("sendto (TFTP_ACK) failed");
				return(EXIT_ERROR);
			}
			break;
		case TFTP_ERR:
			testTftp(TFTP_ERR,0,0);
			errcode = htons(*(ushort *)&sndmsg[2]);
			errmsg = &sndmsg[4];
			printf("Incoming ERROR %d: <%s>\n",errcode, errmsg);
			return(EXIT_ERROR);
		}
	}
	return(EXIT_SUCCESS);
}

// TimerThread:
// This is used to kick off a timer that will keep track of the msgCount
// value and the TftpState variable.  It is started when WRQ or RRQ is
// received; then, every 5 seconds TftpState is polled.  If the state is
// busy, and tftpSrvrTimeout seconds have elapsed without a change in
// msgCount, then assume that the client went away and clear the busy state.
// If not busy, then assume the transaction has completed and terminate.
//
DWORD
WINAPI
timerThread(LPVOID notusedhere)
{
	int	lastcount, no_activity_time;

	/* Don't use the timer thread if a test is active. */
	if (test_Opcode)
		return(0);

	no_activity_time = 0;
	while(1) {
		Sleep(5000);
		if (TftpState == TFTP_BUSY) {
			if (lastcount == msgCount) {
				no_activity_time += 5;
				if (no_activity_time == 5)
					fprintf(stderr,"TFTP server waiting for response");
				else
					fprintf(stderr,".");
			}
			else {
				lastcount = msgCount;
				no_activity_time = 0;
			}
			if (no_activity_time >= tftpSrvrTimeout) {
				fprintf(stderr,"\nTFTP timeout");
				if (RRQfd > 0) {
					close(RRQfd);
					fprintf(stderr,", RRQ of %s aborted",RRQfile);
				}
				if (WRQfd > 0) {
					close(WRQfd);
					fprintf(stderr,
						", WRQ of %s aborted (file prematurely truncated)",
						WRQfile);
				}
				fprintf(stderr,".\n");
				TftpState = TFTP_IDLE;
				SetConsoleTitle(ServerTitleBar);
				stopTimer();	/* Doesn't return, it kills this thread. */
			}
		}
		else {
			if (no_activity_time > 0)
				fprintf(stderr,"\n");
			stopTimer();	/* Doesn't return, it kills this thread. */
		}
	}
	return(0);				/* Should never get here. */
}

DWORD
startTimer(void)
{
	DWORD	tid;

	/* Don't use the timer thread if a test is active. */
	if (test_Opcode)
		return(0);

	hdlTimer = CreateThread(NULL,0,timerThread,(LPVOID)0,CREATE_SUSPENDED,&tid);
	if (!hdlTimer) {
		ShowLastError("CreatThread()");
		return(0);
	}
	ResumeThread(hdlTimer);
	return(tid);
}

void
stopTimer(void)
{
	/* Don't use the timer thread if a test is active. */
	if (test_Opcode)
		return;

	if (hdlTimer) {
		if (TerminateThread(hdlTimer,1) == FALSE) {
			fprintf(stderr,"Thread termination failed\n");
			return;
		}
	}
}
