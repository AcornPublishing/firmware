/************************************************************************/
/* 					 													*/
/* DHCP stuff...	 													*/
/* See RFCs 2131 & 2132 for more details.								*/
/* Note that the values used for dhcpstate enum are based on the state  */
/* diagram in 3rd Edition Comer pg 375.									*/
/************************************************************************/

typedef unsigned char uchar;
typedef unsigned long ulong;
typedef unsigned short ushort;

#define	CLIENT_IS_BOOTP	1
#define CLIENT_IS_DHCP	2

#define DHCPSIZE (sizeof(struct ether_header) + sizeof(struct ip) + \
	sizeof(struct Udphdr) + sizeof(struct dhcphdr))

#define IPPORT_DHCP_SERVER	67
#define IPPORT_DHCP_CLIENT	68

#define DHCPBOOTP_REQUEST	1
#define DHCPBOOTP_REPLY		2

/* DHCP Message types: */
#define DHCPDISCOVER	1
#define DHCPOFFER		2
#define DHCPREQUEST		3
#define DHCPDECLINE		4
#define DHCPACK			5
#define DHCPNACK		6
#define DHCPRELEASE		7
#define BOOTPREPLY		98
#define DHCPUNKNOWN		99

#define MAXOPTSIZE		256

enum dhcpstate { INITIALIZE, SELECT, REQUEST, BOUND, RENEW, REBIND, NOTUSED };

/* DHCP Options */
#define DHCPOPT_SUBNETMASK			1
#define DHCPOPT_ROUTER				3
#define DHCPOPT_HOSTNAME			12
#define DHCPOPT_BROADCASTADDRESS	28
#define DHCPOPT_VENDORSPECIFICINFO	43
#define DHCPOPT_REQUESTEDIP			50
#define DHCPOPT_MESSAGETYPE			53
#define DHCPOPT_SERVERID			54
#define DHCPOPT_VCID				60
#define DHCPOPT_NISDOMAINNAME		64
#define DHCPOPT_NISSERVER			65
#define DHCPOPT_SSO130				130

#define DEFAULT_MAGIC_COOKIE		0x63825363		/* 99.130.83.99 */

struct bootphdr {
	unsigned char	op;
	unsigned char	htype;
	unsigned char	hlen;
	unsigned char	hops;
	unsigned long	transaction_id;
	unsigned short	seconds;
	unsigned short	unused;
	unsigned long	client_ip;
	unsigned long	your_ip;
	unsigned long	server_ip;
	unsigned long	router_ip;
	unsigned char	client_macaddr[16];
	unsigned char	server_hostname[64];
	unsigned char	bootfile[128];
	unsigned char	vsa[64];
};

struct dhcphdr {
	unsigned char	op;
	unsigned char	htype;
	unsigned char	hlen;
	unsigned char	hops;
	unsigned long	transaction_id;
	unsigned short	seconds;
	unsigned short	flags;
	unsigned long	client_ip;
	unsigned long	your_ip;
	unsigned long	server_ip;
	unsigned long	router_ip;
	unsigned char	client_macaddr[16];
	unsigned char	server_hostname[64];
	unsigned char	bootfile[128];
	unsigned long	magic_cookie;
	/* Dhcp options would start here */
};

struct dhcpbootphdr {
	int				hdrtype;		/* not part of actual dhcp/bootp hdr */
	int				optlistsize;	/* not part of actual dhcp/bootp hdr */
	unsigned char	op;
	unsigned char	htype;
	unsigned char	hlen;
	unsigned char	hops;
	unsigned long	transaction_id;
	unsigned short	seconds;
	unsigned short	flags;			/* for BOOTP this is unused */
	unsigned long	client_ip;
	unsigned long	your_ip;
	unsigned long	server_ip;
	unsigned long	router_ip;
	unsigned char	client_macaddr[16];
	unsigned char	server_hostname[64];
	unsigned char	bootfile[128];
	unsigned long	magic_cookie;
	unsigned char	vsa_or_opts[1024];	/* vsa size = (64 - (sizeof long)) */
};

unsigned char *DhcpGetOption();

#define IPPORT_DHCP_SERVER	67

/* Exit codes... */
#define EXIT_SUCCESS	0
#define EXIT_TIMEOUT	1
#define EXIT_ERROR		2

#if HOST_IS_WINNT | HOST_IS_WIN95
#define sleep(i) Sleep(i*1000)
#endif

extern int	getopt_sp;
extern int	optopt, optind, verbose;
extern int	cfgTotal, dhcpVerbose;
extern char	*optarg;
extern char configFile[];

extern int	getopt();
extern void printDhcp(struct dhcphdr *,char *,int,int);
extern int	IpToBin(char *,uchar *);
extern int	EtherToBin(char *,uchar *);
extern char *IpToString(ulong,char *);
extern char *EtherToString(unsigned char *,char *);
extern int	buildarp(char *);
extern int	buildDhcpReply(struct dhcphdr *,int);
extern char *Malloc(int);
extern int	newCfgInfo(void);
extern void showCfgInfo(void);
extern char *addStringOption(char *,char,char *);
extern char *addMemOption(char *,char,char *,int);
extern char *addCharOption(char *,char,char);
extern char *addLongOption(char *,char,long);
extern char *getCfgFileName(char *);
extern int	noCfgFile(void);
extern int	dhcpMsgType(struct dhcphdr *,int);
extern int	loadCfgInfo(int);
extern void ShowLastError(char *);
extern int  HexasciiToBin(char *,char **);
extern DWORD tftpsrvr(void);
