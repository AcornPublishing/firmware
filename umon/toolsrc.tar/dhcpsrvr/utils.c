#define WIN32_LEAN_AND_MEAN

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#include <io.h>
#include <winsock2.h>
#include "dhcpsrvr.h"


int	getopt_sp = 1;
int	optopt, optind = 1;
char	*optarg;

int
getopt(int argc,char *argv[],char *opts)
{
	register int c;
	register char *cp;

	if (getopt_sp == 1) {
		char	c0, c1;

		if (optind >= argc)
			return(EOF);

		c0 = argv[optind][0];
		c1 = argv[optind][1];

		if (c0 != '-')
			return(EOF);
		if (c1 == '\0')
			return(EOF);
		if (c0 == '-') {
			if ((isdigit(c1)) && (!strchr(opts,c1)))
				return(EOF);
			if (c1 == '-') {
				optind++;
				return(EOF);
			}
		}
	}
	optopt = c = argv[optind][getopt_sp];
	if (c == ':' || ((cp=strchr(opts, c)) == NULL)) {
		fprintf(stderr,"Illegal '%s' option: %c.\n",argv[0],c);
		if(argv[optind][++(getopt_sp)] == '\0') {
			optind++;
			getopt_sp = 1;
		}
		return('?');
	}
	if (*++cp == ':') {
		if(argv[optind][getopt_sp+1] != '\0')
			optarg = &argv[optind++][getopt_sp+1];
		else if(++(optind) >= argc) {
			fprintf(stderr,
				"Option '%c' of '%s' requires argument.\n",
				c,argv[0]);
			getopt_sp = 1;
			return('?');
		} else
			optarg = argv[optind++];
		getopt_sp = 1;
	} else {
		if(argv[optind][++(getopt_sp)] == '\0') {
			getopt_sp = 1;
			optind++;
		}
		optarg = NULL;
	}
	return(c);
}

void
getoptinit()
{
	getopt_sp = 1;
	optind = 1;
}

char *
Malloc(size)
int	size;
{
	char	*cptr;

	cptr = (char *)calloc(size,1);
	if (cptr == NULL) {
		perror("malloc");
		exit(1);
	}
	return(cptr);
}

void
Free(ptr)
char	*ptr;
{
	free(ptr);
}

char *
Realloc(base,size)
char	*base;
int	size;
{
	char	*nbase;

	nbase = (char *)realloc(base,size);
	if (nbase == (char *)NULL) {
		perror("realloc");
		exit(1);
	}
	return(nbase);
}

/* isInPath():
   Using the PATH shell variable, return non-zero if file is in one of the
   directories within PATH; else return 0.
*/
int
isInPath(char *fname)
{
	int		ret;
	struct	stat buf;
	char	*path, *eop, *semicolon, *fullpath, *slash;

	path = getenv("PATH");
	if (!path)
		path = ".\\";

	ret = 0;
	eop = path + strlen(path);
	fullpath = Malloc(strlen(path)+strlen(fname)+16);
	while(path < eop) {
		semicolon = strchr(path,';');
		if (semicolon)
			*semicolon = 0;
		if (path[strlen(path)-1] != '\\')
			slash = "\\";
		else
			slash = "";
		sprintf(fullpath,"%s%s%s",path,slash,fname);
		if (semicolon)
			*semicolon = ';';
		if (stat(fullpath,&buf) == 0) {
			if (buf.st_mode & _S_IFREG) {
				ret = 1;
				break;
			}
		}
		if (semicolon)
			path = semicolon+1;
		else
			break;
	}
	Free(fullpath);
	return(ret);
}

/* HexasciiToBin():
	Incoming ascii string is converted to binary.  The size of the new
	string is returned if successful (else -1).  The binary data buffer is
	allocated so it is up to the caller to free the pointer.
*/
int
HexasciiToBin(char *ascii, char **membase)
{
	int	len, i;
	char *mem;

	len = strlen(ascii);
	if (len & 1) {
		fprintf(stderr,"Can't have odd-length hex-ascii string: %s\n",ascii);
		return(-1);
	}
	for(i=0;i<len;i++) {
		if (!isxdigit(ascii[i])) {
			fprintf(stderr,"Illegal digit in hex-ascii string: %c\n",ascii[i]);
			return(-1);
		}
	}
	len /= 2;
	mem = *membase = Malloc(len);
	for(i=0;i<len;i++) {
		char tmp;

		tmp = ascii[2];
		ascii[2] = 0;
		*mem++ = (uchar)strtol(ascii,0,16);
		ascii[2] = tmp;
		ascii += 2;
	}
	return(len);
}

int
IpToBin(ascii,binary)
char	*ascii;
uchar	*binary;
{
	int	i;
	char	*acpy;

	acpy = ascii;
	for(i=3;i>=0;i--) {
		binary[i] = (uchar)strtol(acpy,&acpy,10);
		if ((i != 0) && (*acpy++ != '.')) {
			printf("Misformed IP addr: %s\n",ascii);
			return(-1);
		}
	}
	return(0);
}

EtherToBin(ascii,binary)
char	*ascii;
uchar	*binary;
{
	int	i;
	char	*acpy;

	acpy = ascii;
	for(i=0;i<6;i++) {
		binary[i] = (uchar)strtol(acpy,&acpy,16);
		if ((i != 5) && (*acpy++ != ':')) {
			printf("Misformed ethernet addr: %s\n",ascii);
			return(-1);
		}
	}
	return(0);
}

char *
IpToString(ipadd,ascii)
ulong	ipadd;
char	*ascii;
{
	uchar	*cp;

	cp = (uchar *)&ipadd;
	sprintf(ascii,"%d.%d.%d.%d",
	    (int)cp[3],(int)cp[2],(int)cp[1],(int)cp[0]);
	return(ascii);
}

char *
EtherToString(mac,ascii)
uchar	*mac;
char	*ascii;
{
	sprintf(ascii,"%02x:%02x:%02x:%02x:%02x:%02x",
	    mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
	return(ascii);
}

// noCfgFile():
// Return 1 if config file does not exist; else 0.

noCfgFile(void)
{
	FILE	*fp;

	fp = fopen(configFile,"r");
	if (!fp)
		return(1);
	fclose(fp);
	return(0);
}

// ShowLastError():
// Implementation of a discussion in VC++ documentation for displaying
// the error string that corresponds to the return value of GetLastError().
// A win32 implementation of perror()...
//
void
ShowLastError(char *msg)
{
	LPVOID	lpMessageBuffer;
	int		err;

	err = GetLastError();
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, err, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR) &lpMessageBuffer, 0, NULL);
	if (!msg)
		msg = "";
	fprintf(stderr,"Error:\t %s: %s",msg,lpMessageBuffer);
	LocalFree(lpMessageBuffer);
}

// getCfgFileName(char *):
// Strip off any leading slashes or backslashes.
// Strip off the trailing '.' extension (if one).
// Append ".cfg" to the name.
// Return the modified string in newly allocated memory.
char *
getCfgFileName(char *string)
{
	char	*base, *new, *slash, *dot;

	slash = strrchr(string,'\\');
	if (slash)
		slash = strrchr(slash,'/');
	else
		slash = strrchr(string,'/');

	if (slash)
		base = slash + 1;
	else
		base = string;

	new = Malloc(strlen(base)+8);
	strcpy(new,base);
	dot = strrchr(new,'.');
	if (dot)
		*dot = 0;
	strcat(new,".cfg");
	return(new);
}
