/* DHCPSRVR:
	A basic DHCP server.
	The purpose of this program is to provide a portable (PC-based) alternative
	to the DHCP server currently setup for use by targets using MicroMonitor.
	
    Note: as of my upgrade to VCC 5.0, I had to change 2 things:
	1.	#define WIN32_LEAN_AND_MEAN
	2.	#include <winsock.h> changed to #include <winsock2.h>
*/
#define WIN32_LEAN_AND_MEAN

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#include <io.h>
#include <winsock2.h>
#include "dhcpsrvr.h"
#include "version.h"

#define DEFAULT_ARP_CMD_NAME	"arp"

int		dhcpVerbose, arpCacheCheck, useArpCleanup, BroadcastReply;
int		tftpVerbose, tftpSrvrTimeout;
char	arpCmdName[128];
char	configFile[128];
char	consoleTitle[256];
char	*ServerTitleBar;

char *helpinfo[] = {
 "",
 "DHCP Server...",
 " This program provides a very basic DHCP/BOOTP server for targets that have",
 " been configured to boot from a server. It supports the 'automatic",
 " allocation' mode (see RFC2131) in which the server simply assigns an IP",
 " address that is then assumed to be owned by that client.",
 " The intent of this program is not that it be used as a true DHCP server;",
 " rather, that it provide an alternative to the real DHCP server when",
 " a target is configured to boot from a DHCP server and the real one is",
 " not readily available.",
 "",
 " The server requires a configuration file be established.  A template",
 " config file can be dumped to stdout using the -C option. By default, the",
 " server looks for xxx.cfg (where xxx is the name of this executable) to",
 " use as the config file.  This name can be overridden with the -c option.",
 " When starting up, the server reads in the config file and converts that",
 " data to binary for quick parsing when incoming DHCP requests are received.",
 " The purpose of the config file is to allow the server to uniquely",
 " configure each client based on the client_macaddr field of the incoming",
 " DHCP_DISCOVER request.",
 "",
 " The server can also kick off a TFTP server that the client can use to",
 " retrieve files.  Refer to the -T option.",
 "",
 " The server assumes that the 'arp' command exists on the machine. It",
 " uses the -s and -d options of window's arp.exe to modify entries in",
 " the arp cache.  If your system does not have an arp, then this server",
 " can self-extract one and place it on your system with the name you",
 " specify.  That executable can then be used by this server.",
 " For example:",
 "   Create the arp executable with the name 'myarp.exe'...",
 "      dhcpsrvr -A myarp.exe",
 "   Run the server using that executable...",
 "      dhcpsrvr -a ./myarp.exe",
 " Note that if the executable is created with the name 'arp.exe' and",
 " it is placed in the execution path of the system, then the -a option",
 " isn't necessary.",
 " Note also that because the arp cache is modified, this program must be",
 " run as superuser or administrator.",
 "",
 " When the server is running, and a client makes a DHCP request, the server",
 " will print out the state transitions occurring as the transaction",
 " progresses.  Since the server will try to delete an entry from the host",
 " system's arp cache, there may be an error message...",
 "",
 "                 The specified entry was not found",
 "",
 " in the output.  This can be ignored, it is output from the attempted",
 " arp cache removal indicating that the entry that the server attempted",
 " to delete did not exist.  It should only be seen if the -d option is",
 " used to force the deletion.  Following is typical (non-verbose) output",
 " from the server when a client initiates a DHCP transaction...",
 "",
 "   INCOMING DHCP REQUEST: DHCPDISCOVER (mac = 00:60:1d:02:0b:fe)",
 "   OUTGOING DHCP REPLY  : DHCPOFFER    (mac = 00:60:1d:02:0b:fe)",
 "   INCOMING DHCP REQUEST: DHCPREQUEST  (mac = 00:60:1d:02:0b:fe)",
 "   OUTGOING DHCP REPLY  : DHCPACK      (mac = 00:60:1d:02:0b:fe)",
 "",
 " BOOTP is also supported.  Refer to the output of \"dhcpsrvr -C\" for",
 " details on how to tell the server to treat an incoming request as a",
 " standard BOOTP request instead of a DHCP request.",
 " Following is typical (non-verbose) output from the server when a BOOTP",
 " broadcast request is received by the server...",
 "",
 "   INCOMING BOOTP: (mac = 00:60:1d:02:0b:fe)",
 "   OUTGOING BOOTP: (mac = 00:60:1d:02:0b:fe)",
	0,
};

char *usageinfo[] = {
	" Usage: dhcpsrvr -[A:a:Cc:hq:Tv] [help]",
	"  Options:\n",
	"   -A{arpcmdname}  self-extract and build an arp command for use by",
	"                   this server if not available on system.",
	"   -a{arpcmdname}  use the specified string as the command name",
	"                   replacement for arp.",
	"   -b              reply with IP broadcast (eliminates need for arp).",
	"   -C              dump a config file template to stdout.",
	"   -c{cfgfile}     override the default config file name.",
	"   -D              don't use arp command internally",
	"   -d              don't check for existence of arp entry, just issue",
	"                   the \"arp -d\" regardless.",
	"   -h              dump more help information.",
	"   -qN             quit after 'N' discover/request handshakes.",
	"   -T              start up a TFTP server.",
	"   -V              show version of dhcpsrvr.exe.",
	"   -v              verbose mode.",
	"   -w              don't print warnings of incomplete .cfg entries.",
	0,
};

void
usage(error)
char	*error;
{
	int	i;

	if (error)
		fprintf(stderr,"ERROR: %s\n",error);
	for(i=0;usageinfo[i];i++)
		fprintf(stderr,"%s\n",usageinfo[i]);
	exit(EXIT_ERROR);
}

void
help(void)
{
	int	i;

	for(i=0;helpinfo[i];i++)
		printf("%s\n",helpinfo[i]);
	printf("\n");
	for(i=0;usageinfo[i];i++)
		printf("%s\n",usageinfo[i]);
	exit(EXIT_SUCCESS);
}

// arpCleanup():
//
// 1...
// If arpCacheCheck is set (default), then check to see if the specified
// arp cache entry exists and if it does, delete it.
// If arpCacheCheck is not set, then just issue the deletion regardless of
// whether or not the entry exists (this may generate an error message to
// the user).
//
// 2...
// Add the new entry to the arp cache.

void
arpCleanup(SOCKADDR_IN *ladd, struct	dhcphdr *dhdr)
{
	char	arpcmd[128], arpresp[128], ipstring[32];
	FILE	*fp;

	sprintf(ipstring,"%d.%d.%d.%d",
		(int)(ladd->sin_addr.S_un.S_un_b.s_b1),
		(int)(ladd->sin_addr.S_un.S_un_b.s_b2),
		(int)(ladd->sin_addr.S_un.S_un_b.s_b3),
		(int)(ladd->sin_addr.S_un.S_un_b.s_b4));

	if (arpCacheCheck) {
		sprintf(arpcmd,"%s -a",arpCmdName);
		if (dhcpVerbose)
			printf("Issuing ARP Command: <%s>\n",arpcmd);
		fp = _popen(arpcmd,"r");

		while(fgets(arpresp,sizeof(arpresp),fp)) {
			char	*cp;
	
			cp = arpresp;
			while(isspace(*cp)) cp++;
			if (!isdigit(*cp))
				continue;
			if (!strncmp(cp,ipstring,strlen(ipstring))) {
				sprintf(arpcmd,"%s -d %s",arpCmdName,ipstring);
				if (dhcpVerbose)
					printf("Issuing ARP Command: <%s>\n",arpcmd);
				system(arpcmd);
				break;
			}
		}
		_pclose(fp);
	}
	else {
		sprintf(arpcmd,"%s -d %s",arpCmdName,ipstring);
		if (dhcpVerbose)
			printf("Issuing ARP Command: <%s>\n",arpcmd);
		system(arpcmd);
	}

	/* Add the arp entry... */
	sprintf(arpcmd,"%s -s %s %02x-%02x-%02x-%02x-%02x-%02x",
		arpCmdName,ipstring,
	    dhdr->client_macaddr[0], dhdr->client_macaddr[1],
	    dhdr->client_macaddr[2], dhdr->client_macaddr[3],
	    dhdr->client_macaddr[4], dhdr->client_macaddr[5]);

	if (dhcpVerbose)
		printf("Issuing ARP Command: <%s>\n",arpcmd);
	system(arpcmd);
}

char *cfgTemplate[] = {
 "# Configuration File Template....",
 "# Notes:",
 "# * Each line consists of an ID string followed by a PARAMETER string.",
 "#   ID and PARAMETER must be whitespace delimited.",
 "# * Blank lines are ignored, and lines starting with a '#' are ignored.",
 "# * Specifying a client MAC address of 00:00:00:00:00:00 tells the server",
 "#   to use this as a default.  Note that this should be the last entry in",
 "#   the config file because the server will scan this file from top to",
 "#   bottom searching for a matching CLIENT_MAC entry, if a match is not",
 "#   found by the time this entry is scanned, the default will be used.",
 "# * A complete entry begins with the CLIENT_MAC ID.  The server expects to",
 "#   find all other entries associated with that MAC prior to finding the",
 "#   next CLIENT_MAC ID.",
 "# * The server will respond to BOOTP requests also.  To signify",
 "#   a BOOTP (instead of a DHCP) entry, use BOOTP_CLIENT_MAC instead of.",
 "#   DHCP_CLIENT_MAC.",
 "# * The subnet of the PC that is running this server must be the same",
 "#   subnet that the CLIENT_IP entries are set to.",
 "# * The XXX_OPTNO_NNN entries below demonstrate the fact that the server",
 "#   can be told to load any option with a hex, ascii or IP type of value.",
 "# * The XXX_VSOPTNO_NNN entries below demonstrate the fact that the server",
 "#   can be told to load any vendor-specific option (#43) with a hex, ascii",
 "#   or IP type of value.",
 "",
 "# Valid DHCP entry:",
 "DHCP_CLIENT_MAC:  00:60:1D:02:0B:FE",
 "CLIENT_IP:        135.3.94.136",
 "SERVER_IP:        135.3.94.76",
 "RLYAGNT_IP:       135.3.94.3",
 "GATEWAY:          135.3.94.1",
 "NETMASK:          255.255.255.0",
 "SERVER_NAME:      server_name_here",
 "BOOTFILE:         some_filename_here",
 "STR_OPTNO_131:    some_ascii-string_here",
 "HEX_OPTNO_132:    AABBCCDDEEFF",
 "IPA_OPTNO_133:    4.8.12.16",
 "STR_VSOPTNO_11:   ascii_string",
 "HEX_VSOPTNO_132:  112233",
 "IPA_VSOPTNO_13:   1.2.3.4",
 "#",
 "# Note that in the above example, NETMASK is the same as IPA_OPTNO_1",
 "# and GATEWAY is the same as IPA_OPTNO_3",
 "#",
 "# Valid BOOTP entry:",
 "BOOTP_CLIENT_MAC: 00:60:1D:02:0B:FC",
 "CLIENT_IP:        135.3.94.131",
 "SERVER_IP:        135.3.94.76",
 "RLYAGNT_IP:       135.3.94.1",
 "GATEWAY:          135.3.94.1",
 "NETMASK:          255.255.255.0",
 "SERVER_NAME:      server_name_here_too",
 "BOOTFILE:         some_other_filename_here",
 "",
 "# Default.. ",
 "# Uncomment this entire entry if a default is to be specified.",
 "# It is shown here for example purposes only.",
 "#DHCP_CLIENT_MAC: 00:00:00:00:00:00",
 "#CLIENT_IP:       135.3.94.148",
 "#SERVER_IP:       135.3.94.76",
 "#GATEWAY:         135.3.94.1",
 "#NETMASK:         255.255.255.0",
 "#SERVER_NAME:     servername_again",
 "#BOOTFILE:        yet_another_filename_here",
 0,
};

void
dumpCfgTemplate(void)
{
	int	i;

	for(i=0;cfgTemplate[i];i++)
		printf("%s\n",cfgTemplate[i]);
}

//
// Single threaded server (non-concurrent).
//
dhcpServer(int lastpass)
{
	WSADATA		WsaData;
	SOCKET		sfd;
	SOCKADDR_IN localAddr;
	char		sndmsg[1024], rcvmsg[1024];
	int			err, msglen, i, set, pass;
	struct		dhcphdr *dhdrIn, *dhdrOut;

	err = WSAStartup (0x0101, &WsaData);
	if (err == SOCKET_ERROR) {
		fprintf (stdout, "WSAStartup Failed\n");
		return(-1);
	}

	// Open a socket to listen for incoming connections.
	sfd = socket (AF_INET, SOCK_DGRAM, 0);
	if (sfd == INVALID_SOCKET) {
		fprintf (stdout, "Socket Create Failed\n");
		return(-1);
	}

	// Bind to the DHCP_SERVER port number.
	ZeroMemory (&localAddr, sizeof (localAddr));
	localAddr.sin_port = htons (IPPORT_DHCP_SERVER);
	localAddr.sin_family = AF_INET;

	err = bind (sfd, (PSOCKADDR) & localAddr, sizeof (localAddr));
	if (err == SOCKET_ERROR) {
		fprintf (stderr,"Socket Bind Failed\n");
		if (WSAGetLastError () == WSAEADDRINUSE)
			fprintf (stderr,"The port number may already be in use.\n");
		return(-1);
	}

	// Set options to deal with broadcast...
	set = 1;
	i = setsockopt(sfd,SOL_SOCKET,SO_BROADCAST,(const char *)&set,sizeof(int));
	if (i == SOCKET_ERROR) {
		fprintf(stderr,"Couldn't enable BROADCAST (err %d)\n",
			WSAGetLastError());
	}

	pass = 0;
	dhdrIn = (struct dhcphdr *)rcvmsg;
	dhdrOut = (struct dhcphdr *)sndmsg;

	while(1) {
		int		msgtype, size;

		msglen = sizeof(struct sockaddr);
		size = recvfrom(sfd,rcvmsg,sizeof(rcvmsg),0,
			(struct sockaddr *)&localAddr,&msglen);

		if (size == SOCKET_ERROR) {
			fprintf (stderr,"recvfrom failed (%d)\n",WSAGetLastError());
			continue;
		}

		/* Based on RFC1534 (Interoperation Between DHCP and BOOTP), any	*/
		/* message received by a DHCP server that contains a				*/
		/* 'DHCP_MESSAGETYPE' option is assumed to have been sent by a		*/
		/* DHCP client.  A message without the DHCP_MESSAGETYPE option		*/
		/* is assumed to have been sent by a BOOTP client.					*/
		if (dhcpMsgType(dhdrIn,size) == DHCPDISCOVER)
			msgtype = DHCPOFFER;
		else if (dhcpMsgType(dhdrIn,size) == DHCPREQUEST) {
			msgtype = DHCPACK;
			pass++;
		}
		else
			msgtype = BOOTPREPLY;

		// Build the reply...
		// If buildDhcpReply() returns -1, then there was no MAC address match,
		// so don't respond; just print a brief status message.
		// If buildDhcpReply() returns positive, a match was found, so
		// print some status and issue the response.

		memcpy(sndmsg,rcvmsg,sizeof(rcvmsg));
		size = buildDhcpReply(dhdrOut,msgtype);
		if (size == -1) {
			printDhcp(dhdrIn,"INCOMING",0,msgtype);
			pass--;
			printf("    IGNORED\n");
			continue;
		}

		printDhcp(dhdrIn,"INCOMING",dhcpVerbose,msgtype);

		if (BroadcastReply)
			localAddr.sin_addr.S_un.S_addr = 0xffffffff;
		else
			localAddr.sin_addr.S_un.S_addr = dhdrOut->your_ip;

		if (useArpCleanup) {
			if ((msgtype == DHCPOFFER) || (msgtype == BOOTPREPLY))
				arpCleanup(&localAddr, dhdrIn);
		}
			
		printDhcp(dhdrOut,"OUTGOING",dhcpVerbose,msgtype);

		size = sendto(sfd,sndmsg,size,0,
			(struct sockaddr *)&localAddr,sizeof(struct sockaddr));
		if (size == SOCKET_ERROR) {
			fprintf (stderr,"sendto failed (%d)\n",WSAGetLastError());
			continue;
		}

		if ((lastpass) && (pass >= lastpass)) {
			fprintf(stderr,"Terminating after %d pass%s\n",pass,
				pass > 1 ? "es" : "");
			break;
		}
	}
	return(0);
}

// Ctrl-c handler...

BOOL
ConsCtrlHdlr(DWORD ctrltype)
{
	SetConsoleTitle(consoleTitle);
	return(FALSE);
}

void
showVersion(void)
{
	printf(" Built: %s @ %s\n",BUILDDATE,BUILDTIME);
	exit(1);
}

DWORD
WINAPI
tftpSrvrThread(LPVOID notusedhere)
{
	tftpVerbose = 0;
	tftpSrvrTimeout = 60;

	tftpsrvr();
	return(0);
}

void
main(argc,argv)
int	argc;
char	*argv[];
{
	int		opt, warnings, quitatpass, runtftpsrvr;

	runtftpsrvr = 0;
	quitatpass = 0;
	BroadcastReply = 0;
	warnings = 1;
	arpCacheCheck = 1;
	useArpCleanup = 1;
	strcpy(arpCmdName,DEFAULT_ARP_CMD_NAME);
//	strcpy(configFile,getCfgFileName(argv[0]));
	strcpy(configFile,"dhcpsrvr.cfg");

	while ((opt=getopt(argc,argv,"A:a:bc:CdDhq:TVvw")) != EOF) { 
		switch(opt) {
		case 'A':
			if (buildarp(optarg) < 0)
				exit(EXIT_ERROR);
			exit(EXIT_SUCCESS);
		case 'a':
			strcpy(arpCmdName,optarg);
			break;
		case 'b':
			BroadcastReply = 1;
			break;
		case 'c':
			strcpy(configFile,optarg);
			break;
		case 'C':
			dumpCfgTemplate();
			exit(EXIT_SUCCESS);
		case 'd':
			arpCacheCheck = 0;
			break;
		case 'D':
			useArpCleanup = 0;
			break;
		case 'h':
			help();
			break;
		case 'q':
			quitatpass = atoi(optarg);
			break;
		case 'T':
			runtftpsrvr = 1;
			break;
		case 'V':
			showVersion();
			break;
		case 'v':
			dhcpVerbose = 1;
			break;
		case 'w':
			warnings = 0;
			break;
		default:
			usage("bad option");
		}
	}

	if (argc != optind)
		usage(0);

	if (loadCfgInfo(warnings) <= 0)
		exit(EXIT_ERROR);

	if (dhcpVerbose)
		printf("%d configuration entr%s loaded\n",cfgTotal,
			cfgTotal == 1 ? "y" : "ies");
		
	// Store away the current console title.
	GetConsoleTitle((LPTSTR)consoleTitle,(DWORD)sizeof(consoleTitle));

	// Establish a ctrl-c handler...
	if (SetConsoleCtrlHandler((PHANDLER_ROUTINE)ConsCtrlHdlr,TRUE) != TRUE)
		ShowLastError("Can't establish ctrl-c handler\n");

	// If runtftpsrvr is set, then kick off a thread that runs the TFTP 
	// server that is part of the ttftp command...  This is provided in 
	// dhcpsrvr just as a convenience.
	if (runtftpsrvr) {
		DWORD	tid;
		HANDLE hdlTftpSrvr;

		ServerTitleBar = "DHCP/TFTP SERVER";
		printf("DHCP/BOOTP/TFTP SERVER Running\n");
		hdlTftpSrvr = CreateThread(NULL,0,tftpSrvrThread,
			(LPVOID)0,CREATE_SUSPENDED,&tid);
		if (!hdlTftpSrvr) {
			ShowLastError("CreatThread()");
			return;
		}
		ResumeThread(hdlTftpSrvr);
	}
	else {
		ServerTitleBar = "DHCP SERVER";
		printf("DHCP/BOOTP SERVER Running\n");
	}
	SetConsoleTitle(ServerTitleBar);

	// Run the server...
	dhcpServer(quitatpass);

	// Restore the original console title.
	SetConsoleTitle(consoleTitle);

	exit(EXIT_SUCCESS);
}

