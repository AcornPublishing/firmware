#define WIN32_LEAN_AND_MEAN

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#include <io.h>
#include <winsock2.h>
#include "dhcpsrvr.h"

struct	dhcpbootphdr *cfgInMemory = (struct dhcpbootphdr *)0;
int		cfgTotal = 0;

char *
DHCPop(op)
int	op;
{
	switch(op) {
	case DHCPBOOTP_REQUEST:
		return("REQUEST");
	case DHCPBOOTP_REPLY:
		return("REPLY  ");
	default:
		return("  ???  ");
	}
}

char *
DHCPopt(op)
int	op;
{
	switch(op) {
	case DHCPDISCOVER:
		return("DISCOVER");
	case DHCPOFFER:
		return("OFFER   ");
	case DHCPREQUEST:
		return("REQUEST ");
	case DHCPDECLINE:
		return("DECLINE ");
	case DHCPACK:
		return("ACK     ");
	case DHCPNACK:
		return("NACK    ");
	case DHCPRELEASE:
		return("RELEASE ");
	default:
		return("???");

	}
}

int
dhcpMsgType(struct dhcphdr *d,int size)
{
	uchar	*options, *endofpacket;

	endofpacket = (uchar *)d + size;
	options = (uchar *)(d+1);

	while ((*options != 0xff) && (options < endofpacket)) {
		int	opt, optlen;

		opt = (int)*options++;
		if (opt == 0)	/* padding */
			continue;
		optlen = (int)*options++;
		if (opt == DHCPOPT_MESSAGETYPE)
			return((int)*options);
		else
			options += optlen;
	}
	return(DHCPUNKNOWN);
}

/* printDhcp():
   Try to format the DHCP stuff...
*/
void
printDhcp(struct dhcphdr *d,char *direction,int verbose,int msgtype)
{
	uchar	*options;
	int		safety;

	safety = 0;
	options = (uchar *)(d+1);

	if (msgtype == BOOTPREPLY)
		printf("%s BOOTP: ",direction);
	else
		printf("%s DHCP %s: ",direction,DHCPop(d->op));
	if (!verbose) {
		if (msgtype != BOOTPREPLY) {
			while(*options != 0xff) {
				unsigned	int	opt, optlen;
	
				if (safety++ > MAXOPTSIZE) {
					printf("Aborting, overflow likely.\n");
					break;
				}
				opt = (unsigned int)*options++;
				if (opt == 0)	/* padding */
					continue;
				optlen = (unsigned int)*options++;

				if (opt==DHCPOPT_MESSAGETYPE)
					printf("DHCP%s",DHCPopt(*options));
				options += optlen;
			}
		}
		printf(" (mac = %02x:%02x:%02x:%02x:%02x:%02x",
		    d->client_macaddr[0], d->client_macaddr[1],
		    d->client_macaddr[2], d->client_macaddr[3],
		    d->client_macaddr[4], d->client_macaddr[5]);
		if (!strcmp(direction,"OUTGOING")) {
			printf(", ip = %d.%d.%d.%d",
				(d->your_ip & 0xff),
			    (d->your_ip & 0xff00) >> 8,
			    (d->your_ip & 0xff0000) >> 16,
			    (d->your_ip & 0xff000000) >> 24);
		}
		printf(")\n");
		return;
	}

	printf("\n");
	printf("    client_macaddr = %02x:%02x:%02x:%02x:%02x:%02x\n",
	    d->client_macaddr[0], d->client_macaddr[1],
	    d->client_macaddr[2], d->client_macaddr[3],
	    d->client_macaddr[4], d->client_macaddr[5]);

	printf("    htype = %d, hlen = %d, hops = %d\n",
	    d->htype,d->hlen,d->hops);
	printf("    xid = 0x%x\n",ntohl(d->transaction_id));
	printf("    seconds = %d, flags = 0x%x\n",
		ntohs(d->seconds),ntohs(d->flags));
	printf("    client_ip = %d.%d.%d.%d\n",
		(d->client_ip & 0xff),
	    (d->client_ip & 0xff00) >> 8,
	    (d->client_ip & 0xff0000) >> 16,
	    (d->client_ip & 0xff000000) >> 24);
	printf("    your_ip =   %d.%d.%d.%d\n",
		(d->your_ip & 0xff),
	    (d->your_ip & 0xff00) >> 8,
	    (d->your_ip & 0xff0000) >> 16,
	    (d->your_ip & 0xff000000) >> 24);
	printf("    server_ip = %d.%d.%d.%d\n",
		(d->server_ip & 0xff),
	    (d->server_ip & 0xff00) >> 8,
	    (d->server_ip & 0xff0000) >> 16,
	    (d->server_ip & 0xff000000) >> 24);
	printf("    router_ip = %d.%d.%d.%d\n",
		(d->router_ip & 0xff),
	    (d->router_ip & 0xff00) >> 8,
	    (d->router_ip & 0xff0000) >> 16,
	    (d->router_ip & 0xff000000) >> 24);
	if (d->bootfile[0])
		printf("    bootfile: %s\n", d->bootfile);
	if (d->server_hostname[0])
		printf("    server_hostname: %s\n", d->server_hostname);

	if (msgtype == BOOTPREPLY)
		return;

	while(*options != 0xff) {
		int	i, opt, optlen;

		if (safety++ > MAXOPTSIZE) {
			printf("Aborting, overflow likely\n");
			break;
		}
		opt = (int)*options++;
		if (opt == 0)	/* padding */
			continue;
		printf("    option %3d: ",opt);
		optlen = (int)*options++;
		if (opt==DHCPOPT_MESSAGETYPE) {
			printf("DHCP%s",DHCPopt(*options++));
		}
		/* Vendor specific information: */
		/* Note that the data within this option is vendor specific. */
		/* The RFC2132 says that the encapsulated data with this option */
		/* SHOULD follow the same format as the outer-layer options, but */
		/* is not mandatory. */
		else if (opt==DHCPOPT_VENDORSPECIFICINFO) {
			int	vsopt, vsoptlen;
			printf("\n");
			while(*options != 0xff) {
				vsopt = (int)*options++;
				vsoptlen = (int)*options++;
				printf("       vso %3d: 0x",vsopt);
				for(i=0;i<vsoptlen;i++)
					printf("%02x",*options++);
				if (*options != 0xff)
					printf("\n");
			}
			options++;	/* Skip over the 0xff in this option sub-set. */
		}
		else if ((opt < DHCPOPT_HOSTNAME) ||
		    (opt == DHCPOPT_BROADCASTADDRESS) ||
		    (opt == DHCPOPT_REQUESTEDIP) ||
		    (opt == DHCPOPT_SERVERID) ||
		    (opt == DHCPOPT_NISSERVER)) {
			for(i=0;i<optlen;i++)
				printf("%d ",*options++);
		}
		else if ((opt == DHCPOPT_NISDOMAINNAME) ||
		    (opt == DHCPOPT_VCID)) {
			for(i=0;i<optlen;i++)
				printf("%c",*options++);
		}
		else {
			printf("0x");
			for(i=0;i<optlen;i++)
				printf("%02x",*options++);
		}
		printf("\n");
	}
}

/* buildDhcpReply():
	Not much to do here.  Most of the work is already done by loadCfgInfo()
	below...  See if the client's mac address matches one of the mac addresses
	in the configuration in memory.  If yes, process it; else just return.
*/
int
buildDhcpReply(struct dhcphdr *dhdr,int msgtype)
{
	int		i;
	char	def[6];
	uchar	*options, *optbase;
	struct	dhcpbootphdr *rp;

	rp = (struct dhcpbootphdr *)cfgInMemory;

	// Scan through the .cfg file looking for a MAC address match or
	// a MAC address of 0:0:0:0:0:0 to use as the default.
	memset(def,0,6);
	for (i=0;i<cfgTotal;i++) {
		if (!memcmp(rp->client_macaddr,dhdr->client_macaddr,6)) {
			if ((rp->hdrtype == CLIENT_IS_BOOTP) && (msgtype != BOOTPREPLY)) {
				fprintf(stderr,"Received DHCP request, but .cfg is BOOTP\n");
				return(-1);
			}
			if ((rp->hdrtype == CLIENT_IS_DHCP) && (msgtype == BOOTPREPLY)) {
				fprintf(stderr,"Received BOOTP request, but .cfg is DHCP\n");
				return(-1);
			}
			break;
		}
		if (!memcmp(rp->client_macaddr,def,6)) {
			if ((msgtype == DHCPACK) || (msgtype == BOOTPREPLY))
				printf("Using default configuration.\n");
			break;
		}
		rp++;
	}

	if (i == cfgTotal) {
		fprintf(stderr,"No MAC address match found in .cfg file\n");
		return(-1);
	}

	dhdr->op  = DHCPBOOTP_REPLY;
	dhdr->your_ip = htonl(rp->your_ip);
	dhdr->server_ip = htonl(rp->server_ip);
	dhdr->magic_cookie = htonl(DEFAULT_MAGIC_COOKIE);
	strcpy(dhdr->bootfile,rp->bootfile);
	strcpy(dhdr->server_hostname,rp->server_hostname);

	/* Copy the options list built by loadCfgInfo() earlier... */
	options = optbase = (char *)(dhdr + 1);
	memcpy(options,rp->vsa_or_opts,rp->optlistsize);

	if (rp->hdrtype == CLIENT_IS_BOOTP)
		return(sizeof(struct bootphdr));
	else {
		/* Append the DHCP message type to the options list... */
		options += rp->optlistsize;
		options--;						/* 	remove the final 0xff */
		options = addCharOption(options,DHCPOPT_MESSAGETYPE,(char)msgtype);
		*options++ = 0xff;
		return(sizeof(struct dhcphdr) + (options-optbase));
	}
}

char *
addCharOption(char *options,char optno,char charopt)
{
	*options++ = optno;
	*options++ = (char)1;
	*options++ = charopt;
	return(options);
}

char *
addLongOption(char *options,char optno,long longopt)
{
	*options++ = optno;
	*options++ = (char)4;
	memcpy(options,(char *)&longopt,4);
	return(options+4);
}

char *
addStringOption(char *options,char optno,char *string)
{
	*options++ = optno;
	*options++ = (char)(strlen(string) + 1);
	while(*string)
		*options++ = *string++;
	*options++ = 0;
	return(options);
}

char *
addMemOption(char *options,char optno,char *mem,int size)
{
	int	i;

	*options++ = optno;
	*options++ = (char)size;
	for(i=0;i<size;i++)
		*options++ = *mem++;
	return(options);
}

// loadCfgInfo():
// This function parses the config file for the configuration information
// per MAC address.  Each configuration is stored in a dhcpbootphdr
// structure and saved in memory for use by buildDhcpReply() when a 
// DHCPREQUEST message is received.
//
// Upon completion of this function, the pointer cfgInMemory points to
// the base of a block of memory that can be assumed to be a table of
// dhcpbootphdr structures.
int
loadCfgInfo(int warnings)
{
	FILE	*fp;
	char	*options;
	struct	dhcpbootphdr *reply;
	char	line[512], linecopy[512];
	char	*colon, *eol, *lp, *end, *id, *vsoptptr, vsoptlist[1024];
	int		cfgsize, retval, tot, firstentry;

	fp = fopen(configFile,"r");
	if (!fp) {
		fprintf(stderr,"Config file '%s' not found.\n",configFile);
		return(-1);
	}

	// First pass through the file to find each instance of
	// "BOOTP_CLIENT_MAC" or "DHCP_CLIENT_MAC".
	// This tells us how much space to allocate for all of the dhcphdr
	// storage in memory.
	cfgTotal = 0;
	while(fgets(line,sizeof(line),fp)) {
		if ((!strncmp(line,"BOOTP_CLIENT_MAC:",17)) ||
			(!strncmp(line,"DHCP_CLIENT_MAC:",16)))
			cfgTotal++;
	}
	cfgsize = (cfgTotal * sizeof(struct dhcpbootphdr));
	cfgInMemory = (struct dhcpbootphdr *)Malloc(cfgsize);
	memset(cfgInMemory,0,cfgsize);
	rewind(fp);

	retval = cfgTotal;
	reply = cfgInMemory;
	firstentry = 1;
	vsoptptr = vsoptlist;
	while (fgets(line,sizeof(line),fp)) {

		if (line[0] == '#')			// Ignore line if it begins with '#'.
			continue;

		eol = strpbrk(line,"\r\n");	// Remove CR and/or LF if present.
		if (eol)
			*eol = 0;

		strcpy(linecopy,line);		// Keep a copy of original line for use
									// with error messages.

		lp = line;					// Skip over initial whitespace.
		while(isspace(*lp))
			lp++;
		if (*lp == 0)				// Ignore line if only whitespace.
			continue;

		//
		// Each line is made up of an ID field followed by a argument field.
		// For example:
		//
		// BOOTP_CLIENT_MAC:	00:60:1d:02:0b:fe 
		//
		// The ID is BOOTP_CLIENT_MAC and the argument is 00:60:1d:02:0b:fe 
		// At this point, lp should be pointing to the start of the ID field
		// that is terminated by a colon...

		colon = strchr(lp,':');
		if (!colon) {
			fprintf(stderr,"Error1 in '%s' file at: %s\n",configFile,linecopy);
			retval = -1;
			break;
		}
		*colon = 0;
		id = lp;
		lp = colon+1;
		while(isspace(*lp))
			lp++;
		if (*lp == 0) {
			fprintf(stderr,"Error2 in '%s' file at: %s\n",configFile,linecopy);
			retval = -1;
			break;
		}
		end = lp;
		while(1) {
			if ((*end == '\r') || (*end == '\n') || (*end == 0))
				break;
			end++;
		}
		*end = 0;

		// At this point, id is pointing to the ID field and lp is pointing
		// to the parameter field of the line.  It can be assumed that the
		// ID field has the colon replaced with null and the parameter field
		// is null terminated.

		if ((!strcmp("BOOTP_CLIENT_MAC",id)) ||
			(!strcmp("DHCP_CLIENT_MAC",id))) {
			if (firstentry)
				firstentry = 0;
			else {
				if (vsoptptr != vsoptlist) {
					*vsoptptr++ = (char)0xff;
					options = addMemOption(options,
						(char)DHCPOPT_VENDORSPECIFICINFO,
						vsoptlist,vsoptptr-vsoptlist);
					vsoptptr = vsoptlist;
				}

				/* Terminate the previous option list: */
				if (options == reply->vsa_or_opts)
					reply->optlistsize = 0;
				else {
					*options++ = (char)0xff;
					reply->optlistsize = options - reply->vsa_or_opts;
					if ((reply->hdrtype == CLIENT_IS_BOOTP) &&
						(reply->optlistsize > 60)) {
						fprintf(stderr,"Opt-list too big for BOOTP VSA[]\n");
						retval = -1;
						break;
					}
				}
				reply++;
			}

			/* Begin the next options list: */
			options = reply->vsa_or_opts;

			if (EtherToBin(lp,(uchar *)&reply->client_macaddr) == -1) {
				retval = -1;
				break;
			}
		}

		if (!strcmp("BOOTP_CLIENT_MAC",id)) {
			reply->hdrtype = CLIENT_IS_BOOTP;
		}
		else if (!strcmp("DHCP_CLIENT_MAC",id)) {
			reply->hdrtype = CLIENT_IS_DHCP;
		}
		else if (!strcmp("CLIENT_MAC",id)) {
			fprintf(stderr,"Old-style paramter (%s) no longer supported\n",id);
			retval = -1;
			break;
		}
		else if (!strcmp("CLIENT_IP",id)) {
			if (IpToBin(lp,(uchar *)&reply->your_ip) == -1) {
				retval = -1;
				break;
			}
		}
		else if (!strcmp("SERVER_IP",id)) {
			if (IpToBin(lp,(uchar *)&reply->server_ip) == -1) {
				retval = -1;
				break;
			}
		}
		else if (!strcmp("RLYAGNT_IP",id)) {
			if (IpToBin(lp,(uchar *)&reply->router_ip) == -1) {
				retval = -1;
				break;
			}
		}
		else if (!strcmp("SERVER_NAME",id)) {
			if (strlen(lp) >= 64) {
				fprintf(stderr,"Field too big: %s\n",lp);
				retval = -1;
				break;
			}
			strcpy(reply->server_hostname,lp);
		}
		else if (!strcmp("BOOTFILE",id)) {
			if (strlen(lp) >= 128) {
				fprintf(stderr,"Field too big: %s\n",lp);
				retval = -1;
				break;
			}
			strcpy(reply->bootfile,lp);
		}
		else if (!strcmp("NETMASK",id)) {		/* Same as IPA_OPTNO_1 */
			ulong	ip;

			if (IpToBin(lp,(uchar *)&ip) == -1) {
				retval = -1;
				break;
			}
			options = addLongOption(options,DHCPOPT_SUBNETMASK,htonl(ip));
		}
		else if (!strcmp("GATEWAY",id)) {	/* Same as IPA_OPTNO_3 */
			ulong	ip;

			if (IpToBin(lp,(uchar *)&ip) == -1) {
				retval = -1;
				break;
			}
			options = addLongOption(options,DHCPOPT_ROUTER,htonl(ip));
		}
		else if ((!strncmp("IPA_VSOPTNO_",id,12)) ||
				 (!strncmp("STR_VSOPTNO_",id,12)) ||
				 (!strncmp("HEX_VSOPTNO_",id,12))) {
			int	optno;

			optno = atoi(id+12);
			if (optno < 1 || optno > 254) {
				fprintf(stderr,"Option #%d out of range\n");
				retval = -1;
				break;
			}
			if (id[0] == 'I') {
				ulong	ip;

				if (IpToBin(lp,(uchar *)&ip) == -1) {
					retval = -1;
					break;
				}
				vsoptptr = addLongOption(vsoptptr,(char)optno,htonl(ip));
			}
			else if (id[0] == 'H') {
				int	size;
				char *mem;

				size = HexasciiToBin(lp,&mem);
				if (size == -1) {
					retval = -1;
					break;
				}
				vsoptptr = addMemOption(vsoptptr,(char)optno,mem,size);
			}
			else {
				vsoptptr = addStringOption(vsoptptr,(char)optno,lp);
			}
		}
		else if ((!strncmp("IPA_OPTNO_",id,10)) ||
				 (!strncmp("STR_OPTNO_",id,10)) ||
				 (!strncmp("HEX_OPTNO_",id,10))) {
			int	optno;

			optno = atoi(id+10);
			if (optno < 1 || optno > 254) {
				fprintf(stderr,"Option #%d out of range\n");
				retval = -1;
				break;
			}
			if (id[0] == 'I') {
				ulong	ip;

				if (IpToBin(lp,(uchar *)&ip) == -1) {
					retval = -1;
					break;
				}
				options = addLongOption(options,(char)optno,htonl(ip));
			}
			else if (id[0] == 'H') {
				int	size;
				char *mem;

				size = HexasciiToBin(lp,&mem);
				if (size == -1) {
					retval = -1;
					break;
				}
				options = addMemOption(options,(char)optno,mem,size);
			}
			else {
				options = addStringOption(options,(char)optno,lp);
			}
		}
		else {
			fprintf(stderr,"Unrecognized parameter name: %s\n",linecopy);
			retval = -1;
			break;
		}
	}
	fclose(fp);
	if (retval != -1) {
		if (vsoptptr != vsoptlist) {
			*vsoptptr++ = (char)0xff;
			options = addMemOption(options,
				(char)DHCPOPT_VENDORSPECIFICINFO,vsoptlist,vsoptptr-vsoptlist);
		}
		if (options != reply->vsa_or_opts) {
			*options++ = (char)0xff;
			reply->optlistsize = options - reply->vsa_or_opts;
		}
	}
	else {
		fprintf(stderr,"Config file error.\n");
		return(-1);
	}


	// As a final check, verify that there are no duplicate CLIENT_MAC fields:
	tot = 0;
	while(tot < cfgTotal) {
		int	i;
		for(i=tot+1;i<cfgTotal;i++) {
			if (!memcmp(cfgInMemory[tot].client_macaddr,
				cfgInMemory[i].client_macaddr,6)) {
				fprintf(stderr,
					"Duplicate CLIENT_MAC entries (#%d & #%d) in cfg file.\n",
					tot+1,i+1);
				retval = -1;
				break;
			}
		}
		tot++;
	}
	return(retval);
}
