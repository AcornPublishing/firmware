extern char *Malloc(int);
extern void Free(char *);
extern char *Realloc(char *,int);
extern int getopt(int,char **,char *);
extern void ShowLastError(char *);
extern void Die(char *);

extern int	getopt_sp, optopt, optind;
extern char	*optarg;

