#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wtypes.h>
#include <ctype.h>
#include <io.h>
#include <conio.h>
#include <fcntl.h>
#include <errno.h>
#include <setjmp.h>
#include <stdarg.h>
#include <direct.h>
#include <fcntl.h>
#include <math.h>
#include <malloc.h>
#include <process.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <mapiwin.h>
#include <wincon.h>
#include <winsock.h>
#include <tlhelp32.h>
#include "info.h"
#include "utils.h"
#include "comport.h"

#define PROTOCOL_CAT		0
#define PROTOCOL_XMODEM		1

static int	verbose, ctrlcCount;
static HANDLE comHandle;
static char *progName;
extern int Xsend(char *,HANDLE);
extern int Fsend(char *,HANDLE);

int
getIntCount()
{
	return(ctrlcCount);
}

BOOL
ConsCtrlHdlr(DWORD ctrltype)
{
	switch(ctrltype) {
	case CTRL_CLOSE_EVENT:
	case CTRL_LOGOFF_EVENT:
	case CTRL_SHUTDOWN_EVENT:
		Die("Shutdown/Close/Logoff Event");
		return(FALSE);
	case CTRL_BREAK_EVENT:
	case CTRL_C_EVENT:
		ctrlcCount++;
		return(TRUE);
	default:
		fprintf(stderr,"Unexpected Console Ctrl type: %ld\n",ctrltype);
		return(TRUE);
	}
}

void
usage()
{
	fprintf(stderr,"Usage: %s -[b:p:V]\n",progName);
	fprintf(stderr," Options:\n");
	fprintf(stderr," -b{baud}  default = 9600\n");
	fprintf(stderr," -f{fname} name of file to transfer\n");
	fprintf(stderr," -i{lvl}   display incoming \"invisible\" chars\n");
	fprintf(stderr,"           lvl=1 invisible-to-hex\n");
	fprintf(stderr,"           lvl=2 invisible-to-hex + space-to-underscore\n");
	fprintf(stderr," -p{port}  default = 1\n");
	fprintf(stderr," -c{cmd}   command sent to target, prior to file xfer\n");
	fprintf(stderr," -x        use XMODEM for file transfer\n");
	fprintf(stderr," -V        show version\n");
	fprintf(stderr,"\n");
	fprintf(stderr,"Note:\n");
	fprintf(stderr," When com is active, ctrl-x will initiate a file\n");
	fprintf(stderr," transfer to the target.  The -f and -c options allow\n");
	fprintf(stderr," that transfer to be automated.  If not specified on\n");
	fprintf(stderr," the command line, then it is assumed that the user\n");
	fprintf(stderr," put the target into the file recieve mode and must\n");
	fprintf(stderr," also specify the file to be transferred.\n");
	fprintf(stderr,"Note1:\n");
	fprintf(stderr," The -i option will process all incoming characters\n");
	fprintf(stderr," that are not clearly visible to the reader and\n");
	fprintf(stderr," prints them as hex-coded-ascii enclosed within\n");
	fprintf(stderr," square brackets.  If the character is CR or LF, it\n");
	fprintf(stderr," will also generate the appropriate CR/LF so that\n");
	fprintf(stderr," the output stays somewhat sane.\n");
	fprintf(stderr," The -i is an additive option...\n");
	fprintf(stderr,"  Level 1 (-i1) prints as described above.\n");
	fprintf(stderr,"  Level 2 (-i2) also replaces space with underscore.\n");
	fprintf(stderr,"  Level 3 (-i3) replaces non-printables, but does not \n");
	fprintf(stderr,"   try to cleanup CR/LF stuff.\n");
}

void
main(int argc,char *argv[])
{
	char	dld_file[256], pre_cmd[256], *from, *to;
	DWORD	ocmode;
	HANDLE	stdinhdl;
	int		opt, baud, port, showinvisible, protocol;

	// Defaults:
	port = 1;
	baud = 9600;
	verbose = 0;
	progName = argv[0];
	memset(pre_cmd,0,sizeof(pre_cmd));
	memset(dld_file,0,sizeof(dld_file));

	ctrlcCount = 0;
	showinvisible = 0;
	protocol = PROTOCOL_CAT;

	while ((opt=getopt(argc,argv,"c:b:f:i:p:Vx")) != EOF) { 
		switch(opt) {
		case 'b':
			baud = atoi(optarg);
			break;
		case 'c':
			to = pre_cmd;
			from = optarg;
			while(*from) {
				if (*from == '\\') {
					if (*(from+1) == 'r') {
						*to++ = '\r';		
						from++;
						continue;
					}
					else if (*(from+1) == 'n') {
						*to++ = '\n';		
						*from++;
						continue;
					}
				}
				*to++ = *from++;
			}
			*to = 0;
			break;
		case 'f':
			strcpy(dld_file,optarg);
			break;
		case 'i':
			showinvisible = atoi(optarg);
			break;
		case 'p':
			port = atoi(optarg);
			break;
		case 'x':
			protocol = PROTOCOL_XMODEM;
			break;
		case 'V':
			printf("Built: %s %s\n",BUILDDATE,BUILDTIME);
			exit(0);
		default:
			usage();
			exit(1);
		}
	}
	if (argc != optind) {
		usage();
		exit(1);
	}

	if (SetConsoleCtrlHandler((PHANDLER_ROUTINE)ConsCtrlHdlr,TRUE) != TRUE) {
		ShowLastError("Can't establish ctrl-c restart handler");
		exit(1);
	}

	// Call comInit() just to initialize the com stuff...
	comInit();

	// Open the com port
	comHandle = comOpen(port,baud);
	if (comHandle == INVALID_HANDLE_VALUE)
		exit(1);

	comIoctl(COMIOCTL_SHOWINVISIBLE,(void *)showinvisible,0);

	// Startup a reader thread...
	if (!comRdrThreadCreate(comHandle))
		exit(1);

	stdinhdl = GetStdHandle(STD_INPUT_HANDLE);
	GetConsoleMode(stdinhdl,&ocmode);
	SetConsoleMode(stdinhdl,ENABLE_PROCESSED_INPUT);

	fprintf(stderr,"Direct connect to COM%d at %d baud\n",port,baud);
	fprintf(stderr,"Hit ctrl-c to terminate.\n");
	while(!getIntCount()) {
		char	c;
		DWORD	bytesread;

#if 0
		if (ReadFile(stdinhdl,&c,(DWORD)1,&bytesread,NULL) != TRUE) {
			ShowLastError("comDirectConnect ReadFile(2)");
			break;
		}
#else
		c = getch();
		if (c == 0x03)
			break;
#endif
		if (bytesread == 1) {
			/* Send file using xmodem */
			if (c == 24) {	/* ctrl-x */

				// If the dld_file[] array is empty, then the user must specify
				// the file to be transferred...
				if (!dld_file[0]) {
					fprintf(stderr,"File: ");
					SetConsoleMode(stdinhdl,ocmode);
					fgets(dld_file,sizeof(dld_file)-1,stdin);
					SetConsoleMode(stdinhdl,ENABLE_PROCESSED_INPUT);
					dld_file[strlen(dld_file)-1] = 0;
				}

				// Stop the reader and send the file.  Also, if
				// the pre_cmd[] array is non-empty, then send it as
				// the command to kick off the xmoded transfer on the
				// the target.
				stopComReader();
				if (pre_cmd[0]) {
					comWrite(comHandle,pre_cmd,strlen(pre_cmd));
					comRead(comHandle,pre_cmd,strlen(pre_cmd));
				}
				if (protocol == PROTOCOL_XMODEM) {
					Xsend(dld_file,comHandle);
				}
				else {
					Fsend(dld_file,comHandle);
				}
				resumeComReader();
			}
			else
				comWrite(comHandle,&c,1);
		}
	}
	SetConsoleMode(stdinhdl,ocmode);
	comRdrThreadKill();
	comClose(comHandle);
}
