#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wtypes.h>
#include <ctype.h>
#include <io.h>
#include <conio.h>
#include <fcntl.h>
#include <errno.h>
#include <setjmp.h>
#include <stdarg.h>
#include <direct.h>
#include <fcntl.h>
#include <math.h>
#include <malloc.h>
#include <process.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <mapiwin.h>
#include <wincon.h>
#include <winsock.h>
#include <tlhelp32.h>

void
Die(char *msg)
{
	fprintf(stderr,"Process voluntarily terminating: %s\n",msg);
	perror("Die");
	exit(1);
}

char *
Malloc(int size)
{
	char	*cp;

	cp = malloc(size);
	if (!cp) {
		perror("mem alloc failed");
		exit(1);
	}
	memset(cp,0,size);
	return(cp);
}

void
Free(char *ptr)
{
	free(ptr);
}

char *
Realloc(char *base,int size)
{
	char	*nbase;

	nbase = (char *)realloc(base,size);
	if (nbase == (char *)NULL)
		Die("realloc");
	return(nbase);
}

int	getopt_sp = 1;
int	optopt, optind = 1;
char	*optarg;

int
getopt(int argc,char *argv[],char *opts)
{
	register int c;
	register char *cp;

	if (getopt_sp == 1) {
		char	c0, c1;

		if (optind >= argc)
			return(EOF);

		c0 = argv[optind][0];
		c1 = argv[optind][1];

		if (c0 != '-')
			return(EOF);
		if (c1 == '\0')
			return(EOF);
		if (c0 == '-') {
			if ((isdigit(c1)) && (!strchr(opts,c1)))
				return(EOF);
			if (c1 == '-') {
				optind++;
				return(EOF);
			}
		}
	}
	optopt = c = argv[optind][getopt_sp];
	if (c == ':' || ((cp=strchr(opts, c)) == NULL)) {
		fprintf(stderr,"Illegal '%s' option: %c.\n",argv[0],c);
		if(argv[optind][++(getopt_sp)] == '\0') {
			optind++;
			getopt_sp = 1;
		}
		return('?');
	}
	if (*++cp == ':') {
		if(argv[optind][getopt_sp+1] != '\0')
			optarg = &argv[optind++][getopt_sp+1];
		else if(++(optind) >= argc) {
			fprintf(stderr,
				"Option '%c' of '%s' requires argument.\n",
				c,argv[0]);
			getopt_sp = 1;
			return('?');
		} else
			optarg = argv[optind++];
		getopt_sp = 1;
	} else {
		if(argv[optind][++(getopt_sp)] == '\0') {
			getopt_sp = 1;
			optind++;
		}
		optarg = NULL;
	}
	return(c);
}

// ShowLastError():
// Implementation of a discussion in VC++ documentation for displaying
// the error string that corresponds to the return value of GetLastError().
// A win32 implementation of perror()...
//
void
ShowLastError(char *msg)
{
	LPVOID	lpMessageBuffer;
	int		err;

	err = GetLastError();
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, err, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR) &lpMessageBuffer, 0, NULL);
	if (!msg)
		msg = "";
	fprintf(stderr,"\nERROR: %s: %s", msg,lpMessageBuffer);
	LocalFree(lpMessageBuffer);
}

//
// getverbose():
