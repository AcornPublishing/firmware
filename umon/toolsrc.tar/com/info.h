#define BUILDDATE "Nov 09, 2001"
#define BUILDTIME "09:42"
