//
// comport.c:
// Functions useful for comport interfacing in WIN95/98/NT...
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wtypes.h>
#include <ctype.h>
#include <io.h>
#include <conio.h>
#include <fcntl.h>
#include <errno.h>
#include <setjmp.h>
#include <stdarg.h>
#include <direct.h>
#include <fcntl.h>
#include <math.h>
#include <malloc.h>
#include <process.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <mapiwin.h>
#include <wincon.h>
#include <winsock.h>
#include <tlhelp32.h>
#include "utils.h"
#include "comport.h"

extern	int getIntCount();
int		rdrOffRqst, rdrOffRqstAck;
int		showInvisible;
HANDLE	hComRdr;

void
comInit(void)
{
	showInvisible = 0;
	rdrOffRqst = rdrOffRqstAck = 0;
	hComRdr = (HANDLE)NULL;
}

HANDLE
comOpen(int portnum, int baud)
{
	DCB dcb;
	HANDLE hCom;
	char portname[16];

	sprintf(portname,"COM%d",portnum);
	hCom = CreateFile(portname,
		GENERIC_READ | GENERIC_WRITE,		// Open for read/write.
		0,									// Sharing flags.
		NULL,								// Security attributes.
		OPEN_EXISTING,						// Required for serial port.
		0,									// File attributes (NA).
		NULL);								// Required for serial port.
	if (hCom == INVALID_HANDLE_VALUE) {
		ShowLastError("comOpen() CreatFile()");
		return(INVALID_HANDLE_VALUE);
	}

	// Fill in the DCB...
	if (!GetCommState(hCom,&dcb)) {
		ShowLastError("comOpen() GetCommState()");
		return(INVALID_HANDLE_VALUE);
	}
	dcb.BaudRate = baud;
	dcb.ByteSize = 8;
	dcb.Parity = NOPARITY;
	dcb.StopBits = ONESTOPBIT;
	dcb.fDtrControl = DTR_CONTROL_ENABLE;
	dcb.fDsrSensitivity = FALSE;
	dcb.fOutX = FALSE;
	dcb.fInX = FALSE;
	dcb.fNull = FALSE;
	if (!SetCommState(hCom,&dcb)) {
		ShowLastError("comOpen() SetCommState()");
		return(INVALID_HANDLE_VALUE);
	}

	return(hCom);
}

void
comShow(HANDLE hCom)
{
	DCB dcb;

	// Get the current configuration.
	if (GetCommState(hCom, &dcb)) {
		printf("Baudrate: %d\n",dcb.BaudRate);
		printf("ByteSize: %d\n",dcb.ByteSize);
	}
}

void
comClose(HANDLE hCom)
{
	CloseHandle(hCom);
}

int
comFlush(HANDLE hCom)
{
	DWORD	bytesread;
	DWORD	tot;
	char	c;
	COMMTIMEOUTS tout, otout;

	// Establish timeouts so that a ReadFile() call will return if
	// no characters are incoming.
	GetCommTimeouts(hCom,&otout);
	tout = otout;
	tout.ReadIntervalTimeout = MAXDWORD;
	tout.ReadTotalTimeoutMultiplier = 0;
	tout.ReadTotalTimeoutConstant = 0;
	SetCommTimeouts(hCom,&tout);
	
	tot = 0;

	while(1) {
		if (ReadFile(hCom,&c,(DWORD)1,
			&bytesread,NULL) != TRUE) {
			ShowClearCommError(hCom);
			return(-1);
		}
		if (!bytesread)
			break;
		tot += bytesread;
	}
	SetCommTimeouts(hCom,&otout);
	return(tot);
}

int
comRead(HANDLE hCom,char *buf,int count)
{
	DWORD	bytesread;
	DWORD	tot;
	int		timeout;
	COMMTIMEOUTS tout, otout;

	timeout = 0;
	if (timeout > 0) {
		// Establish timeout so that a ReadFile() call will return if
		// no characters are incoming after some period of time.
		GetCommTimeouts(hCom,&otout);
		tout = otout;
		tout.ReadIntervalTimeout = MAXDWORD;
		tout.ReadTotalTimeoutMultiplier = MAXDWORD;
		tout.ReadTotalTimeoutConstant = timeout*1000;
		SetCommTimeouts(hCom,&tout);
	}

	tot = (DWORD)count;
	while(tot) {
		if (ReadFile(hCom,buf,(DWORD)tot,
		    &bytesread,NULL) != TRUE) {
			ShowClearCommError(hCom);
			ShowLastError("comread ReadFile()");
			if (timeout > 0)
				SetCommTimeouts(hCom,&otout);
			return(-1);
		}
		if ((timeout > 0) && (!bytesread))
			break;
		tot -= bytesread;
		buf += bytesread;
	}
	if (timeout > 0)
		SetCommTimeouts(hCom,&otout);
	return(0);
}

static int
comReadFlush(HANDLE hCom, char **bp)
{
	DWORD	bytesread;
	DWORD	tot, max;
	char	*buf;
	COMMTIMEOUTS tout, otout;

	// Establish timeouts so that a ReadFile() call will return if
	// no characters are incoming.
	GetCommTimeouts(hCom,&otout);
	tout = otout;
	tout.ReadIntervalTimeout = MAXDWORD;
	tout.ReadTotalTimeoutMultiplier = 0;
	tout.ReadTotalTimeoutConstant = 0;
	SetCommTimeouts(hCom,&tout);
	
	tot = 0;
	max = 256;
	buf = Malloc(256);
	while(1) {
		if (ReadFile(hCom,buf+tot,(DWORD)128,
			&bytesread,NULL) != TRUE) {
			ShowClearCommError(hCom);
			return(-1);
		}
		if (!bytesread)
			break;
		tot += bytesread;
		if (tot+128 >= max-2) {
			max += 128;
			buf = Realloc(buf,max);
		}
	}
	buf[tot] = 0;
	*bp = buf;
	SetCommTimeouts(hCom,&otout);
	return(tot);
}

static int
comReadLine(HANDLE hCom, char **bp, int timeout)
{
	DWORD	bytesread;
	DWORD	tot, max;
	char	*buf, c;
	COMMTIMEOUTS tout, otout;

	if (timeout > 0) {
		// Establish timeout so that a ReadFile() call will return if
		// no characters are incoming for some period of time.
		GetCommTimeouts(hCom,&otout);
		tout = otout;
		tout.ReadIntervalTimeout = MAXDWORD;
		tout.ReadTotalTimeoutMultiplier = MAXDWORD;
		tout.ReadTotalTimeoutConstant = timeout*1000;
		SetCommTimeouts(hCom,&tout);
	}
	
	tot = 0;
	max = 256;
	buf = Malloc(256);
	while(1) {
		if (ReadFile(hCom,&c,(DWORD)1,
			&bytesread,NULL) != TRUE) {
			ShowClearCommError(hCom);
			return(-1);
		}
		if ((timeout > 0) && (!bytesread))
			break;
		if ((c == '\r') || (c == '\n')) {
//			buf[tot++] = c;
			buf[tot] = 0;
			break;
		}
		buf[tot] = c;
		tot += bytesread;
		if (tot >= max-8) {
			max += 128;
			buf = Realloc(buf,max);
		}
	}
	*bp = buf;
	if (timeout > 0)
		SetCommTimeouts(hCom,&otout);
	return(tot);
}

int
comWait(HANDLE hCom,char *string,int verbose)
{
	int		i;
	DWORD	bytesread;
	char	*cp, buf[128];
	COMMTIMEOUTS otout, tout;

	// Redefine timeouts for COM port so that it returns immediately
	// regardless of the presence of a character...
	if (GetCommTimeouts(hCom,&otout)) {
		tout = otout;
		tout.ReadIntervalTimeout = MAXDWORD;
		tout.ReadTotalTimeoutMultiplier = 0;
		tout.ReadTotalTimeoutConstant = 0;
		tout.WriteTotalTimeoutMultiplier = 0;
		tout.WriteTotalTimeoutConstant = 0;
		if (!SetCommTimeouts(hCom,&tout)) {
			fprintf(stderr,"comwait: SetCommTimeout() failed\n");
			return(-1);
		}
	}
	else {
		fprintf(stderr,"comwait: GetCommTimeout() failed\n");
		return(-1);
	}

	// stay in loop until the specified string is received.
	cp = string;
	while(1) {
		if (ReadFile(hCom,buf,(DWORD)sizeof(buf),
			&bytesread,NULL) != TRUE) {
			ShowClearCommError(hCom);
			return(-1);
		}
		if (getIntCount()) {
			printf("\nInterrupted while waiting for: '%s'\n",string);
			break;
		}
		if (bytesread >= 1) {
			for(i=0;i<(int)bytesread;i++) {
				if (verbose)
					putchar(buf[i]);
				if (buf[i] == *cp) {
					cp++;
					if (*cp == 0)
						goto gotit;
				}
				else
					cp = string;
			}
		}
		fflush(stdout);
	}
gotit:
	SetCommTimeouts(hCom,&otout);
	return(0);
}

// comwrite():
// Send a block of characters to the specified com port.
// If the reader is active, then shut it down while the write is in
// progress.  This is done because apparently you can't write to a port
// if a thread is actively reading from that port.  I have no documentation
// stating this, but that's what I've found to be true.
//
int
comWrite(HANDLE hCom, char *buffer,int count)
{
	DWORD	byteswritten;
	int	i, retval, dbc;

	retval = 0;

	dbc = 0;
	stopComReader();

	if (!dbc) {
		if (WriteFile(hCom,buffer,(DWORD)count,
			&byteswritten,NULL) != TRUE)
			retval = -1;
	}
	else {
		for(i=0;i<count;i) {
			if (WriteFile(hCom,&buffer[i],
			  (DWORD)1,&byteswritten,NULL) != TRUE) {
				retval = -1;
				break;
			}
			i += byteswritten;
			Sleep(dbc);
		}
	}
	resumeComReader();
	return(retval);
}

int
comWrite_q(HANDLE hCom, char *buffer,int count)
{
	DWORD	byteswritten;

	if (WriteFile(hCom,buffer,(DWORD)count,
		&byteswritten,NULL) != TRUE)
		return(-1);
	return(0);
}

//
// comDirectConnect():
// A loop that will provide the equivalent of a direct connection between
// this process and the COM port...
// The loop will only terminate in response to an interrupt (ctrl-c).
//
void
comDirectConnect(HANDLE hCom)
{
	int		done;
	char	buf[128], c;
	COMMTIMEOUTS otout, tout;
	HANDLE	stdinhdl, stdouthdl;
	DWORD	bytesread, byteswritten, ocmode;
	
	stdinhdl = GetStdHandle(STD_INPUT_HANDLE);
	stdouthdl = GetStdHandle(STD_OUTPUT_HANDLE);

	if ((stdinhdl == INVALID_HANDLE_VALUE) ||
		(stdouthdl == INVALID_HANDLE_VALUE)) {
		fprintf(stderr,"GetStdHandle() failed\n");
		return;
	}


#if 0  // This way works, but puts a burden on the CPU...
	// Prepare to redefine timeouts for COM port so that it returns
	// immediately regardless of the presence of a character...
	if (GetCommTimeouts(hCom,&otout)) {
		tout = otout;
		tout.ReadIntervalTimeout = MAXDWORD;
		tout.ReadTotalTimeoutMultiplier = 0;
		tout.ReadTotalTimeoutConstant = 0;
		tout.WriteTotalTimeoutMultiplier = 0;
		tout.WriteTotalTimeoutConstant = 0;
	}
#else
	if (GetCommTimeouts(hCom,&otout)) {
		tout = otout;
		tout.ReadIntervalTimeout = MAXDWORD;
		tout.ReadTotalTimeoutMultiplier = MAXDWORD;
		tout.ReadTotalTimeoutConstant = 1;
		tout.WriteTotalTimeoutMultiplier = 0;
		tout.WriteTotalTimeoutConstant = 0;
	}
#endif
	else {
		fprintf(stderr,"GetCommTimeout() failed\n");
		return;
	}

	// Stop the reader if it is active...
	stopComReader();

	// Reconfigure the timeouts...
	if (!SetCommTimeouts(hCom,&tout)) {
		fprintf(stderr,"SetCommTimeout() failed\n");
		return;
	}

	GetConsoleMode(stdinhdl,&ocmode);
	SetConsoleMode(stdinhdl,ENABLE_PROCESSED_INPUT);

	printf("Direct-connect to COMport...\n");
	printf("Type ctrl-c to terminate.\n");

	// Terribly inefficient!
	done = 0;
	while(!done) {
		if (ReadFile(hCom,buf,(DWORD)(sizeof(buf)),
			&bytesread,NULL) != TRUE) {
			ShowLastError("comDirectConnect ReadFile(1)");
			ShowClearCommError(hCom);
		}
		if (bytesread >= 1) {
			if (WriteFile(stdouthdl,&buf,bytesread,&byteswritten,NULL)!=TRUE) {
				ShowLastError("comDirectConnect WriteFile(1)");
				break;
			}
		}
		if (kbhit()) {
			if (ReadFile(stdinhdl,&c,(DWORD)1,&bytesread,NULL) != TRUE) {
				ShowLastError("comDirectConnect ReadFile(2)");
				break;
			}
			if (bytesread == 1) {
				if (WriteFile(hCom,&c,(DWORD)1,
					&byteswritten,NULL) != TRUE) {
					ShowLastError("comDirectConnect WriteFile(2)");
					ShowClearCommError(hCom);
					break;
				}
			}
		}
		// If an interrupt occurred (ctrl-c), get out of this loop...
		if (getIntCount()) 
			break;
	}
	printf("\nDirect-connect terminated\n");

	// Restore the configuration this function modified: 
	SetCommTimeouts(hCom,&otout);
	SetConsoleMode(stdinhdl,ocmode);

	resumeComReader();
}


DWORD
WINAPI
comReaderThread(LPVOID id)
{
	int		i, crlf;
	char	buf[0x8000];
	DWORD	bytesread;
	HANDLE	hCom;
	COMMTIMEOUTS tout;

	hCom = (HANDLE)id;

	GetCommTimeouts(hCom,&tout);
	tout.ReadIntervalTimeout = MAXDWORD;
	tout.ReadTotalTimeoutMultiplier = MAXDWORD;
	tout.ReadTotalTimeoutConstant = 50;
	SetCommTimeouts(hCom,&tout);

	crlf = 0;
	while(1) {
		if (ReadFile(hCom,buf,(DWORD)(sizeof(buf)),
			&bytesread,NULL) != TRUE) {
				ShowLastError("comReaderThread ReadFile()");
				exit(1);
		}

		for(i=0;i<(int)bytesread;i++) {
			if ((showInvisible) && (!isprint(buf[i]))) {
				printf("<%02x>",(unsigned char)buf[i]);
				if (showInvisible < 3) {
					if ((buf[i] == 0x0a) || (buf[i] == 0x0d))
						crlf++;
					else
						crlf = 0;
					if (crlf == 2) {
						putchar('\n');
						crlf = 0;
					}
				}
			}
			else if ((showInvisible == 2) && (buf[i] == ' '))
				putchar('_');
			else 
				putchar(buf[i]);
		}
		fflush(stdout);

		if (rdrOffRqst) {
			rdrOffRqstAck = rdrOffRqst;
			while(rdrOffRqstAck) {
				if (rdrOffRqstAck != rdrOffRqst)
					rdrOffRqstAck = rdrOffRqst;
				Sleep(10);
			}
		}
	}
	return(0);
}

DWORD
comRdrThreadCreate(HANDLE hCom)
{
	DWORD	tid;

	hComRdr = CreateThread(NULL,0,comReaderThread,
		(LPVOID)hCom,CREATE_SUSPENDED,&tid);
	if (hComRdr == INVALID_HANDLE_VALUE) {
		ShowLastError("CreatThread()");
		return(0);
	}
	ResumeThread(hComRdr);
	return(tid);
}

void
comRdrThreadKill(void)
{
	TerminateThread(hComRdr,1);
}

// ShowClearCommError():
// Wrapper for ClearCommError to display the actual error that was
// cleared...
void
ShowClearCommError(HANDLE hdl)
{
	DWORD comerrs;
	COMSTAT comstat;

	fprintf(stderr,"\007COM Error:\n");
	ClearCommError(hdl,&comerrs,&comstat);
	if (comerrs & CE_BREAK)
		fprintf(stderr,"<break detected>\n");
	if (comerrs & CE_FRAME)
		fprintf(stderr,"<framing error>\n");
	if (comerrs & CE_IOE)
		fprintf(stderr,"<io error>\n");
	if (comerrs & CE_MODE)
		fprintf(stderr,"<mode not supported>\n");
	if (comerrs & CE_OVERRUN)
		fprintf(stderr,"<buffer overrun>\n");
	if (comerrs & CE_RXOVER)
		fprintf(stderr,"<input buffer overflow>\n");
	if (comerrs & CE_TXFULL)
		fprintf(stderr,"<output buffer overflow>\n");
	if (comerrs & CE_DNS)
		fprintf(stderr,"<parallel device not selected>\n");
	if (comerrs & CE_OOP)
		fprintf(stderr,"<out of paper>\n");
	if (comerrs & CE_PTO)
		fprintf(stderr,"<parallel device timeout>\n");
}

//
// stopComReader() & resumeComReader()
// These two functions interface with the reader thread to coordinate the
// stoppage and resumption of the reader thread calling ReadFile().
// This is necessary because apparently if ReadFile is blocked on a COM port
// waiting for characters, then a WriteFile destined for that same COM port
// will not work. I can't say that I've seen that documented anywhere, but it
// certainly seems to be the case.
//
// stopComReader...
// If reader is active, then increment the "reader-off-request" flag
// and wait for the reader to acknowledge that it has received the
// request (it will increment the "reader-off-request-ack" flag).
// resumeComReader...
// If reader is active, then decrement the "reader-off-request" flag
// and wait for the reader to acknowledge that it has received the
// request (it will decrement the "reader-off-request-ack" flag).
//

void
stopComReader()
{
	int	waitcnt;

	// If reader isn't active, return immediately...
	if (hComRdr == (HANDLE)NULL)
		return;

	waitcnt = 0;

	// Modify the request level...
	rdrOffRqst++;

	// Wait for the reader to acknowledge the change in the request level...
	while(rdrOffRqstAck != rdrOffRqst) {
		if (++waitcnt >= 100) {
			fprintf(stderr,"s");
			waitcnt = 0;
		}
		Sleep(10);
	}
}

void
resumeComReader()
{
	int	waitcnt;

	// If reader isn't active, return immediately...
	if (hComRdr == (HANDLE)NULL)
		return;

	waitcnt = 0;

	// Modify the request level...
	rdrOffRqst--;

	// Wait for the reader to acknowledge the change in the request level...
	while(rdrOffRqstAck != rdrOffRqst) {
		if (++waitcnt >= 100) {
			fprintf(stderr,"r");
			waitcnt = 0;
		}
		Sleep(10);
	}
}

/* comIoctl():
	Used for external configuration of comport stuff...
	SHOWINVISIBLE:
		0 = normal output
		1 = print non-printables
		2 = replace space with underscore (plus 1)
*/
int
comIoctl(int command, void *arg1, void *arg2)
{
	switch(command) {
		case COMIOCTL_SHOWINVISIBLE:
			showInvisible = (int)arg1; 	
			break;
		default:
			return(-1);
	}
	return(0);
} 
