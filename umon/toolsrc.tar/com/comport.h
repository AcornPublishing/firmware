extern HANDLE comOpen(int, int);
extern void comShow(HANDLE);
extern void comClose(HANDLE);
extern int comFlush(HANDLE);
extern int comRead(HANDLE,char *,int);
extern void comInit(void);

extern int comReadLine(HANDLE, char **,int);
extern int comWait(HANDLE,char *,int);
extern int comWrite(HANDLE,char *,int);
extern int comWrite_q(HANDLE,char *,int);
extern int comIoctl(int, void *, void *);
extern void comDirectConnect(HANDLE);
extern DWORD WINAPI comReaderThread(LPVOID);
extern DWORD comRdrThreadCreate(HANDLE);
extern void comRdrThreadKill(void);
void ShowClearCommError(HANDLE);
extern void stopComReader(void);
extern void resumeComReader(void);

/* Definitions for use with comIoctl(): */
#define COMIOCTL_SHOWINVISIBLE	1
