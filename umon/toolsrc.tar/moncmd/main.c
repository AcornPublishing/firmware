/* main.c:
	The front end to moncmd.c.  
	See moncmd.c for details.

	General notice:
	This code is part of a boot-monitor package developed as a generic base
	platform for embedded system designs.  As such, it is likely to be
	distributed to various projects beyond the control of the original
	author.  Please notify the author of any enhancements made or bugs found
	so that all may benefit from the changes.  In addition, notification back
	to the author will allow the new user to pick up changes that may have
	been made by other users after this version of the code was distributed.

	Author:	Ed Sutter
	email:	esutter@lucent.com		(home: lesutter@worldnet.att.net)
	phone:	908-582-2351			(home: 908-889-5161)
*/
#if HOST_IS_WINNT | HOST_IS_WIN95
#define WIN32_LEAN_AND_MEAN
#endif

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#if HOST_IS_WINNT | HOST_IS_WIN95
#include <winsock.h>
typedef unsigned long ulong;
#else
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#endif

#include "moncmd.h"
#include "version.h"

char *errmsg[] = {
	"Usage: moncmd [options] {sysname} \"monitor command\"",
	" Options:",
	"  -p#    override default port number of 777",
	"  -w#    override default timeout of 10 seconds with '#' seconds",
	"  -q     quiet mode (don't print timeout message)",
	"  -r     if timeout waiting for command reception, retry (forever)",
	"  -v     verbose mode (print 'Sending...' message)",
	"  -V     show version of moncmd.exe.",
	" Exit status:",
	"  0 if successful",
	"  1 if timeout waiting for command completion",
	"  2 if error",
	"  3 if timeout waiting for command reception",
	0,
};

void
usage(error)
char	*error;
{
	int	i;

	if (error)
		fprintf(stderr,"ERROR: %s\n",error);
	for(i=0;errmsg[i];i++)
		fprintf(stderr,"%s\n",errmsg[i]);
	exit(EXIT_ERROR);
}

/* err():
	Common error handling function.
*/
void
err(char *msg)
{
	if (msg)
		fprintf(stderr,"%s, ",msg);
#if HOST_IS_WINNT | HOST_IS_WIN95
	fprintf(stderr,"err=%d\n",WSAGetLastError());
#else
	perror("");
#endif
	exit(EXIT_ERROR);
}

void
showVersion(void)
{
	printf(" Built: %s @ %s\n",BUILDDATE,BUILDTIME);
	exit(1);
}

int
main(int argc,char **argv)
{
	int		opt;
	short	portnum;

	if (argc == 1)
		usage(0);

	moncmd_init(argv[0]);

	portnum = IPPORT_MONCMD;

	while((opt=getopt(argc,argv,"p:w:qrvV")) != EOF) { 
		switch(opt) {
		case 'p':
			portnum = atoi(optarg);
			break;
		case 'v':
			verbose = 1;
			break;
		case 'q':
			quietMode = 1;
			break;
		case 'r':
			retryFlag = 1;
			break;
		case 'w':
			waitTime = atoi(optarg);
			break;
		case 'V':
			showVersion();
			break;
		default:
			usage("bad option");
		}
	}

	if (argc < optind+2)
		usage("bad arg count");

	if ((waitTime == 0) && (retryFlag)) {
		fprintf(stderr,
			"Warning: -r option ignored with zero waittime\n"); 
		retryFlag = 0;
	}
	do_moncmd(argv[optind],argv[optind+1],portnum);
	return(EXIT_SUCCESS);
}
