/* moncmd.c:
	This tool is used to support simple UDP communication between a host and
	a target running MicroMonitor.  The target is listening on port 
	IPPORT_MONCMD (777) for incoming command strings just as they would be
	seen if typed in at the RS-232 console port.  When the monitor receives
	this, it processes the string through the same mechanism as the console.
	The only addition is that all output is copied to the sender of the UDP
	packet (one line at a time).  Once the command has been processed, the
	final packet returned to the sender is a packet of size 1 with the data
	being zero.  This is what tells moncmd that the command has completed
	on the target.

	Note that this is UDP, so it is not error free.

	General notice:
	This code is part of a boot-monitor package developed as a generic base
	platform for embedded system designs.  As such, it is likely to be
	distributed to various projects beyond the control of the original
	author.  Please notify the author of any enhancements made or bugs found
	so that all may benefit from the changes.  In addition, notification back
	to the author will allow the new user to pick up changes that may have
	been made by other users after this version of the code was distributed.

	Author:	Ed Sutter
	email:	esutter@lucent.com		(home: lesutter@worldnet.att.net)
	phone:	908-582-2351			(home: 908-889-5161)
*/
#if HOST_IS_WINNT | HOST_IS_WIN95
#define WIN32_LEAN_AND_MEAN
#endif

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#if HOST_IS_WINNT | HOST_IS_WIN95
#include <winsock.h>
typedef unsigned long ulong;
#else
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#endif

#include "moncmd.h"

extern	void err(char *);

char *thisProgname;		/* String containing the value of argv[0] when */
						/* the program was executed. */
char *msgString;		/* Pointer to the message that this program is */
						/* to send to the target host. */
char *targetHost;		/* Ip address or DNS name of host that this */
						/* program is to communicate with. */

int	retryFlag;			/* If set, then the program will retry. */
int	retryCount;			/* Running total number of retries. */
int	quietMode;			/* If set, then don't output status message at */
						/* the end of the program. */
int waitTime;			/* This is the amount of time that program will */
						/* wait for a response prior to giving up. */
int	socketFd;			/* File descriptor of the open socket used to */
						/* communicate with the target host. */
int verbose;			/* Set for more verbosity. */
int	cmdRcvd;			/* Set if the command has been received by the */
						/* target, but no additional response has been */
						/* received. */
struct sockaddr_in targetAddr;	/* This structure is used to hold the socket */
								/* address info related to the target host. */

/* Giveup():
	This function is called if the alarm worker determines that it is time
	to call it quits.
*/
void
Giveup(int sig)
{
	if (!quietMode) {
		if (cmdRcvd) {
			fprintf(stderr,
				"\n%s timeout: command received but not completed.\n",
				thisProgname);
		}
		else {
			fprintf(stderr,"\n%s timeout: command not received.\n",
				thisProgname);
		}
	}

	if (cmdRcvd)
		exit(EXIT_CMP_TIMEOUT);
	else
		exit(EXIT_ACK_TIMEOUT);
}

#if HOST_IS_WINNT | HOST_IS_WIN95
int	AlarmCount;

/* AlarmWorker():
	This is a thread that is created to provide a timeout if moncmd
	does not receive a response within a specified amount of time.
*/
DWORD
WINAPI
AlarmWorker(LPVOID notused)
{
	while(1) {
		Sleep(1000);	
		if (AlarmCount) {
			if (AlarmCount == 1) {
				if ((retryFlag) && (!cmdRcvd)) {
					retryCount++;
					if (verbose)
						fprintf(stderr,"Retry %d: <%s> to %s...\n",
							retryCount, msgString,targetHost);
					if (sendto(socketFd,msgString,(int)strlen(msgString)+1,0,
					    (struct sockaddr *)&targetAddr,sizeof(targetAddr))<0) {
						close(socketFd);
						err("re-sendto failed");
					}
					AlarmCount = waitTime+1;
				}
				else
					Giveup(0);
			}
			AlarmCount--;
		}
	}
	return(0);
}

#endif

/* do_moncmd():
	Open a socket and send the command to the specified port of the
	specified host.  Wait for a response if necessary.
*/
int
do_moncmd(char *hostname, char *command_to_monitor, short portnum)
{
	int	i, lasterr;
#if HOST_IS_UNIXWARE
	size_t	msglen;
#else
	int	msglen;
#endif
	ulong	inaddr;
	struct	hostent	*hp, host_info;
	char	rcvmsg[1024];
#if HOST_IS_WINNT | HOST_IS_WIN95
	WSADATA WsaData;
	DWORD	tid;
	HANDLE	tHandle;
#endif

#if HOST_IS_WINNT | HOST_IS_WIN95
	if (WSAStartup (0x0101, &WsaData) == SOCKET_ERROR)
		err("WSAStartup Failed");
#endif

	targetHost = hostname;

	/* Accept target name as string or internet dotted-decimal address: */
	memset((char *)&targetAddr,0,sizeof(struct sockaddr));
	if ((inaddr = inet_addr(targetHost)) != INADDR_NONE) {
		memcpy((char *)&targetAddr.sin_addr,(char *)&inaddr,sizeof(inaddr));
		host_info.h_name = NULL;
	}
	else {
		hp = gethostbyname(targetHost);
		if (hp == NULL)
			err("gethostbyname failed");
		host_info = *hp;
		memcpy((char *)&targetAddr.sin_addr,hp->h_addr,hp->h_length);
	}
	targetAddr.sin_family = AF_INET;
	targetAddr.sin_port = htons(portnum);

	socketFd = socket(AF_INET,SOCK_DGRAM,0);

#if HOST_IS_WINNT | HOST_IS_WIN95
	if (socketFd == INVALID_SOCKET)
#else
	if (socketFd < 0)
#endif
		err("socket failed");

	if (verbose)
		printf("Sending <%s> to %s...\n",command_to_monitor,targetHost);

	msgString = command_to_monitor;
	if (sendto(socketFd,msgString,(int)strlen(msgString)+1,0,
	    (struct sockaddr *)&targetAddr,sizeof(targetAddr)) < 0) {
		close(socketFd);
		err("sendto failed");
	}

	/* If the -w option says that wait time is zero, then don't bother */
	/* waiting for a response, just return here. */
	if (waitTime <= 0) {
		close(socketFd);
		exit(EXIT_SUCCESS);
	}

#if HOST_IS_WINNT | HOST_IS_WIN95
	AlarmCount = waitTime;
	tHandle = CreateThread(NULL,0,AlarmWorker,(LPVOID)0,0,&tid);
#else
	signal(SIGALRM,Giveup);
	alarm(waitTime);
#endif

	while(1) {
		int	j;

		/* Wait for incoming message: */
		msglen = sizeof(struct sockaddr);
		i = recvfrom(socketFd,rcvmsg,sizeof(rcvmsg),0,
			(struct sockaddr *)&targetAddr,&msglen);

		if (i == 0) {
			fprintf(stderr,"Connection closed\n");
			close(socketFd);
			exit(EXIT_ERROR);
		}
#if HOST_IS_WINNT | HOST_IS_WIN95
		else if (i == SOCKET_ERROR) {
			lasterr = WSAGetLastError();
			if (lasterr == WSAEINTR) {
				close(socketFd);
				Giveup(0);
			}
			else
				continue;
		}
		else  {
			/* Each time something is received, restart */\
			/* the timeout. */
			AlarmCount = waitTime;
		}
#else
		else if (i < 0)
			perror("recvfrom failed");
	
		/* Each time something is received, restart the timeout. */
		alarm(waitTime);
#endif

		/* If ANY response is received from the target, then the command */
		/* was received... */
		cmdRcvd = 1;

		/* If size is 1 and 1st byte is 0 assume that's the target */
		/* saying "I'm done". */
		if ((i==1) && (rcvmsg[0] == 0))
			break;

		/* Print the received message: */
		for(j=0;j<i;j++)
			putchar(rcvmsg[j]);
		fflush(stdout);
	}

#if HOST_IS_WINNT | HOST_IS_WIN95
	if (TerminateThread(tHandle,1) == FALSE) { // Terminate the thread
		fprintf(stderr,"moncmd thread kill failed\n");
		exit(EXIT_ERROR);
	}
#else
	alarm(0);
#endif
	close(socketFd);
	return(EXIT_SUCCESS);
}

void
moncmd_init(char *progname)
{
	thisProgname = progname;
	cmdRcvd = 0;
	waitTime = 10;
	verbose = 0;
	retryCount = retryFlag = quietMode = 0;
}
