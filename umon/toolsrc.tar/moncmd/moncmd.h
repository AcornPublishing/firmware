#ifndef INADDR_NONE
#define INADDR_NONE	0xffffffff
#endif

#define EXIT_SUCCESS		0
#define EXIT_CMP_TIMEOUT	1
#define EXIT_ERROR			2
#define EXIT_ACK_TIMEOUT	3

typedef unsigned char uchar;

#define IPPORT_MONCMD	777

extern int		sfd, retryFlag, retryCount, quietMode;
extern int		verbose, waitTime, cmdRcvd;
extern char		*thisProgname, *msgString, *targetHost;
extern struct	sockaddr_in targetAddr;

extern	int 	do_moncmd(char *,char *,short);
extern	void	moncmd_init(char *);

extern int		optind, getopt(), close();
extern char		*optarg;

