/* newmon.c:
	General notice:
	This code is part of a boot-monitor package developed as a generic base
	platform for embedded system designs.  As such, it is likely to be
	distributed to various projects beyond the control of the original
	author.  Please notify the author of any enhancements made or bugs found
	so that all may benefit from the changes.  In addition, notification back
	to the author will allow the new user to pick up changes that may have
	been made by other users after this version of the code was distributed.

	Author:	Ed Sutter
	email:	esutter@lucent.com		(home: lesutter@worldnet.att.net)
	phone:	908-582-2351			(home: 908-889-5161)
*/
#define WIN32_LEAN_AND_MEAN

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#include <winsock.h>

#include "ttftp.h"
#include "moncmd.h"

typedef unsigned char uchar;
typedef unsigned char ushort;
typedef unsigned long ulong;

char *errmsg[] = {
	"Usage: newmon [options] {sysname} {binfile}",
	" Options:",
	"  -A#    override default use of $APPRAMBASE",
	"  -B#    override default use of $BOOTROMBASE",
	"  -p#    override default port number of 777",
	"  -w#    override default timeout of 10 seconds with '#' seconds",
	"  -v     verbose mode (print 'Sending...' message)",
	"  -V     show version of newmon.exe.",
	" Exit status:",
	"  0 if successful",
	"  1 if timeout waiting for command completion",
	"  2 if error",
	"  3 if timeout waiting for command reception",
	0,
};

void
usage(error)
char	*error;
{
	int	i;

	if (error)
		fprintf(stderr,"ERROR: %s\n",error);
	for(i=0;errmsg[i];i++)
		fprintf(stderr,"%s\n",errmsg[i]);
	exit(EXIT_ERROR);
}

void
err(msg)
char	*msg;
{
	if (msg)
		fprintf(stderr,"%s, ",msg);
	fprintf(stderr,"err=%d\n",WSAGetLastError());
	exit(EXIT_ERROR);
}

void
showVersion(void)
{
	printf(" Built: %s @ %s\n",__DATE__,__TIME__);
	exit(1);
}

void
testTftp(int i,char *cp,int j)
{
}

void
main(int argc,char *argv[])
{
	int		opt;
	char	*AppRamBase, *BootRomBase;
	char	ewritecmd[128];
	short	portnum;
	struct	stat	mstat;

	if (argc == 1)
		usage(0);

	AppRamBase = "$APPRAMBASE";
	BootRomBase = "$BOOTROMBASE";
	moncmd_init(argv[0]);
	portnum = IPPORT_MONCMD;

	while((opt=getopt(argc,argv,"A:B:p:w:vV")) != EOF) {
		switch(opt) {
		case 'A':
			AppRamBase = optarg;
			break;
		case 'B':
			BootRomBase = optarg;
			break;
		case 'p':
			portnum = atoi(optarg);
			break;
		case 'v':
			verbose = 1;
			break;
		case 'w':
			waitTime = atoi(optarg);
			break;
		case 'V':
			showVersion();
			break;
		default:
			usage("bad option");
		}
	}

	if (optind+2 != argc)
		usage(0);

	if (stat(argv[optind+1],&mstat) == -1) {
		perror(argv[optind+1]);
		exit(EXIT_ERROR);
	}

	/* If do_moncmd() returns, then it succeeded... */
	do_moncmd(argv[optind], "version", portnum);

	if (ttftp(argv[optind],"put",argv[optind+1],AppRamBase,
		"octet") != EXIT_SUCCESS)
		exit(EXIT_ERROR);

	do_moncmd(argv[optind], "flash opw", portnum);

	sprintf(ewritecmd,"flash ewrite %s %s %d",
		BootRomBase,AppRamBase,mstat.st_size);
	do_moncmd(argv[optind], ewritecmd, portnum);

	exit(EXIT_SUCCESS);
}
