#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>

main(int argc,char **argv)
{
	int		ifd, opt, state;
	char	*ifile, *buf, *end, *bp, *whatstring, *wsp;
	struct	stat	mstat;

	if (argc == 2)
		system(argv[1]);
	else
		fprintf(stderr,"Usage: runpqa \"cmdline\"\n");
	
}
