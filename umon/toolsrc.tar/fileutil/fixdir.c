/* fixdir.c:
   Look through a file and replace all instances of TOP_DIRNAME with the
   specified string.
   I use this tool to convert absolute URL paths in the .c.html files that
   are created for browsing the monitor source code.
*/
#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "utils.h"

#define	TOPDIRNAME		"TOP_DIRNAME"
#define	TOPDIRNAMELEN	(sizeof(TOPDIRNAME)-1)

#if HOST_IS_SOLARIS | HOST_IS_LINUX
#define O_BINARY 0
#endif

int debug;

main(argc,argv)
int	argc;
char	*argv[];
{
	struct	stat stat1;
	int		fd1, i, opt, topdirnamelen;
	char	*filename, *dirname, *topdirname, *buf1, *buf2, *cp1, *cp2, *end;
	char	*outfilename;
	
	topdirname = TOPDIRNAME;
	outfilename = (char *)0;
	while ((opt=getopt(argc,argv,"d:o:")) != EOF) {
		switch(opt) {
		case 'd':
			topdirname = optarg;
			break;
		case 'o':
			outfilename = optarg;
			break;
		default:
			usage(0);
		}
	}

	if (argc != (optind+2))
		usage("Bad arg count");

	topdirnamelen = strlen(topdirname);
	filename = argv[optind];
	dirname = argv[optind+1];

	if ((fd1 = open(filename,O_RDONLY | O_BINARY)) == -1) {
		perror(filename);
		exit(1);
	}

	/* Copy file to local buffer: */
	stat(filename,&stat1);
	buf1 = Malloc(stat1.st_size);
	read(fd1,buf1,stat1.st_size);
	close(fd1);

	buf2 = Malloc(stat1.st_size*3);

	cp1 = buf1;
	cp2 = buf2;
	end = buf1 + stat1.st_size - topdirnamelen;
	while(cp1 < end) {
		if (!memcmp(cp1,topdirname,topdirnamelen)) {
			strcpy(cp2,dirname);
			cp2 += strlen(dirname);
			cp1 += topdirnamelen;
		}
		else {
			*cp2++ = *cp1++;
		}
	}

	end = buf1 + stat1.st_size;
	while(cp1 < end)
		*cp2++ = *cp1++;
		

	if (!outfilename) {
		unlink(filename);
		outfilename = filename;
	}

	if ((fd1 = open(outfilename,O_CREAT | O_WRONLY | O_BINARY,0777)) == -1) {
		perror(outfilename);
		exit(1);
	}

	if (write(fd1,buf2,cp2-buf2) == -1) {
		perror(outfilename);
		exit(1);
	}
	close(fd1);
	exit(0);
}

char *usage_txt[] = {
	"Usage: fixdir [-o OUTFILENAME] {filename} {dirname}",
	0,
};
