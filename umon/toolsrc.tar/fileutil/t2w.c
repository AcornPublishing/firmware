/* t2w.c:
 * tabs to whitespace converter...
 * I use this when I build the .c.html files so that all of the tabs are
 * cleaned up (I use ts=4, and netscape displays the stuff with ts=8).
 * Over time I've been adding additional option for printing source code.
 */
#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "utils.h"
#if HOST_IS_SOLARIS | HOST_IS_LINUX
#define O_BINARY 0
#endif

int verbose;
int	debug = 0;

main(argc,argv)
int	argc;
char	*argv[];
{
	char	*fname, c, lfmt[32];
	int		fd, i, opt, spacecount, loffset;
	int		linenumbers, lineno, showfilename;
	
	lineno = 1;
	verbose = 0;
	linenumbers = 0;
	showfilename = 0;
	while ((opt=getopt(argc,argv,"fl:v")) != EOF) {
		switch(opt) {
		case 'f':
			showfilename = 1;
			break;
		case 'v':
			verbose = 1;
			break;
		case 'l':
			linenumbers = atoi(optarg);
			break;
		default:
			usage(0);
		}
	}

	if (argc != (optind+2))
		usage("Bad arg count");

	spacecount = atoi(argv[optind]);
	fname = argv[optind+1];

	if (spacecount < 0)
		usage("Space count must be >= 0");

	if ((fd = open(fname,O_RDONLY | O_BINARY)) == -1) {
		perror(fname);
		exit(1);
	}

	if (showfilename)
		printf("FILE %s:\n",fname);

	if (linenumbers > 0) {
		sprintf(lfmt,"%%%dd: ",linenumbers);
		printf(lfmt,lineno);
	}

	loffset = 0;
	while(read(fd,&c,1) == 1) {
		int	shift;
		switch(c) {
			case '\r':
				loffset = 0;
				break;
			case '\n':
				putchar(c);
				lineno++;
				if (linenumbers > 0)
					printf(lfmt,lineno);
				loffset = 0;
				break;
			case '\t':
				shift = spacecount - (loffset % spacecount);
				for(i=0;i<shift;i++)
					putchar(' ');
				loffset += shift;
				break;
			default:
				putchar(c);
				loffset++;
				break;
		}
	}
	if (verbose)
		fprintf(stderr,"%d lines processed\n",lineno);
	exit(0);
}

char *usage_txt[] = {
	"Usage: t2w -[fl:v] {spacecount} {file}",
	" Options:",
	" -f     display filename at top of first page",
	" -l{#}  prefix linenumbers using '#' characters",
	" -v     verbose mode",
	0,
};
