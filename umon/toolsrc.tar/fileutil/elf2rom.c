#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <sys\types.h>
#include <sys\stat.h>
typedef unsigned char uchar;
typedef unsigned long ulong;
#include "..\crush\shell.h"
#include "elfdbg.h"

#define MAPDATASIZE	24

extern unsigned long strtoul(), tell();

extern int 	DbgFD;
extern FILE 	*DbgFP;
extern char	*DbgFname;

unsigned long	SizeOfDevice;

Elf2rom(argc,argv)
int	argc;
char	*argv[];
{
	extern	int optind;
	extern	char *optarg;
	uchar	*cp, byte;
	char	outfile[64];
	struct	elf_fhdr efhdr;
	struct	elf_shdr eshdr;
	int	i, opt, ofd, mapdata_inserted;
	ulong	size, j, mapdata[MAPDATASIZE], totalspace, entry;

	if (DbgFname)
		sprintf(outfile,"%s.img",DbgFname);
	else	
		outfile[0] = (char)0;

	mapdata_inserted = 0;
	SizeOfDevice = 0x20000;
	while((opt=Getopt(argc,argv,"o:ms:")) != EOF) {
                switch(opt) {
		case 'o':
			if (_fstrlen(optarg) >= sizeof(outfile))
				fprintf(stderr,"Name too big\n");
			strcpy(outfile,optarg);
			break;
		case 'm':
			mapdata_inserted = 1;
			break;
		case 's':
			SizeOfDevice = strtoul(optarg,(char **)0,0);
			break;
		default:
			return(0);
		}
	}

	fprintf(stderr,"Building rom-image file %s...\n",outfile);

	/* Open up an output file... */
	ofd = open(outfile,O_RDWR|O_BINARY|O_CREAT,S_IREAD | S_IWRITE);
	if (ofd == -1) {
		fprintf(stderr,"Error opening file: %s\n",outfile);
		return(-1);
	}

	/* Read in the elf header. */
	GetElfFileHdr(&efhdr);

	if (!mapdata_inserted) {
		if (BuildMapData(&efhdr,(uchar *)mapdata) < 0)
			return(0);
	}

	/* First pass through all sections that are allocated progbits, but */
	/* not writeable... */
	for(i=0;i<efhdr.e_shnum;i++) {
		GetElfScnHdr(&efhdr,&eshdr,i);
		size = eshdr.sh_size;
		if (size)
			size--;
		if ((eshdr.sh_type == SHT_PROGBITS) &&
		    (eshdr.sh_flags & SHF_ALLOC) &&
		    (!(eshdr.sh_flags & SHF_WRITE))) {
			printf("%10s: 0x%lx..0x%lx (%ld bytes) %s\n",
				SectionName(&efhdr,eshdr.sh_name),
				eshdr.sh_addr,eshdr.sh_addr+size,eshdr.sh_size,
				VerboseShtype(eshdr.sh_type));
			if (mapdata_inserted) {
				Lseek(DbgFD,eshdr.sh_offset,SEEK_SET);
				for(j=0;j<eshdr.sh_size;j++) {
					Read(DbgFD,&byte,1);
					Write(ofd,&byte,1);
				}
			}
			else {
				Write(ofd,mapdata,MAPDATASIZE);
				Lseek(DbgFD,eshdr.sh_offset+MAPDATASIZE,
					SEEK_SET);
				eshdr.sh_size -= MAPDATASIZE;
				for(j=0;j<eshdr.sh_size;j++) {
					Read(DbgFD,&byte,1);
					Write(ofd,&byte,1);
				}
				mapdata_inserted = 1;
			}
		}
	}

	/* Start the copy of the relocated section to be 8-bit aligned. */
	/* Write upto 8 bytes of junk to output file, to adjust offset... */
	j = tell(ofd);
	j = 8 - (j & ~7);
	Write(ofd,&eshdr,j);

	/* Second pass through all sections that are allocated progbits, and */
	/* are writeable. It is this group of sections that will be relocated */
	/* to RAM space at boot time. */
	for (i=0;i<efhdr.e_shnum;i++) {
		GetElfScnHdr(&efhdr,&eshdr,i);
		size = eshdr.sh_size;
		if (size)
			size--;
		if ((eshdr.sh_type == SHT_PROGBITS) &&
		    (eshdr.sh_flags & SHF_ALLOC) &&
		    (eshdr.sh_flags & SHF_WRITE)) {
			printf("%10s: 0x%lx..0x%lx (%ld bytes) %s\n",
				SectionName(&efhdr,eshdr.sh_name),
				eshdr.sh_addr,eshdr.sh_addr+size,eshdr.sh_size,
				VerboseShtype(eshdr.sh_type));
			Lseek(DbgFD,eshdr.sh_offset,SEEK_SET);
			for(j=0;j<eshdr.sh_size;j++) {
				Read(DbgFD,&byte,1);
				Write(ofd,&byte,1);
			}
		}
	}
	/* Fill up the reset of the image with 0xff's, (except for the */
	/* last four bytes which will be loaded with a branch to the entry */
	/* point address). */
	byte = 0xff;
	totalspace = tell(ofd);
	totalspace += 4;	/* Save 4 bytes at end for branch. */
	printf("Adding a %ld-byte hole...\n",SizeOfDevice-totalspace);
	while(totalspace < SizeOfDevice) {
		Write(ofd,&byte,1);
		totalspace++;
	}

	/* Insert a branch to the entry point... Since the branch address is */
	/* an offset with respect to the address of the instruction, and */
	/* the address of this instruction is fixed at 0xfffffffc, the */
	/* offset to the entry point is calculated by simply adding 4 to */
	/* the entry point. */
	entry = efhdr.e_entry + 4;
	cp = (uchar *)&entry;
	byte = (cp[3] & 0x3) | 0x48;
	Write(ofd,&byte,1);
	Write(ofd,&cp[2],1);
	Write(ofd,&cp[1],1);
	Write(ofd,cp,1);
	printf("Reset vector: 0x%02x%02x%02x%02x at 0xfffffffc\n",
		byte,cp[2],cp[1],cp[0]);

	close(ofd);
	return(0);
}

/* BuildMapData():
   Information regarding the memory map of the system is created here.
   This is needed so that the boot code can copy the initialized data 
   section from ROM to RAM, also needed so the boot code can clear out
   its ram space to zero initially.

   Some notes...
   The ROM copy of the .data section is placed just above the end of all of
   the other "real" rom sections.  It is then copied from that ROM space to
   its actual address in ram space.
   The RAM space owned by the monitor is considered to be from the base of
   the first "allocated-writeable-progbits" section, to the end of the
   last "allocated-writeable-progbits" section.
   
   If accessed in 'C', the structure created would look like this...
	struct	mapdata {
		ulong	id;		deadbeef for sanity
		ulong	ramstart;	base of RAM space
		ulong	ramsize;	size of RAM space
		ulong	datastart;	location of .data section in RAM
		ulong	datasize;	size of .data section
		ulong	romdata;	location of .data section in ROM
	};
.set            ..block_id,0x0          ! Should be 0xBFAB
.set            ..block_size,0x2        ! size of block in bytes
.set            ..entry_point,0x4       ! entry point (from loader)
.set            ..toc_pointer,0x8       ! TOC pointer
.set            ..text_length,0xC       ! text section length
.set            ..text_addr,0x10        ! text address
.set            ..data_length,0x14      ! data section length
.set            ..data_addr,0x18        ! data address
.set            ..bss_length,0x1C       ! bss section length
.set            ..bss_addr,0x20         ! bss address
.set            ..num_syms,0x24         ! number of symbols
.set            ..sym_addr,0x28         ! symbol table offset
.set            ..text_offset,0x2C      ! text offset in original offset
.set            ..sect_block_size,0x30
*/
BuildMapData(struct elf_fhdr *efhdr,uchar *mapdata)
{
	int	i;
	ulong	val, romstart, romend, romdata;
	ulong	ramstart, ramend, ramsize;
	ulong	datastart, datasize;
	uchar	*cp;
	char	*sname;
	struct	elf_shdr eshdr;

	romstart = ramstart = 0xffffffffL;
	for (i=0;i<efhdr->e_shnum;i++) {
		GetElfScnHdr(efhdr,&eshdr,i);
		sname = SectionName(efhdr,eshdr.sh_name);
		if (_fstrcmp(sname,".data") == 0) {
			datastart = eshdr.sh_addr;
			datasize = eshdr.sh_size;
		}
		if (eshdr.sh_flags & SHF_ALLOC) {
			if (eshdr.sh_flags & SHF_WRITE) {
				if (ramstart == 0xffffffffL)
					ramstart = eshdr.sh_addr;
				else
					ramend = eshdr.sh_addr+eshdr.sh_size;
			}
			else if (eshdr.sh_type == SHT_PROGBITS) {
				if (romstart == 0xffffffffL)
					romstart = eshdr.sh_addr;
				else
					romend = eshdr.sh_addr+eshdr.sh_size;
			}
		}
	}

	romdata = romstart + (romend & ~7) + 8;
	ramsize = ramend - ramstart;

	/* Make sure the memory size is large enough to hold everything... */
	if (((romend - romstart) + ramsize) > SizeOfDevice) {
		fprintf(stderr,"Device size of 0x%lx, too small.\n",
			SizeOfDevice);
		fprintf(stderr,"Map indicates that ROM starts at 0x%lx ",
			romstart);
		fprintf(stderr,
			"and must span to EOM at 0xffffffff (reset vector)\n");
		return(-1);
	}

	/* Offset 0: Mapdata sanity check. */
	*mapdata++ = 0xde;
	*mapdata++ = 0xad;
	*mapdata++ = 0xbe;
	*mapdata++ = 0xef;

	/* Offset 4: Ram begin address. */
	cp = (uchar *)&ramstart;
	*mapdata++ = cp[3];
	*mapdata++ = cp[2];
	*mapdata++ = cp[1];
	*mapdata++ = cp[0];

	/* Offset 8: Size of ram. */
	cp = (uchar *)&ramsize;
	*mapdata++ = cp[3];
	*mapdata++ = cp[2];
	*mapdata++ = cp[1];
	*mapdata++ = cp[0];

	/* Offset 12: Data in ram begin. */
	cp = (uchar *)&datastart;
	*mapdata++ = cp[3];
	*mapdata++ = cp[2];
	*mapdata++ = cp[1];
	*mapdata++ = cp[0];

	/* Offset 16: Data size. */
	cp = (uchar *)&datasize;
	*mapdata++ = cp[3];
	*mapdata++ = cp[2];
	*mapdata++ = cp[1];
	*mapdata++ = cp[0];

	/* Offset 20: Data in rom begin. */
	cp = (uchar *)&romdata;
	*mapdata++ = cp[3];
	*mapdata++ = cp[2];
	*mapdata++ = cp[1];
	*mapdata++ = cp[0];

	printf("Ram start: 0x%lx\n",ramstart);
	printf("Ram size: 0x%lx\n",ramsize);
	printf("Data start: 0x%lx\n",datastart);
	printf("Data size: 0x%lx\n",datasize);
	printf("Data in rom: 0x%lx\n",romdata);
	return(0);
}
