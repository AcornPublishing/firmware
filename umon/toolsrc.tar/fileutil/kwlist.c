#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "utils.h"
#if HOST_IS_WINNT | HOST_IS_WIN95
#else
#define O_BINARY	0
#include <unistd.h>
#endif

int debug;
int minKWsize, gotoLower;

char *ignorelist[] = {
	"was", "are", "can", "from", "this", "that", "on", "or", "by"
	"what", "with", "why", "not", "no",
	"int", "the", "and", "void", "char", "long"
	"ulong", "uchar", "ushort", "volatile", "struct", "if"
	"while", "for", "to", "when", "me", "you", "include",
	"else", "define", "endif", "ifdef",
	"is", "of",
	(char *)0,
};

void
showVersion(void)
{
	printf(" Built: %s @ %s\n",__DATE__,__TIME__);
	exit(1);
}


void
showkey(char *kw)
{
	int	i;

	for(i=0;ignorelist[i];i++) {
		if (!strcmp(ignorelist[i],kw))
			return;
	}
	if (isdigit(kw[0]))
		return;
	if (gotoLower) {
		while(*kw) {
			putchar(tolower(*kw++));
		}
		putchar('\n');
	}
	else
		printf("%s\n",kw);
}

main(argc,argv)
int	argc;
char	**argv;
{
	int		ifd, i, opt, ksize;
	char	kbuf[100], *cp, *memfile, *end;
	struct	stat	mstat;

	minKWsize = 3;
	gotoLower = 0;
	while((opt=getopt(argc,argv,"lm:V")) != EOF) {
		switch(opt) {
		case 'V':
			showVersion();
			break;
		case 'l':
			gotoLower = 1;
			break;
		case 'm':
			minKWsize = atoi(optarg);
			break;
		default:
			exit(0);
		}
	}
	if (argc != optind+1)
		usage(0);

	/* Open input file: */
	if (stat(argv[optind],&mstat) == -1) {
		perror(argv[optind]);
		exit(1);
	}
	ifd = open(argv[optind],O_RDONLY | O_BINARY);
	if (ifd == -1) {
		perror(argv[optind]);
		usage(0);
	}
	memfile = Malloc(mstat.st_size);
	if (read(ifd,memfile,mstat.st_size) != mstat.st_size) {
		perror("read");
		exit(1);
	}
	close(ifd);
	end = memfile+mstat.st_size;
	ksize = 0;
	cp = memfile;
	while(cp < end) {
		if (isalnum(*cp)) {
			kbuf[ksize++] = *cp;
		}
		else {
			if (isspace(*cp)) {
				if (ksize) {
					kbuf[ksize] = 0;
					if (ksize >= minKWsize)
						showkey(kbuf);
				}
			}
			ksize = 0;
		}
		cp++;
	}

	exit(0);
}

char *usage_txt[] = {
	"Usage: keyword {ifile}",
	" Options:",
	" -l             output all lower case",
	" -m   {minsize} (default=3)",
	" -V             show version",
	(char *)0,
};
