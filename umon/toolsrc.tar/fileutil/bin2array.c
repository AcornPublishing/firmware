#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#if HOST_IS_WINNT | HOST_IS_WIN95
#else
#define O_BINARY	0
#include <unistd.h>
#endif
#include "utils.h"

int debug;
#define BLKSIZ	1000

void
showVersion(void)
{
	printf(" Built: %s @ %s\n",__DATE__,__TIME__);
	exit(1);
}


/* converts a raw binary file to a C array */

main(argc,argv)
int	argc;
char	**argv;
{
	FILE	*ofp;
	int	ifd, i, j, total, cnt, tenth, percent, width, opt;
	int	swap, begin, end, Size, AssemblerFormat, definetot;
	char	buf[100], arrayname[64], outputfilename[64], *filename;
	unsigned char	ibuf[BLKSIZ+100];
	char	defines[16][80];
	struct	stat	mstat;
	
	width = 1;
	definetot = 0;
	arrayname[0] = 0;
	outputfilename[0] = 0;
	swap = 0;
	begin = end = 0;
	AssemblerFormat = 0;
	while((opt=getopt(argc,argv,"Aa:b:D:e:w:o:sV")) != EOF) {
		switch(opt) {
		case 'a':
			strncpy(arrayname,optarg,sizeof arrayname -1);
			break;
		case 'A':
			AssemblerFormat = 1;
			break;
		case 'D':
			strcpy(defines[definetot++],optarg);
			break;
		case 'o':
			strncpy(outputfilename,optarg,sizeof outputfilename -1);
			break;
		case 'w':
			width = atoi(optarg);
			break;
		case 's':
			swap = 1;
			break;
		case 'b':
			begin = strtol(optarg,0,0);
			break;
		case 'e':
			end = strtol(optarg,0,0);
			break;
		case 'V':
			showVersion();
			break;
		default:
			usage(0);
		}
	}

	if ((width != 1) && (width != 2) && (width != 4)) {
		fprintf(stderr,"Invalid width: %d (use 1,2, or 4).\n",width);
		usage(0);
	}
	if ((swap) && (width != 1)) {
		fprintf(stderr,"ERROR: Swap only supported for width = 1\n");
		exit(1);
	}
	if ((AssemblerFormat) && (width != 1)) {
		fprintf(stderr,
		     "ERROR: Assembler format only supported for width = 1\n");
		exit(1);
	}

	if (argc - optind + 1 == 2) 
		filename = argv[optind];
	else {
		usage("Bad argcnt");
	}

	if (!arrayname[0])
		strcpy(arrayname,argv[optind]);

	/* Open binary input file: */
	ifd = open(filename,O_RDONLY | O_BINARY);
	if (ifd == -1) {
		perror(filename);
		usage(0);
	}
	fstat(ifd,&mstat);
	fprintf(stderr,"Binary file size=%d\n",mstat.st_size);

	if (swap) {
		if ((mstat.st_size % width*(swap*2)) != 0)
			fprintf(stderr,"Warning: %d modulo %d != 0\n",
				mstat.st_size,width*(swap*2));
	}
	else {
		if ((mstat.st_size % width) != 0)
			fprintf(stderr,"Warning: %d modulo %d != 0\n",
				mstat.st_size,width);
	}

	if ((begin > end) || (end > mstat.st_size)) {
		usage("Bad -e or -b option");
	}

	if (!end)
		end = mstat.st_size;

	if (outputfilename[0]) {
		if ((ofp = fopen(outputfilename,"w")) == (FILE *)NULL) {
			perror(outputfilename);
			usage(0);
		}
	}
	else
		ofp = stdout;

	for(i=0;i<definetot;i++) 
		fprintf(ofp,"#define %s\n",defines[i]);

	if (definetot)
		fprintf(ofp,"\n");

	if (AssemblerFormat) {
		fprintf(ofp,".byte ");
	}
	else {
		switch(width) {
		case 1:
			fprintf(ofp,"unsigned char %s[] = {\n    ",arrayname);
			break;
		case 2:
			fprintf(ofp,"unsigned short %s[] = {\n    ",arrayname);
			break;
		case 4:
			fprintf(ofp,"unsigned long %s[] = {\n    ",arrayname);
			break;
		}
	}

	if (begin) {
		if (lseek(ifd,begin,SEEK_SET) == -1) {
			perror("lseek");
			return(-1);
		}
	}

	total = 0;
	Size = end-begin;
	tenth = Size/10;
	percent = 10;
	j = 1;
	while(1) {
		if ((total + BLKSIZ) > Size)
			cnt = Read(ifd,ibuf,Size-total);
		else
			cnt = Read(ifd,ibuf,BLKSIZ);
		if (cnt <= 0)
			break;
		if (width == 1) {
			if (swap) {
				for(i=0;i<cnt;i+=2,j+=2) {
					fprintf(ofp,"0x%02x,",ibuf[i+1]);
					fprintf(ofp,"0x%02x",ibuf[i]);
					if (j>12) {
						j = 0;
						if (AssemblerFormat)
							fprintf(ofp,"\n.byte ");
						else
							fprintf(ofp,",\n    ");
					}
					else
						fprintf(ofp,",");
				}
			}
			else {
				for(i=0;i<cnt;i++,j++) {
					fprintf(ofp,"0x%02x",ibuf[i]);
					if (j>12) {
						j = 0;
						if (AssemblerFormat)
							fprintf(ofp,
								"\n.byte ");
						else
							fprintf(ofp,",\n    ");
					}
					else {
						if ((!AssemblerFormat) ||
							(i+1 == cnt))
							fprintf(ofp,",");
					}
				}
			}
		}
		else if (width == 2) {
			for(i=0;i<cnt;i+=2,j+=2) {
				fprintf(ofp,"0x%02x%02x, ",ibuf[i],ibuf[i+1]);
				if (j>12) {
					j = 0;
					fprintf(ofp,"\n    ");
				}
			}
		}
		else if (width == 4) {
			for(i=0;i<cnt;i+=4,j+=4) {
				fprintf(ofp,"0x%02x%02x%02x%02x, ",
					ibuf[i],ibuf[i+1],ibuf[i+2],ibuf[i+3]);
				if (j>12) {
					j = 0;
					fprintf(ofp,"\n    ");
				}
			}
		}
		total += cnt;
		if (total >= Size)
			break;
		if (total >= tenth) {
			tenth += Size/10;
			fprintf(stderr,"Completed %d%%\r",percent);
			fflush(stdout);
			percent += 10;
		}
	}

	if (!AssemblerFormat)
		fprintf(ofp,"\n};");
	fprintf(ofp,"\n");

	close(ifd);
	fclose(ofp);

	fprintf(stderr,"Completed 100%%\n");
	exit(0);
}

char	*usage_txt[] = {
	"Usage: bin2array [options] {infile} [array-name]",
	"Options:",
	"       -A              use assembler .byte format",
	"       -a{arrayname}   (default = filename)",
	"       -b{offset}      offset into binary file to begin at",
	"       -D{define}      up to 16 '#define' statements inserted in output",
	"       -e{offset}      offset into binary file to end at",
	"       -w{width}       unit width 1|2|4 (default = 1)",
	"       -o{filename}    output file (default = stdout)",
	"       -s              swap data",
	"       -V              display version (build date) of tool",
	0,
};
