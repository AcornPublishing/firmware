/* tabs.c:
 * Just print the lines that contain tabs...
 */
#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "utils.h"
#if HOST_IS_SOLARIS | HOST_IS_LINUX
#define O_BINARY 0
#endif


main(argc,argv)
int	argc;
char	*argv[];
{
	int		lno;
	FILE	*fp;
	char	line[128];

	fp = fopen(argv[1],"r");
	lno = 0;
	while(fgets(line,sizeof(line),fp)) {
		lno++;
		if (strchr(line,'\t'))
			printf("%s %d: %s\n",argv[1],lno,line);
	}
	fclose(fp);
	exit(0);
}
