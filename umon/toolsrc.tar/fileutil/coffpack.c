#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "coff.h"

unsigned long btl32(unsigned long);
unsigned short btl16(unsigned short);
unsigned long ltb32(unsigned long);
unsigned short ltb16(unsigned short);

int 	coffFD = 0;
char	*coffFname = (char *)0;

struct	filehdr	CoffFhdr;
struct	aouthdr	OptAhdr;
struct	scnhdr	*ScnTbl;

/* open verbosity: */
#define SHOWHDR			0x0001
#define SHOWSECTIONS	0x0002
#define SHOWMAP			0x0004
#define SHOWMAPOFFSET	0x0008

struct	filehdr *GetCoffFileHdr();
char	*StrAllocAndCopy(char *);
char	*Malloc(int);
int		BEConvert, verbose;

main(argc,argv)
int	argc;
char	*argv[];
{
	extern	int optind;
	extern	char *optarg;
	char	fname[128], buf[16], *append, *stripto, *binto, *packto;
	int		i, tot, opt, showstuff;

	verbose = 0;
	showstuff = 0;
	stripto = (char *)0;
	packto = (char *)0;
	append = (char *)0;
	binto = (char *)0;
#if HOST_IS_WINNT | HOST_IS_WIN95
	BEConvert = 1;
#else
	BEConvert = 0;
#endif
	while ((opt=getopt(argc,argv,"a:cB:dfmMp:sS:v")) != EOF) {
		switch(opt) {
		case 'a':
			append = optarg;
			break;
		case 'B':
			binto = optarg;
			break;
		case 'c':
			if (BEConvert)
				BEConvert = 0;
			else
				BEConvert = 1;
			break;
		case 'f':
			showstuff |= SHOWHDR;
			break;
		case 'M':
			showstuff |= SHOWMAPOFFSET;
			break;
		case 'm':
			showstuff |= SHOWMAP;
			break;
		case 'p':
			packto = optarg;
			break;
		case 'S':
			stripto = optarg;
			break;
		case 's':
			showstuff |= SHOWSECTIONS;
			break;
		case 'v':
			verbose = 1;
			break;
		default:
			usage(0);
		}
	}

	if (argc != (optind+1))
		usage("Missing filename");

	strcpy(fname,argv[optind]);

	if (!fileexists(fname)) {
		fprintf(stderr,"No such file: %s\n",fname);
		exit(1);
	}

#if HOST_IS_WINNT | HOST_IS_WIN95
	if ((coffFD = open(fname,O_RDONLY | O_BINARY)) == -1) {
#else
	if ((coffFD = open(fname,O_RDONLY)) == -1) {
#endif
		perror(fname);
		exit(1);
	}

	coffFname = StrAllocAndCopy(fname);
	GetCoffFileHdr();
	GetCoffSectionHdrs();

	if (append && !stripto)
		usage("-a requires -S");

	tot = 0;
	if (binto) tot++;
	if (packto) tot++;
	if (stripto) tot++;
	if (tot > 1)
		usage("-S, -B and -p options must be run individually");

	if (binto) {
		int	fd, sidx, firstone;
		struct	stat buf;
		struct  filehdr *fhdr;
		uchar	*tfrom, *dfrom, *cp;
		ulong	paddr;
		struct	scnhdr	*sptr;

		unlink(binto);
#if HOST_IS_WINNT | HOST_IS_WIN95
		if ((fd = open(binto,O_WRONLY|O_BINARY|O_CREAT,0777))==-1) 
#else
		if ((fd = open(binto,O_WRONLY|O_CREAT,0777))==-1)
#endif
		{
			perror(binto);
			exit(1);
		}
		fprintf(stderr,"Converting %s into %s\n",
			coffFname,binto);
		firstone = 1;
		for(sptr=ScnTbl,sidx=0;sidx<CoffFhdr.f_nscns;sidx++,sptr++) {
			char	name[9], padbyte;
			int		padtot;
			ulong	nextpaddr;
			
			memcpy(name,sptr->s_name,8);
			name[8] = 0;

			if ((sptr->s_flags != STYP_BSS) &&
			    (sptr->s_flags != STYP_INFO) &&
			    (sptr->s_size)) {
				if (!firstone) {	/* Pad if necessary... */
					if (nextpaddr != sptr->s_paddr) {
						if (sptr->s_paddr < nextpaddr) {
							fprintf(stderr,"Unexpected section address\n");
							exit(1);
						}
						padtot = sptr->s_paddr-nextpaddr;
						printf("Pad 0x%x bytes\n",padtot);
						padbyte = 0;
						while(padtot) {
							write(fd,&padbyte,1);
							padtot--;
						}
					}
				}
				printf("Sec %-8s at 0x%-8x 0x%-6x bytes\n",
					name,sptr->s_paddr,sptr->s_size);
				cp = (uchar *)Malloc(sptr->s_size);
				Lseek(coffFD,sptr->s_scnptr,SEEK_SET);
				read(coffFD,cp,sptr->s_size);
				write(fd,cp,sptr->s_size);
				free(cp);
				nextpaddr = sptr->s_paddr + sptr->s_size;
				firstone = 0;
			}
		}
		close(fd);
	}
	else if (packto) {
		char	*ibuf,*obuf, *sdata, *obase, *ibase;
		int		size, pfd, sno, savings;
		struct	stat finfo;
		struct  filehdr *coffp;
		struct	scnhdr *sp;

		unlink(packto);
#if HOST_IS_WINNT | HOST_IS_WIN95
		if ((pfd = open(packto,O_WRONLY|O_BINARY|O_CREAT,0777))==-1)
#else
		if ((pfd = open(packto,O_WRONLY|O_CREAT,0777))==-1)
#endif
		{
			perror(packto);
			exit(1);
		}
		fprintf(stderr,"Packing %s into %s...\n",
			coffFname,packto);

		/* First copy the entire COFF file into the input buffer: */
		fstat(coffFD,&finfo);
		Lseek(coffFD,0,SEEK_SET);
		ibuf = Malloc(finfo.st_size+32);
		ibase = ibuf;
		obuf = Malloc(finfo.st_size+32);
		obase = obuf;
		coffp = (struct filehdr *)obase;
		Read(coffFD,ibuf,finfo.st_size);

		/* Now copy the file header and optional header to the out buffer: */
		for(i=0;i<sizeof(struct filehdr)+CoffFhdr.f_opthdr;i++)
			*obuf++ = *ibuf++;

		/* Since the output file will be stripped, modify the new header: */
		coffp->f_symptr = 0;
		coffp->f_nsyms = 0;

		/* At this point ibuf & obuf are at the base of the table of section */
		/* headers.  The section headers must be adjusted because the size */
		/* of the sections will be changing, so for each section, compress */
		/* the data and adjust the header information... */
		sp = (struct scnhdr *)obuf;

		/* Set sdata to point into the new buffer at the point immediately */
		/* after the headers. This pointer will be used to write the new */
		/* compressed sections. */
		sdata = obase + sizeof(struct filehdr) + CoffFhdr.f_opthdr +
			(CoffFhdr.f_nscns * sizeof(struct scnhdr));

		/* For each section, if the section is loadable, the compress the */
		/* data associated with that section... */
		savings = 0;
		for (sno=0;sno<CoffFhdr.f_nscns;sno++) {
			int	psize;

			/* If the section has data, compress it and adjust the */
			/* section header information. */
			if (ScnTbl[sno].s_scnptr) {
				/* Compress the section: */
				printf("Section %s: ",ScnTbl[sno].s_name);
				psize = packdata(ibase+ScnTbl[sno].s_scnptr,sdata,
					ScnTbl[sno].s_size,1);

				/* Keep track of total space saved: */
				savings += (ScnTbl[sno].s_size - psize);

				/* Adjust the affected section header members: */
				ScnTbl[sno].s_size = psize;
				ScnTbl[sno].s_scnptr = (ulong)(sdata - obase);
				sdata += psize;
			}

			memcpy(sp->s_name,ScnTbl[sno].s_name,8);
			sp->s_paddr = ltb32(ScnTbl[sno].s_paddr);
			sp->s_vaddr = ltb32(ScnTbl[sno].s_vaddr);
			sp->s_size = ltb32(ScnTbl[sno].s_size);
			sp->s_scnptr = ltb32(ScnTbl[sno].s_scnptr);
			sp->s_relptr = ltb32(ScnTbl[sno].s_relptr);
			sp->s_lnnoptr = ltb32(ScnTbl[sno].s_lnnoptr);
			sp->s_nreloc = ltb16(ScnTbl[sno].s_nreloc);
			sp->s_nlnno = ltb16(ScnTbl[sno].s_nlnno);
			sp->s_flags = ltb32(ScnTbl[sno].s_flags);
			sp++;
		}

		if (write(pfd,(char *)obase,sdata-obase) != (sdata-obase)) {
			perror(packto);
			exit(1);
		}
		close(pfd);
		free(ibuf);
		free(obuf);
		printf("Total savings of %d bytes\n",savings);
	}
	else if (stripto) {
		int	size, sfd, afd;
		struct  filehdr *coffp;

		unlink(stripto);
#if HOST_IS_WINNT | HOST_IS_WIN95
		if ((sfd = open(stripto,O_WRONLY|O_BINARY|O_CREAT,0777))==-1)
#else
		if ((sfd = open(stripto,O_WRONLY|O_CREAT,0777))==-1)
#endif
		{
			perror(stripto);
			exit(1);
		}
		fprintf(stderr,"Stripping %s into %s...\n",
			coffFname,stripto);
		Lseek(coffFD,0,SEEK_SET);
		size = CoffFhdr.f_symptr;
		coffp = (struct filehdr *)Malloc(size+32);
		Read(coffFD,(char *)coffp,size);
		coffp->f_symptr = 0;
		coffp->f_nsyms = 0;
		if (write(sfd,(char *)coffp,size) != size) {
			perror(stripto);
			exit(1);
		}
		if (append) {
			struct	stat buf;
			char	*aspace;
#if HOST_IS_WINNT | HOST_IS_WIN95
			if ((afd = open(append,O_RDONLY|O_BINARY))==-1)
#else
			if ((afd = open(append,O_RDONLY))==-1)
#endif
			{
				perror(append);
				exit(1);
			}
			stat(append,&buf);
			aspace = Malloc(buf.st_size+32);
			read(afd,aspace,buf.st_size);
			write(sfd,aspace,buf.st_size);
			free(aspace);
			close(afd);
		}
		close(sfd);
	}
	else {
		if (showstuff & SHOWHDR)
			ShowCoffHdr();
		if (showstuff & SHOWMAP)
			ShowCoffMap();
		if (showstuff & SHOWMAPOFFSET)
			ShowCoffOffsets();
		if (showstuff & SHOWSECTIONS)
			ShowCoffSections();
	}
	exit(0);
}

/* fileexists():
	Return1 if name is a valid file; else 0.
*/
fileexists(char *name)
{
	struct	stat buf;

	if (stat(name,&buf) == 0)
		return(1);
	else
		return(0);
}

ShowCoffSections()
{
	int	i, j;

	printf("\n\t\tCOFF FILE SECTION HEADERS\n");
	for(i=0;i<CoffFhdr.f_nscns;i++) {
		printf("Section: %s...\n",ScnTbl[i].s_name);
		printf("  s_paddr:   0x%x\n",ScnTbl[i].s_paddr);
		printf("  s_vaddr:   0x%x\n",ScnTbl[i].s_vaddr);
		printf("  s_size:    %d\n",ScnTbl[i].s_size);
		printf("  s_scnptr:  0x%x\n",ScnTbl[i].s_scnptr);
		printf("  s_relptr:  0x%x\n",ScnTbl[i].s_relptr);
		printf("  s_lnnoptr: 0x%x\n",ScnTbl[i].s_lnnoptr);
		printf("  s_nreloc:  %d\n",ScnTbl[i].s_nreloc);
		printf("  s_nlnno:   %d\n",ScnTbl[i].s_nlnno);
		printf("  s_flags:   0x%x\n\n",ScnTbl[i].s_flags);
	}
}

ShowCoffHdr()
{
	int	i, j;

	printf("\n\t\tCOFF FILE HEADER\n");

	printf("Magic:				0x%x\n",CoffFhdr.f_magic);
	if (CoffFhdr.f_opthdr) {
		printf("Text size:			0x%x (%d)\n",
			OptAhdr.tsize,OptAhdr.tsize);
		printf("Data size:			0x%x (%d)\n",
			OptAhdr.dsize,OptAhdr.dsize);
		printf("Bss size:			0x%x (%d)\n",
			OptAhdr.bsize,OptAhdr.bsize);
		printf("Entrypoint:			0x%x\n",OptAhdr.entry);
	}
	printf("Number of sections:		%d\n",CoffFhdr.f_nscns);
	printf("Number of symbols:		%d\n",CoffFhdr.f_nsyms);
}

ShowCoffMap()
{
	int	i, size;

	printf("\n\t\tCOFF FILE MEMORY MAP\n\n");
	for(i=0;i<CoffFhdr.f_nscns;i++) {
		char name[9];
		memcpy(name,ScnTbl[i].s_name,8);
		name[8] = 0;
		
		size = ScnTbl[i].s_size;
		printf("%8s: 0x%08x .. 0x%08x, 0x%x (%d) bytes.\n",
			name,ScnTbl[i].s_paddr,ScnTbl[i].s_paddr+size,size,size);
	}
}

ShowCoffOffsets()
{
	int	i, start;

	start = sizeof(struct filehdr) + CoffFhdr.f_opthdr;
	printf("\n\t\tCOFF FILE SECTION FILE OFFSETS\n");

	for(i=0;i<CoffFhdr.f_nscns;i++) {
		printf("%8s: 0x%08x .. 0x%08x (%d bytes)\n",
			ScnTbl[i].s_name,ScnTbl[i].s_scnptr,
			ScnTbl[i].s_scnptr+ScnTbl[i].s_size,
			ScnTbl[i].s_size);
		start += ScnTbl[i].s_size;
	}
}

/* GetCoffFileHdr():
   Retrieve the header from the file and do a BE-to-LE conversion
   on each of its members.
*/
struct filehdr *
GetCoffFileHdr()
{
	if (verbose)
		fprintf(stderr,"GetCoffFileHdr()\n");

	/* Read in the coff file header. */
	Lseek(coffFD,0,SEEK_SET);
	Read(coffFD,(char *)&CoffFhdr,(unsigned)sizeof(struct filehdr));
	CoffFhdr.f_magic = btl16(CoffFhdr.f_magic);
	CoffFhdr.f_nscns = btl16(CoffFhdr.f_nscns);
	CoffFhdr.f_timdat = btl32(CoffFhdr.f_timdat);
	CoffFhdr.f_symptr = btl32(CoffFhdr.f_symptr);
	CoffFhdr.f_nsyms = btl32(CoffFhdr.f_nsyms);
	CoffFhdr.f_opthdr = btl16(CoffFhdr.f_opthdr);
	CoffFhdr.f_flags = btl16(CoffFhdr.f_flags);

	if (CoffFhdr.f_opthdr) {
		Read(coffFD,(char *)&OptAhdr,(unsigned)sizeof(struct aouthdr));
		OptAhdr.magic = btl16(OptAhdr.magic);
		OptAhdr.vstamp = btl16(OptAhdr.vstamp);
		OptAhdr.tsize = btl32(OptAhdr.tsize);
		OptAhdr.dsize = btl32(OptAhdr.dsize);
		OptAhdr.bsize = btl32(OptAhdr.bsize);
		OptAhdr.entry = btl32(OptAhdr.entry);
		OptAhdr.text_start = btl32(OptAhdr.text_start);
		OptAhdr.data_start = btl32(OptAhdr.data_start);
	}
	return(&CoffFhdr);
}

/* btlXX:
   Conversion routines to go from be endian to little endian.
   ELF file is BE, PC is LE.
*/
unsigned short
btl16(unsigned short be)
{
	unsigned char	*bcp, *lcp;
	unsigned short	le;

	if (!BEConvert)
		return(be);
	bcp = (uchar *)&be;
	lcp = (uchar *)&le;
	lcp[0] = bcp[1];
	lcp[1] = bcp[0];
	return(le);
}

unsigned long
btl32(unsigned long be)
{
	unsigned char	*bcp, *lcp;
	unsigned long	le;

	if (!BEConvert)
		return(be);
	bcp = (uchar *)&be;
	lcp = (uchar *)&le;
	lcp[0] = bcp[3];
	lcp[1] = bcp[2];
	lcp[2] = bcp[1];
	lcp[3] = bcp[0];
	return(le);
}

unsigned short
ltb16(unsigned short le)
{
	unsigned char	*bcp, *lcp;
	unsigned short	be;

	if (!BEConvert)
		return(le);
	bcp = (uchar *)&be;
	lcp = (uchar *)&le;
	bcp[0] = lcp[1];
	bcp[1] = lcp[0];
	return(be);
}

unsigned long
ltb32(unsigned long le)
{
	unsigned char	*bcp, *lcp;
	unsigned long	be;

	if (!BEConvert)
		return(le);
	bcp = (uchar *)&be;
	lcp = (uchar *)&le;
	bcp[0] = lcp[3];
	bcp[1] = lcp[2];
	bcp[2] = lcp[1];
	bcp[3] = lcp[0];
	return(be);
}

char *
StrAllocAndCopy(char *string)
{
	int	len;
	char	*cp;

	if (verbose)
		fprintf(stderr,"StrAllocAndCopy(%s)\n",string);

	len = strlen(string);
	len += 16;
	cp = malloc(len);
	if (!cp) {
		perror("strallocandcopy malloc");
		exit(1);
	}
	strcpy(cp,string);
	return(cp);
}

char *
Malloc(int size)
{
	char	*cp;

	if (verbose)
		fprintf(stderr,"Malloc(size=%d)\n",size);

	cp = malloc(size);
	if (!cp) {
		perror("malloc");
		exit(1);
	}
	return(cp);
}

Read(int fd,char *buf,int size)
{
	int	i;

	if (verbose)
		fprintf(stderr,"Read(size=%d)\n",size);

	i = read(fd,buf,size);
	if (i <= 0) {
		fprintf(stderr,"read returned %d...",i);
		perror("");
		exit(1);
	}
	return(i);
	
}

Lseek(int fd,int offset,int type)
{
	if (verbose)
		fprintf(stderr,"Lseek(offset=%d)\n",offset);

	if (lseek(fd,offset,type) == -1) {
		perror("lseek");
		exit(1);
	}
}

#if HOST_IS_WINNT | HOST_IS_WIN95
int	getopt_sp = 1;
int	optopt, optind = 1;
char	*optarg;

int
getopt(int argc,char *argv[],char *opts)
{
	extern char	*strchr();
	register int c;
	register char *cp;

	if (getopt_sp == 1) {
		char	c0, c1;

		if (optind >= argc)
			return(EOF);

		c0 = argv[optind][0];
		c1 = argv[optind][1];

		if (c0 != '-')
			return(EOF);
		if (c1 == '\0')
			return(EOF);
		if (c0 == '-') {
			if ((isdigit(c1)) && (!strchr(opts,c1)))
				return(EOF);
			if (c1 == '-') {
				optind++;
				return(EOF);
			}
		}
	}
	optopt = c = argv[optind][getopt_sp];
	if (c == ':' || ((cp=strchr(opts, c)) == NULL)) {
		fprintf(stderr,"Illegal '%s' option: %c.\n",argv[0],c);
		if(argv[optind][++(getopt_sp)] == '\0') {
			optind++;
			getopt_sp = 1;
		}
		return('?');
	}
	if (*++cp == ':') {
		if(argv[optind][getopt_sp+1] != '\0')
			optarg = &argv[optind++][getopt_sp+1];
		else if(++(optind) >= argc) {
			fprintf(stderr,
				"Option '%c' of '%s' requires argument.\n",
				c,argv[0]);
			getopt_sp = 1;
			return('?');
		} else
			optarg = argv[optind++];
		getopt_sp = 1;
	} else {
		if(argv[optind][++(getopt_sp)] == '\0') {
			getopt_sp = 1;
			optind++;
		}
		optarg = NULL;
	}
	return(c);
}
#endif

char *usage_txt[] = {
	"Usage: coff [options] {filename}",
	" Options:",
	" -a{filename}  append file to end of -S file",
	" -B{filename}  coff-2-bin to filename",
	" -c            BE-to-LE convert",
	" -f            show coff file header",
	" -M            show coff map with file offsets",
	" -m            show coff map without file offsets",
	" -p{filename}  pack to specified file (output file is also stripped)",
	" -s            show coff section headers",
	" -S{filename}  strip to specified file",
	" -v            verbose (debug) mode",
	" Notes:",
	" * The -B, -p and -S options must be run individually.",
	" * If the -a option is used, it requires the -S option.",
	0,
};

usage(char *msg)
{
	int	i;

	if (msg)
		fprintf(stderr,"%s\n",msg);

	for(i=0;usage_txt[i];i++)
		fprintf(stderr,"%s\n",usage_txt[i]);
	
	exit(1);
}

GetCoffSectionHdrs()
{
	int	i;

	ScnTbl = (struct scnhdr *)Malloc(CoffFhdr.f_nscns * sizeof(struct scnhdr));

	/* Read in the coff section headers. */
	Lseek(coffFD,sizeof(struct filehdr)+CoffFhdr.f_opthdr,SEEK_SET);
	Read(coffFD,(char *)ScnTbl,
		(unsigned)(CoffFhdr.f_nscns * sizeof(struct scnhdr)));

	for(i=0;i<CoffFhdr.f_nscns;i++) {
		ScnTbl[i].s_paddr = btl32(ScnTbl[i].s_paddr);
		ScnTbl[i].s_vaddr = btl32(ScnTbl[i].s_vaddr);
		ScnTbl[i].s_size = btl32(ScnTbl[i].s_size);
		ScnTbl[i].s_scnptr = btl32(ScnTbl[i].s_scnptr);
		ScnTbl[i].s_relptr = btl32(ScnTbl[i].s_relptr);
		ScnTbl[i].s_lnnoptr = btl32(ScnTbl[i].s_lnnoptr);
		ScnTbl[i].s_nreloc = btl16(ScnTbl[i].s_nreloc);
		ScnTbl[i].s_nlnno = btl16(ScnTbl[i].s_nlnno);
		ScnTbl[i].s_flags = btl32(ScnTbl[i].s_flags);
	}

	return(CoffFhdr.f_nscns);
}
