/* install.c:
	This is an executable that is used to install from CD, the monitor 
	website pages onto a local disk drive.  In theory, one would think that
	this should be done with a .bat file, but I found that even 
	"if not exist"
	works different on a Win98 machine than on WinNT, so to avoid OS
	incompatibilities, it is an executable.

	Steps in the installation:
	1. One argument is expcected, the destination directory name.
	   If this directory does not exist, then create it.
	2. Create the destination directory structure.
	3. Copy each file in the "filelist" from the source path to the 
	   destination path.
	4. Run fixdir on the .c.html files.
*/
#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "utils.h"

int debug;

#define NAMESIZE 512		/* Ridiculously large */

#define LISTFILE "filelist"

#define	TOPDIRNAME		"TOP_DIRNAME"
#define	TOPDIRNAMELEN	(sizeof(TOPDIRNAME)-1)

int
fixdir(char *dirname,char *filename)
{
	struct	stat stat1;
	int		fd1, i, opt, topdirnamelen;
	char	*topdirname, *buf1, *buf2, *cp1, *cp2, *end;
	
	topdirname = TOPDIRNAME;
	topdirnamelen = strlen(topdirname);

	if ((fd1 = open(filename,O_RDONLY | O_BINARY)) == -1) {
		perror(filename);
		return(-1);
	}

	/* Copy file to local buffer: */
	stat(filename,&stat1);
	buf1 = Malloc(stat1.st_size);
	read(fd1,buf1,stat1.st_size);
	close(fd1);

	buf2 = Malloc(stat1.st_size*3);

	cp1 = buf1;
	cp2 = buf2;
	end = buf1 + stat1.st_size - topdirnamelen;
	while(cp1 < end) {
		if (!memcmp(cp1,topdirname,topdirnamelen)) {
			strcpy(cp2,dirname);
			cp2 += strlen(dirname);
			cp1 += topdirnamelen;
		}
		else {
			*cp2++ = *cp1++;
		}
	}

	end = buf1 + stat1.st_size;
	while(cp1 < end)
		*cp2++ = *cp1++;
		
	unlink(filename);

	if ((fd1 = open(filename,O_CREAT | O_WRONLY | O_BINARY,0777)) == -1) {
		perror(filename);
		return(-1);
	}

	if (write(fd1,buf2,cp2-buf2) == -1) {
		perror(filename);
		return(-1);
	}
	close(fd1);
	return(0);
}

void
finish(int exitval)
{
	fflush(stdin);
	printf("Hit --ENTER-- to finish.");
	fflush(stdout);
	getchar();
	exit(exitval);
}

void
InstallHeader(void)
{
	printf("\n\n    ***** MICRO-MONITOR INSTALLATION *****\n\n");
}

/* GetInstallDirectory():
	Ask the user for a directory name to be used as an installation directory.
*/
void
GetInstallDirectory(char *dirname,char *slash)
{
	int	retries;
	char c;
	struct	stat dirstat;

	for(retries = 0;retries < 3; retries++) {
		printf("Enter full-path of destination directory: ");
		fflush(stdin);
		fflush(stdout);
		if (fgets(dirname,NAMESIZE,stdin) == NULL) {
			perror("input error");
			finish(1);
		}
		dirname[strlen(dirname)-1] = 0;
	
		/* If directory doesn't exist, create it... */
		if (stat(dirname,&dirstat) == -1) {
			fprintf(stderr,
				"Directory <%s> does not exist, ok to create it now (y or n)?",
					dirname);
			fflush(stdin);
			c = (char)getchar();
			if (c != 'y')
				continue;
			if (mkdir(dirname) == -1)
				fprintf(stderr,"Can't create directory '%s'.\n",dirname);
			else {
				printf("Created directory: %s.\n",dirname);
				break;
			}
		}
		else {
			fprintf(stderr,"The directory '%s' already exists.\n",dirname);
			fprintf(stderr,"This installation should be placed in a newly\n");
			fprintf(stderr,"created directory.  Please re-specify...\n");
		}
	}
	if (retries == 3) {
		fprintf(stderr,"Giving up, check your directory name.\n");
		finish(1);
	}
	else {	/* Use slash or backslash, depending on what the user uses... */
		if (strchr(dirname,'/'))
			*slash = '/';
		else
			*slash = '\\';
	}
}

/* CheckForPrefix():
	Look at "fullpath" to see if there are any slashes or backslashes.
	If there are any, then load the string upto the last slash into the
	area pointed to by prefix.
*/
void
CheckForPrefix(char *fullpath, char *prefix)
{
	char	*lastslash, *lastbslash;

	/* If there is a prefix to argv[0], load it now... */
	/* This is necessary because if install is run from some other directory */
	/* it must know where to find the file list and source files. */
	lastslash = strrchr(fullpath,'/');
	lastbslash = strrchr(fullpath,'\\');
	if (lastslash && lastbslash) {
		if (lastslash > lastbslash)
			lastbslash = (char *)0;
		else
			lastslash = (char *)0;
	}
	if (lastslash) {
		*lastslash = 0;
		strcpy(prefix,fullpath);
		*lastslash = '/';
		strcat(prefix,"/");
	}
	else if (lastbslash) {
		*lastbslash = 0;
		strcpy(prefix,fullpath);
		*lastbslash = '\\';
		strcat(prefix,"\\");
	}
	else
		prefix[0] = 0;
}

char *usage_txt[] = {
	"Usage: install {DIRNAME}",
	0,
};

void
main(argc,argv)
int	argc;
char	*argv[];
{
	FILE	*listfp;
	int		opt, fd;
	struct	stat filestat;
	char	*buf, c, slash;
	char	prefix[NAMESIZE], filename[NAMESIZE], newfilename[NAMESIZE];
	char	dirname[NAMESIZE], fullfilename[NAMESIZE], listfile[NAMESIZE];

	/* Process options: */
	while ((opt=getopt(argc,argv,"d")) != EOF) {
		switch(opt) {
		case 'd':
			debug = 1;
			break;
		default:
			usage(0);
		}
	}

	if (argc != optind) {
		fprintf(stderr,"Unexpected command line arguments\n");
		fprintf(stderr,"Usage: install\n");
		finish(1);
	}

	/* Print initial greeting: */
	InstallHeader();

	/* Retrieve the directory into which the installation will be done: */
	GetInstallDirectory(dirname,&slash);

	/* If there is a prefix to this command, load it into prefix: */
	CheckForPrefix(argv[0],prefix);

	/* Open the list of files to be copied... */
	sprintf(listfile,"%s%s",prefix,LISTFILE);
	listfp = fopen(listfile,"r");
	if (!listfp) {
		fprintf(stderr,"File %s not found\n",listfile);
		finish(1);
	}

	/* First go through the file list and create the destination directory */
	/* structure: */
	printf("Creating directory structure under %s...\n",dirname);
	while(fgets(filename,NAMESIZE,listfp)) {
		char *slash;

		slash = filename;
		while(slash = strchr(slash,'/')) {
			*slash = 0;
			sprintf(newfilename,"%s/%s",dirname,filename);
			if (stat(newfilename,&filestat) == -1) {
				if (debug)
					fprintf(stderr,"Creating directory: %s\n",newfilename);
				mkdir(newfilename);
			}
			*slash = '/';
			slash++;
		}
	}

	/* Copy each file listed in file list to the destination directory: */
	rewind(listfp);
	printf("Copying files from CD to %s...\n",dirname);
	while(fgets(filename,NAMESIZE,listfp)) {
		filename[strlen(filename)-1] = 0;
		sprintf(fullfilename,"%s%s",prefix,filename);
		sprintf(newfilename,"%s%c%s",dirname,slash,filename);

		if ((fd = open(fullfilename,O_RDONLY|O_BINARY)) == -1) {
			fprintf(stderr,"Can't open %s, skipping it.\n",fullfilename);
			continue;
		}
		stat(fullfilename,&filestat);
		buf = Malloc(filestat.st_size);
		read(fd,buf,filestat.st_size);
		close(fd);
		if ((fd = open(newfilename,O_CREAT|O_WRONLY|O_BINARY,0777)) == -1) {
			fprintf(stderr,"Can't create %s, skipping it.\n",newfilename);
			continue;
		}
		if (write(fd,buf,filestat.st_size) == -1) {
			perror(newfilename);
			finish(1);
		}
		free(buf);
		close(fd);
		if (debug)
			fprintf(stderr,"Copy %s to %s...\n",fullfilename,newfilename);
	}
	rewind(listfp);

	/* Now run fixdir on each of the .c.html files... */
	printf("Converting \".c.html\" references...\n");
	while(fgets(filename,NAMESIZE,listfp)) {
		filename[strlen(filename)-1] = 0;
		if (!strcmp(filename+strlen(filename)-7,".c.html")) {
			sprintf(newfilename,"%s%c%s",dirname,slash,filename);
			if (debug)
				fprintf(stderr,"fixdir %s %s\n",dirname,newfilename);
			fixdir(dirname,newfilename);
		}
	}

	fclose(listfp);
	printf("\n\nInstallation completed.\n");
	printf("To remove this installation, simply remove the\n");
	printf("directory %s and all of its contents.\n",dirname);
	printf("Open %s%cREADME.txt for more information.\n",dirname,slash);
	printf("\nYou can now start browsing at %s%cindex.html\n",dirname,slash);
	
	finish(0);
}
