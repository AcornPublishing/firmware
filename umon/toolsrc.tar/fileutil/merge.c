#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "utils.h"
#if HOST_IS_WINNT | HOST_IS_WIN95
#else
#define O_BINARY	0
#include <unistd.h>
#endif

int debug;

void
showVersion(void)
{
	printf(" Built: %s @ %s\n",__DATE__,__TIME__);
	exit(1);
}

struct fstuff {
	char 			*name;
	char 			*buf;
	struct	stat	stat;
	int				fd;
};

/* Merge the files on the arglist */

main(argc,argv)
int	argc;
char	**argv;
{
	char	*obuf, *obase, *ofile;
	struct fstuff finfo[16], *fip;
	int	ftot, fsize, ofd, i, j, opt;

	debug = 0;
	ofile = "merge.bin";
	while((opt=getopt(argc,argv,"do:V")) != EOF) {
		switch(opt) {
		case 'd':
			debug = 1;
			break;
		case 'o':
			ofile = optarg;
			break;
		case 'V':
			showVersion();
			break;
		default:
			exit(1);
		}
	}
	ftot = argc - optind;

	if (ftot < 2) {
		usage("Need atleast 2 input files");
	}
	for(i=0;i<ftot;i++) {
		fip = &finfo[i];
		fip->name = argv[optind+i];
		fip->fd = open(fip->name,O_RDONLY | O_BINARY);
		if (fip->fd == -1) {
			perror(fip->name);
			exit(1);
		}
		fstat(fip->fd,&fip->stat);
		if (i == 0) {
			fsize = fip->stat.st_size;
		}
		else {
			if (fip->stat.st_size != fsize) {
				fprintf(stderr,"Files must all be equal size");
				exit(1);
			}
		}
		fip->buf = malloc(fip->stat.st_size);
		if (fip->buf == 0) {
			perror("malloc #1 failed");
			exit(1);
		}
		if (read(fip->fd,fip->buf,fsize) != fsize) {
			perror(fip->name);
			exit(1);
		}
	}
	obuf = obase = malloc(ftot*fsize);
	if (!obuf) {
		perror("malloc #2 failed");
		exit(1);
	}

	for(j=0;j<fsize;j++) {
		for(i=0;i<ftot;i++) {
			*obuf++ = finfo[i].buf[j];
		}
	}

	/* Move merge buffer to file: */
	ofd = open(ofile,O_WRONLY|O_BINARY|O_CREAT,0777);
	if (ofd < 0) {
		fprintf(stderr,"Can't open output file:",ofile);
		exit(1);
	}

	if (write(ofd,obase,fsize*ftot) != fsize*ftot) {
		fprintf(stderr,"Can't write file:",ofile);
		exit(1);
	}
	free(obase);
	close(ofd);
	for(i=0;i<ftot;i++) {
		fip = &finfo[i];
		free(fip->buf);
		close(fip->fd);
	}
	
	printf("Files merged to %s (%d bytes)\n",ofile,ftot*fsize);
	exit(0);
}

char *usage_txt[] = {
	"Usage: merge [options] {f1} {f2} [f3] [f4] ...",
	" Merge multiple files to one file",
	" Options:",
	" -d         enable debug mode",
	" -o{ofile}  override default 'merge.bin' as output file",
	" -V         show version",
	(char *)0,
};
