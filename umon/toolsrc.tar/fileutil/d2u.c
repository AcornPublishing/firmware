/* d2u:
 * Dos-to-Unix converter.
 * Simply scans through the file removing all instances of 0x0d.
 */
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "utils.h"
#if HOST_IS_WINNT | HOST_IS_WIN95
#else
#define O_BINARY	0
#include <unistd.h>
#endif

int debug;

void
showVersion(void)
{
	printf(" Built: %s @ %s\n",__DATE__,__TIME__);
	exit(1);
}

main(argc,argv)
int	argc;
char	**argv;
{
	char	c;
	FILE	*ifp;
	int		opt, i;
	struct	stat	mstat;

	while((opt=getopt(argc,argv,"V")) != EOF) {
		switch(opt) {
		case 'V':
			showVersion();
			break;
		default:
			usage(0);
		}
	}

	/* If input file is present, open input file, else use stdin. */
	if (argc == optind+1) {
		ifp = fopen(argv[optind],"r");
		if (ifp == (FILE *)NULL) {
			perror(argv[optind]);
			usage(0);
		}
	}
	else {
		ifp = stdin;
	}
	while(!feof(ifp)) {
		c = fgetc(ifp);
		if (c != 0x0d)
			putchar(c);	
	}
	exit(0);
}

char *usage_txt[] = {
	"Usage: d2u [options] [ifile]",
	" Options:",
	"  -V     show version of tool",
	"",
	" Notes:",
	" Remove all 0x0ds from input file",
	" If no ifile is specified, take input from stdin",
	(char *)0,
};
