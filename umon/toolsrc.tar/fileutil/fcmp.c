/* fcmp.c:
   Cheap and dirty file comparison utility.  Yea, I know there's 'cmp'
   but we found that it doesn't work on some binary files.
   Exit...
	0 if files are identical;
	1 if the files are the same size, but not identical;
	2 if the files are different sizes, and are identical up to the point
	  of the smaller of the two files.
*/
#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "utils.h"
#if HOST_IS_SOLARIS | HOST_IS_LINUX
#define O_BINARY 0
#endif

#define EXIT_IDENTICAL		0
#define EXIT_DIFFERENT		1
#define EXIT_DIFFERENTSIZE	2

void
showVersion(void)
{
	printf(" Built: %s @ %s\n",__DATE__,__TIME__);
	exit(1);
}

int verbose, debug;

main(argc,argv)
int	argc;
char	*argv[];
{
	char	*f1, *f2, *buf1, *buf2;
	int		fd1, fd2, i, opt, size;
	struct	stat stat1, stat2;
	
	verbose = 0;
	debug = 0;
	while ((opt=getopt(argc,argv,"dvV")) != EOF) {
		switch(opt) {
		case 'd':
			debug = 1;
			break;
		case 'v':
			verbose = 1;
			break;
		case 'V':
			showVersion();
			break;
		default:
			usage(0);
		}
	}

	if (argc != (optind+2))
		usage("Bad arg count");

	f1 = argv[optind];
	f2 = argv[optind+1];

	if ((fd1 = open(f1,O_RDONLY | O_BINARY)) == -1) {
		perror(f1);
		exit(1);
	}
	if ((fd2 = open(f2,O_RDONLY | O_BINARY)) == -1) {
		perror(f2);
		exit(1);
	}

	stat(f1,&stat1);
	stat(f2,&stat2);
	if ((stat1.st_size == stat2.st_size) || (stat1.st_size < stat2.st_size))
		size = stat1.st_size;
	else
		size = stat2.st_size;

	buf1 = Malloc(stat1.st_size);
	buf2 = Malloc(stat2.st_size);

	read(fd1,buf1,stat1.st_size);
	read(fd2,buf2,stat2.st_size);
	
	for(i=0;i<size;i++) {
		if (buf1[i] != buf2[i]) {
			fprintf(stderr,"files differ at position %d (0x%x)\n",i,i);
			exit(EXIT_DIFFERENT);
		}
	}
	if (stat1.st_size != stat2.st_size) {
		fprintf(stderr,
			"files differ at position %d (0x%x) due to different sizes\n",i,i);
		exit(EXIT_DIFFERENTSIZE);
	}
	else {
		fprintf(stderr,"files are identical\n");
		exit(EXIT_IDENTICAL);
	}
}

char *usage_txt[] = {
	"Usage: cmp {file1} {file2}",
	0,
};
