#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "utils.h"
#if HOST_IS_WINNT | HOST_IS_WIN95
#else
#define O_BINARY	0
#include <unistd.h>
#endif

int debug;

void
showVersion(void)
{
	printf(" Built: %s @ %s\n",__DATE__,__TIME__);
	exit(1);
}

/* Take an input file an break it up into two files.
 * Take first 4 bytes and put in file1, next 4 into file2,
 * next 4 in file1, next 4 in file2, etc...
 */

main(argc,argv)
int	argc;
char	**argv;
{
	char	*ofile, *buf1, *buf2, *bp1, *bp2, *fname, ofilename[128];
	struct	stat	stat;
	int		ifd, ofd, i, j, opt, size1, size2;

	debug = 0;
	ofile = "chunk";
	while((opt=getopt(argc,argv,"do:V")) != EOF) {
		switch(opt) {
		case 'd':
			debug = 1;
			break;
		case 'o':
			ofile = optarg;
			break;
		case 'V':
			showVersion();
			break;
		default:
			exit(1);
		}
	}
	if (argc != optind +1)
		usage(0);
	
	fname = argv[optind];

	ifd = open(fname,O_RDONLY | O_BINARY);
	if (ifd == -1) {
		perror(fname);
		exit(1);
	}
	fstat(ifd,&stat);
	if (stat.st_size % 4) {
		fprintf(stderr,"Input file must be mod 4\n");
		exit(1);
	}
	buf1 = bp1 = malloc(stat.st_size);
	buf2 = bp2 = malloc(stat.st_size);
	if ((!buf1) || (!buf2)) {
		perror("malloc");
		exit(1);
	}
	size1 = size2 = 0;
	while(1) {
		if (read(ifd,bp1,4) != 4)
			break;
		bp1 += 4;
		size1 += 4;
		if (read(ifd,bp2,4) != 4)
			break;
		bp2 += 4;
		size2 += 4;
	}

	sprintf(ofilename,"%s1.bin",ofile);
	ofd = open(ofilename,O_WRONLY|O_BINARY|O_CREAT|O_TRUNC,0777);
	if (ofd < 0) {
		fprintf(stderr,"Can't open %s\n",ofilename);
		exit(1);
	}
	if (write(ofd,buf1,size1) != size1) {
		fprintf(stderr,"Can't write file %s\n",ofilename);
		exit(1);
	}
	close (ofd);

	sprintf(ofilename,"%s2.bin",ofile);
	ofd = open(ofilename,O_WRONLY|O_BINARY|O_CREAT|O_TRUNC,0777);
	if (ofd < 0) {
		fprintf(stderr,"Can't open %s\n",ofilename);
		exit(1);
	}
	if (write(ofd,buf2,size2) != size2) {
		fprintf(stderr,"Can't write file %s\n",ofilename);
		exit(1);
	}
	close (ofd);
	close (ifd);
	free(buf1);
	free(buf2);
	printf("Files chunk1.bin (%d) & chunk2.bin (%d) created\n",size1,size2);
	exit(0);
}

char *usage_txt[] = {
	"Usage: chunk [options] {file}",
	" Chunk one file into 2",
	" Options:",
	" -V         show version",
	(char *)0,
};
