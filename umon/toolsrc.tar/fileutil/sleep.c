#include <wtypes.h>

void
main(int argc, char *argv[])
{
	Sleep(1000 * atoi(argv[1]));
}
