/* flash.h:
   Header file for use with 29F800B for 16 bit mode.
*/
#define FLASH_TIMEOUT       1000000
#define FLASHFUNCSIZE       320

#define FLASH_PROTECT_WINDOW_CLOSED 0
#define ALL_SECTORS -1

/* Manufacturer and device ids... */
#define AMD29F800T  0x000122d6
#define AMD29F800B  0x00012258
#define SGS29F040   0x20e2
#define AMD29F040   0x01a4
#define AMD29F010   0x0120
#define FLASHRAM    0x9999

#define Fwrite(to,frm)      (*(ftype *)to = *(ftype *)frm)
#define Is_Equal(p1,p2)     (*(ftype *)p1 == *(ftype *)p2)
#define Is_Not_Equal(p1,p2) (*(ftype *)p1 != *(ftype *)p2)
#define NotAligned(ptr)     ((long)ptr & 1)

extern int FlashProtectionWindow;

struct  flashdesc {
    unsigned long   id;             /* manufacturer & device id */
    char        *desc;              /* ascii string */
};

struct  sectorinfo {
    long    size;                   /* size of sector */
    int     snum;                   /* number of sector (amongst possibly */
                                    /* several devices) */
    int     protected;              /* if set, sector is protected by window */
    unsigned char   *begin;         /* base address of sector */
    unsigned char   *end;           /* end address of sector */
};

struct  flashinfo {
    unsigned long   id;             /* manufacturer & device id */
    unsigned char   *base;          /* base address of device */
    unsigned char   *end;           /* end address of device */
    int     sectorcnt;              /* number of sectors */
    int     width;                  /* 1, 2, or 4 */
    int     (*fltype)();
    int     (*flerase)();
    int     (*flwrite)();
    int     (*flewrite)();
    struct sectorinfo *sectors;     /* information per sector */
};

extern struct flashinfo FlashBank[];
