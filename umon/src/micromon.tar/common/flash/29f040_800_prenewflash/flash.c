/* This file contains all of the flash support code that does not need
   to be relocated to RAM.  Two separate files (flash.c and flashpic.c)
   are maintained because under certain compilers, they may need to be
   compiled with different options to be made position independent.

   NOTE: THESE FUNCTIONS ARE NOT RE-ENTRANT!!!  All of the FLASH routines
   assume they can copy themselves into the array FlashFunc[]; hence, only
   one operation can be active at any time.
*/
#include "config.h"
#if INCLUDE_FLASH
#include "cpu.h"
#include "flash.h"

typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned long ulong;
typedef volatile unsigned char vuchar;
typedef volatile unsigned short vushort;
typedef volatile unsigned long vulong;
typedef volatile unsigned int vuint;
typedef volatile int vint;

extern int Flashtype29F040_8();
extern int EndFlashtype29F040_8();
extern int Flasherase29F040_8();
extern int EndFlasherase29F040_8();
extern int Flashwrite29F040_8();
extern int EndFlashwrite29F040_8();
extern int Flashewrite29F040_8();
extern int EndFlashewrite29F040_8();

extern int Flashtype29F800B_16();
extern int EndFlashtype29F800B_16();
extern int Flasherase29F800B_16();
extern int EndFlasherase29F800B_16();
extern int Flashwrite29F800B_16();
extern int EndFlashwrite29F800B_16();
extern int Flashewrite29F800B_16();
extern int EndFlashewrite29F800B_16();

struct flashinfo *addrtobank();
int CurrentBank;

/* FlashXXXFbufYYY[]:
    Where XXX is the function to be stored in the buffer and YYY is the
    device that the function is to operate on.
    These arrays are loaded with the flash operation function (TYPE, ERASE,
    WRITE & EWRITE) that must run in different memory space than the device
    that is being operated on.  Recall that to operate on the flash, you
    cannot be executing out of it.
    The flash functions are copied here, then executed through a function
    pointer flashfunc which is set (in FlashInit) to point to the buffer.
*/
long    FlashTypeFbuf040[FLASHFUNCSIZE];
long    FlashWriteFbuf040[FLASHFUNCSIZE];
long    FlashEraseFbuf040[FLASHFUNCSIZE];
long    FlashEwriteFbuf040[FLASHFUNCSIZE];
long    FlashTypeFbuf800[FLASHFUNCSIZE];
long    FlashWriteFbuf800[FLASHFUNCSIZE];
long    FlashEraseFbuf800[FLASHFUNCSIZE];
long    FlashEwriteFbuf800[FLASHFUNCSIZE];

/* FlashProtectWindow:
   Must be set to allow any flash operation to be done on space assumed
   to be boot code.
*/
int FlashProtectWindow;

/* FlashNamId[]:
   Used to correlate between the ID and a string representing the name
   of the flash device.
*/
struct flashdesc FlashNamId[] = {
    AMD29F800B, "AMD-29F800B",
    AMD29F800T, "AMD-29F800T",
    SGS29F040,  "SGS-29F040",
    AMD29F040,  "AMD-29F040",
    AMD29F010,  "AMD-29F010",
    FLASHRAM,   "FLASH-RAM",
};

int SectorSizes29F040_8[] = {
        0x10000, 0x10000, 0x10000, 0x10000,
        0x10000, 0x10000, 0x10000, 0x10000,
};

int SectorSizes29F800B_16[] = {
        0x4000,     0x2000,     0x2000,     0x8000,
        0x10000,    0x10000,    0x10000,    0x10000,
        0x10000,    0x10000,    0x10000,    0x10000,
        0x10000,    0x10000,    0x10000,    0x10000,
        0x10000,    0x10000,    0x10000
};

struct sectorinfo sinfo800[19], sinfo040[8];
struct sectorinfo sinfoRAM[(FLASHRAM_SIZE/FLASHRAM_SSIZE)];

/* FlashBank[]:
    This table contains all of the information that is needed to keep the
    flash code somewhat generic across multiple flash devices.
*/
struct  flashinfo FlashBank[FLASHBANKS];

showflashtype(id)
ulong id;
{
    int i;

    for(i=0;i<sizeof FlashNamId/sizeof(struct flashdesc);i++) {
        if (id == FlashNamId[i].id) {
            printf("Device = %s\n",FlashNamId[i].desc);
            return(0);
        }
    }
    printf("Flash id 0x%x not recognized\n",id);
    return(-1);
}

showflashinfo(fdev)
struct flashinfo *fdev;
{
    int i;

    if (showflashtype(fdev->id) < 0)
        return(-1);

    printf("  Base addr   : 0x%08x\n",fdev->base);
    printf("  Sectors     : %d\n",fdev->sectorcnt);
    printf("  Bank width  : %d\n",fdev->width);
    printf("  Sector     Begin       End        Size     SW-Protected?\n");
    for(i=0;i<fdev->sectorcnt;i++) {
        printf("    %2d    0x%08x  0x%08x  0x%06x      %s\n",
            fdev->sectors[i].snum,
            fdev->sectors[i].begin,fdev->sectors[i].end,
            fdev->sectors[i].size,
            fdev->sectors[i].protected ? "yes" : " no");
    }
    return(0);
}

/* flashopload():
    Copy flash operation to ram space.  
    Note that this function assumes that cache is disabled at this point.
    This is important because we are copying text into bss space and if
    cache was on, there could be a coherency problem.
*/
flashopload(ulong *begin,ulong *end,ulong *copy,int size)
{
    volatile ulong  *bp;
    int ret, mode;

    /* Verify space availability: */
    if (((int)end - (int)begin) >= size) {
        printf("flashopload overflow ((0x%x-0x%x) > 0x%x)\n",end,begin,size);
        return(-1);
    }

    ret = 0;
    /* Copy function() to RAM, then verify: */
    bp = begin;
    while(bp <= end) {
        *copy = *bp;
        if (*copy++ != *bp++) {
            printf("flashopload failed\n");
            ret = -1;
            break;
        }
    }

    return(ret);
}

/* flashtype():
    Use the device-specific function pointer to call the routine
    relocated to RAM space.
*/
flashtype(fdev)
struct flashinfo *fdev;
{
    return(fdev->fltype(fdev));
}

/* flasherase():
    Use the device-specific function pointer to call the routine
    relocated to RAM space.
    Note that flasherase() is called with a sector number.  The sector
    number is relative to the entire system, not just the particular device.
    This means that if there is more than one flash device in the system that
    the actual sector number (relative to the device) may not be the same
    value.  This adjustment is made here so that the underlying code that is
    pumped into ram for execution does not have to be aware of this.
*/
flasherase(fdev,snum)
struct  flashinfo *fdev;
int snum;
{
    int size;
    char *base, *end;

    if (fdev->id == FLASHRAM) {
        if (snum == ALL_SECTORS) {
            size = fdev->end - fdev->base;
            base = fdev->base;
        }
        else {
            sectortoaddr(snum,&size,&base);
        }
        end = base+size;
        while(base < end) {
            *base = 0xff;
            if (*base++ != 0xff)
                return(-1);
        }
        return(0);
    }

    if ((snum != ALL_SECTORS) && (fdev->sectors[0].snum != 0)) {
/*      printf("Adjusting snum from %d to",snum); */
        snum -= fdev->sectors[0].snum;
/*      printf(" %d.\n",snum); */
    }
    return(fdev->flerase(fdev,snum));
}

/* flashwrite():
    Use the device-specific function pointer to call the routine
    relocated to RAM space.
    First make a few checks on the request, then write to flash if all
    checks succeed.
*/
flashwrite(fdev,dest,src,bytecnt)
struct  flashinfo *fdev;
uchar   *src, *dest;
long    bytecnt;
{
    int i, j, lowsector, highsector;
    register uchar  *dp, *sp, *edp;

    if (fdev->id == FLASHRAM) {
        uchar *sp, *dp, *end;
        sp = src;
        dp = dest;
        end = dp+bytecnt;
        while(dp < end) {
            *dp = *sp;
            if (*dp != *sp)
                return(-1);
            dp++; sp++;
        }
        return(0);
    }

    dp = dest;
    sp = src;
    edp = (dest + bytecnt) - 1;

    /* If outside the devices space, return failed.. */
    if ((edp < fdev->sectors[0].begin) ||
        (dp > fdev->sectors[fdev->sectorcnt-1].end)) {
        printf("flashwrite() failed: dest out of flash range\n");
        return(-1);
    }

    /* Make sure the destination is not within a protected sector */
    if (FlashProtectWindow == FLASH_PROTECT_WINDOW_CLOSED) {

        /* First determine the sectors that overlap with the */
        /* flash space to be written... */

        lowsector = highsector = -1;
        for(j=0;j<fdev->sectorcnt;j++) {
            if ((dp >= fdev->sectors[j].begin) &&
                (dp <= fdev->sectors[j].end))
                lowsector = j;
        }
        for(j=0;j<fdev->sectorcnt;j++) {
            if ((edp >= fdev->sectors[j].begin) &&
                (edp <= fdev->sectors[j].end))
                highsector = j;
        }
        if ((lowsector == -1) || (highsector == -1)) {
            printf("flashwrite() failed: can't find sector\n");
            return(-1);
        }

        /* Now that the range of affected sectors is known, */
        /* verify that those sectors are not protected... */
        for(j=lowsector;j<=highsector;j++) {
            if (fdev->sectors[j].protected) {
                printf("flashwrite() failed: sector protected\n");
                return(-1);
            }
        }
    }

    /* Now make sure that there is no attempt to transition a bit */
    /* in the affected range from 0 to 1...  A flash write can only */
    /* bring bits low (erase brings them  high). */
    while(dp < edp) {
        if ((*dp & *sp) != *sp) {
            printf("flashwrite() failed: bit 0->1 rqst denied.\n");
            return(-1);
        }
        dp++; 
        sp++;
    }
    return(fdev->flwrite(fdev,dest,src,bytecnt));
}

/* flashewrite():
    Use the device-specific function pointer to call the routine
    relocated to RAM space.
*/
flashewrite(fdev,dest,src,bytecnt)
struct  flashinfo *fdev;
ulong   *src, *dest;
long    bytecnt;
{
    int i;

    /* Source and destination addresses must be long-aligned. */
    if (((int)src & 3) || ((int)dest & 3))
        return(-1);

    /* If the protection window is closed, then verify that no protected */
    /* sectors will be written over... */
    if (FlashProtectWindow == FLASH_PROTECT_WINDOW_CLOSED) {
        for (i=0;i<fdev->sectorcnt;i++) {
            if((((uchar *)dest) > (fdev->sectors[i].end)) ||
                (((uchar *)dest+bytecnt) < (fdev->sectors[i].begin)))
                continue;
            else
                if (fdev->sectors[i].protected)
                    return(-1);
        }
    }
    return(fdev->flewrite(fdev,dest,src,bytecnt));
}

AppFlashWrite(dest,src,bytecnt)
ulong   *src, *dest;
long bytecnt;
{
    struct flashinfo *fbnk;
    ulong   oints;
    int ret;

    fbnk = addrtobank(dest);
    if (!fbnk)
        return(-1);
    oints = intsoff();
    ret = flashwrite(fbnk,dest,src,bytecnt);
    intsrestore(oints);
    if (ret < 0)
        printf("AppFlashWrite(0x%x,0x%x,%d) failed\n", dest,src,bytecnt);
    return(ret);
}

AppFlashEraseAll()
{
    int     ret, i;
    ulong   oints;
    struct  flashinfo *fbnk;

    oints = intsoff();
    fbnk = FlashBank;
    for(i=0;i<FLASHBANKS;i++,fbnk++) {
        ret = flasherase(fbnk,ALL_SECTORS);
        if (ret == -1)
            break;
    }
    intsrestore(oints);
    return(ret);
}

/* Erase the flash sector specified. */
AppFlashErase(snum) /* erase specified sector */
int snum;
{
    ulong   oints;
    char    *base;
    int     ret, size;
    struct  flashinfo *fbnk;

    sectortoaddr(snum,&size,&base);
    fbnk = addrtobank(base);
    if (!fbnk)
        return(-1);
    oints = intsoff();
    ret = flasherase(fbnk,snum);
    intsrestore(oints);
    return(ret);
}


/* FlashCmd():
   Code that handles the user interface.  See FlashHelp[] below for usage.
*/
FlashCmd(argc,argv)
int argc;
char **argv;
{
    int     snum, ret;
    ulong   dest, src, oints;
    long    bytecnt, size, rslt;
    struct  flashinfo *fbnk;

    oints = intsoff();

    fbnk = &FlashBank[CurrentBank];
    ret = 0;

    if (strcmp(argv[1],"init") == 0)
        FlashInit();
    else if (strcmp(argv[1],"info") == 0)
        showflashinfo(fbnk);
    else if (strcmp(argv[1],"bank") == 0)  {
        int tmpbank;
        if (argc == 3) {
            tmpbank = atoi(argv[2]);
            if (tmpbank < FLASHBANKS)
                CurrentBank = tmpbank;
            printf("Subsequent flash ops apply to bank %d\n",CurrentBank);
        }
        else 
            printf("Current flash bank: %d\n",CurrentBank);
    }
    else if (strcmp(argv[1],"ewrite") == 0) {
        if (argc == 5) {
            dest = strtoul(argv[2],(char **)0,0);
            src = strtoul(argv[3],(char **)0,0);
            bytecnt = (long)strtoul(argv[4],(char **)0,0);
            if (flashewrite(fbnk,dest,src,bytecnt) == -1)
                printf("ewrite failed\n");
        }
        else
            ret = -1;
    }
    else if (strcmp(argv[1],"write") == 0) {
        if (argc == 5) {
            dest = strtoul(argv[2],(char **)0,0);
            src = strtoul(argv[3],(char **)0,0);
            bytecnt = (long)strtoul(argv[4],(char **)0,0);
            rslt = flashwrite(fbnk,dest,src,bytecnt);
            if (rslt == -1)
                printf("Write failed\n");
        }
        else
            ret = -1;
    }
    else if (strcmp(argv[1],"opw") == 0) {
        FlashProtectWindow = 2;
    }
    else if (strcmp(argv[1],"erase") == 0) {
        if (argc != 3)
            printf("Bad 'erase' arg count...");
        else if (strcmp(argv[2],"all") == 0)
            snum = ALL_SECTORS;
        else 
            snum = (int)strtoul(argv[2],(char **)0,0);

        rslt = flasherase(fbnk,snum);
        if (rslt == -1)
            printf("Erase failed\n");
    }
    else {
        ret = -1;
    }

    intsrestore(oints);
    return(ret);
}

NotUsed()
{
    printf("ERROR: flash operation not supported\n");
}

char *FlashHelp[] = {
    "Flash memory operations",
    "{op} [args]",
    "Ops...",
    "  opw",
    "  info",
    "  init",
    "  bank [#]",
    "  erase {# | all}",
    "  write {dest} {src} {byte_cnt}",
    "  ewrite {dest} {src} {byte_cnt}",
    0,
};

/* FlashInit():
   Initialize data structures for each bank of flash...
*/
FlashInit()
{
    int i, snum;
    uchar   *begin;
    struct  flashinfo *fbnk;

    CurrentBank = 0;
    snum = 0;

    /* Copy functions to ram space... */
    /* Note that this MUST be done when cache is disabled to assure that */
    /* the RAM is occupied by the designated block of code. */

    if (flashopload((ulong *)Flashtype29F040_8,
        (ulong *)EndFlashtype29F040_8,
        FlashTypeFbuf040,sizeof(FlashTypeFbuf040)) < 0)
        return(-1);
    if (flashopload((ulong *)Flasherase29F040_8,
        (ulong *)EndFlasherase29F040_8,
        FlashEraseFbuf040,sizeof(FlashEraseFbuf040)) < 0)
        return(-1);
    if (flashopload((ulong *)Flashewrite29F040_8,
        (ulong *)EndFlashewrite29F040_8,
        FlashEwriteFbuf040,sizeof(FlashEwriteFbuf040)) < 0)
        return(-1);
    if (flashopload((ulong *)Flashwrite29F040_8,
        (ulong *)EndFlashwrite29F040_8,
        FlashWriteFbuf040,sizeof(FlashWriteFbuf040)) < 0)
        return(-1);

    if (flashopload((ulong *)Flashtype29F800B_16,
        (ulong *)EndFlashtype29F800B_16,
        FlashTypeFbuf800,sizeof(FlashTypeFbuf800)) < 0)
        return(-1);
    if (flashopload((ulong *)Flasherase29F800B_16,
        (ulong *)EndFlasherase29F800B_16,
        FlashEraseFbuf800,sizeof(FlashEraseFbuf800)) < 0)
        return(-1);
    if (flashopload((ulong *)Flashewrite29F800B_16,
        (ulong *)EndFlashewrite29F800B_16,
        FlashEwriteFbuf800,sizeof(FlashEwriteFbuf800)) < 0)
        return(-1);
    if (flashopload((ulong *)Flashwrite29F800B_16,
        (ulong *)EndFlashwrite29F800B_16,
        FlashWriteFbuf800,sizeof(FlashWriteFbuf800)) < 0)
        return(-1);

    /* Initialize each bank of flash... */
    fbnk = &FlashBank[0];
    fbnk->id = AMD29F040;                       /* Device id. */
    fbnk->base = (uchar *)FLASH_BANK0_BASE_ADDR;/* Base address of bank. */
    fbnk->end = fbnk->base + 0x7ffff;           /* End address of bank. */
    fbnk->sectorcnt = 8;                        /* Number of sectors. */
    fbnk->width = 1;                            /* Width (in bytes). */
    fbnk->fltype = (int(*)())FlashTypeFbuf040;      /* Flashtype(). */
    fbnk->flerase = (int(*)())FlashEraseFbuf040;    /* Flasherase(). */
    fbnk->flwrite = (int(*)())FlashWriteFbuf040;    /* Flashwrite(). */
    fbnk->flewrite = (int(*)())FlashEwriteFbuf040;  /* Flashewrite(). */
    fbnk->sectors = sinfo040;
    begin = fbnk->base;
    for(i=0;i<fbnk->sectorcnt;i++,snum++) {
        sinfo040[i].snum = snum;
        sinfo040[i].size = SectorSizes29F040_8[i];
        sinfo040[i].begin = begin;
        sinfo040[i].end =
            sinfo040[i].begin + sinfo040[i].size - 1;
        /* All sectors of bank 0 whose base is less than FLASH_PROTECT_SIZE */
        /* are marked as protected... */
        if (begin < (uchar *)(FLASH_BANK0_BASE_ADDR + FLASH_PROTECT_SIZE))
            sinfo040[i].protected = 1;
        else
            sinfo040[i].protected = 0;
        
        begin += SectorSizes29F040_8[i];
    }

    fbnk = &FlashBank[1];
    fbnk->id = AMD29F800B;                      /* Device id. */
    fbnk->base = (uchar *)FLASH_BANK1_BASE_ADDR;/* Base address of bank. */
    fbnk->end = fbnk->base + 0xfffff;           /* End address of bank. */
    fbnk->sectorcnt = 19;                       /* Number of sectors. */
    fbnk->width = 2;                            /* Width (in bytes). */
    fbnk->fltype = (int(*)())FlashTypeFbuf800;      /* Flashtype(). */
    fbnk->flerase = (int(*)())FlashEraseFbuf800;    /* Flasherase(). */
    fbnk->flwrite = (int(*)())FlashWriteFbuf800;    /* Flashwrite(). */
    fbnk->flewrite = (int(*)())FlashEwriteFbuf800;  /* Flashewrite(). */
    fbnk->sectors = sinfo800;               /* Pointer to sector size table. */
    begin = fbnk->base;
    for(i=0;i<fbnk->sectorcnt;i++,snum++) {
        sinfo800[i].snum = snum;
        sinfo800[i].size = SectorSizes29F800B_16[i];
        sinfo800[i].begin = begin;
        sinfo800[i].end =
            sinfo800[i].begin + sinfo800[i].size - 1;
        sinfo800[i].protected = 0;
        begin += SectorSizes29F800B_16[i];
    }

    if (FLASHBANKS < 3)
        return(0);

    /* This is a TFS FLASH/RAM bank... */
    fbnk = &FlashBank[2];
    fbnk->id = FLASHRAM;                    /* Device id. */
    fbnk->base = (uchar *)FLASHRAM_BASE;    /* Base address of bank. */
    fbnk->end = (uchar *)FLASHRAM_END;      /* End address of bank. */
    fbnk->sectorcnt = (FLASHRAM_SIZE/FLASHRAM_SSIZE);/* Number of sectors. */
    fbnk->width = 0;                        /* Width (in bytes). */
    fbnk->fltype = NotUsed;                 /* Flashtype() function. */
    fbnk->flerase = NotUsed;                /* Flasherase() function. */
    fbnk->flwrite = NotUsed;                /* Flashwrite() function. */
    fbnk->flewrite = NotUsed;               /* Flashewrite() function. */
    fbnk->sectors = sinfoRAM;               /* Pointer to sector size table. */
    begin = fbnk->base;
    for(i=0;i<fbnk->sectorcnt;i++,snum++) {
        sinfoRAM[i].snum = snum;
        sinfoRAM[i].size = FLASHRAM_SSIZE;
        sinfoRAM[i].begin = begin;
        sinfoRAM[i].end = sinfoRAM[i].begin + sinfoRAM[i].size - 1;
        sinfoRAM[i].protected = 0;
        begin += FLASHRAM_SSIZE;
    }
    return(0);
}

/* addrtosector():
    Incoming address is translated to sector number, size of sector
    and base of sector.
    Return 0 if successful; else -1.
*/
addrtosector(addr,sector,size,base)
uchar   *addr, **base;
int     *sector, *size;
{
    struct flashinfo *fbnk;
    struct  sectorinfo *sinfo;
    int     dev, sec, i;

    sec = 0;
    for(dev=0;dev<FLASHBANKS;dev++) {
        fbnk = &FlashBank[dev];
        for(i=0;i<fbnk->sectorcnt;i++,sec++) {
            sinfo = &fbnk->sectors[i];
            if ((addr >= sinfo->begin) && (addr <= sinfo->end)) {
                if (sector) {
                    *sector = sec;
                }
                if (base) {
                    *base = sinfo->begin;
                }
                if (size) {
                    *size = sinfo->size;
                }
                return(0);
            }
        }
    }
    printf("addrtosector(0x%x) failed\n",addr);
    return(-1);
}

struct flashinfo *
addrtobank(addr)
uchar   *addr;
{
    struct flashinfo *fbnk;
    struct  sectorinfo *sinfo;
    int     dev, i;

    for(dev=0;dev<FLASHBANKS;dev++) {
        fbnk = &FlashBank[dev];
        if ((addr >= fbnk->base) && (addr <= fbnk->end))
            return(fbnk);
    }
    printf("addrtobank(0x%x) failed\n",addr);
    return(0);
}

sectortoaddr(sector,size,base)
uchar   **base;
int     sector, *size;
{
    struct flashinfo *fbnk;
    struct  sectorinfo *sinfo;
    int     dev, sec, i;

    sec = 0;
    for(dev=0;dev<FLASHBANKS;dev++) {
        fbnk = &FlashBank[dev];
        for(i=0;i<fbnk->sectorcnt;i++,sec++) {
            if (sec == sector) {
                sinfo = &fbnk->sectors[i];
                if (base) *base = sinfo->begin;
                if (size) *size = sinfo->size;
                return(0);
            }
        }
    }
    printf("sectortoaddr(%d) failed\n",sector);
    return(-1);
}

void
LowerFlashProtectWindow()
{
    if (FlashProtectWindow)
        FlashProtectWindow--;
}

#endif
