/* flash.h:
   Header file for use with 29F800B for 16 bit mode.
*/
/* FLASHFUNCSIZE:
    Size of the array used by the flash operations to copy functions into
    RAM space for execution out of non-flash memory.
*/
#define FLASH_LOCK_SUPPORTED    1

#define FLASHFUNCSIZE       320

#define FLASH_TIMEOUT       1000000

/* Manufacturer and device ids... */
#define INTEL28F800B    0x008988C1
#define INTEL28F160B    0x008988C3
#define INTEL28F320B    0x008988C5

#define WIDTH           2
#define WIDTH_IN_BYTES  2
#define WIDTH_IN_BITS   16
#define WIDTH_MASK      1
#define ftype               volatile unsigned short
#define FLASHLOCK           Flashlock16
#define ENDFLASHLOCK        EndFlashlock16
#define FLASHERASE          Flasherase16
#define ENDFLASHERASE       EndFlasherase16
#define FLASHWRITE          Flashwrite16
#define ENDFLASHWRITE       EndFlashwrite16
#define FLASHEWRITE         Flashewrite16
#define ENDFLASHEWRITE      EndFlashewrite16
#define FLASHTYPE           Flashtype16
#define ENDFLASHTYPE        EndFlashtype16
#define NotAligned(ptr)     ((long)ptr & 1)
#define Write_20_to_base()  (*(ftype *)(fdev->base) = 0x0020)
#define Write_40_to_base()  (*(ftype *)(fdev->base) = 0x0040)
#define Write_50_to_base()  (*(ftype *)(fdev->base) = 0x0050)
#define Write_60_to_base()  (*(ftype *)(fdev->base) = 0x0060)
#define Write_70_to_base()  (*(ftype *)(fdev->base) = 0x0070)
#define Write_90_to_base()  (*(ftype *)(fdev->base) = 0x0090)
#define Write_FF_to_base()  (*(ftype *)(fdev->base) = 0x00FF)
#define Write_d0_to_(add)   (*(ftype *)add = 0x00D0)
#define Write_01_to_(add)   (*(ftype *)add = 0x0001)
#define Write_2f_to_(add)   (*(ftype *)add = 0x002f)
#define Read_0000()         (*(ftype *)(fdev->base+(0x0000<<1)))
#define Read_0001()         (*(ftype *)(fdev->base+(0x0001<<1)))
#define Read_5555()         (*(ftype *)(fdev->base+(0x5555<<1)))
#define Is_ff(add)          (*(ftype *)add == 0xffff)
#define Is_not_ff(add)      (*(ftype *)add != 0xffff)

#define Fwrite(to,frm)      (*(ftype *)to = *(ftype *)frm)
#define Is_Equal(p1,p2)     (*(ftype *)p1 == *(ftype *)p2)
#define Is_Not_Equal(p1,p2) (*(ftype *)p1 != *(ftype *)p2)
