/* This file contains all of the flash support code that does not need
   to be relocated to RAM.  Two separate files (flash.c and flashpic.c)
   are maintained because under certain compilers, they may need to be
   compiled with different options to be made position independent.

   NOTE: THESE FUNCTIONS ARE NOT RE-ENTRANT!!!  All of the FLASH routines
   assume they can copy themselves into the array FlashFunc[]; hence, only
   one operation can be active at any time.
*/
#include "config.h"
#if INCLUDE_FLASH
#include "cpu.h"
#include "flash.h"

typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned long ulong;
typedef volatile unsigned char vuchar;
typedef volatile unsigned short vushort;
typedef volatile unsigned long vulong;
typedef volatile unsigned int vuint;
typedef volatile int vint;

extern int Flashtype16();
extern int EndFlashtype16();
extern int Flashwrite16();
extern int EndFlashwrite16();
extern int Flashewrite16();
extern int EndFlashewrite16();
extern int Flasherase16();
extern int EndFlasherase16();
int FlashOpError(), FlashWidthNotSupported();

/* FlashFunc[]:
   This array will contain the flash operation function that is executing.
   Recall that to operate on the flash, you cannot be executing out of it.
   The flash functions are copied here, then executed through the function
   pointer flashfunc which is set to point to FlashFunc.
*/
long    FlashFunc[FLASHFUNCSIZE];
int (*flashfunc)();

/* FlashProtectWindow:
   Must be set to allow any flash operation to be done on space assumed
   to be boot code.
*/
int FlashProtectWindow;

/* FlashBank[]:
   This structure contains all of the information that must be made available
   to the various flash operation commands.  It is initialized by flashtype()
   and used thereafter by the other operations.
*/
struct  flashinfo FlashBank[FLASHBANKS];

/* FlashNamId[]:
   Used to correlate between the ID and a string representing the name
   of the flash device.
*/
struct flashdesc FlashNamId[] = {
        AMD29F800B, "AMD-29F800B",
        AMD29F800T, "AMD-29F800T",
};

int SectorSizes800B[] = {
        0x4000, 0x2000, 0x2000, 0x8000,
        0x10000, 0x10000, 0x10000, 0x10000,
        0x10000, 0x10000, 0x10000, 0x10000,
        0x10000, 0x10000, 0x10000, 0x10000,
        0x10000, 0x10000, 0x10000
};

showflashtype(id)
ulong id;
{
    int i;

    for(i=0;i<sizeof FlashNamId/sizeof(struct flashdesc);i++) {
        if (id == FlashNamId[i].id) {
            printf("Device = %s\n",FlashNamId[i].desc);
            return(0);
        }
    }
    printf("Flash id 0x%04x not recognized\n",id);
    return(-1);
}

showflashinfo(fdev)
struct flashinfo *fdev;
{
    int i;

    if (showflashtype(fdev->id) < 0)
        return(-1);

    printf("  Base addr   : 0x%08x\n",fdev->base);
    printf("  Sectors     : %d\n",fdev->sectorcnt);
    printf("  Bank width  : %d\n",fdev->width);
    printf("  Sector     Begin       End        Size     SW-Protected?\n");
    for(i=0;i<fdev->sectorcnt;i++) {
        printf("    %2d    0x%08x  0x%08x  0x%06x      %s\n",
            i,fdev->sectors[i].begin,fdev->sectors[i].end,
            fdev->sectors[i].size,
            fdev->sectors[i].protected ? "yes" : " no");
    }
    return(0);
}

/* flashopload():
   Used by all flash operations to load the appropriate flash function into
   ram.  It first verifies that the request is not larger than the allocated
   area (FlashFunc[]), then it copies, and verifies the copy.  Finally,
   caches are flushed.
   Note that this function is copying code into data space with the intent
   that the code will be executed shortly.  This means that after the code
   is copied to data space the data cache MUST be flushed (to insure that the
   code is in physical memory) and the instruction cache MUST be invalidated
   (to insure that there is no instruction cached from a previous run of
   this function that may have copied different code to the data space).
   The generic calls to preFlashopload() and postFlashopload() are used
   to keep this function generic.
*/
flashopload(begin,end)
ulong   *begin, *end;
{
    extern  ulong preFlashopload(), postFlashopload();
    volatile ulong  *bp, *copy;
    int ret, mode;

    /* Verify space availability: */
    if (((int)end - (int)begin) >= sizeof FlashFunc) {
        printf("flashopload overflow ((0x%x-0x%x) > 0x%x)\n",
            end,begin,sizeof FlashFunc);
        return(-1);
    }

    ret = 0;
    mode = preFlashopload((char *)FlashFunc,
        (char *)(&FlashFunc[FLASHFUNCSIZE-1]));

    /* Copy function() to RAM, then verify: */
    copy = (ulong *)FlashFunc;
    bp = begin;
    while(bp <= end) {
        *copy = *bp;
        if (*copy++ != *bp++) {
            printf("flashopload failed\n");
            ret = -1;
            break;
        }
    }

    postFlashopload(mode,(char *)FlashFunc,
        (char *)(&FlashFunc[FLASHFUNCSIZE-1]));

    flashfunc = (int(*)())FlashFunc;
    return(ret);
}

/* flashtype():
   Copy the Flashtype() function to the array FlashFunc[], then use
   the function pointer flashfunc to call the routine relocated to
   RAM space.
*/
flashtype(fdev)
struct flashinfo *fdev;
{
    int ret;

    if (flashopload((ulong *)Flashtype16,(ulong *)EndFlashtype16) < 0)
        return(-1);
    ret = flashfunc(fdev);
    return(ret);
}

/* flasherase():
   Copy the Flasherase() function to the array FlashFunc[], then use
   the function pointer flashfunc to call the routine relocated to
   RAM space.
*/
flasherase(fdev,snum)
struct  flashinfo *fdev;
int snum;
{
    if (flashopload((ulong *)Flasherase16,(ulong *)EndFlasherase16) < 0)
        return(-1);
    return(flashfunc(fdev,snum));
}

/* flashwrite():
   Copy the Flashwrite() function to the array FlashFunc[], then use
   the function pointer flashfunc to call the routine relocated to
   RAM space.
   First make a few checks on the request, then write to flash if all
   checks succeed.
*/
flashwrite(fdev,dest,src,bytecnt)
struct  flashinfo *fdev;
uchar   *src, *dest;
long    bytecnt;
{
    int i, j, lowsector, highsector;
    register uchar  *dp, *sp, *edp;

    dp = dest;
    sp = src;
    edp = (dest + bytecnt) - 1;

    /* If outside the devices space, return failed.. */
    if ((edp < fdev->sectors[0].begin) ||
        (dp > fdev->sectors[fdev->sectorcnt-1].end)) {
        printf("flashwrite() failed: dest out of flash range\n");
        return(-1);
    }

    /* Make sure the destination is not within a protected sector */
    if (FlashProtectWindow == FLASH_PROTECT_WINDOW_CLOSED) {

        /* First determine the sectors that overlap with the */
        /* flash space to be written... */

        lowsector = highsector = -1;
        for(j=0;j<fdev->sectorcnt;j++) {
            if ((dp >= fdev->sectors[j].begin) &&
                (dp <= fdev->sectors[j].end))
                lowsector = j;
        }
        for(j=0;j<fdev->sectorcnt;j++) {
            if ((edp >= fdev->sectors[j].begin) &&
                (edp <= fdev->sectors[j].end))
                highsector = j;
        }
        if ((lowsector == -1) || (highsector == -1)) {
            printf("flashwrite() failed: can't find sector\n");
            return(-1);
        }

        /* Now that the range of affected sectors is known, */
        /* verify that those sectors are not protected... */
        for(j=lowsector;j<=highsector;j++) {
            if (fdev->sectors[j].protected) {
                printf("flashwrite() failed: sector protected\n");
                return(-1);
            }
        }
    }

    /* Now make sure that there is no attempt to transition a bit */
    /* in the affected range from 0 to 1...  A flash write can only */
    /* bring bits low (erase brings them  high). */
    while(dp < edp) {
        if ((*dp & *sp) != *sp) {
            printf("flashwrite() failed: bit 0->1 rqst denied.\n");
            return(-1);
        }
        dp++; 
        sp++;
    }
    if (flashopload((ulong *)Flashwrite16,(ulong *)EndFlashwrite16) < 0) {
        printf("flashopload() failed\n");
        return(-1);
    }

    return(flashfunc(fdev,dest,src,bytecnt));
}

/* flashewrite():
   Copy the Flashewrite() function to the array FlashFunc[], then use
   the function pointer flashfunc to call the routine relocated to
   RAM space.
*/
flashewrite(fdev,dest,src,bytecnt)
struct  flashinfo *fdev;
ulong   *src, *dest;
long    bytecnt;
{
    int i;

    /* Source and destination addresses must be long-aligned. */
    if (((int)src & 3) || ((int)dest & 3))
        return(-1);

    /* If the protection window is closed, then verify that no protected */
    /* sectors will be written over... */
    if (FlashProtectWindow == FLASH_PROTECT_WINDOW_CLOSED) {
        for (i=0;i<fdev->sectorcnt;i++) {
            if((((uchar *)dest) > (fdev->sectors[i].end)) ||
                (((uchar *)dest+bytecnt) < (fdev->sectors[i].begin)))
                continue;
            else
                if (fdev->sectors[i].protected)
                    return(-1);
        }
    }

    if (flashopload((ulong *)Flashewrite16,(ulong *)EndFlashewrite16) < 0)
        return(-1);
    return(flashfunc(fdev,dest,src,bytecnt));
}

AppFlashWrite(dest,src,bytecnt)
ulong   *src, *dest;
long bytecnt;
{
    ulong   oints;
    int ret;

    oints = intsoff();
    ret = flashwrite(&FlashBank[0],dest,src,bytecnt);
    intsrestore(oints);
    if (ret < 0)
        printf("AppFlashWrite(0x%x,0x%x,%d) failed\n", dest,src,bytecnt);
    return(ret);
}

AppFlashEraseAll()
{
    ulong   oints;
    int ret;

    oints = intsoff();
    ret = flasherase(&FlashBank[0],ALL_SECTORS);
    intsrestore(oints);
    return(ret);
}

/* Erase the flash sector specified. */
AppFlashErase(snum) /* erase specified sector */
int snum;
{
    ulong   oints;
    int     ret;

    oints = intsoff();
    ret = flasherase(&FlashBank[0],snum);
    intsrestore(oints);
    return(ret);
}

/* FlashCmd():
   Code that handles the user interface.  See FlashHelp[] below for usage.
*/
FlashCmd(argc,argv)
int argc;
char **argv;
{
    int snum, ret;
    ulong   dest, src, oints;
    long    bytecnt, size, rslt;
    struct  flashinfo *fbnk;
    static  bank = 0;

    oints = intsoff();

    fbnk = &FlashBank[bank];
    ret = 0;

    if (strcmp(argv[1],"init") == 0)
        FlashInit();
    else if (strcmp(argv[1],"info") == 0)
        showflashinfo(fbnk);
    else if (strcmp(argv[1],"bank") == 0)  {
        if (argc == 3) {
            bank = atoi(argv[2]);
            printf("Subsequent flash ops apply to bank %d\n",bank);
        }
        else 
            printf("Current flash bank: %d\n",bank);
    }
    else if (strcmp(argv[1],"ewrite") == 0) {
        if (argc == 5) {
            dest = strtoul(argv[2],(char **)0,0);
            src = strtoul(argv[3],(char **)0,0);
            bytecnt = (long)strtoul(argv[4],(char **)0,0);
            if (flashewrite(fbnk,dest,src,bytecnt) == -1)
                printf("ewrite failed\n");
        }
        else
            ret = -1;
    }
    else if (strcmp(argv[1],"write") == 0) {
        if (argc == 5) {
            dest = strtoul(argv[2],(char **)0,0);
            src = strtoul(argv[3],(char **)0,0);
            bytecnt = (long)strtoul(argv[4],(char **)0,0);
            rslt = flashwrite(fbnk,dest,src,bytecnt);
            if (rslt == -1)
                printf("Write failed\n");
        }
        else
            ret = -1;
    }
    else if (strcmp(argv[1],"opw") == 0) {
        FlashProtectWindow = 2;
    }
    else if (strcmp(argv[1],"erase") == 0) {
        if (argc != 3)
            printf("Bad 'erase' arg count...");
        else if (strcmp(argv[2],"all") == 0)
            snum = ALL_SECTORS;
        else 
            snum = (int)strtoul(argv[2],(char **)0,0);

        rslt = flasherase(fbnk,snum);
        if (rslt == -1)
            printf("Erase failed\n");
    }
    else {
        ret = -1;
    }

    intsrestore(oints);
    return(ret);
}

char *FlashHelp[] = {
    "Flash memory operations",
    "{op} [args]",
    "Ops...",
    "  opw",
    "  info",
    "  init",
    "  bank [#]",
    "  erase {# | all}",
    "  write {dest} {src} {byte_cnt}",
    "  ewrite {dest} {src} {byte_cnt}",
    0,
};

/* FlashInit():
   Initialize data structures for each bank of flash...
*/
FlashInit()
{
    int i;
    long    size;

    FlashBank[0].width = FLASH_BANK0_WIDTH;
    FlashBank[0].base = (unsigned char *)FLASH_BANK0_BASE_ADDR;
    FlashBankInit(&FlashBank[0]);

    /* Assume monitor resides in bank0 and that it uses the first 128K */
    /* of code space (actually it uses much less, but different options */
    /* within the monitor are configurable, so assume worst case). */
    /* These "monitor-owned" sectors should be marked as protected. */
    size = 0;
    for (i=0;((i<FlashBank[0].sectorcnt)&(size<FLASH_PROTECT_SIZE));i++) {
        FlashBank[0].sectors[i].protected = 1;
        size += FlashBank[0].sectors[i].size;
    }
    /* Additional flash memory banks would be initialized here... */
    return(0);
}

/* FlashBankInit():
   Initialize flash structures and determine flash device type.
*/
FlashBankInit(fbnk)
struct flashinfo *fbnk;
{
    int i;
    uchar   *begin;

    flashtype(fbnk);
    switch(fbnk->id) {
    case AMD29F800B:
        fbnk->sectorcnt = 19;
        begin = fbnk->base;
        for(i=0;i<19;i++) {
            fbnk->sectors[i].size = SectorSizes800B[i];
            fbnk->sectors[i].begin = begin;
            fbnk->sectors[i].end =
                fbnk->sectors[i].begin + fbnk->sectors[i].size - 1;
            fbnk->sectors[i].protected = 0;
            begin += SectorSizes800B[i];
        }
        break;
    default:
        printf("Unrecognized flashid: 0x%04x\n",fbnk->id);
        break;
    }
    return(0);
}

/* addrtosector():
    Incoming address is translated to sector number, size of sector
    and base of sector.
    Return 0 if successful; else -1.
*/
addrtosector(addr,sector,size,base)
uchar   *addr, **base;
int     *sector, *size;
{
    struct flashinfo *fbnk;
    struct  sectorinfo *sinfo;
    int     dev, sec, i;

    sec = 0;
    for(dev=0;dev<FLASHBANKS;dev++) {
        fbnk = &FlashBank[dev];
        for(i=0;i<fbnk->sectorcnt;i++,sec++) {
            sinfo = &fbnk->sectors[i];
            if ((addr >= sinfo->begin) && (addr <= sinfo->end)) {
                if (sector) {
                    *sector = sec;
                }
                if (base) {
                    *base = sinfo->begin;
                }
                if (size) {
                    *size = sinfo->size;
                }
                return(0);
            }
        }
    }
    printf("addrtosector(0x%x) failed\n",addr);
    return(-1);
}

sectortoaddr(sector,size,base)
uchar   **base;
int     sector, *size;
{
    struct flashinfo *fbnk;
    struct  sectorinfo *sinfo;
    int     dev, sec, i;

    sec = 0;
    for(dev=0;dev<FLASHBANKS;dev++) {
        fbnk = &FlashBank[dev];
        for(i=0;i<fbnk->sectorcnt;i++,sec++) {
            if (sec == sector) {
                sinfo = &fbnk->sectors[i];
                if (base) *base = sinfo->begin;
                if (size) *size = sinfo->size;
                return(0);
            }
        }
    }
    printf("sectortoaddr(%d) failed\n",sector);
    return(-1);
}

void
LowerFlashProtectWindow()
{
    if (FlashProtectWindow)
        FlashProtectWindow--;
}

int
FlashOpError()
{
    printf("Flash-op width index error\n");
    return(0);
}

int
FlashWidthNotSupported(fdev)
struct  flashinfo *fdev;
{
    printf("Flashops for %d-bit width not supported.\n",fdev->width*8);
    return(0);
}
#endif
