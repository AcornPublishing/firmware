/* xmodem.c:
 * Command to upload or download via XMODEM protocol.  Xmodem is quite
 * limited, but adequate for simple file up/down load.
 * This also supports XMODEM-1K and YMODEM.  YMODEM is an extension to XMODEM
 * that uses a 1K packet size, CRC and the first packet (seqno=0) contains
 * information about the file being downloaded (in partiuclar, the name).
 * YMODEM also supports BATCH downloads (multiple files downloaded in one
 * transaction).  This code supports incoming BATCH downloads (not tested
 * because I can't find any terminal emulators that do it), but not for 
 * uploads.
 *
 *  General notice:
 *  This code is part of a boot-monitor package developed as a generic base
 *  platform for embedded system designs.  As such, it is likely to be
 *  distributed to various projects beyond the control of the original
 *  author.  Please notify the author of any enhancements made or bugs found
 *  so that all may benefit from the changes.  In addition, notification back
 *  to the author will allow the new user to pick up changes that may have
 *  been made by other users after this version of the code was distributed.
 *
 *  Note1: the majority of this code was edited with 4-space tabs.
 *  Note2: as more and more contributions are accepted, the term "author"
 *         is becoming a mis-representation of credit.
 *
 *  Original author:    Ed Sutter
 *  Email:              esutter@lucent.com
 *  Phone:              908-582-2351
 */
#include "config.h"
#include "genlib.h"
#include "stddefs.h"
#include "flash.h"
#include "tfs.h"
#include "tfsprivate.h"
#include "cli.h"

#if INCLUDE_XMODEM

/* struct xinfo:
 * Used to contain information pertaining to the current transaction.
 * The structure is built by the command Xmodem, then passed to the other
 * support functions (Xup, Xdown, etc..) for reference and update.
 */
struct xinfo {
    uchar   sno;            /* Sequence number. */
    uchar   pad;            /* Unused, padding. */
    int     xfertot;        /* Running total of transfer. */
    int     pktlen;         /* Length of packet (128 or 1024). */
    int     pktcnt;         /* Running tally of number of packets processed. */
    int     filcnt;         /* Number of files transferred by ymodem. */
    long    size;           /* Size of upload. */
    ulong   flags;          /* Storage for various runtime flags. */
    ulong   base;           /* Starting address for data transfer. */
    ulong   dataddr;        /* Running address for data transfer. */
    int     errcnt;         /* Keep track of errors (used in verify mode). */
    char    *firsterrat;    /* Pointer to location of error detected when */
                            /* transfer is in verify mode. */
    char    fname[TFSNAMESIZE];
};

/* Runtime flags: */
#define USECRC  (1<<0)
#define VERIFY  (1<<1)
#define YMODEM  (1<<2)

/* Current xmodem operation: */
#define XNULL   0
#define XUP     1
#define XDOWN   2

/* X/Ymodem protocol: */
#define SOH     0x01
#define STX     0x02
#define EOT     0x04
#define ACK     0x06
#define NAK     0x15
#define CAN     0x18
#define ESC     0x1b

#define PKTLEN_128  128
#define PKTLEN_1K   1024

static int Xup(struct xinfo *);
static int Xdown(struct xinfo *);
static int getPacket(uchar *,struct xinfo *);
static int putPacket(uchar *,struct xinfo *);

char *XmodemHelp[] = {
    "Xmodem file transfer",
    "-[a:BdF:f:i:s:t:uvy]",
    "Options:",
    " -a{##}     address (overrides default of APPRAMBASE)",
#if INCLUDE_FLASH
    " -B         boot sector reload",
#endif
    " -c         use crc (default = checksum)",
    " -d         download",
#if INCLUDE_TFS
    " -F{name}   filename",
    " -f{flags}  file flags (see tfs)",
    " -i{info}   file info (see tfs)",
#endif
    " -s{##}     size (overrides computed size)",
    " -t{##}     address for xmodem trace buffer",
    " -u         upload",
    " -v         verify only",
#if INCLUDE_TFS
    " -y         use Ymodem extensions",
#endif
    "Notes:",
    " * Either -d or -u must be specified (-B implies -d).",
    " * XMODEM forces a 128-byte modulo on file size.  The -s option",
    "   can be used to override this when transferring a file to TFS.",
    " * File upload requires no address or size (size will be mod 128).",
    " * When using -B, it should be the ONLY command line option,",
    "   it's purpose is to reprogram the boot sector, so be careful!",
    (char *)0,
};

int
Xmodem(int argc,char *argv[])
{
#if INCLUDE_TFS
    TFILE   *tfp;
#endif
    char    *info, *flags;
    struct  xinfo xi;
    int opt, xop, newboot;

    xop = XNULL;
    newboot = 0;
    info = (char *)0;
    flags = (char *)0;
    MtraceInit(0,0);
    xi.fname[0] = 0;
    xi.size = 0;
    xi.flags = 0;
    xi.filcnt = 0;
    xi.pktlen = PKTLEN_128;
    xi.base = xi.dataddr = getAppRamStart();
    while ((opt=getopt(argc,argv,"a:Bci:f:dF:ks:t:uvy")) != -1) {
        switch(opt) {
        case 'a':
            xi.dataddr = xi.base = strtoul(optarg,(char **)0,0);
            break;
        case 'B':
            xop = XDOWN;
            newboot = 1;
            break;
        case 'c':
            xi.flags |= USECRC;
            break;
        case 'd':
            xop = XDOWN;
            break;
#if INCLUDE_TFS
        case 'F':
            strncpy(xi.fname,optarg,TFSNAMESIZE);
            break;
        case 'f':
            flags = optarg;
            break;
        case 'i':
            info = optarg;
            break;
#endif
        case 'k':
            xi.pktlen = PKTLEN_1K;
            break;
        case 's':
            xi.size = (ulong)strtoul(optarg,(char **)0,0);
            break;
        case 't':
            MtraceInit((char *)strtoul(optarg,(char **)0,0),99999999);
            break;
        case 'u':
            xop = XUP;
            break;
        case 'v':
            xi.flags |= VERIFY;
            break;
#if INCLUDE_TFS
        case 'y':
            xi.flags |= (YMODEM | USECRC);
            xi.pktlen = PKTLEN_1K;
            break;
#endif
        default:
            return(CMD_PARAM_ERROR);
        }
    }

    /* There should be no arguments after the option list. */
    if (argc != optind)
        return(CMD_PARAM_ERROR);

    if (xop == XUP) {
        if ((xi.flags & YMODEM) && !(xi.fname[0]))
            printf("Ymodem upload needs filename\n");
        else {
            if (xi.fname[0]) {  /* Causes -a and -s options to be ignored. */
#if INCLUDE_TFS
                tfp = tfsstat(xi.fname);
                if (!tfp) {
                    printf("%s: file not found\n",xi.fname);
                    return(CMD_FAILURE);
                }
                xi.base = xi.dataddr = (ulong)TFS_BASE(tfp);
                xi.size = TFS_SIZE(tfp);
#endif
            }
            rawon();
            Xup(&xi);
            rawoff();
        }
    }
    else if (xop == XDOWN) {
        long    tmpsize;

        if ((xi.flags & YMODEM) && (xi.fname[0]))
            printf("Ymodem download gets name from protocol, '%s' ignored\n",
                xi.fname);

        rawon();
        tmpsize = (long)Xdown(&xi);
        rawoff();
        if ((!xi.size) || (tmpsize < 0))
            xi.size = tmpsize;

#if INCLUDE_FLASH
#if INCLUDE_TFS
        if ((xi.fname[0]) && (xi.size > 0)) {
            int err;

            printf("Writing to file '%s'...\n",xi.fname);
            err = tfsadd(xi.fname,info,flags,(uchar *)xi.base,xi.size);
            if (err != TFS_OKAY) {
                printf("%s: %s\n",xi.fname,(char *)tfsctrl(TFS_ERRMSG,err,0));
                return(CMD_FAILURE);
            }
        }
        else
#endif
        if ((newboot) && (xi.size > 0)) {
            extern  int FlashProtectWindow;
            char    *bb;
            ulong   bootbase;

            bb = getenv("BOOTROMBASE");
            if (bb)
                bootbase = strtoul(bb,0,0);
            else
                bootbase = BOOTROM_BASE;

            FlashProtectWindow = 1;
            printf("Reprogramming boot @ 0x%lx from 0x%lx, %ld bytes.\n",
                bootbase,xi.base,xi.size);
            if (askuser("OK?")) {
                if (flashewrite(&FlashBank[0],(char *)bootbase,
                  (char *)xi.base,xi.size) == -1) {
                    printf("failed\n");
                    return(CMD_FAILURE);
                }
            }
        }
#endif
    }
    else
        return(CMD_PARAM_ERROR);
    return(CMD_SUCCESS);
}

/* putPacket():
 * Used by Xup to send packets.
 */
static int
putPacket(uchar *tmppkt, struct xinfo *xip)
{
    int     c, i;
    uchar   *cp;
    ushort  chksm;

    cp = (uchar *)&chksm;
    chksm = 0;
    
    if (xip->pktlen == PKTLEN_128)
        rputchar(SOH);
    else
        rputchar(STX);

    rputchar(xip->sno);
    rputchar((uchar)~(xip->sno));

    if (xip->flags & USECRC) {
        for(i=0;i<xip->pktlen;i++) {
            rputchar(*tmppkt);
            chksm = (chksm<<8)^xcrc16tab[(chksm>>8)^*tmppkt++];
        }
        /* An "endian independent way to extract the CRC bytes. */
        rputchar((char)(chksm >> 8));
        rputchar((char)chksm);
    }
    else {
        for(i=0;i<xip->pktlen;i++) {
            rputchar(*tmppkt);
            chksm = ((chksm+*tmppkt++)&0xff);
        }
        rputchar((uchar)(chksm&0x00ff));
    }
    c = getchar();          /* Wait for ack */

    /* If pktcnt == -1, then this is the first packet sent by
     * YMODEM (filename) and we must wait for one additional
     * character in the response.
     */
    if (xip->pktcnt == -1)
        c = getchar();
    return(c);
}

/* getPacket():
 * Used by Xdown to retrieve packets.
 */
static int
getPacket(uchar *tmppkt, struct xinfo *xip)
{
    int     i;
    char    *pkt;
    uchar   seq[2];

    getbytes(seq,2,1);
    Mtrace("*");
    if (xip->flags & VERIFY) {
        getbytes(tmppkt,xip->pktlen,1);
        for(i=0;i<xip->pktlen;i++) {
            if (tmppkt[i] != ((char *)xip->dataddr)[i]) {
                if (xip->errcnt++ == 0)
                    xip->firsterrat = (char *)(xip->dataddr+i);
            }
        }
        pkt = (char *)tmppkt;
    }
    else {
        getbytes((char *)xip->dataddr,xip->pktlen,1);
        pkt = (char *)xip->dataddr;
    }

    Mtrace("*");

    if (xip->flags & USECRC) {
        ushort  crc, xcrc;
        
        /* An "endian independent way to combine the CRC bytes. */
        crc  = (ushort)getchar() << 8;
        crc += (ushort)getchar();
        xcrc = xcrc16((uchar *)pkt,(ulong)(xip->pktlen));
        if (crc != xcrc) {
            rputchar(CAN);
            Mtrace("1 %04x != %04x",crc,xcrc);
            return(-1);
        }
    }
    else {
        uchar   csum, xcsum;

        xcsum = (uchar)getchar();
        Mtrace("*");
        csum = 0;
        for(i=0;i<xip->pktlen;i++)
            csum += *pkt++;
        if (csum != xcsum) {
            rputchar(CAN);
            Mtrace("2");
            Mtrace("2 %02x != %02x",csum,xcsum);
            return(-1);
        }
    }
    if ((uchar)seq[0] !=  xip->sno) {
        if ((xip->sno == 0x02) && (seq[0] == 0x01)) {   /* TeraTerm has a */
            xip->sno = 0x01;                            /* "peculiarity". */
            Mtrace("--TERABUG--");
        }
        else {
            rputchar(CAN);
            Mtrace("3 %02x != %02x",seq[0],xip->sno);
            return(-1);
        }
    }
    if ((uchar)seq[1] != (uchar)~(xip->sno)) {
        rputchar(CAN);
        Mtrace("4 %02x != %02x",seq[1],(uchar)~(xip->sno));
        return(-1);
    }
    /* First packet of YMODEM contains information about the transfer: */
    /* FILENAME SP FILESIZE SP MOD_DATE SP FILEMODE SP FILE_SNO */
    /* Only the FILENAME is required and if others are present, then none */
    /* can be skipped. */
    if ((xip->flags & YMODEM) && (xip->pktcnt == 0)) {
        char *slash, *space, *fname;

        slash = strrchr((char *)(xip->dataddr),'/');
        space = strchr((char *)(xip->dataddr),' ');
        if (slash)
            fname = slash+1;
        else
            fname = (char *)(xip->dataddr);
        Mtrace("<fname=%s>",fname);
        if (space) {
            *space = 0;
            xip->size = atoi(space+1);
        }
        strcpy(xip->fname,fname);
        if (fname[0])
            xip->filcnt++;
    }
    else
        xip->dataddr += xip->pktlen;
    xip->sno++;
    xip->pktcnt++;
    xip->xfertot += xip->pktlen;
    rputchar(ACK);
    if (xip->flags & YMODEM) {
        if (xip->fname[0] == 0) {
            printf("\nRcvd %d file%c\n",
                xip->filcnt,xip->filcnt > 1 ? 's' : ' ');
            return(1);
        }
    }
    return(0);
}

/* Xup():
 * Called when a transfer from target to host is being made (considered
 * an upload).
 */
static int
Xup(struct xinfo *xip)
{
    uchar   c, buf[PKTLEN_128];
    int     done, pktlen;
    long    actualsize;

    Mtrace("Xup starting");

    actualsize = xip->size;

    if (xip->size & 0x7f) {
        xip->size += 128;
        xip->size &= 0xffffff80L;
    }

    printf("Upload %ld bytes from 0x%lx\n",xip->size,(ulong)xip->base);

    /* Startup synchronization... */
    /* Wait to receive a NAK or 'C' from receiver. */
    done = 0;
    while(!done) {
        c = (uchar)getchar();
        switch(c) {
        case NAK:
            done = 1;
            Mtrace("CSM");
            break;
        case 'C':
            xip->flags |= USECRC;
            done = 1;
            Mtrace("CRC");
            break;
        case 'q':   /* ELS addition, not part of XMODEM spec. */
            return(0);
        default:
            break;
        }
    }


    if (xip->flags & YMODEM) {
        Mtrace("SNO_0");
        xip->sno = 0;
        xip->pktcnt = -1;
        memset((char *)buf,0,PKTLEN_128);
        sprintf(buf,"%s",xip->fname);
        pktlen = xip->pktlen;
        xip->pktlen = PKTLEN_128;
        putPacket(buf,xip);
        xip->pktlen = pktlen;
    }

    done = 0;
    xip->sno = 1;
    xip->pktcnt = 0;
    while(!done) {
        c = (uchar)putPacket((uchar *)(xip->dataddr),xip);
        switch(c) {
        case ACK:
            xip->sno++;
            xip->pktcnt++;
            xip->size -= xip->pktlen;
            xip->dataddr += xip->pktlen;
            Mtrace("A");
            break;
        case NAK:
            Mtrace("N");
            break;
        case CAN:
            done = -1;
            Mtrace("C");
            break;
        case EOT:
            done = -1;
            Mtrace("E");
            break;
        default:
            done = -1;
            Mtrace("<%2x>",c);
            break;
        }
        if (xip->size <= 0) {
            rputchar(EOT);
            getchar();  /* Flush the ACK */
            break;
        }
        Mtrace("!");
    }

    Mtrace("Xup_almost");
    if ((done != -1) && (xip->flags & YMODEM)) { 
        xip->sno = 0;
        memset((char *)buf,0,PKTLEN_128);
        pktlen = xip->pktlen;
        xip->pktlen = PKTLEN_128;
        putPacket(buf,xip);
        xip->pktlen = pktlen;
    }
    Mtrace("Xup_done.");
    return(0);
}


/* Xdown():
 * Called when a transfer from host to target is being made (considered
 * an download).
 */

static int
Xdown(struct xinfo *xip)
{
    long    timeout;
    char    c, *tmppkt;
    int     done;

    tmppkt = malloc(PKTLEN_1K);
    if (!tmppkt) {
        Mtrace("malloc failed");
        return(-1);
    }

nextfile:
    if (xip->flags & YMODEM)
        xip->sno = 0x00;
    else
        xip->sno = 0x01;
    xip->pktcnt = 0;
    xip->errcnt = 0;
    xip->xfertot = 0;
    xip->firsterrat = 0;

    /* Startup synchronization... */
    /* Continuously send NAK or 'C' until sender responds. */
restart:
    Mtrace("Xdown");
    while(1) {
        if (xip->flags & USECRC)
            rputchar('C');
        else
            rputchar(NAK);
        timeout = LoopsPerSecond;
        while(!gotachar() && timeout)
            timeout--;
        if (timeout)
            break;
    }

    done = 0;
    Mtrace("Got response");
    while(done == 0) {
        c = (char)getchar();
        switch(c) {
        case SOH:               /* 128-byte incoming packet */
            Mtrace("O");
            xip->pktlen = 128;
            done = getPacket(tmppkt,xip);
            if (!done && (xip->pktcnt == 1) && (xip->flags & YMODEM))
                goto restart;
            break;
        case STX:               /* 1024-byte incoming packet */
            Mtrace("T");
            xip->pktlen = 1024;
            done = getPacket(tmppkt,xip);
            if (!done && (xip->pktcnt == 1) && (xip->flags & YMODEM))
                goto restart;
            break;
        case CAN:
            Mtrace("C");
            done = -1;
            break;
        case EOT:
            Mtrace("E");
            rputchar(ACK);
            if (xip->flags & YMODEM) {
#if INCLUDE_TFS
                if (!xip->size)
                    xip->size = xip->pktcnt * xip->pktlen;
                if (xip->fname[0])
                    tfsadd(xip->fname,0,0,(uchar *)xip->base,xip->size);
                xip->dataddr = xip->base;
#endif
                goto nextfile;
            }
            else {
                done = xip->xfertot;
                printf("\nRcvd %d pkt%c (%d bytes)\n",xip->pktcnt,
                        xip->pktcnt > 1 ? 's' : ' ',xip->xfertot);
            }
            break;
        case ESC:       /* User-invoked abort */
            Mtrace("X");
            done = -1;
            break;
        default:
            Mtrace("<%02x>",c);
            done = -1;
            break;
        }
        Mtrace("!");
    }
    if (xip->flags & VERIFY) {
        if (xip->errcnt)
            printf("%d errors, first at 0x%lx\n",
                xip->errcnt,(ulong)(xip->firsterrat));
        else
            printf("verification passed\n");
    }
    free(tmppkt);
    return(done);
}


#endif
