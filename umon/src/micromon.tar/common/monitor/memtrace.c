/* memtrace.c:
 *  This file contains CLI and API code to support a simple memory trace
 *  capability that allows application developers to call mon_memtrace()
 *  with a "printf-like" formatted arglist and the formatted string is
 *  put into a circular buffer in some allocated RAM space.
 *  The circular buffer is established by "mtrace cfg" command, then all
 *  subsequent calls to mon_memtrace() will have the formatted string
 *  destined for that buffer.
 *
 *  To keep the output formatted clean, the user of mon_memtrace() should
 *  not include any line-feeds in the string.  Each time mon_memtrace() is
 *  called, a line feed and sequence number is prepended to the string.
 *  This allows the dump to simply run through the buffer using putchar().
 *
 *  Both the mon_memtrace() API function and the dump facility in the CLI
 *  will deal with buffer wrapping.
 *
 *  General notice:
 *  This code is part of a boot-monitor package developed as a generic base
 *  platform for embedded system designs.  As such, it is likely to be
 *  distributed to various projects beyond the control of the original
 *  author.  Please notify the author of any enhancements made or bugs found
 *  so that all may benefit from the changes.  In addition, notification back
 *  to the author will allow the new user to pick up changes that may have
 *  been made by other users after this version of the code was distributed.
 *
 *  Note1: the majority of this code was edited with 4-space tabs.
 *  Note2: as more and more contributions are accepted, the term "author"
 *         is becoming a mis-representation of credit.
 *
 *  Original author:    Ed Sutter
 *  Email:              esutter@lucent.com
 *  Phone:              908-582-2351
 */

#include "config.h"
#include "stddefs.h"
#include "genlib.h"
#include "cli.h"

#if INCLUDE_MEMTRACE

/* struct mtInfo:
 *  This structure is at the base of the memory space allocated for
 *  the print buffer.  The control structure is part of the print buffer
 *  because the print buffer is assumed to be outside of the bss area
 *  of the monitor; hence, if a reset occurs and the monitor clears out
 *  its bss space, this structure will still be accessible and contain
 *  the data prior to the reset.
 *  So, to initialize a memory trace buffer use...
 *       mtrace cfg BASE SIZE
 *  and to re-establish the trace after a reset, use...
 *       mtrace mip BASE
 */
struct mtInfo {
    char *base;     /* Base of ram space allocated for print buffer. */
    char *ptr;      /* Running pointer into circular print buffer. */
    char *end;      /* End of ram space allocated. */
    int sno;        /* Sequence number of Mtrace() call. */
    int wrap;       /* Wrap counter. */
};

struct mtInfo *Mip;

/* Mtrace():
 * Memory trace... This function can be used to place some trace statements
 * (readable text) in some memory location specified by the
 * setting of mtracebuf.  This was originally written for debugging Xmodem
 * because you can't use printf() since the protocol is using the serial 
 * port.  I have since pulled it out of the Xmodem.c file and placed it in
 * generally accessible space so that it can be made available to the
 * application code and other monitor code.
 */
void
Mtrace(format,arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12)
char    *format;
long    arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12;
{
    if (!Mip)
        return;

    Mip->ptr += sprintf(Mip->ptr,"\n<%04d> ",Mip->sno++);
    Mip->ptr += sprintf(Mip->ptr,format,
        arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12);

    if (Mip->ptr >= Mip->end) {
        Mip->ptr = Mip->base;
        Mip->wrap++;
    }
    return;
}

void
MtraceInit(char *base, int size)
{
    if (size < 256)
        return;

    Mip = (struct mtInfo *)base;
    Mip->ptr = base + sizeof(struct mtInfo);
    Mip->base = Mip->ptr;
    Mip->end = (Mip->base + size - 128);
    Mip->sno = 1;
    Mip->wrap = 0;
    memset(Mip->base,0,size-sizeof(struct mtInfo));
}

char *MtraceHelp[] = {
    "Configure/Dump memory trace.",
    "{cmd} [cmd specific args]",
    "Cmd:",
    " cfg [{base} {size}]",
    " mip {base}",
    " log {msg}",
    " dump",
    0
};

int
MtraceCmd(int argc,char *argv[])
{
    char    *bp;

    if (!strcmp(argv[optind],"cfg")) {
        if (argc == optind + 3) {
            MtraceInit((char *)strtoul(argv[optind+1],0,0),
                strtoul(argv[optind+2],0,0));
        }
        else if (argc == optind + 1) {
            printf("Base: 0x%lx, End: 0x%lx\n",
                (ulong)Mip->base,(ulong)Mip->end);
            printf("Ptr:  0x%lx, Sno: %d\n",(ulong)Mip->ptr,Mip->sno);
            printf("Wrap: %d\n",Mip->wrap);
        }
        else
            return(CMD_PARAM_ERROR);
    }
    else if (!strcmp(argv[optind],"mip")) {
        Mip = (struct mtInfo *)strtoul(argv[optind+1],0,0);
    }
    else if (!strcmp(argv[optind],"log")) {
        Mtrace(argv[optind+1]);
    }
    else if (!strcmp(argv[optind],"dump")) {
        if (Mip->wrap) {
            printf("Buffer wrapped...\n");
            bp =  Mip->ptr;
            while(bp < Mip->end) {
                if (*bp == '\n') {
                    while((bp < Mip->end) && (*bp))
                        putchar(*bp++);
                    while(*bp)
                        putchar(*bp++);
                    break;
                }
                bp++;
            }
            bp =  Mip->base;
            while(bp < Mip->ptr)
                putchar(*bp++);
        }
        else {
            bp =  Mip->base;
            while((bp < Mip->end) && (*bp))
                putchar(*bp++);
            while(*bp)
                putchar(*bp++);
        }
        printf("\n\n");
    }
    else
        return(CMD_PARAM_ERROR);
    return(CMD_SUCCESS);
}

#else

void
MtraceInit(char *base, int size)
{
    printf("Mtrace() facility not built in.\n");
}

void
Mtrace()
{
    return;
}

#endif
