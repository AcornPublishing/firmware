/* ethernet.c:
 *  This code supports most of the generic ethernet/IP/ARP/UDP stuff.
 *
 *  General notice:
 *  This code is part of a boot-monitor package developed as a generic base
 *  platform for embedded system designs.  As such, it is likely to be
 *  distributed to various projects beyond the control of the original
 *  author.  Please notify the author of any enhancements made or bugs found
 *  so that all may benefit from the changes.  In addition, notification back
 *  to the author will allow the new user to pick up changes that may have
 *  been made by other users after this version of the code was distributed.
 *
 *  Note1: the majority of this code was edited with 4-space tabs.
 *  Note2: as more and more contributions are accepted, the term "author"
 *         is becoming a mis-representation of credit.
 *
 *  Original author:    Ed Sutter
 *  Email:              esutter@lucent.com
 *  Phone:              908-582-2351
 */
#include "config.h"
#include "endian.h"
#include "stddefs.h"
#include "genlib.h"

#if INCLUDE_ETHERNET
#include "cpuio.h"
#include "ether.h"
#include "monflags.h"
#include "cli.h"

void ShowEthernetStats(void);
void processMONCMD(struct ether_header *,ushort);
int  SendIPMonChar(uchar,int);

#if INCLUDE_DHCPBOOT
#define dhcpStateCheck()    dhcpStateCheck()
#define dhcpDisable()       dhcpDisable()
#define ShowDhcpStats()     ShowDhcpStats()
#else
#define dhcpStateCheck()
#define dhcpDisable()
#define ShowDhcpStats()
#endif

#if INCLUDE_TFTP
#define tftpStateCheck()    tftpStateCheck()
#define tftpInit()          tftpInit()
#define ShowTftpStats()     ShowTftpStats()
#else
#define tftpStateCheck()
#define tftpInit()
#define ShowTftpStats()
#endif


char *Etheradd, *IPadd;     /* Pointers to ascii addresses */
uchar BinIpAddr[4];         /* Space for binary IP address */
uchar BinEnetAddr[6];       /* Space for binary MAC address */
int EtherVerbose;           /* Verbosity flag (see ether.h). */
int EtherIsActive;          /* Non-zero if ethernet is up. */
int EtherIPERRCnt;          /* Number of IP errors detected. */
int EtherUDPERRCnt;         /* Number of UDP errors detected. */
int EtherXFRAMECnt;         /* Number of packets transmitted. */
int EtherRFRAMECnt;         /* Number of packets received. */
int EtherPollNesting;       /* Incremented when pollethernet() is called. */
int MaxEtherPollNesting;    /* High-warter mark of EtherPollNesting. */
int IPMonCmdActive;         /* Set if MONCMD is in progress. */
ushort  UniqueIpId;
struct  ether_header *IPMonCmdHdr;

/* Ports used by the monitor have defaults, but can be redefined using
 * shell variables:
 */
ushort  MoncmdPort;         /* shell var: MCMDPORT */
ushort  DhcpClientPort;     /* shell var: DCLIPORT */
ushort  DhcpServerPort;     /* shell var: DSRVPORT */
ushort  TftpPort;           /* shell var: TFTPPORT */
ushort  TftpSrcPort;        /* shell var: TFTPPORT */

uchar BroadcastAddr[] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };

struct  pinfo {
    int pnum;
    char    *pname;
} protocols[] = {
        { IP_IP,        "IP" },
        { IP_ICMP,  "ICMP" },
        { IP_IGMP,  "IGMP" },
        { IP_GGP,       "GGP" },
        { IP_TCP,       "TCP" },
        { IP_PUP,       "PUP" },
        { IP_UDP,       "UDP" },
        { 0,0 },
};

char *EtherHelp[] = {
    "Ethernet interface",
    "-[ps:v:V] {on | off | stat}",
    "Options...",
    " -p {1|0}     promiscuous mode (1=on)",
#ifdef SNOOP_ENABLED
    " -s {MAC}     print all packets to/from MAC (snoop)",
#endif
    " -t           self-test ethernet interface",
    " -v {flgs}    enable specific verbosity...",
    "    a: enable ARP trace",
    "    c: print csum errmsg",
    "    C: dump csum errpkt",
    "    d: enable DHCP trace",
    "    i: incoming packets (minus broadcast)",
    "    I: incoming packets (including broadcast)",
    "    o: outgoing packets",
    "    p: phy r/w accesses",
    "    t: enable TFTP trace",
    "    x: enable hex dump (requires i,I or o)",
    "    X: same as 'x' plus ascii",
    " -V        full verbosity (same as -v Iodtx)",
    0
};

int
Ether(int argc,char *argv[])
{
    int i, len, opt;

    /* Set up some defaults: */
    EtherVerbose = 0;

    while ((opt=getopt(argc,argv,"p:s:tv:V")) != -1) {
        switch(opt) {
        case 'p':   /* Promiscuous mode: accept all packets */
            if (*optarg == '1')
                enablePromiscuousReception();
            else
                disablePromiscuousReception();
            return(CMD_SUCCESS);
#ifdef SNOOP_ENABLED
        case 's':
            if (EtherToBin(optarg,snoopInfo.mac) < 0)
                return(CMD_FAILURE);
            enablePromiscuousReception();
            snoopInfo.on = 1;
            break;
#endif
        case 't':
            enselftest(1);
            return(CMD_SUCCESS);
        case 'V':
            EtherVerbose = SHOW_ALL;
            break;
        case 'v':
            len = strlen(optarg);
            for(i=0;i<len;i++) {
                switch(optarg[i]) {
                case 'a':
                    EtherVerbose |= SHOW_ARP;
                    EtherVerbose |= SHOW_BROADCAST;
                    break;
                case 'c':
                    EtherVerbose |= SHOW_BADCSUM;
                    break;
                case 'C':
                    EtherVerbose |= SHOW_BADCSUM;
                    EtherVerbose |= SHOW_BADCSUMV;
                    break;
                case 'i':
                    EtherVerbose |= SHOW_INCOMING;
                    break;
                case 'I':
                    EtherVerbose |= SHOW_INCOMING;
                    EtherVerbose |= SHOW_BROADCAST;
                    break;
                case 'o':
                    EtherVerbose |= SHOW_OUTGOING;
                    break;
                case 'p':
                    EtherVerbose |= SHOW_PHY;
                    break;
                case 'd':
                    EtherVerbose |= SHOW_DHCP;
                    break;
                case 't':
                    EtherVerbose |= SHOW_TFTP;
                    break;
                case 'x':
                    EtherVerbose |= SHOW_HEX;
                    break;
                case 'X':
                    EtherVerbose |= SHOW_HEX;
                    EtherVerbose |= SHOW_ASCII;
                    break;
                default:
                    printf("Bad 'v' arg\n");
                    return(CMD_PARAM_ERROR);
                }
            }
            break;
        default:
            return(CMD_PARAM_ERROR);
        }
    }

    if (argc != optind+1) {
        printf("Ethernet interface currently %sabled.\n",
            EtherIsActive ? "en" : "dis");
        return(CMD_SUCCESS);
    }

    if (!strcmp(argv[optind],"off")) {
        enreset();
        EtherIsActive = 0;
        return(CMD_SUCCESS);
    }
    else if (!strcmp(argv[optind],"stat")) {
        ShowEthernetStats();
        ShowEtherdevStats();
        ShowDhcpStats();
        ShowTftpStats();
        return(CMD_SUCCESS);
    }
    else if (strcmp(argv[optind],"on"))
        return(CMD_PARAM_ERROR);

    EthernetStartup(EtherVerbose,0);
    return(CMD_SUCCESS);
}

void
ShowEthernetStats(void)
{
    printf("Ethernet currently %s\n",EtherIsActive ? "active" : "off");
    printf("Transmitted frames:      %d\n",EtherXFRAMECnt);
    printf("Received frames:         %d\n",EtherRFRAMECnt);
    printf("IP hdr cksum errors:     %d\n",EtherIPERRCnt);
    printf("UDP pkt cksum errors:    %d\n",EtherUDPERRCnt);
    printf("Max pollethernet nest:   %d\n",MaxEtherPollNesting);
}

void
DisableEthernet(void)
{
    EtherIsActive = 0;
    IPMonCmdActive = 0;
    DisableEtherdev();
}

int
EthernetStartup(int verbose, int justreset)
{
    char *ipa;

    /* Initialize the retransmission delay calculator: */
    RetransmitDelay(DELAY_INIT_DHCP);

    EtherIPERRCnt = 0;
    EtherXFRAMECnt = 0;
    EtherRFRAMECnt = 0;
    EtherUDPERRCnt = 0;
    IPMonCmdActive = 0;
    EtherPollNesting = 0;
    EtherVerbose = verbose;
    MaxEtherPollNesting = 0;
    DHCPState = DHCPSTATE_NOTUSED;

    /* Setup all the IP addresses used by the monitor... */
    if (getAddresses() == -1)
        return(-1);

    /* If, after having set up all addresses, the content of the IPADD
     * shell variable is 0.0.0.0, then don't startup ethernet, just return
     * here.
     */
    ipa = getenv("IPADD");
    if (ipa) {
        if (!strcmp(ipa,"0.0.0.0"))
            return(-1);
    }
    else
        return(-1);

    /* Call device specific startup code: */
    EtherdevStartup(verbose);

    /* Initialize some TFTP state... */
    tftpInit();

#if INCLUDE_DHCPBOOT
    /* If EthernetStartup is called as a result of anything other than a
     * target reset, don't startup any DHCP/BOOTP transaction...
     */
    if (!justreset)
        dhcpDisable();
#endif
    EtherIsActive = 1;
    return(0);
}

/* pollethernet():
 *  Called at a few critical points in the monitor code to poll the
 *  ethernet device and keep track of the state of DHCP and TFTP.
 */
int
pollethernet(void)
{
    int pcnt;

    if ((!EtherIsActive) || (EtherPollNesting > 4))
        return(0);

    EtherPollNesting++;
    if (EtherPollNesting > MaxEtherPollNesting)
        MaxEtherPollNesting = EtherPollNesting;

    pcnt = polletherdev();
    dhcpStateCheck();
    tftpStateCheck();

    EtherPollNesting--;
    return(pcnt);
}

/* getAddresses():
 * Try getting ether/ip addresses from environment.
 * If not there, try getting them from some target-specific interface.
 * If not there, then get them from raw flash.
 * If not there, just use the hard-coded default.
 * Also, load all port numbers from shell variables, else default.
 *
 * Discussion regarding etheraddr[] and ipaddr[]...
 * The purpose of these two arrays is to provide a point in flash that is 
 * initialized to 0xff by the code (see reset.s).  This then allows some
 * other mechanism (bed of nails, etc..) to program these locations to some
 * other non-0xff value.  It is one of the alternatives provided by the
 * monitor code for storage of IP and MAC.
 */

int
getAddresses(void)
{
    char    *mcmdPort, *dcliPort, *dsrvPort, *tftpPort;

    /* Set up port numbers: */
    mcmdPort = getenv("MCMDPORT");
    dcliPort = getenv("DCLIPORT");
    dsrvPort = getenv("DSRVPORT");
    tftpPort = getenv("TFTPPORT");

    if (mcmdPort)
        MoncmdPort = (ushort)strtol(mcmdPort,0,0);
    else
        MoncmdPort = IPPORT_MONCMD;
    if (dcliPort)
        DhcpClientPort = (ushort)strtol(dcliPort,0,0);
    else
        DhcpClientPort = IPPORT_DHCP_CLIENT;
    if (dsrvPort)
        DhcpServerPort = (ushort)strtol(dsrvPort,0,0);
    else
        DhcpServerPort = IPPORT_DHCP_SERVER;
    if (tftpPort)
        TftpPort = (ushort)strtol(tftpPort,0,0);
    else
        TftpPort = IPPORT_TFTP;             /* 69   */
    TftpSrcPort = IPPORT_TFTPSRC;           /* 8888 */

    /* Retrieve MAC address and store in shell variable ETHERADD...
     * First see if the shell variable is already loaded.
     * If not see if some target-specific interface has it.
     * If not see if the the string is stored in raw flash (usually this
     *   storage is initialized in reset.s of the target-specific code).
     * Finally, as a last resort, use the default set up in config.h.
     */
    if (!(Etheradd = getenv("ETHERADD"))) {
        if (!(Etheradd = extGetEtherAdd())) {
            if (etheraddr[0] != 0xff)
                Etheradd = etheraddr;
            else {
                if (!strcmp(DEFAULT_ETHERADD,"ETHER_OFF")) {
                    printf("Ethernet disabled, must set MAC address\n");
                    return(-1);
                }
                printf("WARNING: using default MAC address.\n");
                Etheradd = DEFAULT_ETHERADD;
            }
        }
        setenv("ETHERADD",Etheradd);
    }

    /* Apply the same logic as above to the IP address... */
    if (!(IPadd = getenv("IPADD"))) {
        if (!(IPadd = extGetIpAdd())) {
            if (ipaddr[0] != 0xff)
                IPadd = ipaddr;
            else
                IPadd = DEFAULT_IPADD;
        }
        setenv("IPADD",IPadd);
    }

    /* Convert addresses to binary: */
#if INCLUDE_DHCPBOOT
    if (DhcpIPCheck(IPadd) == -1)
        return(-1);
#else
    if (IpToBin(IPadd,BinIpAddr) < 0)
        return(-1);
#endif
    if (EtherToBin(Etheradd,BinEnetAddr) < 0)
        return(-1);

    /* Initialize a unique number based on MAC: */
    UniqueIpId = xcrc16(BinEnetAddr,6);

    return(0);
}

/* processPACKET():
 *  This is the top level of the message processing after a complete
 *  packet has been received over ethernet.  It's all just a lot of
 *  parsing to determine whether the message is for this board's IP
 *  address (broadcast reception may be enabled), and the type of
 *  incoming protocol.  Once that is determined, the packet is either
 *  processed (TFTP, DHCP, ARP, ICMP-ECHO, etc...) or discarded.
 */
void
processPACKET(struct ether_header *ehdr, ushort size)
{
    int i;
    ushort  *datap, udpport;
    ulong   csum;
    struct ip *ihdr;
    struct Udphdr *uhdr;

    printPkt(ehdr,size,ETHER_INCOMING);

    if (ehdr->ether_type == ecs(ETHERTYPE_ARP)) {
        processARP(ehdr,size);
        return;
    }
    else if (ehdr->ether_type == ecs(ETHERTYPE_REVARP)) {
        processRARP(ehdr,size);
        return;
    }
    else if (ehdr->ether_type != ecs(ETHERTYPE_IP)) {
        return;
    }

    /* If we are NOT in the middle of a DHCP or BOOTP transaction, then
     * if destination MAC address is broadcast, return now.
     */
#if INCLUDE_DHCPBOOT
    if ((DHCPState == DHCPSTATE_NOTUSED) &&
        (!memcmp((char *)&(ehdr->ether_dhost),BroadcastAddr,6))) {
        return;
    }
#else
    if (!memcmp((char *)&(ehdr->ether_dhost),BroadcastAddr,6)) {
        return;
    }
#endif

    /* If source MAC address is this board, then assume we received our
     * own outgoing broadcast message...
     */
    if (!memcmp((char *)&(ehdr->ether_shost),BinEnetAddr,6)) {
        return;
    }

    ihdr = (struct ip *) (ehdr + 1);

    /* If not version # 4, return now... */
    if (getIP_V(ihdr->ip_vhl) != 4) {
        return;
    }

    /* IP address filtering:
     * At this point, the only packets accepted are those destined for this
     * board's IP address, plus, DHCP, if active.
     * also accepted.
     */
#if INCLUDE_DHCPBOOT
    if (memcmp((char *)&(ihdr->ip_dst),BinIpAddr,4)) {
        if (DHCPState == DHCPSTATE_NOTUSED)
            return;
        if (ihdr->ip_p != IP_UDP)
            return;
        uhdr = (struct Udphdr *)(ihdr+1);
        if (uhdr->uh_dport != ecs(DhcpClientPort)) {
            return;
        }
    }
#else
    if (memcmp((char *)&(ihdr->ip_dst),BinIpAddr,4)) {
        return;
    }
#endif

    /* Verify incoming IP header checksum...
     * Refer to section 3.2 of TCP/IP Illustrated, Vol 1 for details.
     */
    csum = 0;
    datap = (ushort *) ihdr;
    for (i=0;i<(sizeof(struct ip)/sizeof(ushort));i++,datap++)
        csum += *datap;
    csum = (csum & 0xffff) + (csum >> 16);
    if (csum != 0xffff) {
        EtherIPERRCnt++;
        if (EtherVerbose & SHOW_BADCSUM) {
            printf("IP csum error: 0x%04x != 0xffff\n",(ushort)csum);
            if (EtherVerbose & SHOW_BADCSUMV) {
                int overbose = EtherVerbose;

                EtherVerbose = SHOW_ALL;
                printPkt(ehdr,size,ETHER_INCOMING);
                EtherVerbose = overbose;
            }
        }   
        return;
    }
    
    if (ihdr->ip_p == IP_ICMP) {
        processICMP(ehdr,size);
        return;
    }
    else if (ihdr->ip_p == IP_TCP) {
        processTCP(ehdr,size);
        return;
    }
    else if (ihdr->ip_p != IP_UDP) {
        int j;

        SendICMPUnreachable(ehdr,ICMP_UNREACHABLE_PROTOCOL);
        if (!(EtherVerbose & SHOW_INCOMING))
            return;
        for(j=0;protocols[j].pname;j++) {
            if (ihdr->ip_p == protocols[j].pnum) {
                printf("%s not supported\n",
                    protocols[j].pname);
                return;
            }
        }
        printf("<%02x> protocol unrecognized\n", ihdr->ip_p);
        return;
    }

    uhdr = (struct Udphdr *)(ihdr+1);

    /* If non-zero, verify incoming UDP packet checksum...
     * Refer to section 11.3 of TCP/IP Illustrated, Vol 1 for details.
     */
    if (uhdr->uh_sum) {
        int     len;
        struct  UdpPseudohdr    pseudohdr;

        memcpy((char *)&pseudohdr.ip_src.s_addr,(char *)&ihdr->ip_src.s_addr,4);
        memcpy((char *)&pseudohdr.ip_dst.s_addr,(char *)&ihdr->ip_dst.s_addr,4);
        pseudohdr.zero = 0;
        pseudohdr.proto = ihdr->ip_p;
        pseudohdr.ulen = uhdr->uh_ulen;

        csum = 0;
        datap = (ushort *) &pseudohdr;
        for (i=0;i<(sizeof(struct UdpPseudohdr)/sizeof(ushort));i++)
            csum += *datap++;

        /* If length is odd, pad and add one. */
        len = ecs(uhdr->uh_ulen);
        if (len & 1) {
            uchar   *ucp;
            ucp = (uchar *)uhdr;
            ucp[len] = 0;
            len++;
        }
        len >>= 1;

        datap = (ushort *) uhdr;
        for (i=0;i<len;i++)
            csum += *datap++;
        csum = (csum & 0xffff) + (csum >> 16);
        if (csum != 0xffff) {
            EtherUDPERRCnt++;
            if (EtherVerbose & SHOW_BADCSUM) {
                printf("UDP csum error: 0x%04x != 0xffff\n",(ushort)csum);
                if (EtherVerbose & SHOW_BADCSUMV) {
                    int overbose = EtherVerbose;

                    EtherVerbose = SHOW_ALL;
                    printPkt(ehdr,size,ETHER_INCOMING);
                    printf("pseudohdr.ip_src: 0x%08lx\n",
                        pseudohdr.ip_src.s_addr);
                    printf("pseudohdr.ip_dst: 0x%08lx\n",
                        pseudohdr.ip_dst.s_addr);
                    printf("pseudohdr.zero: 0x%02x\n", pseudohdr.zero);
                    printf("pseudohdr.proto: 0x%02x\n", pseudohdr.proto);
                    printf("pseudohdr.ulen: 0x%04x\n", pseudohdr.ulen);
                    EtherVerbose = overbose;
                }
            }   
            return;
        }
    }
    udpport = ecs(uhdr->uh_dport);

    if (udpport == MoncmdPort)
        processMONCMD(ehdr,size);
#if INCLUDE_DHCPBOOT
    else if (udpport == DhcpClientPort)
        processDHCP(ehdr,size);
#endif
#if INCLUDE_TFTP
    else if ((udpport == TftpPort) || (udpport == TftpSrcPort))
        processTFTP(ehdr,size);
#endif
    else {
        if (EtherVerbose & SHOW_INCOMING) {
            uchar *cp;
            cp = (uchar *)&(ihdr->ip_src);
            printf("  Unexpected IP pkt from %d.%d.%d.%d ",
                cp[0],cp[1],cp[2],cp[3]);
            printf("(sport=0x%x,dport=0x%x)\n",
                ecs(uhdr->uh_sport),ecs(uhdr->uh_dport));
        }
        SendICMPUnreachable(ehdr,ICMP_UNREACHABLE_PORT);
    }
}

void
processMONCMD(struct ether_header *ehdr,ushort size)
{
    struct  ip *ihdr;
    struct  Udphdr *uhdr;
    char    *moncmd;
    uchar   *src;

    ihdr = (struct ip *)(ehdr + 1);
    uhdr = (struct Udphdr *)(ihdr + 1);
    moncmd = (char *)(uhdr + 1);
    IPMonCmdHdr = ehdr;
    src = (uchar *)&ihdr->ip_src;
    if (!MFLAGS_NOMONCMDPRN())
        printf("MONCMD (from %d.%d.%d.%d): ", src[0],src[1],src[2],src[3]);
    IPMonCmdActive = 1;
    docommand(moncmd,1);
    SendIPMonChar(0,1);
    stkchk("Post-sendIPmonchar");
    IPMonCmdActive = 0;
    writeprompt();
}

int
SendIPMonChar(uchar c, int done)
{
    static  int idx;
    static  char linebuf[128];
    int len, hdrlen;
    struct ether_header *te;
    struct ip *ti, *ri;
    struct Udphdr *tu, *ru;

    if (!IPMonCmdActive)
        return(0);

    /* While inside this function, clear the IPMonCmdActive flag to avoid
     * recursion if an error message is to be printed...
     */
    IPMonCmdActive = 0;

    if (idx >= 128) {
        printf("SendIPMonChar() overflow.\n");
        IPMonCmdActive = 1;
        return(-1);
    }

    linebuf[idx++] = c;
    if ((!done) && (c != '\n')) {
        IPMonCmdActive = 1;
        return(0);
    }

    hdrlen = sizeof(struct ip) + sizeof(struct Udphdr);
    len = idx + hdrlen ;

    te = EtherCopy(IPMonCmdHdr);

    ti = (struct ip *) (te + 1);
    ri = (struct ip *) (IPMonCmdHdr + 1);
    ti->ip_vhl = ri->ip_vhl;
    ti->ip_tos = ri->ip_tos;
    ti->ip_len = ecs(len);
    ti->ip_id = ipId();
    ti->ip_off = ri->ip_off;
    ti->ip_ttl = UDP_TTL;
    ti->ip_p = IP_UDP;
    memcpy((char *)&(ti->ip_src.s_addr),(char *)&(ri->ip_dst.s_addr),
        sizeof(struct in_addr));
    memcpy((char *)&(ti->ip_dst.s_addr),(char *)&(ri->ip_src.s_addr),
        sizeof(struct in_addr));

    tu = (struct Udphdr *) (ti + 1);
    ru = (struct Udphdr *) (ri + 1);
    tu->uh_sport = ru->uh_dport;
    tu->uh_dport = ru->uh_sport;
    tu->uh_ulen = ecs((ushort)(sizeof(struct Udphdr) + idx));
    memcpy((char *)(tu+1),linebuf,idx);

    ipChksum(ti);       /* Compute checksum of ip hdr */
    udpChksum(ti);      /* Compute UDP checksum */

    sendBuffer(MONRESPSIZE);
    idx = 0;
    IPMonCmdActive = 1;
    return(1);
}

/*
 *  printMem(p,n)
 */
void
printMem(uchar *base, int size)
{
    int i, col;
    uchar *cp, *cp1;

    if (!(EtherVerbose & SHOW_HEX))
        return;

    cp = cp1 = base;
    printf("  ");
    for(col=1,i=0;i<size;i++,col++) {
        printf("%02x ",*cp++);
        if ((col == 8) || (col == 16)) {
            printf("  ");
            if (col == 16) {
                col = 0;
                if (EtherVerbose & SHOW_ASCII)
                    prascii(cp1,16);
                cp1 += 16;
                printf("\n  ");
            }
        }
    }
    if ((EtherVerbose & SHOW_ASCII) && (col > 1)) {
        int space;

        space = (3 * (17 - col)) + (col <= 8 ? 4 : 2);
        while(space--)
            putchar(' ');
        prascii(cp1,col-1);
    }
    printf("\n");
    return;
}

/*
 *  printPkt(ehdr,len)
 */
void
printPkt(struct ether_header *ehdr, int len, int direction)
{
    struct  arphdr *arpp;
    char    *dir;

    /* Filter based on verbosity level... */
    if (direction == ETHER_INCOMING) {
        if (!(EtherVerbose & SHOW_INCOMING))
            return;
        dir = "INCOMING";
    }
    else if (direction == ETHER_OUTGOING) {
        if (!(EtherVerbose & SHOW_OUTGOING))
            return;
        dir = "OUTGOING";
    }
    else {
        printf("printPkt() direction error\n");
        dir = "???";
    }

    /* If direction is incoming and SHOW_BROADCAST is not set, then */
    /* return here if the destination host is broadcast. */
    if ((direction == ETHER_INCOMING) &&
        (!(EtherVerbose & SHOW_BROADCAST)) &&
        (!memcmp(ehdr->ether_dhost.ether_addr_octet,BroadcastAddr,6)))
        return;

    printf("\n%s PACKET (%d bytes):\n",dir,len);
    printMem((char *)ehdr,len);
    printf("  Destination Host = %02x:%02x:%02x:%02x:%02x:%02x\n",
        ehdr->ether_dhost.ether_addr_octet[0],
        ehdr->ether_dhost.ether_addr_octet[1],
        ehdr->ether_dhost.ether_addr_octet[2],
        ehdr->ether_dhost.ether_addr_octet[3],
        ehdr->ether_dhost.ether_addr_octet[4],
        ehdr->ether_dhost.ether_addr_octet[5]);

    printf("  Source Host =      %02x:%02x:%02x:%02x:%02x:%02x\n",
        ehdr->ether_shost.ether_addr_octet[0],
        ehdr->ether_shost.ether_addr_octet[1],
        ehdr->ether_shost.ether_addr_octet[2],
        ehdr->ether_shost.ether_addr_octet[3],
        ehdr->ether_shost.ether_addr_octet[4],
        ehdr->ether_shost.ether_addr_octet[5]);


    switch (ehdr->ether_type) {
    case ecs(ETHERTYPE_IP):
        printIp((struct ip *)(ehdr+1));
        break;
    case ecs(ETHERTYPE_PUP):
        printf("  Type = PUP\n");
        break;
    case ecs(ETHERTYPE_ARP):
        arpp = (struct arphdr *)(ehdr+1);
        printf("  Type = ARP %s from IP %d.%d.%d.%d)\n",
            arpp->operation == ecs(ARP_RESPONSE) ? "RESPONSE" : "REQUEST",
            arpp->senderia[0],arpp->senderia[1],
            arpp->senderia[2],arpp->senderia[3]);
        break;
    case ecs(ETHERTYPE_REVARP):
        printf("  Type = REVARP\n");
        break;
    default:
        printf("  Type = 0x%04x ???\n", ehdr->ether_type);
        break;
    }
}

/*
 *  printIp(p)
 */
int
printIp(struct ip *ihdr)
{
    int i;
    struct ip *icpy;
    char    buf[16], buf1[16];
    ulong   tmp[sizeof(struct ip)/2];

    /* Copy data to aligned memory space so printf doesn't crash. */
    memcpy((char *)tmp,(char *)ihdr,sizeof(struct ip));
    icpy = (struct ip *)tmp;
    printf("  IP:  vhl/tos  len    id     offset  ttl/proto  csum\n");
    printf("       x%02x%02x    x%04x  x%04x  x%04x   x%02x%02x      x%04x\n",
        icpy->ip_vhl,icpy->ip_tos, ecs(icpy->ip_len),
        ecs(icpy->ip_id), ecs(icpy->ip_off),
        icpy->ip_ttl, icpy->ip_p, ecs(icpy->ip_sum));

    printf("       src          dest\n");
    printf("       %s  %s\n",
        IpToString(icpy->ip_src.s_addr,buf),
        IpToString(icpy->ip_dst.s_addr,buf1));

    if (icpy->ip_p == IP_UDP) {
        printUdp((struct Udphdr *)(ihdr+1));
        return(0);
    }
    for(i=0;protocols[i].pname;i++) {
        if (icpy->ip_p == protocols[i].pnum) {
            printf("  Protocol: %s\n",protocols[i].pname);
            return(0);
        }
    }
    printf("  <%02x>: unknown IP protocol\n", icpy->ip_p);
    return (1);
}

/*
 *  printUdp(p)
 */
int
printUdp(struct Udphdr *p)
{
    ushort  dport, sport;

    dport = ecs(p->uh_dport);
    sport = ecs(p->uh_sport);

#if INCLUDE_DHCPBOOT
    if ((dport == DhcpServerPort) || (dport == DhcpClientPort)) {
        printDhcp(p);
        return(0);
    }
#endif
    printf("  UDP: sport dport ulen sum\n");
    printf("       %4d  %4d  %4d %4d\n",
        sport, dport, ecs(p->uh_ulen),ecs(p->uh_sum));
    return(0);
}

int
IpToBin(char *ascii,uchar *binary)
{
    int i, digit;
    char    *acpy;

    acpy = ascii;
    for(i=0;i<4;i++) {
        digit = (int)strtol(acpy,&acpy,10);
        if (((i != 3) && (*acpy++ != '.')) ||
            ((i == 3) && (*acpy != 0)) ||
            (digit < 0) || (digit > 255)) {
            printf("Misformed IP addr: %s\n",ascii);
            return(-1);
        }
        binary[i] = (uchar)digit;
    }
    return(0);
}

/* IpToString():
 *  Incoming ascii pointer is assumed to be pointing to at least 16
 *  characters of available space.  Conversion from long to ascii is done
 *  and string is terminated with NULL.  The ascii pointer is returned.
 */
char *
IpToString(ulong ipadd,char *ascii)
{
    uchar   *cp;

    cp = (uchar *)&ipadd;
    sprintf(ascii,"%d.%d.%d.%d",
        (int)cp[0],(int)cp[1],(int)cp[2],(int)cp[3]);
    return(ascii);
}

char *
EtherToString(uchar *etheradd,char *ascii)
{
    sprintf(ascii,"%02x:%02x:%02x:%02x:%02x:%02x",(int)etheradd[0],
        (int)etheradd[1],(int)etheradd[2],(int)etheradd[3],
        (int)etheradd[4],(int)etheradd[5]);
    return(ascii);
}

/* ipChksum():
 *  Compute the checksum of the IP header.
 *  The incoming pointer to an IP header is directly populated with
 *  the result.
 */
void
ipChksum(struct ip *ihdr)
{
    register int    i;
    register ushort *sp;
    register long   csum;

    csum = 0;
    ihdr->ip_sum = 0;
    sp = (ushort *) ihdr;
    for (i=0;i<((int)sizeof(struct ip)/(int)sizeof(ushort));i++,sp++) {
        csum += *sp;
        if (csum & 0x80000000)
            csum = (csum & 0xffff) + (csum >> 16);
    }
    while(csum >> 16)
        csum = (csum & 0xffff) + (csum >> 16);
    ihdr->ip_sum = ~csum;
}

/*  udpChksum():
 *  Compute the checksum of the UDP packet.
 *  The incoming pointer is to an ip header, the udp header after that ip
 *  header is directly populated with the result.
 *  Got part of this code out of Steven's TCP/IP Illustrated Volume 2.
 */
void
udpChksum(struct ip *ihdr)
{
    register int    i;
    register ushort *datap;
    register long   sum;
    int     len;
    struct  Udphdr *uhdr;
    struct  UdpPseudohdr    pseudohdr;

    uhdr = (struct Udphdr *)(ihdr+1);
    uhdr->uh_sum = 0;

    /* Note that optionally, the checksum can be forced to zero here,
     * so a return could replace the remaining code.
     * That would be kinda dangerous, but it is an option according to
     * the spec.
     */

    /* Start with the checksum of the pseudo header:
     * Note that we have to use memcpy because we don't know if the incoming
     * stream is aligned properly.
     */
    memcpy((char *)&pseudohdr.ip_src.s_addr,(char *)&ihdr->ip_src.s_addr,4);
    memcpy((char *)&pseudohdr.ip_dst.s_addr,(char *)&ihdr->ip_dst.s_addr,4);
    pseudohdr.zero = 0;
    pseudohdr.proto = ihdr->ip_p;
    pseudohdr.ulen = uhdr->uh_ulen;

    /* Get checksum of pseudo header: */
    sum = 0;
    datap = (ushort *) &pseudohdr;
    for (i=0;i<(sizeof(struct UdpPseudohdr)/sizeof(ushort));i++) {
        sum += *datap++;
        if (sum & 0x80000000)
            sum = (sum & 0xffff) + (sum >> 16);
    }

    len = ecs(uhdr->uh_ulen);
    datap = (ushort *) uhdr;

    /* If length is odd, pad with zero and add 1... */
    if (len & 1) {
        uchar   *ucp;
        ucp = (uchar *)uhdr;
        ucp[len] = 0;
        len++;
    }

    while(len) {
        sum += *datap++;
        if (sum & 0x80000000)
            sum = (sum & 0xffff) + (sum >> 16);
        len -= 2;
    }

    while(sum >> 16)
        sum = (sum & 0xffff) + (sum >> 16);

    uhdr->uh_sum = ~sum;
}

struct  ether_header *
EtherCopy(struct ether_header *re)
{
    struct  ether_header *te;

    te = (struct ether_header *) getXmitBuffer();
    memcpy((char *)&(te->ether_shost),(char *)&(re->ether_dhost),6);
    memcpy((char *)&(te->ether_dhost),(char *)&(re->ether_shost),6);
    te->ether_type = re->ether_type;
    return(te);
}

ushort
ipId(void)
{
    return(++UniqueIpId);
}


/* getTuneup():
 *  The DHCP, TFTP and ARP timeout & retry mechanism can be tuned based on
 *  the content of the shell variables DHCPRETRYTUNE, TFTPRETRYTUNE and
 *  ARPRETRYTUNE respectively.
 *  Return 0 if variable is not found, -1 if there is a detected error in
 *  the content of the shell variable; else 1 indicating that the three
 *  parameters have been loaded from the content of the shell variable.
 */
int
getTuneup(char *varname,int *rexmitdelay,int *giveupcount,int *rexmitdelaymax)
{
    char *vp, *colon1, *colon2;
    
    vp = getenv(varname);
    if (!vp)
        return(0);
    colon1 = strchr(vp,':');
    if (colon1) {
        colon2 = strchr(colon1+1,':');
        if (colon2) {
            *rexmitdelay = (int)strtol(vp,0,0);
            *giveupcount = (int)strtol(colon1+1,0,0);
            *rexmitdelaymax = (int)strtol(colon2+1,0,0);
            return(1);
        }
    }
    printf("Syntax error in %s\n",varname);
    return(-1);
}

/* RetransmitDelay():
 *  This function provides a common point for retransmission delay
 *  calculation.  It is an implementation "similar" to the recommendation
 *  made in the RFC 2131 (DHCP) section 4.1 paragraph #8...
 *
 *  The delay before the first retransmission is 4 seconds randomized by
 *  the value of a uniform random number chosen from the range -1 to +2.
 *  The delay before the next retransmission is 8 seconds randomized by
 *  the same number as previous randomization.  Each subsequent retransmission
 *  delay is doubled up to a maximum of 66 seconds.  Once a delay of 66
 *  seconds is reached, return that value for for 6 subsequent delay
 *  requests, then return RETRANSMISSION_TIMEOUT (-1) indicating that the
 *  requestor should give up.
 *
 *  The value of randomdelta will be 2, 1, 0 or -1 depending on the target's
 *  IP address.
 *
 *  The return values will be...
 *  4+randomdelta, 8+randomdelta, 16+randomdelta, etc... up to 64+randomdelta.
 *  Then after returning 64+randomdelta 6 times, return RETRANSMISSION_TIMEOUT.
 *
 *  NOTE: if DELAY_RETURN is the opcode, then RETRANSMISSION_TIMEOUT is
 *        never returned, once the max is reached, it is always the value
 *        returned;
 *        if DELAY_OR_TIMEOUT_RETURN is the opcode, then once maxoutcount
 *        reaches 6, RETRANSMISSION_TIMEOUT is returned.
 *
 *  NOTE1: this function supports the ability to modify the above-discussed
 *         parameters.  Start with DELAY_INIT_DHCP to set up the parameters
 *         discussed above; start with DELAY_INIT_XXXX for others.
 */
int
RetransmitDelay(int opcode)
{
    static int randomdelta;     /* Used to slightly randomize the delay.
                                 * Taken from the 2 least-significant-bits
                                 * of the IP address (range = -1 to 2).
                                 */
    static int rexmitdelay;     /* Doubled each time DELAY_INCREMENT
                                 * is called until it is greater than the
                                 * value stored in rexmitdelaymax.
                                 */
    static int rexmitdelaymax;  /* See rexmitdelay. */
    static int maxoutcount;     /* Number of times the returned delay has
                                 * reached its max.
                                 */
    static int giveupcount;     /* Once maxoutcount reaches this value, we
                                 * give up and return TIMEOUT.
                                 */
    int     rexmitstate;

    rexmitstate = RETRANSMISSION_ACTIVE;
    switch(opcode) {
        case DELAY_INIT_DHCP:       
            if (getTuneup("DHCPRETRYTUNE",&rexmitdelay,
                &giveupcount,&rexmitdelaymax) <= 0) {
                rexmitdelay = 4;
                giveupcount = 6;
                rexmitdelaymax = 64;
            }
            maxoutcount = 0;
            randomdelta = (int)(BinIpAddr[3] & 3) - 1;
            break;
        case DELAY_INIT_TFTP:
            if (getTuneup("TFTPRETRYTUNE",&rexmitdelay,
                &giveupcount,&rexmitdelaymax) <= 0) {
                rexmitdelay = 4;
                giveupcount = 3;
                rexmitdelaymax = 32;
            }
            maxoutcount = 0;
            randomdelta = (int)(BinIpAddr[3] & 3) - 1;
            break;
        case DELAY_INIT_ARP:
            if (getTuneup("ARPRETRYTUNE",&rexmitdelay,
                &giveupcount,&rexmitdelaymax) <= 0) {
                rexmitdelay = 1;    
                giveupcount = 0;
                rexmitdelaymax = 4;
            }
            maxoutcount = 0;
            randomdelta = 0;
            break;
        case DELAY_INCREMENT:
            if (rexmitdelay < rexmitdelaymax)
                rexmitdelay <<= 1;      /* double it. */
            else 
                maxoutcount++;

            if (maxoutcount > giveupcount)
                rexmitstate = RETRANSMISSION_TIMEOUT;
            break;
        case DELAY_OR_TIMEOUT_RETURN:
            if (maxoutcount > giveupcount)
                rexmitstate = RETRANSMISSION_TIMEOUT;
            break;
        case DELAY_RETURN:
            break;
        default:
            printf("\007TimeoutAlgorithm error 0x%x.\n",opcode);
            rexmitstate = RETRANSMISSION_TIMEOUT;
            break;
    }
    if (rexmitstate == RETRANSMISSION_TIMEOUT)
        return(RETRANSMISSION_TIMEOUT);
    else
        return(rexmitdelay+randomdelta);
}

#endif

/* EtherToBin():
 *  Convert ascii MAC address string to binary.  Note that this is outside
 *  the #if INCLUDE_ETHERNET because it is used by password.c.  This correctly
 *  implies that if there is no ethernet interface, then we need a different
 *  solution for the password backdoor!.
 */
int
EtherToBin(char *ascii,uchar *binary)
{
    int i, digit;
    char    *acpy;

    acpy = ascii;
    for(i=0;i<6;i++) {
        digit = (int)strtol(acpy,&acpy,16);
        if (((i != 5) && (*acpy++ != ':')) ||
            ((i == 5) && (*acpy != 0)) ||
            (digit < 0) || (digit > 255)) {
            printf("Misformed ethernet addr: %s\n",ascii);
            return(-1);
        }
        binary[i] = (uchar)digit;
    }
    return(0);
}

