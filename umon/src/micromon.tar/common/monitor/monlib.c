/* monlib.c:
 *  This file is part of the monitor code, but it is actually linked into
 *  the application.  It is built with (but not linked with) the monitor,
 *  then the monlib.o file is linked with the application.
 *  The only requirement on the application is that it know where the address
 *  of the monCom function is in the monitor's space.  
 *  The monCom function will be accessible in some "well-known" way (processor
 *  and platform dependent) so that this will not be a problem.
 *
 *  This monlib.c file is a replacement for the older mechanism that was
 *  a bit more error-prone...  A table of function pointers existed at some
 *  well-known location in the monitor, and the content of that table was
 *  assumed to also be "well-known".  This new version only assumes that the
 *  pointer to monCom is well-known; everything else will work based on the
 *  fact that the monitor and application will share the monlib.h header
 *  file.
 *
 *  General notice:
 *  This code is part of a boot-monitor package developed as a generic base
 *  platform for embedded system designs.  As such, it is likely to be
 *  distributed to various projects beyond the control of the original
 *  author.  Please notify the author of any enhancements made or bugs found
 *  so that all may benefit from the changes.  In addition, notification back
 *  to the author will allow the new user to pick up changes that may have
 *  been made by other users after this version of the code was distributed.
 *
 *  Note1: the majority of this code was edited with 4-space tabs.
 *  Note2: as more and more contributions are accepted, the term "author"
 *         is becoming a mis-representation of credit.
 *
 *  Original author:    Ed Sutter
 *  Email:              esutter@lucent.com
 *  Phone:              908-582-2351
 */
#include "monlib.h"

static unsigned short   (*_xcrc16)(), (*_crc32)();
static unsigned long    (*_intsoff)();
static struct   tfshdr  *(*_tfsnext)(), *(*_tfsstat)();
static long     (*_tfsctrl)(), (*_tfstell)();
static int      (*_tfsseek)(), (*_tfsgetline)(), (*_tfsipmod)();
static int      (*_tfsinit)(), (*_tfsadd)(), (*_tfsunlink)(), (*_tfsrun)();
static int      (*_tfsread)(), (*_tfswrite)(), (*_tfsopen)(), (*_tfsclose)();
static int      (*_printf)(), (*_cprintf)(), (*_sprintf)(), (*_monrestart)();
static int      (*_rputchar)(), (*_getchar)(), (*_gotachar)(), (*_getbytes)();
static int      (*_addcommand)(), (*_docommand)(), (*_pioget)(), (*_getline)();
static int      (*_tfsfstat)(), (*_tfseof)(), (*_decompress)();
static int      (*_tfstruncate)(), (*_heapextend)(), (*_tfslink)();
static char     *(*_getenv)(), *(*_malloc)(), *(*_version)();
static void     (*_intsrestore)(), (*_appexit)(), (*_free)();
static void     (*_setenv)(), (*_getargv)(), (*_pioset)(), (*_pioclr)();
static void     (*_profiler)(), (*_bbc)(), (*_memtrace)();

static void (*_monlock)(), (*_monunlock)();
static int (*_moncom)(int,void *,void *, void *);

/* monConnect():
 *  This must be the first call by the application code to talk to the
 *  monitor.  It is expecting three incoming function pointers:
 *
 *  mon:    Points to the monitor's _moncom function;
 *          This is a "well-known" address because the monitor and
 *          application code (two separately linked binaries) must
 *          know it.
 *  lock:   Points to a function in the application code that will be
 *          used by the monitor as a lock-out function (some kind of
 *          semaphore in the application).  
 *  unlock: Points to a function in the application code that will be
 *          used by the monitor as an un-lock-out function (undo whatever
 *          lock-out mechanism was done by lock).
 */
void
monConnect(int (*mon)(), void (*lock)(), void (*unlock)())
{
    /* Assign incoming lock and unlock functions... */
    _monlock = lock;
    _monunlock = unlock;

    /* If the mon pointer is non-zero, then make the mon_ connections... */
    if (mon) {

        _moncom = mon;

        /* Make the connections between "mon_" functions that are           */
        /* symbolically accessible by the application and the corresponding */
        /* functions that exists in the monitor.                            */
        _moncom(GETMONFUNC_PUTCHAR,&_rputchar,0,0);
        _moncom(GETMONFUNC_GETCHAR,&_getchar,0,0);
        _moncom(GETMONFUNC_GOTACHAR,&_gotachar,0,0);
        _moncom(GETMONFUNC_GETBYTES,&_getbytes,0,0);
        _moncom(GETMONFUNC_PRINTF,&_printf,0,0);
        _moncom(GETMONFUNC_CPRINTF,&_cprintf,0,0);
        _moncom(GETMONFUNC_SPRINTF,&_sprintf,0,0);
        _moncom(GETMONFUNC_RESTART,&_monrestart,0,0);
        _moncom(GETMONFUNC_GETENV,&_getenv,0,0);
        _moncom(GETMONFUNC_SETENV,&_setenv,0,0);
        _moncom(GETMONFUNC_TFSINIT,&_tfsinit,0,0);
        _moncom(GETMONFUNC_TFSADD,&_tfsadd,0,0);
        _moncom(GETMONFUNC_TFSUNLINK,&_tfsunlink,0,0);
        _moncom(GETMONFUNC_TFSRUN,&_tfsrun,0,0);
        _moncom(GETMONFUNC_TFSNEXT,&_tfsnext,0,0);
        _moncom(GETMONFUNC_TFSSTAT,&_tfsstat,0,0);
        _moncom(GETMONFUNC_TFSREAD,&_tfsread,0,0);
        _moncom(GETMONFUNC_TFSWRITE,&_tfswrite,0,0);
        _moncom(GETMONFUNC_TFSOPEN,&_tfsopen,0,0);
        _moncom(GETMONFUNC_TFSCLOSE,&_tfsclose,0,0);
        _moncom(GETMONFUNC_TFSSEEK,&_tfsseek,0,0);
        _moncom(GETMONFUNC_TFSGETLINE,&_tfsgetline,0,0);
        _moncom(GETMONFUNC_TFSIPMOD,&_tfsipmod,0,0);
        _moncom(GETMONFUNC_TFSCTRL,&_tfsctrl,0,0);
        _moncom(GETMONFUNC_ADDCOMMAND,&_addcommand,0,0);
        _moncom(GETMONFUNC_DOCOMMAND,&_docommand,0,0);
        _moncom(GETMONFUNC_GETARGV,&_getargv,0,0);
        _moncom(GETMONFUNC_CRC16,&_xcrc16,0,0);
        _moncom(GETMONFUNC_CRC32,&_crc32,0,0);
        _moncom(GETMONFUNC_PIOGET,&_pioget,0,0);
        _moncom(GETMONFUNC_PIOSET,&_pioset,0,0);
        _moncom(GETMONFUNC_PIOCLR,&_pioclr,0,0);
        _moncom(GETMONFUNC_INTSOFF,&_intsoff,0,0);
        _moncom(GETMONFUNC_INTSRESTORE,&_intsrestore,0,0);
        _moncom(GETMONFUNC_APPEXIT,&_appexit,0,0);
        _moncom(GETMONFUNC_MALLOC,&_malloc,0,0);
        _moncom(GETMONFUNC_FREE,&_free,0,0);
        _moncom(GETMONFUNC_GETLINE,&_getline,0,0);
        _moncom(GETMONFUNC_TFSFSTAT,&_tfsfstat,0,0);
        _moncom(GETMONFUNC_TFSEOF,&_tfseof,0,0);
        _moncom(GETMONFUNC_DECOMPRESS,&_decompress,0,0);
        _moncom(GETMONFUNC_TFSTRUNCATE,&_tfstruncate,0,0);
        _moncom(GETMONFUNC_HEAPXTEND,&_heapextend,0,0);
        _moncom(GETMONFUNC_PROFILER,&_profiler,0,0);
        _moncom(GETMONFUNC_TFSLINK,&_tfslink,0,0);
        _moncom(GETMONFUNC_BBC,&_bbc,0,0);
        _moncom(GETMONFUNC_MEMTRACE,&_memtrace,0,0);
        _moncom(GETMONFUNC_TFSTELL,&_tfstell,0,0);
        _moncom(GETMONFUNC_VERSION,&_version,0,0);
    }
}

/* ignorelock:
 * Used as a back-door to disable the monLock()/monUnlock() stuff.
 * This is useful if the application CLI falls through to the monitor's
 * CLI and you are using the "call" command in the monitor to execute some
 * function that has a mon_xxx function in it.  In this case, the fact that
 * the application has fallen through to the monitor means that the lock
 * is already active, so when the function tries to call some other mon_xxx
 * function it won't be able to because of the lock already being set.
 *
 * With these functions in the application space, the user can do the 
 * following:
 *  call %DisableLock
 *  call %Func_with_monXXX_in_it
 *  call %EnableLock
 *
 * Note that this is NOT to be used by application code, it is simply a
 * back-door mechanism to allow "call" from the CLI to invoke functions
 * that have mon_XXX functionality in them.
 */
static int ignorelock = 0;

void
DisableMonLock(void)
{
    ignorelock = 2;
}

void
EnableMonLock(void)
{
    ignorelock = 0;
}

/* monLock() & monUnlock():
 * Used by all of the wrapper functions below this point to call
 * the function pointed to by _monlock & _monunlock function pointers
 * (if set).
 * These functions must test both the function pointer and the state
 * of the ignorelock variable.  The function DisableMonLock() sets the
 * ignorelock variable to 2 because it is being executed through "call"
 * which means that the lock is active.  
 */
static void
monLock()
{
    if (_monlock) {
        switch(ignorelock) {
            case 1:
                break;
            case 2:
                ignorelock--;
                break;
            default:
                _monlock();
                break;
        }
    }
}

static void
monUnlock()
{
    if (_monunlock) {
        switch(ignorelock) {
            case 1:
                break;
            case 2:
                ignorelock--;
            default:
                _monunlock();
                break;
        }
    }
}

int
mon_com(int cmd, void *arg1, void *arg2, void *arg3)
{
    int ret;
    
    monLock();
    ret = _moncom(cmd,arg1,arg2,arg3);
    monUnlock();
    return(ret);
}

int
mon_putchar(unsigned char c)
{
    int ret;
    
    monLock();
    ret = _rputchar(c);
    monUnlock();
    return(ret);
}

int
mon_getchar(void)
{
    int ret;

    monLock();
    ret = _getchar();
    monUnlock();
    return(ret);
}

int
mon_gotachar(void)
{
    int ret;

    monLock();
    ret = _gotachar();
    monUnlock();
    return(ret);
}

int
mon_getbytes(char *buf,int cnt,int block)
{
    int ret;

    monLock();
    ret = _getbytes(buf,cnt,block);
    monUnlock();
    return(ret);
}

int
mon_printf(fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12)
char *fmt;
int a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12;
{
    int ret;

    monLock();
    ret = _printf(fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12);
    monUnlock();
    return(ret);
}

int
mon_cprintf(fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12)
char *fmt;
int a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12;
{
    int ret;

    monLock();
    ret = _cprintf(fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12);
    monUnlock();
    return(ret);
}

int
mon_sprintf(buf,fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12)
char *fmt, *buf;
int a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12;
{
    int ret;

    monLock();
    ret = _sprintf(buf,fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12);
    monUnlock();
    return(ret);
}

int
mon_restart(int val)
{
    int ret;

    monLock();
    ret = _monrestart(val);
    monUnlock();
    return(ret);
}

char *
mon_getenv(char *name)
{
    char *ret;

    monLock();
    ret = _getenv(name);
    monUnlock();
    return(ret);
}

void
mon_setenv(char *name,char *val)
{
    monLock();
    _setenv(name,val);
    monUnlock();
}

int
mon_tfsinit(void)
{
    int ret;

    monLock();
    ret = _tfsinit();
    monUnlock();
    return(ret);
}

int
mon_tfsadd(char *name, char *info, char *flags, unsigned char *src, int size)
{
    int ret;

    monLock();
    ret = _tfsadd(name,info,flags,src,size);
    monUnlock();
    return(ret);
}

int
mon_tfslink(char *src, char *target)
{
    int ret;

    monLock();
    ret = _tfslink(src,target);
    monUnlock();
    return(ret);
}

int
mon_tfsunlink(char *name)
{
    int ret;

    monLock();
    ret = _tfsunlink(name);
    monUnlock();
    return(ret);
}

int
mon_tfsrun(char **name,int verbose)
{
    int ret;

    monLock();
    ret = _tfsrun(name,verbose);
    monUnlock();
    return(ret);
}

struct tfshdr *
mon_tfsnext(struct tfshdr *fp)
{
    struct tfshdr *ret;

    monLock();
    ret = _tfsnext(fp);
    monUnlock();
    return(ret);
}

int
mon_tfstruncate(int tfd, long len)
{
    int ret;

    monLock();
    ret = _tfstruncate(tfd,len);
    monUnlock();
    return(ret);
}

int
mon_tfseof(int tfd)
{
    int ret;

    monLock();
    ret = _tfseof(tfd);
    monUnlock();
    return(ret);
}

int
mon_tfsfstat(char *name, struct tfshdr *fp)
{
    int ret;

    monLock();
    ret = _tfsfstat(name,fp);
    monUnlock();
    return(ret);
}

struct tfshdr *
mon_tfsstat(char *name)
{
    struct tfshdr *ret;

    monLock();
    ret = _tfsstat(name);
    monUnlock();
    return(ret);
}

int
mon_tfsread(int fd, char *buf, int cnt)
{
    int ret;

    monLock();
    ret = _tfsread(fd,buf,cnt);
    monUnlock();
    return(ret);
}

int
mon_tfswrite(int fd, char *buf, int cnt)
{
    int ret;

    monLock();
    ret = _tfswrite(fd,buf,cnt);
    monUnlock();
    return(ret);
}

int
mon_tfsopen(char *file,long flagmode,char *buf)
{
    int ret;

    monLock();
    ret = _tfsopen(file,flagmode,buf);
    monUnlock();
    return(ret);
}

int
mon_tfsclose(int fd,char *info)
{
    int ret;

    monLock();
    ret = _tfsclose(fd,info);
    monUnlock();
    return(ret);
}

int
mon_tfsseek(int fd, int offset, int whence)
{
    int ret;

    monLock();
    ret = _tfsseek(fd,offset,whence);
    monUnlock();
    return(ret);
}

int
mon_tfsgetline(int fd,char *bp,int max)
{
    int ret;

    monLock();
    ret = _tfsgetline(fd,bp,max);
    monUnlock();
    return(ret);
}

int
mon_tfsipmod(char *name,char *buf,int offset,int size)
{
    int ret;

    monLock();
    ret = _tfsipmod(name,buf,offset,size);
    monUnlock();
    return(ret);
}

long
mon_tfsctrl(int rqst,long arg1,long arg2)
{
    long    ret;

    monLock();
    ret = _tfsctrl(rqst,arg1,arg2);
    monUnlock();
    return(ret);
}

long
mon_tfstell(int fd)
{
    long    ret;

    monLock();
    ret = _tfstell(fd);
    monUnlock();
    return(ret);
}

int
mon_addcommand(struct monCommand *cmd)
{
    int ret;

    monLock();
    ret = _addcommand(cmd);
    monUnlock();
    return(ret);
}

int
mon_docommand(char *cmdline,int verbose)
{
    int ret;

    monLock();
    ret = _docommand(cmdline,verbose);
    monUnlock();
    return(ret);
}

void
mon_getargv(int *argc,char ***argv)
{
    monLock();
    _getargv(argc,argv);
    monUnlock();
}

unsigned short
mon_xcrc16(char *buf,long nbytes)
{
    unsigned short ret;

    monLock();
    ret = _xcrc16(buf,nbytes);
    monUnlock();
    return(ret);
}

int
mon_pioget(char port,int bitnum)
{
    int ret;

    monLock();
    ret = _pioget(port,bitnum);
    monUnlock();
    return(ret);
}

void
mon_pioset(char port,int bitnum)
{
    monLock();
    _pioset(port,bitnum);
    monUnlock();
}

void
mon_pioclr(char port,int bitnum)
{
    monLock();
    _pioclr(port,bitnum);
    monUnlock();
}

unsigned long
mon_intsoff(void)
{
    unsigned long ret;

    monLock();
    ret = _intsoff();
    monUnlock();
    return(ret);
}

void
mon_intsrestore(unsigned long msr)
{
    monLock();
    _intsrestore(msr);
    monUnlock();
}

void
mon_appexit(int val)
{
    monLock();
    _appexit(val);
    monUnlock();
}

char *
mon_malloc(int size)
{
    char *ret;

    monLock();
    ret = _malloc(size);
    monUnlock();
    return(ret);
}

void
mon_free(char *cp)
{
    monLock();
    _free(cp);
    monUnlock();
}

int
mon_getline(char *buf,int max,int ledit)
{
    int ret;

    monLock();
    ret = _getline(buf,max,ledit);
    monUnlock();
    return(ret);
}

int
mon_decompress(char *src,int srcsize,char *dest)
{
    int ret;

    monLock();
    ret = _decompress(src,srcsize,dest);
    monUnlock();
    return(ret);
}

int
mon_heapxtend(char *base,int size)
{
    int ret;

    monLock();
    ret = _heapextend(base,size);
    monUnlock();
    return(ret);
}

void
mon_bbc(char *filename, int lineno)
{
    _bbc(filename, lineno);
}

void
mon_profiler(void *pdata)
{
    _profiler(pdata);
}

void
mon_memtrace(fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12)
char *fmt;
int a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12;
{
    _memtrace(fmt,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12);
}

char *
mon_version(void)
{
    char *ret;

    monLock();
    ret = _version();
    monUnlock();
    return(ret);
}
