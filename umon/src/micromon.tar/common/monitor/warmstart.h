/* warmstart.h:
 *
 *  General notice:
 *  This code is part of a boot-monitor package developed as a generic base
 *  platform for embedded system designs.  As such, it is likely to be
 *  distributed to various projects beyond the control of the original
 *  author.  Please notify the author of any enhancements made or bugs found
 *  so that all may benefit from the changes.  In addition, notification back
 *  to the author will allow the new user to pick up changes that may have
 *  been made by other users after this version of the code was distributed.
 *
 *  Note1: the majority of this code was edited with 4-space tabs.
 *  Note2: as more and more contributions are accepted, the term "author"
 *         is becoming a mis-representation of credit.
 *
 *  Original author:    Ed Sutter
 *  Email:              esutter@lucent.com
 *  Phone:              908-582-2351
 */

/* Standard restart (warmstart) definitions used by monitor... */
#define EXCEPTION   (1<<4)
#define BREAKPOINT  (2<<4)
#define INITIALIZE  (3<<4)
#define SSTEP       (4<<4)
#define APPLICATION (5<<4)
#define MORESTART   (6<<4)
#define BAILOUT     (7<<4)
#define MISC        (8<<4)
#define APP_EXIT    (9<<4)
