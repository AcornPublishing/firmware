/* genlib.h:
 *  Header file for functions in genlib.c (and some others).
 *
 *  General notice:
 *  This code is part of a boot-monitor package developed as a generic base
 *  platform for embedded system designs.  As such, it is likely to be
 *  distributed to various projects beyond the control of the original
 *  author.  Please notify the author of any enhancements made or bugs found
 *  so that all may benefit from the changes.  In addition, notification back
 *  to the author will allow the new user to pick up changes that may have
 *  been made by other users after this version of the code was distributed.
 *
 *  Note1: the majority of this code was edited with 4-space tabs.
 *  Note2: as more and more contributions are accepted, the term "author"
 *         is becoming a mis-representation of credit.
 *
 *  Original author:    Ed Sutter
 *  Email:              esutter@lucent.com
 *  Phone:              908-582-2351
 */
#ifndef __INCgenlibh
#define __INCgenlibh

/* Some compilers consider sizeof() to be unsigned... */
#define sizeof (int)sizeof

extern int optind;
extern char *optarg;

extern int abs(int);
extern int atoi(char *);
extern int memcmp(char *, char *, int);
extern int strcmp(char *, char *);
extern int strncmp(char *, char *, int);
extern int strlen(char *);
extern int strspn(char *, char *);
extern int getopt(int,char **,char *);
extern char *memccpy(char *, char *, int, int);
extern char *memchr(char *, char, int);
extern char *memcpy(char *, char *, int);
extern char *memset(char *, char, int);
extern char *strcat(char *, char *);
extern char *strchr(char *, char);
extern char *strstr(char *, char *);
extern char *strcpy(char *, char *);
extern char *strncat(char *, char *, int);
extern char *strncpy(char *, char *, int);
extern char *strpbrk(char *, char *);
extern char *strrchr(char *, char);
extern char *strtok(char *, char *);
extern char *strtolower(char *string);
extern char *strtoupper(char *string);
extern long strtol(char *, char **, int);
extern unsigned short swap2(unsigned short);
extern unsigned long swap4(unsigned long);
extern unsigned long strtoul(char *, char **, int);
extern void getoptinit(void);

/* Included here, but not in genlib.c: */
extern int rputchar(char), getchar(), putchar(unsigned char);
extern int AddrToSym(int,unsigned long,char *,unsigned long *);
extern int printf(), sprintf(), cprintf();
extern int getbytes(char *,int,int);
extern int putbytes(char *,int);
extern int gotachar(void);
extern int getUsrLvl(void);
extern int setenv(char *,char *);
extern int shell_sprintf();
extern int getline(char *,int,int);
extern int getline_t(char *,int,int);
extern int getline_p(char *,int,int,char *);
extern int stkchk(char *);
extern int inRange(char *,int);
extern int More(void);
extern int validPassword(char *,int);
extern int askuser(char *);
extern int hitakey(void);
extern int getreg(char *,unsigned long *);
extern int putargv(int,char *);
extern int addrtosector(unsigned char *,int *,int *,unsigned char **);
extern int AppFlashWrite(unsigned long *,unsigned long *,long);
extern int AppFlashErase(int);
extern int flushDcache(char *,int);
extern int invalidateIcache(char *,int);
extern int pollConsole(char *);
extern int sectortoaddr(int,int *,unsigned char **);
extern int sectorProtect(char *,int);
extern int FlashInit(void);
extern int cacheInit(void);
extern int pioget(char,int);
extern int extendHeap(char *,int);
extern int decompress(char *,int,char *);
extern int RedirectionCheck(char *);
extern int docommand(char *, int);
extern int SymFileFd(int);
extern unsigned short xcrc16(unsigned char *buffer,unsigned long nbytes);
extern unsigned long crc32(unsigned char *,unsigned long);
extern unsigned long intsoff(void);
extern unsigned long getAppRamStart(void);
extern char *line_edit(char *);
extern char *malloc(int);
extern char *realloc(char *,int);
extern char *getenv(char *);
extern char *getpass(char *,char *,int);
extern char *getsym(char *,char *,int);
extern char *monVersion(void);
extern char *ExceptionType2String(int);
extern void Mtrace();
extern void MtraceInit(char *,int);
extern void monrestart(int);
extern void historylog(char *);
extern void free(char *);
extern void puts(char *);
extern void MonitorBuiltEnvSet(void);
extern void writeprompt(void);
extern void intsrestore(unsigned long);
extern void prascii(unsigned char *,int);
extern void cacheInitForTarget(void);
extern void exceptionAutoRestart(int);
extern void clrTmpMaxUsrLvl(int (*)());
extern void rawon(), rawoff();
extern void monHeader(int);
extern void mstatshowcom(void);
extern void CommandLoop(void);
extern void showregs(void), reginit(void);
extern void initUsrLvl(int);
extern void warmstart(int);
extern void coldstart(void);
extern void InitRemoteIO(void);
extern void appexit(int);
extern void pioset(char,int);
extern void pioclr(char,int);
extern void getargv(int *argc, char ***argv);
extern void init1(int), init2(void), init3(void);
extern void EnableBreakInterrupt(void);
extern void DisableBreakInterrupt(void);
extern void ctxMON(void), ctxAPP(void);
#if INCLUDE_REDIRECT
extern void RedirectCharacter(char);
extern void RedirectionCmdDone(void);
#else
#define RedirectCharacter(c)
#define RedirectionCmdDone()
#endif

extern unsigned short xcrc16tab[];
extern unsigned long crc32tab[];
extern char *Mtracebuf;
extern char ApplicationInfo[];
extern unsigned long ExceptionAddr;
extern unsigned long APPLICATION_RAMSTART, BOOTROM_BASE;
extern int ConsoleDevice;
extern int ConsoleBaudRate, LoopsPerSecond;
extern int StateOfMonitor, AppExitStatus, ExceptionType;
extern int  moncomptr;
extern int  bss_start, bss_end, boot_base;
extern int  (*remoterawon)(), (*remoterawoff)();
extern int  (*remoteputchar)(), (*remotegetchar)(), (*remotegotachar)();
extern int  (*dcacheFlush)(), (*icacheInvalidate)();
extern int  (*extgetUsrLvl)();

#endif
