/* flash.h:
 * Device-independent macros and data structures used by flash driver.
 */

#define FLASH_PROTECT_WINDOW_CLOSED 0
#define ALL_SECTORS -1

#define FLASH_LOCK          1
#define FLASH_UNLOCK        2
#define FLASH_LOCKDWN       3

/* Device ID used for ram that is "pretending" to be a flash bank. */
#define FLASHRAM    0x9999

struct  flashdesc {
    unsigned long   id;             /* manufacturer & device id */
    char        *desc;              /* ascii string */
};

struct  sectorinfo {
    long    size;                   /* size of sector */
    int     snum;                   /* number of sector (amongst possibly */
                                    /* several devices) */
    int     protected;              /* if set, sector is protected by window */
    unsigned char   *begin;         /* base address of sector */
    unsigned char   *end;           /* end address of sector */
};

struct  flashinfo {
    unsigned long   id;             /* manufacturer & device id */
    unsigned char   *base;          /* base address of device */
    unsigned char   *end;           /* end address of device */
    int     sectorcnt;              /* number of sectors */
    int     width;                  /* 1, 2, or 4 */
    int     (*fltype)();
    int     (*flerase)();
    int     (*flwrite)();
    int     (*flewrite)();
#if FLASH_LOCK_SUPPORTED
    int     (*fllock)();
#endif
    struct sectorinfo *sectors;
};

extern int      FlashProtectWindow;
extern int      FlashCurrentBank;
extern struct   flashinfo FlashBank[FLASHBANKS];
extern int      flashopload();

extern int showflashtype(unsigned long);
extern int showflashinfo(struct flashinfo *, char *);
extern int flashopload(unsigned long *,unsigned long *,unsigned long *,int);
extern int flashtype(struct flashinfo *);
extern int flasherase(struct flashinfo *,int);
extern int flashwrite(struct flashinfo *,unsigned char *,unsigned char *,long);
extern int flashewrite(struct flashinfo *,unsigned char *,unsigned char *,long);
extern int flasherased(unsigned char *,unsigned char *);
extern int addrtosector(unsigned char *,int *,int *,unsigned char **);
extern struct flashinfo *addrtobank(unsigned char *);
extern int sectortoaddr(int,int *,unsigned char **);
extern int flashbankinfo(int,unsigned char **,unsigned char **,int *);
extern void LowerFlashProtectWindow(void);
extern int AppFlashWrite(unsigned long *,unsigned long *,long);
extern int AppFlashEraseAll(void);
extern int AppFlashErase(int);
extern int srange(char *,int *,int *);
extern int sectorProtect(char *,int);
extern int NotUsed();
extern int lastlargesector(int,int *,int *,unsigned char **);
extern int FlashRamInit(int, int, struct flashinfo *,struct sectorinfo *,int *);
