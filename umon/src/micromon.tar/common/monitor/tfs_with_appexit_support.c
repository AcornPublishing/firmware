/* tfs.c:
    Tiny File System
    TFS supports the ability to store/access files in flash.  The functions
    in this file provide an interface at the monitor's user interface (the
    "tfs" command) as well as a library of functions that are available to
    the monitor/application code on this target (TFS API).
    The files on TFS include the application itself as well as any other file
    that may need to be stored for access by the monitor or application.

    NOTES:
    * This code considers both multiple task access and cache coherency;
      but has not been tested much...

      Dealing with multiple task access:
      The monitors access functions must be provided with a lock/unlock 
      wrapper that will guarantee sequential access to all of the monitor 
      facilities.  Refer to monlib.c in the target-specific code.
      Note that originally this was supported with tfsctrl(TFS_MUTEX ).
      This turned out to be insufficient because it did not prevent other
      tasks from calling other non-tfs functions in the monitor while tfs
      access (and potentially, flash update) was in progress.  This meant
      that a flash update could be in progress and some other task could
      call mon_getenv() and this would screw up the flash update because
      mon_getenv() would fetch out of the same flash device.  The wrapper
      needs to be part of the application (execute in RAM).

      Dealing with cache coherency:
      I believe the only concern here is that Icache must be invalidated
      and Dcache must be flushed whenever TFS does a memory copy that may
      ultimately be executable code.  This is handled at the end of the
      tfsmemcpy function by calling flushDcache() and invalidateIcache().
      It is the application's responsibility to give the monitor the
      appropriate functions (see assigncachefuncs()) if necessary.

 *  General notice:
 *  This code is part of a boot-monitor package developed as a generic base
 *  platform for embedded system designs.  As such, it is likely to be
 *  distributed to various projects beyond the control of the original
 *  author.  Please notify the author of any enhancements made or bugs found
 *  so that all may benefit from the changes.  In addition, notification back
 *  to the author will allow the new user to pick up changes that may have
 *  been made by other users after this version of the code was distributed.
 *
 *  Note1: the majority of this code was edited with 4-space tabs.
 *  Note2: as more and more contributions are accepted, the term "author"
 *         is becoming a mis-representation of credit.
 *
 *  Original author:    Ed Sutter
 *  Email:              esutter@lucent.com
 *  Phone:              908-582-2351
 */
#include "config.h"
#if INCLUDE_TFS
#include "cpu.h"
#include "stddefs.h"
#include "string.h"
#include "tfs.h"
#include "flash.h"
#include "aout.h"
#include "coff.h"
#include "elf.h"
#include "monapp.h"

#define TFSLOG_ADD  0
#define TFSLOG_DEL  1
#define TFSLOG_IPM  2
#define TFSLOG_ON   3
#define TFSLOG_OFF  4
#define TIME_UNDEFINED  0xffffffff

extern int UserLevel;
extern char *malloc(), *realloc();
extern void docommand(char *,int);

static int getndaoffset(struct defraghdr *dp,int sec,int *retoffset);
static long tfsflagsatob(char *), tfsmemuse(void), tfsmemdead(void);
static int tfsclean(), _tfsclean(), setdefragstate(), tfscheck();
static int tfsloadaout(), tfsloadelf(), tfsloadcoff(), tfsreorder();

static char     *(*tfsGetAtime)(long,char *,int);
static long     (*tfsGetLtime)(void), tfsFmodCount;
static void     (*tfsDocommand)(char *,int);
static char     *ScriptGotoTag, changeLog;
static struct   tfsdat fileslots[TFS_MAXOPEN];
static struct   tfshdr **tfsAlist;
static int      tfsAlistSize, tfsrunbootDone, tfsInaScript;

/* crc32tab[]:
    Used for calculating a 32-bit CRC.
*/
unsigned long crc32tab[] = {
    0x00000000, 0x77073096, 0xEE0E612C, 0x990951BA, 0x076DC419, 0x706AF48F,
    0xE963A535, 0x9E6495A3, 0x0EDB8832, 0x79DCB8A4, 0xE0D5E91E, 0x97D2D988, 
    0x09B64C2B, 0x7EB17CBD, 0xE7B82D07, 0x90BF1D91, 0x1DB71064, 0x6AB020F2,
    0xF3B97148, 0x84BE41DE, 0x1ADAD47D, 0x6DDDE4EB, 0xF4D4B551, 0x83D385C7, 
    0x136C9856, 0x646BA8C0, 0xFD62F97A, 0x8A65C9EC, 0x14015C4F, 0x63066CD9,
    0xFA0F3D63, 0x8D080DF5, 0x3B6E20C8, 0x4C69105E, 0xD56041E4, 0xA2677172, 
    0x3C03E4D1, 0x4B04D447, 0xD20D85FD, 0xA50AB56B, 0x35B5A8FA, 0x42B2986C,
    0xDBBBC9D6, 0xACBCF940, 0x32D86CE3, 0x45DF5C75, 0xDCD60DCF, 0xABD13D59, 
    0x26D930AC, 0x51DE003A, 0xC8D75180, 0xBFD06116, 0x21B4F4B5, 0x56B3C423,
    0xCFBA9599, 0xB8BDA50F, 0x2802B89E, 0x5F058808, 0xC60CD9B2, 0xB10BE924, 
    0x2F6F7C87, 0x58684C11, 0xC1611DAB, 0xB6662D3D, 0x76DC4190, 0x01DB7106,
    0x98D220BC, 0xEFD5102A, 0x71B18589, 0x06B6B51F, 0x9FBFE4A5, 0xE8B8D433, 
    0x7807C9A2, 0x0F00F934, 0x9609A88E, 0xE10E9818, 0x7F6A0DBB, 0x086D3D2D,
    0x91646C97, 0xE6635C01, 0x6B6B51F4, 0x1C6C6162, 0x856530D8, 0xF262004E, 
    0x6C0695ED, 0x1B01A57B, 0x8208F4C1, 0xF50FC457, 0x65B0D9C6, 0x12B7E950,
    0x8BBEB8EA, 0xFCB9887C, 0x62DD1DDF, 0x15DA2D49, 0x8CD37CF3, 0xFBD44C65, 
    0x4DB26158, 0x3AB551CE, 0xA3BC0074, 0xD4BB30E2, 0x4ADFA541, 0x3DD895D7,
    0xA4D1C46D, 0xD3D6F4FB, 0x4369E96A, 0x346ED9FC, 0xAD678846, 0xDA60B8D0, 
    0x44042D73, 0x33031DE5, 0xAA0A4C5F, 0xDD0D7CC9, 0x5005713C, 0x270241AA,
    0xBE0B1010, 0xC90C2086, 0x5768B525, 0x206F85B3, 0xB966D409, 0xCE61E49F, 
    0x5EDEF90E, 0x29D9C998, 0xB0D09822, 0xC7D7A8B4, 0x59B33D17, 0x2EB40D81,
    0xB7BD5C3B, 0xC0BA6CAD, 0xEDB88320, 0x9ABFB3B6, 0x03B6E20C, 0x74B1D29A, 
    0xEAD54739, 0x9DD277AF, 0x04DB2615, 0x73DC1683, 0xE3630B12, 0x94643B84,
    0x0D6D6A3E, 0x7A6A5AA8, 0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1, 
    0xF00F9344, 0x8708A3D2, 0x1E01F268, 0x6906C2FE, 0xF762575D, 0x806567CB,
    0x196C3671, 0x6E6B06E7, 0xFED41B76, 0x89D32BE0, 0x10DA7A5A, 0x67DD4ACC, 
    0xF9B9DF6F, 0x8EBEEFF9, 0x17B7BE43, 0x60B08ED5, 0xD6D6A3E8, 0xA1D1937E,
    0x38D8C2C4, 0x4FDFF252, 0xD1BB67F1, 0xA6BC5767, 0x3FB506DD, 0x48B2364B, 
    0xD80D2BDA, 0xAF0A1B4C, 0x36034AF6, 0x41047A60, 0xDF60EFC3, 0xA867DF55,
    0x316E8EEF, 0x4669BE79, 0xCB61B38C, 0xBC66831A, 0x256FD2A0, 0x5268E236, 
    0xCC0C7795, 0xBB0B4703, 0x220216B9, 0x5505262F, 0xC5BA3BBE, 0xB2BD0B28,
    0x2BB45A92, 0x5CB36A04, 0xC2D7FFA7, 0xB5D0CF31, 0x2CD99E8B, 0x5BDEAE1D, 
    0x9B64C2B0, 0xEC63F226, 0x756AA39C, 0x026D930A, 0x9C0906A9, 0xEB0E363F,
    0x72076785, 0x05005713, 0x95BF4A82, 0xE2B87A14, 0x7BB12BAE, 0x0CB61B38, 
    0x92D28E9B, 0xE5D5BE0D, 0x7CDCEFB7, 0x0BDBDF21, 0x86D3D2D4, 0xF1D4E242,
    0x68DDB3F8, 0x1FDA836E, 0x81BE16CD, 0xF6B9265B, 0x6FB077E1, 0x18B74777, 
    0x88085AE6, 0xFF0F6A70, 0x66063BCA, 0x11010B5C, 0x8F659EFF, 0xF862AE69,
    0x616BFFD3, 0x166CCF45, 0xA00AE278, 0xD70DD2EE, 0x4E048354, 0x3903B3C2, 
    0xA7672661, 0xD06016F7, 0x4969474D, 0x3E6E77DB, 0xAED16A4A, 0xD9D65ADC,
    0x40DF0B66, 0x37D83BF0, 0xA9BCAE53, 0xDEBB9EC5, 0x47B2CF7F, 0x30B5FFE9, 
    0xBDBDF21C, 0xCABAC28A, 0x53B39330, 0x24B4A3A6, 0xBAD03605, 0xCDD70693,
    0x54DE5729, 0x23D967BF, 0xB3667A2E, 0xC4614AB8, 0x5D681B02, 0x2A6F2B94, 
    0xB40BBE37, 0xC30C8EA1, 0x5A05DF1B, 0x2D02EF8D
};

/* tfslogaction[]:
    Used by the change-log feature in TFS.  This table provides a simple
    look-up between the TFSLOG_XXX definitions (above) and readable text.
*/
static char *tfslogaction[] = { "ADD", "DEL", "IPM", " ON", "OFF" };

/* tfsflgtbl, tfserrtbl & tfsdfgmsgtbl:
    Tables that establish an easy lookup mechanism to convert from
    bitfield to string or character.
    Note that TFS_ULVL0 is commented out.  I leave it in here as a place
    holder (comment), but it actually is not needed becasue ulvl_0 is the
    default if no other ulvl is specified.
*/
static struct tfsflg tfsflgtbl[] = {
    TFS_BRUN,           'b',    "run_at_boot",          TFS_BRUN,
    TFS_QRYBRUN,        'B',    "qry_run_at_boot",      TFS_QRYBRUN,
    TFS_EXEC,           'e',    "executable",           TFS_EXEC,
    TFS_AOUT,           'A',    "aout",                 TFS_AOUT,
    TFS_COFF,           'C',    "coff",                 TFS_COFF,
    TFS_ELF,            'E',    "elf",                  TFS_ELF,
    TFS_IPMOD,          'i',    "inplace_modifiable",   TFS_IPMOD,
    TFS_UNREAD,         'u',    "ulvl_unreadable",      TFS_UNREAD,
/*  TFS_ULVL0,          '0',    "ulvl_0",               TFS_ULVLMSK, */
    TFS_ULVL1,          '1',    "ulvl_1",               TFS_ULVLMSK,
    TFS_ULVL2,          '2',    "ulvl_2",               TFS_ULVLMSK,
    TFS_ULVL3,          '3',    "ulvl_3",               TFS_ULVLMSK,
#if INCLUDE_UNPACK
    TFS_CPRS,           'c',    "compressed",           TFS_CPRS,
#endif
        0, 0, 0
};

static struct tfserr tfserrtbl[] = {
        TFS_OKAY,               "no error",
        TFSERR_NOFILE,          "file not found",
        TFSERR_NOSLOT,          "max fps opened",
        TFSERR_EOF,             "end of file",
        TFSERR_BADARG,          "bad argument",
        TFSERR_NOTEXEC,         "not executable",
        TFSERR_BADCRC,          "bad crc",
        TFSERR_FILEEXISTS,      "file already exists",
        TFSERR_FLASHFAILURE,    "flash operation failed",
        TFSERR_WRITEMAX,        "max write count exceeded",
        TFSERR_RDONLY,          "file is read-only",
        TFSERR_BADFD,           "invalid descriptor",
        TFSERR_BADHDR,          "bad coff|elf|aout header",
        TFSERR_CORRUPT,         "corrupt file",
        TFSERR_MEMFAIL,         "memory failure",
        TFSERR_NOTIPMOD,        "file is not in-place-modifiable",
        TFSERR_FLASHFULL,       "out of flash space",
        TFSERR_USERDENIED,      "user level access denied",
        0,0
};

static struct tfsdfg tfsdfgmsgtbl[] = {
    SECTOR_DEFRAG_INACTIVE,         "DefragInactive",
    BUILDING_HEADER_TABLE,          "BuildingHeaderTable",
    HEADER_TABLE_READY,             "HeaderTblReady",
    SECTOR_COPIED_TO_SPARE,         "SectorCopiedToSpare",
    SECTOR_UPDATE_STARTED,          "SectorUpdateStarted",
    SECTOR_UPDATE_COMPLETE,         "SectorUpdateComplete",
    SECTOR_DEFRAG_COMPLETE,         "SectorDefragComplete",
    ERASING_LAST_SECTOR,            "ErasingLastSector",
    TOTAL_DEFRAG_COMPLETE,          "TotalDefragComplete",
    COPY_HDRS_TO_SPARE,             "CopyingHdrsToSpare",
    HDRS_IN_SPARE,                  "HeadersInSpare",
    ERASING_DEAD_SECTOR,            "ErasingDeadSector",
    ERASED_DEAD_SECTOR,             "ErasedDeadSector",
    LASTSECTOR_IN_SPARE,            "LastSectorInSpare",
    0,0
};

/* dummyAtime() & dummyLtime():
    These two functions are loaded into the function pointers as defaults
    for the time-retrieval stuff used in TFS.
*/
char *
dummyAtime(long tval,char *buf,int buflen)
{
/*  strcpy(buf,"Fri Sep 13 00:00:00 1986"); */
    *buf = 0;
    return(buf);
}

long
dummyLtime(void)
{
    return(TIME_UNDEFINED);
}

/* crc32():
    The common CRC-32 code.  I got this out of the "Practical Algorithms
    for Programmers" book, but it can be found all over the place.
*/
ulong
crc32(buffer,nbytes)
uchar *buffer;
ulong nbytes;
{
    int temp;
    unsigned long crc_rslt;

    crc_rslt = 0xffffffff;
    while(nbytes) {
        temp = (crc_rslt ^ *buffer++) & 0x000000FFL;
        crc_rslt = ((crc_rslt >> 8) & 0x00FFFFFFL) ^ crc32tab[temp];
        nbytes--;
    }
    return(~crc_rslt);
}

/* tfsflasherase(), tfsflasheraseall() & tfsflashwrite():
    Wrappers for corresponding flash operations.  The wrappers are used
    to provide one place for the incrmentation of tfsFmodCount.
*/
tfsflasheraseall(void)
{
    tfsFmodCount++;
    return(AppFlashEraseAll());
}

tfsflasherase(snum)
int snum;
{
    tfsFmodCount++;
    return(AppFlashErase(snum));
}

tfsflashwrite(dest,src,bytecnt)
ulong   *src, *dest;
long bytecnt;
{
    tfsFmodCount++;
    return(AppFlashWrite(dest,src,bytecnt));
}

/* tfserrmsg():
    Return the error message string that corresponds to the incoming
    tfs error number.
*/
static char *
tfserrmsg(errno)
int errno;
{
    struct  tfserr  *tep;
    
    tep = tfserrtbl;
    while(tep->msg) {
        if (errno == tep->err)
            return(tep->msg);
        tep++;
    }
    return("unknown tfs errno");
}

/* tfsdefragmsg():
    Return the  message string that corresponds to the incoming
    tfs defragmentation state number.
*/
static char *
tfsdefragmsg(state)
int state;
{
    struct tfsdfg *tdp;

    tdp = tfsdfgmsgtbl;
    while(tdp->msg) {
        if (tdp->state == state)
            return(tdp->msg);
        tdp++;
    }
    return("unknown tfs defrag state");
}

/* tfsprflags():
   Print the specified set of flags.
*/
static void
tfsprflags(flags, verbose)
long flags;
int verbose;
{
    struct  tfsflg  *tfp;

    if (verbose)
        printf(" Flags: ");
    tfp = tfsflgtbl;
    while(tfp->sdesc) {
        if ((flags & tfp->mask) == tfp->flag) {
            if (verbose) {
                printf("%s", tfp->ldesc);
                if ((tfp+1)->flag)
                    printf(", ");
            }
            else
                putchar(tfp->sdesc);
        }
        tfp++;
    }
    if (verbose)
        printf("\n");
}

/* tfsflagsbtoa():
   Convert binary flags to ascii and return the string.
*/
static char *
tfsflagsbtoa(flags,fstr)
long    flags;
char    *fstr;
{
    int i;
    struct  tfsflg  *tfp;

    if ((!flags) || (!fstr))
        return((char *)0);

    i = 0;
    tfp = tfsflgtbl;
    *fstr = 0;
    while(tfp->sdesc) {
        if ((flags & tfp->mask) == tfp->flag)
            fstr[i++] = tfp->sdesc;
        tfp++;
    }
    fstr[i] = 0;
    return(fstr);
}

/* tfsflagsatob():
   Convert ascii flags to binary and return the long.
*/
static long
tfsflagsatob(fstr)
char *fstr;
{
    long    flag;
    struct  tfsflg  *tfp;

    if (!fstr)
        return(0);

    flag = 0;
    while(*fstr) {
        tfp = tfsflgtbl;
        while(tfp->sdesc) {
            if (*fstr == tfp->sdesc) {
                flag |= tfp->flag;
                break;
            }
            tfp++;
        }
        if (!tfp->flag)
            return(-1);
        fstr++;
    }
    return(flag);
}

/* tfslog():
    This function is called by tfsadd(), tfsunlink() and tfsipmod() to
    write to a log file indicating that something in tfs has been changed.
    Note that the function can be called at any user level, but it must be
    able to modify the TFS_CHANGELOG_FILE that has "u3" flags.  The 
    user level must be temporarily upped to MAXUSRLEVEL for this.
*/
static void
tfslog(int action, char *string)
{
    static  char buf[TFS_CHANGELOG_SIZE];
    TFILE   *tfp;
    char    *bp, *eol, *eob, *logaction, tbuf[32];
    int     newfsize, fsize, lsize, tfd, err, len, oulvl, tbuflen;

    switch(action) {
        case TFSLOG_ADD:
        case TFSLOG_DEL:        /* Return here if the tfslog() call is on   */
        case TFSLOG_IPM:        /* the TFS_CHANGELOG_FILE itself.           */
            if (!strcmp(string,TFS_CHANGELOG_FILE) || !changeLog)
                return;
            break;
        case TFSLOG_ON:
            if (changeLog == 1)
                return;
            changeLog = 1;
            break;
        case TFSLOG_OFF:
            if (changeLog == 0)
                return;
            changeLog = 0;
            break;
    }

    oulvl = setUserLevel(MAXUSRLEVEL,0);
    logaction = tfslogaction[action];
    tfp = tfsstat(TFS_CHANGELOG_FILE);
    tfsGetAtime(0,tbuf,sizeof(tbuf));
    tbuflen = strlen(tbuf); 

    if (tfp) {
        tfd = tfsopen(TFS_CHANGELOG_FILE,TFS_RDONLY,0);
        fsize = tfsread(tfd,buf,TFS_CHANGELOG_SIZE);
        tfsclose(tfd,0);

        newfsize = (fsize+strlen(logaction)+strlen(string)+3);
        if (tbuflen)
            newfsize += tbuflen + 3;

        eob = buf + fsize;

        /* If newfsize is greater than the maximum size the file is */
        /* allowed to grow, then keep removing the first line */
        /* (oldest entry) until new size is within the limit... */
        if (newfsize > TFS_CHANGELOG_SIZE) {
            lsize = 0;
            eol = buf;
            while ((newfsize-lsize) > TFS_CHANGELOG_SIZE) {
                while((*eol != '\r') && (*eol != '\n')) eol++;
                while((*eol == '\r') || (*eol == '\n')) eol++;
                lsize = eol-buf;
            }
            fsize -= lsize;
            newfsize -= lsize;
            eob -= lsize;
            memcpy(buf,eol,fsize);
        }
        if (tbuflen)
            sprintf(eob,"%s: %s @ %s\n",logaction,string,tbuf);
        else
            sprintf(eob,"%s: %s\n",logaction,string);
        err = tfsunlink(TFS_CHANGELOG_FILE);
        if (err < 0)
            printf("%s: %s\n",TFS_CHANGELOG_FILE,
                (char *)tfsctrl(TFS_ERRMSG,err,0));
        err = tfsadd(TFS_CHANGELOG_FILE,0,"u3",buf,newfsize);
        if (err < 0)
            printf("%s: %s\n",TFS_CHANGELOG_FILE,
                (char *)tfsctrl(TFS_ERRMSG,err,0));
    }
    else {
        if (tbuflen)
            len = sprintf(buf,"%s: %s @ %s\n",logaction,string,tbuf);
        else
            len = sprintf(buf,"%s: %s\n",logaction,string);
        err = tfsadd(TFS_CHANGELOG_FILE,0,"u3",buf,len);
        if (err < 0)
            printf("%s: %s\n",TFS_CHANGELOG_FILE,
                (char *)tfsctrl(TFS_ERRMSG,err,0));
    }
    setUserLevel(oulvl,0);
}

/* validtfshdr():
    Return 1 if the header pointed to by the incoming header pointer is valid.
    Else return 0.  The header crc is calculated based on the hdrcrc
    and next members of the structure being zero.
    Note that if the file is deleted, then just ignore the crc and return 1.
*/
static int
validtfshdr(hdr)
struct  tfshdr *hdr;
{
    struct tfshdr   hdrcpy;
    ulong hdrcrc;

    /* A few quick checks... */
    if (!hdr)                       /* Valid header pointer? */
        return(0);

    if (hdr->flags == 0)            /* Flags indicate that file is deleted. */
        return(1);

    if (!(hdr->flags & TFS_AIPNOT)) /* Flags indicate taht file is in AIP */
        return(1);                  /* state, so hdr crc will be bad. */

    if (hdr->hdrsize == ERASED16)   /* End of stored files. */
        return(0);

    hdrcpy = *hdr;
    hdrcrc = hdr->hdrcrc;
    hdrcpy.hdrcrc = 0;
    hdrcpy.next = 0;
    if (crc32(&hdrcpy,TFSHDRSIZ) == hdrcrc)
        return(1);
    else
        return(0);
}

/* nextfp():
    Used as a common means of retrieving the next file header pointer.  It
    does some sanity checks based on the fact that all pointers must fall
    within the TFSSTART<->TFSEND memory range and since each file is placed
    just after the previous one in linear memory space, fp->next should
    always be greater than fp.
*/
static struct   tfshdr *
nextfp(fp)
struct  tfshdr *fp;
{
    if ((fp < (struct tfshdr *)TFSSTART) ||
        (fp > (struct tfshdr *)TFSEND) ||
        (fp->next < (struct tfshdr *)TFSSTART) ||
        (fp->next > (struct tfshdr *)TFSEND)  ||
        (fp->next <= fp)) {
        printf("Bad TFS file hdr at: 0x%x\n",fp);
        return(0);
    }
    return(fp->next);
}

/* tfsflasherased():
    Jump to the point in flash after the last file in TFS, then verify
    that all remaining flash  that is dedicated to TFS is erased (0xff).
    If erased, return 1; else return 0.
*/
static int
tfsflasherased(int verbose)
{
    struct  tfshdr *tfp;
    ulong   *lp;

    if (verbose)
        printf("Flash after last TFS file... ");
    tfp = (struct tfshdr *)TFSSTART;
    while(validtfshdr(tfp))
        tfp = nextfp(tfp);

    lp = (ulong *)tfp;
    while (lp < (ulong *)TFSEND) {
        if (*lp != ERASED32) {
            if (verbose)
                printf("not erased at 0x%x\n",lp);
            return(0);
        }
        lp++;
    }
    if (verbose)
        printf("ok\n");
    return(1);
}

/* tfsld():
    If the filename specified is AOUT, COFF or ELF, then load it.
*/
static int
tfsld(char *name,int verbose,int verifyonly)
{
    int     err;
    struct  tfshdr *fp;

    err = TFS_OKAY;
    fp = tfsstat(name);

    if (!fp)
        return (TFSERR_NOFILE);

    if (TFS_USRLVL(fp) > UserLevel)
        return(TFSERR_USERDENIED);

    if (fp->flags & (TFS_COFF | TFS_ELF | TFS_AOUT)) {
        if (fp->flags & TFS_COFF)
            err = tfsloadcoff(fp,verbose,0,verifyonly);
        else if (fp->flags & TFS_ELF)
            err = tfsloadelf(fp,verbose,0,verifyonly);
        else if (fp->flags & TFS_AOUT)
            err = tfsloadaout(fp,verbose,0,verifyonly);
    }
    else
        err = TFSERR_BADHDR;
    
    return(err);
}

/* listfilter():
    If the incoming filename (fname) passes the incoming filter, then
    return 1; else return 0.

    Examples:
        if filter is "*.html" and fname is "index.html" return 1.
        if filter is "dir/*" and fname is "dir/abc" return 1.
        if filter is "dir/" and fname is "dir/abc" return 1.

    Notes:
        * If no asterisk is present, assume it is appended to the end of
          the filter; hence the filter is a prefix.
        * A valid filter will have the asterisk as either the first or last
          character of the filter.  If first, assume filter is a suffix, 
          if last (or none at all), assume filter is a prefix.
        * If there is an asterisk in the middle of the filter, it is chopped
          at the asterisk without warning.
*/
int
listfilter(char *filter,char *fname)
{
    int     flen;
    char    *prefix, *suffix, *asterisk, *sp;

    if (!filter)        /* No filter means match everything. */
        return(1);

    flen = 0;
    prefix = suffix = (char *)0;

    asterisk = strchr(filter,'*');
    if (asterisk == filter) {
        suffix = asterisk+1;
        flen = strlen(suffix);
        sp = fname + strlen(fname) - flen;
        if (!strcmp(suffix,sp))
            return(1);
    }
    else {
        if (asterisk)
            *asterisk = 0;
        prefix = filter;
        flen = strlen(prefix);
        if (!strncmp(prefix,fname,flen))
            return(1);
    }
    return(0);
}

/* tfsvlist():  verbose list...
   Display all files currently stored.  Do not put them in alphabetical
   order; display them as they are physically listed in the file system.
   Display complete structure of file header for each file.
   Note1: This version of file listing is only called if "tfs -vv ls"
   or "tfs -vvv ls" is called.  The first level of verbosity is handled
   by tfsqlist to simply display the "dot" files.
*/
static int
tfsvlist(char *filter, int verbose,int more)
{
    struct  tfshdr *fp;
    int     tot;
    char    tbuf[32];

    fp = (struct tfshdr *) TFSSTART;
    tot = 0;
    while(validtfshdr(fp)) {
        if ((fp->flags == 0) && (verbose < 3)) {
            fp = nextfp(fp);
            continue;
        }
        if (!listfilter(filter,TFS_NAME(fp))) {
            fp = nextfp(fp);
            continue;
        }
        if ((fp->flags & TFS_UNREAD) && (TFS_USRLVL(fp) > UserLevel)) {
            fp = nextfp(fp);
            continue;
        }

        if (fp->flags)
            printf(" Name:  '%s'\n", fp->name);
        else
            printf(" Name:  '%s' (deleted)\n", fp->name);
        printf(" Info:  '%s'\n", fp->info);
        if (fp->flags)
            tfsprflags(fp->flags, 1);
        printf(" Addr:  0x%x (hdr @ 0x%x, nxtptr = 0x%x)\n",
            TFS_BASE(fp),fp,fp->next);
        printf(" Size:  0x%x (%d) bytes\n", fp->filsize, fp->filsize);
        if (TFS_TIME(fp) != TIME_UNDEFINED)
            printf(" Time:  %s\n", tfsGetAtime(TFS_TIME(fp),tbuf,sizeof(tbuf)));
        printf("\n");
        tot++;
        fp = nextfp(fp);
        if ((more) && ((tot % 2) == 0))
            if (!More())
                return(TFS_OKAY);
    }
    printf("\nTotal: %d accessible file%s.\n",tot,tot == 1 ? "" : "s");
    printf("Memory Usage: %d bytes (%d bytes of that is dead space)\n",
        tfsmemuse(), tfsmemdead()); 
    printf("TFS Address Range: 0x%x - 0x%x\n",TFSSTART,TFSEND);
    return (TFS_OKAY);
}

/* tfsqlist():  quiet list...
   Display list of files in alphabetical order.
   Display only the name and flag summary.
   Note: a file with a leading dot ('.') is invisible unless verbose is set.
*/
static int
tfsqlist(char *filter, int verbose, int more)
{
    extern  char *strchr();
    struct  tfshdr *fp;
    char    *name, fbuf[16], tbuf[32];
    int     idx, listed, plen, err;

    idx = listed = 0;
    if ((err = tfsreorder()) < 0)
        return(err);

    printf(" Name                       Size    Location   Flags\n");
    while(fp = tfsAlist[idx]) {
        name = TFS_NAME(fp);
        if (((name[0] == '.') && (!verbose)) ||
            (!listfilter(filter,name)) ||
            ((fp->flags & TFS_UNREAD) && (TFS_USRLVL(fp) > UserLevel))) {
            idx++;
            continue;
        }
        printf(" %-23s  %6d   0x%08x   %s\n",TFS_NAME(fp),TFS_SIZE(fp),
            TFS_BASE(fp),tfsflagsbtoa(TFS_FLAGS(fp),fbuf));
        idx++;
        listed++;
        if ((more) && ((listed % 12) == 0))
            if (!More())
                return(TFS_OKAY);
    }
    printf("\nTotal: %d accessible file%s.\n",listed,listed == 1 ? "" : "s");
    return (TFS_OKAY);
}

/* tefmemuse():
    Return the amount of FLASH that is currently being used by the
    file system.
*/
static long
tfsmemuse(void)
{
    struct tfshdr *fp;
    long    tot;

    tot = 0;
    fp = (struct tfshdr *) TFSSTART;
    while(validtfshdr(fp)) {
        tot += TFSHDRSIZ;
        tot += fp->filsize;
        fp = nextfp(fp);
    }
    return(tot);
}

/* tfsmemdead():
    Return the amount of memory space currently used by dead (deleted)
    files.
*/
static long
tfsmemdead(void)
{
    struct tfshdr *fp;
    long    tot;

    tot = 0;
    fp = (struct tfshdr *) TFSSTART;
    while(validtfshdr(fp)) {
        if (fp->flags == 0) {
            tot += TFSHDRSIZ;
            tot += fp->filsize;
        }
        fp = nextfp(fp);
    }
    return(tot);
}


/* tfsclean():
    Defragment the file system. During defragmentation, continually save
    enough state so that this function may be interrupted by a reset or
    power hit and can recover from it.
    Requires that one of the largest sectors of the flash device be designated
    as a SPARE sector, to be used only by defragmentation.
    Defragmentation state is stored at the end of the last TFS sector, so
    it is maintained across reset/powerhit also.
    Use of the SPARE sector and flash-based defragmentation state eliminates
    the vulnerability of the TFS being corrupted if the system is reset during
    defragmentation.  It also eliminates the need for a large amount of RAM
    space (as was needed in earlier versions of tfsclean()).

    The function is designed to be entered at various points of the 
    defragmentation process.  If defragmentation is starting from scratch,
    then all arguments (except verbose) will be zero.  If filtot is non-zero
    on entry, then this means that tfsclean() must pick up from a previously
    started defragmentation and cannot assume that a sane file system
    currently exists.
*/
static ulong    *DefragStateTbl;

#define DEFRAG_TEST_ENABLED 0

#if DEFRAG_TEST_ENABLED
int ExitPoint, ExitSector;

#define TEST_EXIT_POINT(pt,sno) \
    if (ExitPoint == pt) { \
        if ((ExitSector == sno) || (sno == -1)) { \
            printf("!!!!!!!!!!!!! TestExit at point %d, sector %d\n",pt,sno); \
            return(1); \
        } \
    }
#else
#define TEST_EXIT_POINT(pt,sno)
#endif

static int
tfsclean(filtot,tbl1,tbl2,snum,resetwhendone,verbose)
int filtot, verbose, snum, resetwhendone;
ulong   *tbl1;
struct defraghdr *tbl2;
{
    int rslt;

    rslt = _tfsclean(filtot,tbl1,tbl2,snum,resetwhendone,verbose);
    return(rslt);
}


static int
_tfsclean(filtot,tbl1,tbl2,snum,resetwhendone,verbose)
int filtot, verbose, snum, resetwhendone;
ulong   *tbl1;
struct defraghdr *tbl2;
{
    int     ftot, fcnt, fsize, dtot, sparesnum, sparesize, ssize;
    int     firsttfssector, lasttfssector, sectorcheck;
    int     tfssector, sidx, dummy;
    char    *newaddress, *sbase, *firstdeadfile;
    struct  tfshdr  *tfp;
    struct  defraghdr   *defraghdrtbl, *dp, defrag;
    ulong   *lp, *lp1;
    
    if (verbose > 1) {
        printf("tfsclean(%d,0x%x,0x%x,%d,%d,%d)\n",
            filtot,tbl1,tbl2,snum,resetwhendone,verbose);
    }

    /* Do some initial configuration retrieval... */
    /* Determine the first and last sector within TFS... */
    if (addrtosector(TFSSTART,&firsttfssector,&ssize,&sbase) < 0)
        return(TFSERR_MEMFAIL);
    lasttfssector = firsttfssector + TFSSECTORCOUNT - 1;
    if (addrtosector(TFSEND,&sectorcheck,0,0) < 0)
        return(TFSERR_MEMFAIL);
    if (lasttfssector != sectorcheck) {
        printf("TFS SECTORCOUNT does not match TFSSTART <-> TFSEND\n");
        printf("First TFS sector = %d\n",firsttfssector);
        printf("Last TFS sector  = %d\n",sectorcheck);
        return(TFSERR_MEMFAIL);
    }
    /* Store away information about spare sector... */
    if (addrtosector(TFSSPARE,&sparesnum,&sparesize,0) < 0)
        return(TFSERR_MEMFAIL);

    if (filtot) {
        sidx = snum;
        ftot = filtot;
        defraghdrtbl = tbl2;
        DefragStateTbl = tbl1;
        tfssector = firsttfssector+snum;
        printf("Continuing defragmentation at sector %3d ",tfssector);
        printf("(state=%s)...\n",tfsdefragmsg(DefragStateTbl[snum]));

        if (sectortoaddr(tfssector,&ssize,&sbase) == -1)
            return(TFSERR_MEMFAIL);

        switch(DefragStateTbl[snum]) {
            case BUILDING_HEADER_TABLE:
                goto building_hdr;
            case HEADER_TABLE_READY:
                goto hdr_table_ready;
            case COPY_HDRS_TO_SPARE:
                goto copy_hdrs_to_spare;
            case HDRS_IN_SPARE:
                goto hdrs_in_spare;
            case LASTSECTOR_IN_SPARE:
                goto lastsector_in_spare;
            case SECTOR_COPIED_TO_SPARE:
                goto sector_copied_to_spare;
            case SECTOR_UPDATE_STARTED:
                goto sector_update_started;
            case SECTOR_UPDATE_COMPLETE:
                goto sector_update_complete;
            case SECTOR_DEFRAG_COMPLETE:
                goto sector_defrag_complete;
            case ERASING_DEAD_SECTOR:
                goto erasing_dead_sector;
            case ERASED_DEAD_SECTOR:
                goto erased_dead_sector;
            case ERASING_LAST_SECTOR:
                goto erasing_last_sector;
            default:
                return(TFSERR_BADARG);
        }
    }

    /* Determine how many "live" files exist so that we can determine */
    /* where to start building the defragstate[] and defraghdrtbl[] tables. */
    tfp = (struct tfshdr *)TFSSTART;
    ftot = dtot = 0;
    while(validtfshdr(tfp)) {
        if (tfp->flags)
            ftot++;
        else 
            dtot++;
        tfp = nextfp(tfp);
    }

    /* If dtot is 0, then all TFS file headers indicate that there is no */
    /* need to clean up the flash.  There is still a chance that the flash */
    /* (after the end of the last file in TFS) may not be erased, so check */
    /* for that also... */
    if (dtot == 0) {
        printf("No dead files detected.\n");
        if (tfsflasherased(1))
            return(0);
        else
            printf("Running defrag to cleanup...\n");
    }

    /* If ftot is 0, then there are no valid files in the flash, so simply */
    /* erase all TFS flash space and return... */
    if (ftot == 0) {
        printf("No active files detected, erasing all TFS flash...\n");
        tfsinit();
        return(0);
    }

    printf("%s with %d dead file%s (%d bytes) removed.\n",
        "Defragmenting file system",dtot,dtot>1 ? "s":"",tfsmemdead());

    DefragStateTbl = (ulong *)(TFSEND+1);
    DefragStateTbl -= TFSSECTORCOUNT;
    defraghdrtbl = (struct defraghdr *)(DefragStateTbl) - ftot;

    /* Verify that the space to be written to for the */
    /* defrag stuff is erased... */
    lp = (ulong *)defraghdrtbl;
    while(lp < (ulong *)TFSEND) {
        if (*lp++ != (ulong)ERASED32) {
            printf("Defragmentation table space (0x%x-0x%x) not erased.\n",
                defraghdrtbl,TFSEND);
            return(TFSERR_FLASHFAILURE);
        }
    }

    TEST_EXIT_POINT(1,-1);

    /* Erase SPARE sector. */
    if (tfsflasherase(sparesnum) < 0) {
        printf("Flash SPARE sector erase failed\n");
        return(TFSERR_FLASHFAILURE);
    }

    TEST_EXIT_POINT(2,-1);

    if (verbose > 2) {
        printf("Building defrag header for %d files...\n",ftot);
        printf("DefragStateTbl=0x%x\n",DefragStateTbl);
        printf("defraghdrtbl=0x%x\n",defraghdrtbl);
    }

    /* Mark the defragmentation state table to indicate that we are */
    /* about to begin defragmentation. */
    if (setdefragstate(0,BUILDING_HEADER_TABLE,verbose) != TFS_OKAY)
        return(TFSERR_FLASHFAILURE);

building_hdr:
    firstdeadfile = (char *)0;
    tfp = (struct tfshdr *)TFSSTART;
    while(validtfshdr(tfp)) {
        if (!tfp->flags) {
            firstdeadfile = (char *)tfp;
            break;
        }
        tfp = nextfp(tfp);
    }
    
    tfp = (struct tfshdr *)TFSSTART;
    newaddress = (char *)TFSSTART;
    fcnt = 0;
    if (verbose > 2)
        printf("\nDEFRAGMETATION HEADER DATA:\n");
    while(validtfshdr(tfp)) {
        if (tfp->flags) {
            uchar   *base, *eof;
            int     size, slot;
            struct  tfsdat *slotptr;

            defrag.fhdr = *tfp;
            if (addrtosector(tfp,&defrag.bsn,0,&base) < 0)
                return(TFSERR_MEMFAIL);
            defrag.bso = (uchar *)tfp - base;
            eof = (uchar *)(tfp+1)+TFS_SIZE(tfp)-1;
            if (addrtosector(eof,&defrag.esn,0,&base) < 0)
                return(TFSERR_MEMFAIL);
            defrag.fdf = firstdeadfile;
            defrag.eso = eof - base + 1;
            defrag.nda = newaddress;

            /* If the file is currently opened, adjust the base address. */
            slotptr = fileslots;
            for (slot=0;slot<TFS_MAXOPEN;slot++,slotptr++) {
                if (slotptr->offset != -1) {
                    if (slotptr->base == (uchar *)(TFS_BASE(tfp))) {
                        slotptr->base = (uchar *)(newaddress+TFSHDRSIZ);
                        if (verbose)
                            printf("Base of opened file '%s' shifted from 0x%x to 0x%x\n",
                                TFS_NAME(tfp),TFS_BASE(tfp),slotptr->base);
                    }
                }
            }
            if (verbose > 2) {
                printf(" File %s:\n",TFS_NAME(tfp));
                printf("  bsn=%d, bso=0x%08x,",defrag.bsn,defrag.bso);
                printf(" esn=%d, eso=0x%08x,",defrag.esn,defrag.eso);
                printf(" nda=0x%08x, fdf=0x%08x\n",defrag.nda,defrag.fdf);
            }
            size = TFS_SIZE(tfp) + TFSHDRSIZ;
            if (size & 0xf) {
                size += 16;
                size &= ~0xf;
            }
            newaddress += size;
            defrag.fhdr.next = (struct tfshdr *)newaddress;
            if (tfsflashwrite(&defraghdrtbl[fcnt],&defrag,DEFRAGHDRSIZ) == -1) {
                printf("Flash write failed during header build\n");
                return(TFSERR_FLASHFAILURE);
            }
            fcnt++;

            TEST_EXIT_POINT(3,-1);
        }
        tfp = nextfp(tfp);
    }
    if (fcnt != ftot)
        printf("\007 fcnt != ftot!\n");

    TEST_EXIT_POINT(4,-1);

    /* Mark the defragmentation state table to indicate that the */
    /* defragmentation headers have been constructed. */
    if (setdefragstate(0,HEADER_TABLE_READY,verbose) != TFS_OKAY)
        return(TFSERR_FLASHFAILURE);

hdr_table_ready:
    /* For each sector dedicated to TFS, do the following... */
    if (verbose) {
        if (verbose > 1)
            printf("\nPER-SECTOR DEFRAGMENTATION STEPS:\n");
        printf("Defragmenting sectors %d - %d...\n",
            firsttfssector,lasttfssector);
    }
    sidx = 0;
    for(tfssector=firsttfssector;tfssector<=lasttfssector;tfssector++,sidx++) {
        if (verbose) {
            printf(" Sector %3d (base=0x%x, size=%d)...\n",
                tfssector,sbase,ssize);
        }

        /* If the current sector is prior to the first sector that contains */
        /* a file that has been removed, then this sector will not change,  */
        /* so we can skip over it... */
        dp = defraghdrtbl;
        if (dp->fdf > sbase+ssize) {
            if (verbose > 2)
                printf("  no change",dp->fdf,sbase,ssize);
            if (verbose > 3)
                printf("   (0x%x > 0x%x+0x%x",dp->fdf,sbase,ssize);
            if (verbose > 2)
                printf(".\n");
            goto sector_defrag_skip;
        }
        
        /* Look to see if this sector has any valid file data in it. */
        /* If not, continue with next sector. */
        dp = defraghdrtbl;
        while (dp < (struct defraghdr *)DefragStateTbl) {
            if ((tfssector >= dp->bsn) && (tfssector <= dp->esn))
                break;
            dp++;
        }
        if (dp >= (struct defraghdr *)DefragStateTbl) {

            TEST_EXIT_POINT(5,tfssector);

            if (setdefragstate(sidx,ERASING_DEAD_SECTOR,verbose) != TFS_OKAY)
                return(TFSERR_FLASHFAILURE);

erasing_dead_sector:

            TEST_EXIT_POINT(6,tfssector);

            /* Erase the sector within valid TFS space, then update state. */
            if (tfsflasherase(tfssector) < 0) {
                printf("Flash sector erase (%d) failed\n",tfssector);
                return(TFSERR_FLASHFAILURE);
            }

            TEST_EXIT_POINT(7,tfssector);

            if (setdefragstate(sidx,ERASED_DEAD_SECTOR,verbose) != TFS_OKAY)
                return(TFSERR_FLASHFAILURE);

            TEST_EXIT_POINT(8,tfssector);

erased_dead_sector:
            sbase += ssize;
            if (addrtosector(sbase,0,&ssize,0) < 0)
                return(TFSERR_MEMFAIL);
            continue;
        }

        /* If this is the last sector of TFS, then we must copy the defrag */
        /* tables to the end of the SPARE sector (recall that the defrag   */
        /* tables are stored in the last TFS sector).                      */
        if (tfssector == lasttfssector) {
            ulong   *newdefragstatetbl;
            struct defraghdr    *newdefraghdrtbl;

            TEST_EXIT_POINT(9,tfssector);

            if (setdefragstate(sidx,COPY_HDRS_TO_SPARE,verbose) != TFS_OKAY)
                return(TFSERR_FLASHFAILURE);

            TEST_EXIT_POINT(10,tfssector);

copy_hdrs_to_spare:
            newdefragstatetbl = (ulong *)(TFSSPARE+sparesize);
            newdefragstatetbl -= TFSSECTORCOUNT;
            newdefraghdrtbl = (struct defraghdr *)(newdefragstatetbl) - ftot;

            /* Copy defrag tables to end of SPARE sector... */
            if (tfsflashwrite(newdefraghdrtbl,defraghdrtbl,
                TFSEND-(int)defraghdrtbl+1) < 0) {
                printf("Flash defraghdrtbl write failed\n",tfssector);
                return(TFSERR_FLASHFAILURE);
            }
            DefragStateTbl = (ulong *)(TFSSPARE+sparesize);
            DefragStateTbl -= TFSSECTORCOUNT;

            TEST_EXIT_POINT(11,tfssector);

            if (setdefragstate(sidx,HDRS_IN_SPARE,verbose)!=TFS_OKAY)
                return(TFSERR_FLASHFAILURE);
hdrs_in_spare:
            DefragStateTbl = (ulong *)(TFSSPARE+sparesize);
            DefragStateTbl -= TFSSECTORCOUNT;

            TEST_EXIT_POINT(12,tfssector);

            /* Copy remainder of last TFS sector to SPARE... */
            if (tfsflashwrite(TFSSPARE,sbase,
                ssize-(TFSEND-(int)defraghdrtbl+1)) < 0) {
                printf("Flash final sector (%d) copy failed\n",tfssector);
                return(TFSERR_FLASHFAILURE);
            }

            TEST_EXIT_POINT(13,tfssector);

            if (setdefragstate(sidx,LASTSECTOR_IN_SPARE,verbose)!=TFS_OKAY)
                return(TFSERR_FLASHFAILURE);
lastsector_in_spare:
            defraghdrtbl = (struct defraghdr *)(DefragStateTbl) - ftot;

            TEST_EXIT_POINT(14,tfssector);
        }
        else {

            TEST_EXIT_POINT(15,tfssector);

            /* Copy TFS sector to SPARE, then update state. */
            if (tfsflashwrite(TFSSPARE,sbase,ssize) < 0) {
                printf("Flash sector %d copy failed\n",tfssector);
                return(TFSERR_FLASHFAILURE);
            }

            TEST_EXIT_POINT(16,tfssector);

            if (setdefragstate(sidx,SECTOR_COPIED_TO_SPARE,verbose)!=TFS_OKAY)
                return(TFSERR_FLASHFAILURE);

            TEST_EXIT_POINT(17,tfssector);

sector_copied_to_spare:
            dummy = 1;
        }

        TEST_EXIT_POINT(18,tfssector);

        /* Erase the sector within valid TFS space, then update state. */
        if (tfsflasherase(tfssector) < 0) {
            printf("Flash sector erase (%d) failed\n",tfssector);
            return(TFSERR_FLASHFAILURE);
        }

        TEST_EXIT_POINT(19,tfssector);

        if (setdefragstate(sidx,SECTOR_UPDATE_STARTED,verbose) != TFS_OKAY)
            return(TFSERR_FLASHFAILURE);

sector_update_started:
        /* Step through the defrag file header table and copy all files that */
        /* have valid data in the sector that is now in SPARE space. Then */
        /* update state. */
        dp = defraghdrtbl;
        while (dp < (struct defraghdr *)DefragStateTbl) {
            if ((tfssector < dp->bsn) || (tfssector > dp->esn)) {
                dp++;
                continue;
            }
            if (verbose > 1)
                printf("   File %s:\n",dp->fhdr.name);

            if (dp->bsn == dp->esn) {       /* Whole file is in SPARE */
                if (verbose > 1)
                    printf("    Complete_copy (nda=0x%x,nxt=0x%x,size=%d)\n",
                        dp->nda,dp->fhdr.next,dp->fhdr.filsize+TFSHDRSIZ);

                TEST_EXIT_POINT(20,tfssector);

                /* Copy the header from defraghdrtbl[]... */
                if (tfsflashwrite(dp->nda,&dp->fhdr,TFSHDRSIZ) == -1) {
                    printf("Sector-update1.1 (dp=0x%x) failed\n",dp);
                    return(TFSERR_FLASHFAILURE);
                }

                TEST_EXIT_POINT(21,tfssector);

                /* Copy the file data from SPARE... */
                if (tfsflashwrite(dp->nda+TFSHDRSIZ,TFSSPARE+dp->bso+TFSHDRSIZ,
                    dp->fhdr.filsize) == -1) {
                    printf("Sector-update1.2 (dp=0x%x) failed\n",dp);
                    return(TFSERR_FLASHFAILURE);
                }
            }
            else if (tfssector == dp->bsn) {/* Start of file is in SPARE */
                fsize = (ssize - dp->bso) - TFSHDRSIZ;
                if (verbose > 1)
                    printf("    Startof_copy (nda=0x%x,nxt=0x%x,size=%d)\n",
                        dp->nda,dp->fhdr.next,fsize+TFSHDRSIZ);

                TEST_EXIT_POINT(22,tfssector);

                /* Copy the header from defraghdrtbl[]... */
                if (tfsflashwrite(dp->nda,&dp->fhdr,TFSHDRSIZ) == -1) {
                    printf("Sector-update2.1 (dp=0x%x) failed\n",dp);
                    return(TFSERR_FLASHFAILURE);
                }

                TEST_EXIT_POINT(23,tfssector);

                if (tfsflashwrite(dp->nda+TFSHDRSIZ,
                    TFSSPARE+dp->bso+TFSHDRSIZ,fsize) == -1) {
                    printf("Sector-update2 (dp=0x%x) failed\n",dp);
                    return(TFSERR_FLASHFAILURE);
                }

                TEST_EXIT_POINT(24,tfssector);

            }
            else if (tfssector == dp->esn) {/* End of file is in SPARE */
                int offset;
                if (getndaoffset(dp,tfssector,&offset) == -1)
                    return(TFSERR_FLASHFAILURE);
                
                if (verbose > 1)
                    printf("    Endof_copy (nda offset=0x%x, size=%d)\n",
                        offset,dp->eso);

                TEST_EXIT_POINT(25,tfssector);

                if (tfsflashwrite(dp->nda+offset,TFSSPARE,dp->eso) == -1) {
                    printf("Sector-update3 (dp=0x%x) failed\n",dp);
                    return(TFSERR_FLASHFAILURE);
                }

                TEST_EXIT_POINT(26,tfssector);

            }
            else {                          /* Middle of file is in SPARE */
                int offset;
                if (getndaoffset(dp,tfssector,&offset) == -1)
                    return(TFSERR_FLASHFAILURE);

                if (verbose > 1)
                    printf("    Middleof_copy (nda offset=0x%x, size=%d)\n",
                        offset,ssize);

                TEST_EXIT_POINT(27,tfssector);

                if (tfsflashwrite(dp->nda+offset,TFSSPARE,ssize) == -1) {
                    printf("Sector-update4 (dp=0x%x) failed\n",dp);
                    return(TFSERR_FLASHFAILURE);
                }

                TEST_EXIT_POINT(28,tfssector);
            }
            dp++;
        }

        TEST_EXIT_POINT(29,tfssector);

        if (setdefragstate(sidx,SECTOR_UPDATE_COMPLETE,verbose)!=TFS_OKAY)
            return(TFSERR_FLASHFAILURE);

        TEST_EXIT_POINT(30,tfssector);

sector_update_complete:
        /* Erase the SPARE sector, then update state. */
        if (tfssector != lasttfssector) {
            if (tfsflasherase(sparesnum) < 0) {
                printf("Flash SPARE sector erase failed\n");
                return(TFSERR_FLASHFAILURE);
            }
            TEST_EXIT_POINT(31,tfssector);
        }

        TEST_EXIT_POINT(32,tfssector);

sector_defrag_skip:
        if (setdefragstate(sidx,SECTOR_DEFRAG_COMPLETE,verbose)!=TFS_OKAY)
            return(TFSERR_FLASHFAILURE);

sector_defrag_complete:
        sbase += ssize;
        if (addrtosector(sbase,0,&ssize,0) < 0)
            return(TFSERR_MEMFAIL);
    }

    /* If the last file copy did not enter the last tfssector, then erase */
    /* the last tfssector... */
    if (addrtosector(TFSEND,0,0,&sbase) < 0)
        return(TFSERR_MEMFAIL);
    dp = (struct defraghdr *)DefragStateTbl - 1;
    if ((dp->nda + dp->fhdr.filsize + TFSHDRSIZ) < sbase) {

        /* Must use spare sector to record this state because this is */
        /* the same sector that we were using to keep track of state. */
        DefragStateTbl = (ulong *)(TFSSPARE + sparesize - 4);
        if (setdefragstate(0,ERASING_LAST_SECTOR,verbose)!=TFS_OKAY)
            return(TFSERR_FLASHFAILURE);

        TEST_EXIT_POINT(33,-1);

erasing_last_sector:
        if (tfsflasherase(lasttfssector) < 0) {
            printf("Final sector erase (%d) failed\n",lasttfssector);
            return(TFSERR_FLASHFAILURE);
        }

        TEST_EXIT_POINT(34,-1);
    }

    /* All defragmentation is done, so verify sanity of files... */
    dummy = tfscheck(verbose);

    TEST_EXIT_POINT(35,-1);

    if (tfsflasherase(sparesnum) < 0) {
        printf("Final spare sector (%d) failed\n",sparesnum);
        return(TFSERR_FLASHFAILURE);
    }

    /* If resetwhendone flag is set, then reset here; else return result of */
    /* the file system check. */
    if (resetwhendone)
        monrestart(INITIALIZE);

    return(dummy);
}

/* setdefragstate():
    The state of the defragmentation process is maintained by a table of
    longs that is located at the end of the last sector of TFS space.
    Each long represents the state of a TFS sector.  This function simply
    modifies the bits in one of the longs to maintain the state of a
    particular sector.
    Note that the incoming sector number is relative to TFS space, so
    tfssector=0 does not represent the first sector of flash, it represents
    the first sector of TFS flash.
*/
static int
setdefragstate(tfssector,state,verbose)
int     tfssector, verbose;
ulong   state;
{
    if (verbose > 2)
        printf("  DefragState: %s\n",tfsdefragmsg(state));
    if (tfsflashwrite(&DefragStateTbl[tfssector],&state,sizeof(state)) < 0) {
        printf("setdefragstate(tfssec=%d,state=0x%x) failed\n",tfssector,state);
        return(TFSERR_FLASHFAILURE);
    }
    return(TFS_OKAY);
}

/* getndaoffset():
    This function is used by tfsclean when a file that is being defragmented
    spans across multiple sectors.  Since the defrag header only cotains
    the sector number of the starting and ending sectors that the file spans
    across, this is used to retrieve the total offset from the start of
    the new file (new_destination_address) as each additional sector is
    defragmented.
*/
static int
getndaoffset(struct defraghdr *dp,int sec,int *retoffset)
{
    int     i, ssize, offset;
    uchar   *addr, *nextbase, *base;

    offset = 0;
    sectortoaddr(dp->bsn,0,&nextbase);
    for(i=dp->bsn;i<sec;i++) {
        if (addrtosector(nextbase,0,&ssize,&base) < 0) {
            printf("getndaoffset (dp=0x%x,sector=%d) failed\n",dp,sec);
            return(TFSERR_MEMFAIL);
        }
        if (i == dp->bsn)
            offset = ssize - dp->bso;
        else if (i == dp->esn)
            offset += (ssize - dp->eso);
        else
            offset += ssize;
        nextbase = base+ssize;
    }
    
    *retoffset = offset;
    return(TFS_OKAY);
}

/* tfsfixup():
    See if a defragmentation was in progress.  If yes, finish it; else
    return.
*/
static int
tfsfixup(verbose)
int verbose;
{
    struct  defraghdr   *dfhp;
    struct  tfshdr      thdr;
    ulong   *statetbl, *spare_statetbl;
    int     sparesize, ftot, i, tfssector, snum;

#if DEFRAG_TEST_ENABLED
    ExitPoint=0;
    ExitSector=0;
#endif
    if (addrtosector(TFSSPARE,0,&sparesize,0) < 0)
        return(TFSERR_MEMFAIL);

    /* Set statetbl to point to what would be the first TFS sector's state */
    /* information bitfield (if defrag were in progress). */
    statetbl = (ulong *)(TFSEND+1);
    statetbl -= TFSSECTORCOUNT;

    /* Set spare_statetbl to point to the last 'long' in the spare sector. */
    spare_statetbl = (ulong *)(TFSSPARE + sparesize) - 1;

    /* Check the end of the TFS space to see if a state table exists, and */
    /* also check to see if the last location in the spare sector contains */
    /* state.  If neither, then defragmentation was not in progress so just */
    /* return here. */
    if ((*statetbl == (ulong)ERASED32) && (*spare_statetbl == (ulong)ERASED32))
    {
        return(0);
    }
    
    /* Maybe only the last sector (and spare) needs to be erased... */
    /* This means that all the files are up-to-date, but the */
    /* final stages of sector cleanup didn't finish. */
    /* This messiness is caused by the fact that the defragmentation could */
    /* have been interrupted when it was erasing the same sector that it */
    /* was storing state in.  For this sector, the defragmentor uses the */
    /* spare sector to store state. */
    if (*spare_statetbl == ERASING_LAST_SECTOR) {
        spare_statetbl -= (TFSSECTORCOUNT-1);
        if (verbose > 1) {
            printf("Defrag restart at TFS sector %d\n",
                tfssector+TFSSECTORCOUNT-1);
        }
        _tfsclean(1,spare_statetbl,0,TFSSECTORCOUNT-1,0,verbose);
        return(0);
    }
    
    if (verbose)
        printf("File system fixup in progress\n");

    if (*statetbl == (ulong)ERASED32) {
        statetbl = (ulong *)(TFSSPARE + sparesize);
        statetbl -= TFSSECTORCOUNT;
    }
    dfhp = (struct defraghdr *)statetbl - 1;

    ftot = 0;
    while(1) {
        if (dfhp->fhdr.hdrsize == 0xffff)
            break;
        thdr = dfhp->fhdr;
        thdr.next = 0;
        thdr.hdrcrc = 0;
        if (crc32(&thdr,TFSHDRSIZ) != dfhp->fhdr.hdrcrc)
            break;
        ftot++;
        dfhp--;
    }
    dfhp++;

    /* If ftot is zero, then we are fixing up an empty file system that */
    /* was in the process of being defragmented, so just erase all sectors */
    /* and be done... */
    if (ftot == 0) {
        if (verbose)
            printf("Cleaning up empty TFS...\n");
        if (tfsflasheraseall() < 0)
            printf("TFS erase-all failed\n");
        return(TFS_OKAY);
    }

    if (verbose)
        printf("%d files being defragmented\n",ftot);

    if (addrtosector(TFSSTART,&tfssector,0,0) < 0)
        return(TFSERR_MEMFAIL);
    snum = -1;

    /* Find currently active sector by stepping through the state table */
    /* until SECTOR_DEFRAG_INACTIVE state is detected, then step back 1. */
    for(i=0;i<TFSSECTORCOUNT;i++) {
        if (verbose > 1)
            printf("TFS Sector %d state: 0x%x (%s)\n",
                tfssector+i, statetbl[i], tfsdefragmsg(statetbl[i]));
        if ((snum == -1) && (statetbl[i] == SECTOR_DEFRAG_INACTIVE))
            snum = i-1; 
    }
    if (snum == -1) {
        printf("*****Starting at last sector\n");
        snum = TFSSECTORCOUNT-1;
        if (statetbl[snum] == COPY_HDRS_TO_SPARE) {
            spare_statetbl = (ulong *)(TFSSPARE + sparesize) - 1;
            if ((*spare_statetbl == HDRS_IN_SPARE) ||
                (*spare_statetbl == LASTSECTOR_IN_SPARE)) {
                printf("Adjusting statetbl from 0x%x to 0x%x\n",
                    statetbl,spare_statetbl - (TFSSECTORCOUNT-1));
                statetbl = spare_statetbl - (TFSSECTORCOUNT-1);
            }
        }
    }
    if (verbose > 1)
        printf("Defrag restart at TFS sector %d\n",tfssector+snum);
    return(_tfsclean(ftot,statetbl,dfhp,snum,0,verbose));
}

#if INCLUDE_OLDTFSCLEAN
/* oldtfsclean():
    Go through the file list and if any deleted files exist, 
    remove them from the flash to eliminate dead space.
    Copies all valid tfs files to RAM, then erases flash, then
    reloads what is in RAM back into flash.
    The function can be told to use a particular starting point in 
    memory or default to APPLICATION_RAMSTART.

    <<< WARNING >>> THIS FUNCTION SHOULD NOT BE INTERRUPTED
*/
static int
oldtfsclean(verbose,usedefault,tspace,reset)
int verbose, reset, usedefault;
uchar   *tspace;
{
    extern  ulong   APPLICATION_RAMSTART;
    uchar   *tbuf;
    int     delcnt, len, err, nfadd, retval, ilvl;
    struct  tfshdr *fp;

    delcnt = retval = 0;

    /* First just see if there are any deleted files. */
    /* If not, then our work is already done! */
    fp = (struct tfshdr *) TFSSTART;
    while(validtfshdr(fp)) {
        if (!fp->flags)
            delcnt++;
        fp = nextfp(fp);
    }
    if (delcnt == 0) {
        if (verbose)
            printf("No cleanup necessary\n");
        return(0);
    }
    printf("Reconstructing file system with %d dead file%s removed...\n",
        delcnt,delcnt>1 ? "s":"");

    /* From this point on, do not allow any interrupts. */
    ilvl = intsoff();
    if (usedefault)
        tspace = (uchar *)APPLICATION_RAMSTART;
    tbuf = tspace;
    fp = (struct tfshdr *)TFSSTART;
    nfadd = TFSSTART;
    while(validtfshdr(fp)) {
        if (fp->flags) {
            int i;
            /* If the file is currently opened, adjust the base address. */
            for (i=0;i<TFS_MAXOPEN;i++) {
                if (fileslots[i].offset != -1) {
                    if (fileslots[i].base == (uchar *)(TFS_BASE(fp))) {
                        fileslots[i].base = (uchar *)TFSSTART;
                        fileslots[i].base += (tbuf-tspace);
                        fileslots[i].base += TFSHDRSIZ;
                    }
                }
            }
            len = fp->filsize + TFSHDRSIZ;
            if (len % TFS_FSIZEMOD)
                len += TFS_FSIZEMOD - (len % TFS_FSIZEMOD);
            nfadd += len;
            err = tfsmemcpy(tbuf,fp,len,0,0);
            if (err != TFS_OKAY) {
                printf("clean: %s\n",tfserrmsg(err));
                return(err);
            }
            ((struct tfshdr *)tbuf)->next = (struct tfshdr *)nfadd;
            tbuf += len;
        }
        fp = nextfp(fp);
    }
    tfsinit();
    err = tfsflashwrite(TFSSTART,(uchar *)tspace,(tbuf-(uchar*)tspace));
    
    if (err < 0) {
        printf("Flash re-write failed\n");
        return(TFSERR_FLASHFAILURE);
    }
done:
    if (reset)
        monrestart(INITIALIZE);

    intsrestore(ilvl);
    return(TFS_OKAY);
}
#endif

/* tfscheck():
   Basic TFS sanity check...  Step through the file structures and make
   sure that crc of file data passes.
*/
static int
tfscheck(verbose)
int verbose;
{
    struct tfshdr *fp, *fp1;
    int corrupted;

    if (verbose)
        printf("File system check...\n");

    corrupted = 0;
    fp = (struct tfshdr *) TFSSTART;
    while(validtfshdr(fp)) {
        if (fp->flags) {    /* Skip test if file is removed. */
            if (verbose)
                printf("%s...",fp->name);
            if ((!(fp->flags & TFS_IPMOD)) &&
               (crc32(TFS_BASE(fp),fp->filsize) != fp->filcrc)) {
                printf("TFS crc check failure on '%s'\n",
                    fp->name);
                corrupted = 1;
            }
            else if (verbose)
                printf(" ok\n");
        }
        fp1 = nextfp(fp);
        if (!fp1) {
            corrupted = 1;
            break;
        }
        fp = fp1;
    }
    if (corrupted) {
        putchar(0x07);  /* Keyboard beep */
        printf("Corrupt File System\n");
        return(TFSERR_CORRUPT);
    }
    if (tfsflasherased(1))
        return(TFSERR_CORRUPT);
    return (TFS_OKAY);
}

static int
tfscheckfile(name)
char    *name;
{
    struct tfshdr *fp;
    int corrupted;

    corrupted = 0;
    fp = (struct tfshdr *) TFSSTART;
    while(validtfshdr(fp)) {
        if ((fp->flags) && (!strcmp(name,fp->name)) &&
           (!(fp->flags & TFS_IPMOD))) {
            if (crc32(TFS_BASE(fp),fp->filsize) != fp->filcrc) {
                printf("TFS crc check failure on '%s'\n",
                    fp->name);
                corrupted = 1;
            }
            break;
        }
        fp = nextfp(fp);
    }
    if (corrupted) {
        putchar(0x07);  /* Keyboard beep */
        printf("Corrupt File System\n");
        printf("Refer to User Manual for Instructions\n");
        return(TFSERR_CORRUPT);
    }
    return(TFS_OKAY);
}

static void
tfsclear()
{
    int i;

    /* Clear the fileslot[] table indicating that no files are opened. */
    for (i = 0; i < TFS_MAXOPEN; i++)
        fileslots[i].offset = -1;

    /* Init the time retrieval function pointers to their dummy values. */
    tfsGetAtime = dummyAtime;
    tfsGetLtime = dummyLtime;

    /* Default to using standard docommand() within scripts. */
    tfsDocommand = docommand;

#if 0
    /* Clear the in-a-script depth count ... */
    tfsInaScript = 0;

    /* Clear the runbootDone flag so that autoboot will occur... */
    tfsrunbootDone = 0;

    /* Flash modification count starts off at zero... */
    tfsFmodCount = 0;
#endif

    /* Start off with a buffer for 16 files.  This is probably more than */
    /* will be used, so it avoids reallocations in tfsreorder(). */
    tfsAlistSize = 16;
    tfsAlist = (TFILE **)malloc((tfsAlistSize+1) * sizeof(TFILE **));
    if (!tfsAlist) {
        printf("tfsclear(): tfsAlist allocation failed\n");
        tfsAlistSize = 0;
    }
}

/* tfsaipcheck():
    Called at startup to clean up any file that may be in AIP mode.
    A file is in AIP mode if it was in the process of being appended to
    and a power hit occurred.  Refer to notes in tfsclose() for details.
    There are a few cases to be covered here...
    1. there is no AIP file; so there is nothing to do.
    2. there is an AIP file, but no other file with the same name...
        In this case, the AIP file must be copied to another file (with the
        TFS_AIP flag cleared) and the AIP file is deleted.
    3. there is an AIP file and another file with the same name...
        In this case, the AIP file is simply deleted because the other file
        with the same name is newer.
*/ 
static void
tfsaipcheck()
{
    int     err;
    ulong   flags;
    TFILE   *tfp, *tfpa;
    char    buf[16];

    tfp = (struct tfshdr *) TFSSTART;
    tfpa = (struct tfshdr *)0;
    while(validtfshdr(tfp)) {
        if (tfp->flags) {
            if (tfpa) {
                if (!strcmp(TFS_NAME(tfp),TFS_NAME(tfpa))) {
                    tfsunlink(TFS_NAME(tfpa));
                    return;
                }
            }
            else if (!(TFS_FLAGS(tfp) & TFS_AIPNOT)) {
                tfpa = tfp;
            }
        }
        tfp = nextfp(tfp);
    }
    if (tfpa) {
        flags = TFS_FLAGS(tfpa) | TFS_AIPNOT;
        err = tfsadd(TFS_NAME(tfpa),TFS_INFO(tfpa),tfsflagsbtoa(flags,buf),
            (char *)(TFS_BASE(tfpa)),TFS_SIZE(tfpa));
        if (err != TFS_OKAY)
            printf("%s: %s\n",TFS_NAME(tfpa),tfserrmsg(err));
        
        tfsunlink(TFS_NAME(tfpa));
    }
}

/* tfsstartup():
    Called at system startup.
*/
void
tfsstartup()
{
    tfsclear();
    tfsfixup(3);
    tfsaipcheck();
}

/* tfsscript():
   Treat the file as a list of commands that should be executed
   as monitor commands.  Step through each line and execute it.
   If incoming fp is NULL, then assume this is being called by tfscontinue()
   and we are simply continuing the script from whereever we were earlier.
   Note that this function IS reentrant despite the fact that latestFp is
   static...
   Scripts can call other scripts that call other scripts (etc...) and
   that works fine because tfsscript() will just use more stack space but
   it eventually returns through the same function call tree.  The purpose
   of latestFp is to keep track of the most recent file pointer so that it
   can be accessed again if the script called an binary executable that
   called mon_appexit() (which does NOT return through the function call
   tree).
   WARNING:
   This works because it makes the assumption that the binary executable
   DOES NOT call tfsscript().
*/

static int
tfsscript(fp,verbose)
struct tfshdr *fp;
int verbose;
{
    static  struct tfshdr *latestFp[8];
    static  int latestFd[8];
    char    lcpy[CMDLINESIZE];
    int     tfd, lnsize;

    /* A non-null value in fp is the norm. */
    if (fp) {
        tfd = tfsopen(fp->name,TFS_RDONLY,0);
        if (tfd < 0)
            return(tfd);
        latestFp[tfsInaScript] = fp;
        latestFd[tfsInaScript++] = tfd;
printf("tfsscript(in) %d fp=0x%x,fd=%d\n",tfsInaScript,fp,tfd);
    }
    else {
        fp = latestFp[tfsInaScript];
        tfd = latestFd[tfsInaScript];
printf("tfsscript(re-in) %d fp=0x%x,fd=%d\n",tfsInaScript,fp,tfd);
    }

    while(1) {
        lnsize = tfsgetline(tfd,lcpy,CMDLINESIZE);
        if (lnsize == 0)    /* end of file? */
            break;
        if ((lcpy[0] == '\r') || (lcpy[0] == '\n')) /* empty line? */
            continue;

        lcpy[lnsize-1] = 0;         /* Remove the newline */

        /* Just in case the goto tag was set outside a script, */
        /* clear it now. */
        if (ScriptGotoTag) {
            free(ScriptGotoTag);
            ScriptGotoTag = (char *)0;
        }

        /* Execute the command line: */
        tfsDocommand(lcpy,verbose);

        /* If ScriptGotoTag is set, then attempt to reposition the line  */
        /* pointer to the line that contains the tag. */
        if (ScriptGotoTag) {
            char    *lp;
            int     tlen;

            tlen = strlen(ScriptGotoTag);
            tfsseek(tfd,0,TFS_BEGIN);
            while(1) {
                lnsize = tfsgetline(tfd,lcpy,CMDLINESIZE);
                if (lnsize == 0) {
                    printf("Tag '%s' not found\n",ScriptGotoTag+2);
                    free(ScriptGotoTag);
                    ScriptGotoTag = (char *)0;
                    return(TFS_OKAY);
                }
                if (!strncmp(lcpy,ScriptGotoTag,tlen)) {
                    free(ScriptGotoTag);
                    ScriptGotoTag = (char *)0;
                    break;
                }
            }
        }

#if INCLUDE_ETHERNET
        /* After each line, poll ethernet interface. */
        pollethernet();
#endif
    }
    tfsclose(tfd,0);
printf("tfsscript(out) %d fp=0x%x,fd=%d\n",tfsInaScript,fp,tfd);
    tfsInaScript--;
    return(TFS_OKAY);
}

/* gototag():
   Used with tfsscript to allow a command to adjust the pointer into the
   script that is currently being executed.  It simply populates the
   "ScriptGotoTag" pointer with the tag that should be branched to next.
*/
void
gototag(tag)
char    *tag;
{
    if (ScriptGotoTag)
        free(ScriptGotoTag);
    ScriptGotoTag = malloc(strlen(tag)+8);
    sprintf(ScriptGotoTag,"# %s",tag);
}

/* tfscat():
   Print each character of the file until NULL terminate. Replace
   each instance of CR or LF with CRLF.
*/
static void
tfscat(struct tfshdr *fp, int more)
{
    int i, lcnt;
    char    *cp;

    lcnt = 0;
    cp = (char *) (TFS_BASE(fp));
    for(i=0;i<fp->filsize;i++) {
        if ((*cp == '\r') || (*cp == '\n')) {
            puts("\r\n");
            lcnt++;
            if (lcnt == more) {
                if (More() == 0)
                    break;
                lcnt = 0;
            }
        }
        else
            putchar(*cp);
        cp++;
    }
}

/* tfsexec: Treat the file as machine code that is COFF or ELF. */

static int
tfsexec(fp,verbose)
int verbose;
struct tfshdr *fp;
{
    int err, (*entry)(), octx;
    long    address;

    if (fp->flags & TFS_COFF)
        err = tfsloadcoff(fp,verbose,&address,0);
    else if (fp->flags & TFS_ELF)
        err = tfsloadelf(fp,verbose,&address,0);
    else if (fp->flags & TFS_AOUT)
        err = tfsloadaout(fp,verbose,&address,0);
    if (err != TFS_OKAY)
        return(err);

    entry = (int(*)())address;
    octx = ctxAPP();    /* Change context to APPLICATION. */
    entry();            /* Call entrypoint (may not return). */
    ctxMON(octx);       /* Change context to APPLICATION. */
    return(TFS_OKAY);
}

/* tfsmemset():
   Superset of memset().  Includes verbose option plus verification after
   set.
*/
static int
tfsmemset(to,val,count,verbose,verifyonly)
uchar *to, val;
int count, verbose, verifyonly;
{
    uchar   *end;

    if (verifyonly)
        goto done;

    if (verbose)
        printf("set  %6d bytes  at  0x%08x to 0x%02x",count,to,val);

    if (count == 0)
        goto done;

    memset(to,val,count);
    end = to+count;
    while(to < end) {
        if (*to != val) {
            if (verbose)
                printf(" failed\n");
            return(TFSERR_MEMFAIL);
        }
        to++;
    }
done:
    if (verbose)
        printf("\n");
    return(TFS_OKAY);
}

/* tfsmemcpy():
   Superset of memcpy().  Includes verbose option plus verification after
   copy.  Takes advantage of address alignment when possible.
   Also, since TFS may be using this function to load text into memory, it
   is important that Dcache be flushed and Icache be invalidated for the
   range of memory affected.
*/
static int
tfsmemcpy(to,from,count,verbose,verifyonly)
register uchar *to, *from;
int count, verbose, verifyonly;
{
    int err;
    register uchar  *end;

    if (verbose)
        printf("%s %6d bytes from 0x%08x to 0x%08x",
            verifyonly ? "vrfy" : "copy", count,from,to);

    if (verifyonly) {
        while(count) {
            if (*to != *from)
                break;
            to++;
            from++;
            count--;
        }
        if (count) {
            if (verbose) {
                printf(" FAILED\n");
                printf("            (0x%02x @ 0x%08x should be 0x%02x)\n",
                    *to,to,*from);
            }
            return(TFSERR_MEMFAIL);
        }
        else
            if (verbose)
                printf(" OK\n");
            return(TFS_OKAY);
    }

    if (count == 0)
        goto done;

    if (to != from) {
        err = 0;
        if (!((int)to & 3) && !((int)from & 3) && !(count & 3)) {
            register ulong  *lto, *lfrom, *lend;
    
            count >>= 2;
            lto = (ulong *)to;
            lfrom = (ulong *)from;
            lend = lto + count;
            while(lto < lend) {
                *lto = *lfrom;
                if (*lto != *lfrom) {
                    err = 1;
                    break;
                }
                lto++;
                lfrom++;
            }
        }
        else if (!((int)to & 1) && !((int)from & 1) && !(count & 1)) {
            register ushort *sto, *sfrom, *send;
    
            count >>= 1;
            sto = (ushort *)to;
            sfrom = (ushort *)from;
            send = sto + count;
            while(sto < send) {
                *sto = *sfrom;
                if (*sto != *sfrom) {
                    err = 1;
                    break;
                }
                sto++;
                sfrom++;
            }
        }
        else {
            end = to + count;
            while(to < end) {
                *to = *from;
                if (*to != *from) {
                    err = 1;
                    break;
                }
                to++;
                from++;
            }
        }
        if (err) {
            if (verbose)
                printf(" failed\n");
            return(TFSERR_MEMFAIL);
        }
    }

done:
    if (verbose)
        printf("\n");

    flushDcache(to,count);
    invalidateIcache(to,count);

    return(TFS_OKAY);
}

/* tfsloadaout():
   The file pointed to by fp has been determined to be an A.OUT
   formatted file.  This function loads the sections of that file into
   the designated locations and returns the address of the entry point.
*/
static int
tfsloadaout(struct tfshdr *fp,int verbose,long *entrypoint,int verifyonly)
{
    int     i;
    uchar   *cp, *tfrom, *dfrom;
    struct  exec *ehdr;

    /* Establish file header pointer... */
    ehdr = (struct exec *)(TFS_BASE(fp));

    /* Return error if relocatable... */
    if ((ehdr->a_trsize) || (ehdr->a_drsize))
        return(TFSERR_BADHDR);

    /* Establish locations from which text and data are to be */
    /* copied from ... */
    tfrom = (uchar *)(ehdr+1);
    dfrom = tfrom+ehdr->a_text;

    /* Copy/verify text and data sections to RAM: */
    if (verbose)
        printf("%-10s: ","text");
    if (tfsmemcpy(ehdr->a_entry,tfrom,ehdr->a_text,verbose,verifyonly) != 0)
        return(TFSERR_MEMFAIL);

    if (verbose)
        printf("%-10s: ","data");
    if (tfsmemcpy(ehdr->a_entry+ehdr->a_text,dfrom,ehdr->a_data,verbose,
        0,verifyonly) != 0)
        return(TFSERR_MEMFAIL);

    /* Clear out bss space: */
    if (verbose)
        printf("%-10s: ","bss");
    if (tfsmemset(ehdr->a_entry+ehdr->a_text+ehdr->a_data,
        0,ehdr->a_bss,verbose,verifyonly) != 0)
        return(TFSERR_MEMFAIL);


    if (verbose & !verifyonly)
        printf("entrypoint: 0x%x\n",ehdr->a_entry);

    /* Store entry point: */
    if (entrypoint)
        *entrypoint = (long)(ehdr->a_entry);

    return(TFS_OKAY);
}

/* tfsloadcoff():
   The file pointed to by fp has been determined to be a COFF file.
   This function loads the sections of that file into the designated 
   locations.
*/
static int
tfsloadcoff(struct tfshdr *fp,int verbose,long *entrypoint,int verifyonly)
{
    int i, err;
    FILHDR  *fhdr;
    AOUTHDR *ahdr;
    SCNHDR  *shdr;

    /* Establish file header pointers... */
    fhdr = (FILHDR *)(TFS_BASE(fp));
    if ((fhdr->f_opthdr == 0) || ((fhdr->f_flags & F_EXEC) == 0))
        return(TFSERR_BADHDR);
    
    err = 0;
    ahdr = (AOUTHDR *)(fhdr+1);
    shdr = (SCNHDR *)((uchar *)ahdr + fhdr->f_opthdr);

    /* For each section header, relocate or clear if necessary... */
    for (i=0;!err && i<fhdr->f_nscns;i++) {
        if (shdr->s_size == 0) {
            shdr++;
            continue;
        }
        if (verbose)
            printf("%-10s: ",shdr->s_name);
        if (ISLOADABLE(shdr->s_flags)) {
#if INCLUDE_UNPACK
            if (TFS_ISCPRS(fp)) {
                extern  int unpacker();
                int     outsize;

                if (unpacker(shdr->s_scnptr+(int)fhdr,shdr->s_paddr,
                    0,&outsize,0) == -1) {
                    err++;
                    shdr++;
                    continue;
                }
                if (verbose)
                    printf("dcmp %6d bytes from 0x%08x to 0x%08x\n",outsize,
                        shdr->s_scnptr+(int)fhdr,shdr->s_paddr);
            }
            else
#endif
            {
                if (tfsmemcpy(shdr->s_paddr,shdr->s_scnptr+(int)fhdr,
                    shdr->s_size,verbose,verifyonly) != 0)
                    err++;
            }
        }
        else if (ISBSS(shdr->s_flags)) {
            if (tfsmemset(shdr->s_paddr,0,shdr->s_size,verbose,verifyonly) != 0)
                err++;
        }
        else if (verbose)
            printf("???\n");
        shdr++;
    }

    if (verbose & !verifyonly)
        printf("entrypoint: 0x%x\n",ahdr->entry);

    if (err)
        return(TFSERR_MEMFAIL);

    /* Store entry point: */
    if (entrypoint)
        *entrypoint = (long)(ahdr->entry);

    return(TFS_OKAY);
}

static int
tfsloadelf(struct tfshdr *fp,int verbose,long *entrypoint,int verifyonly)
{
    Elf32_Word  size, notproctot;
    int         i, err;
    char        *shname_strings;
    ELFFHDR     *ehdr;
    ELFSHDR     *shdr;

    /* Establish file header pointers... */
    ehdr = (ELFFHDR *)(TFS_BASE(fp));
    shdr = (ELFSHDR *)((int)ehdr + ehdr->e_shoff);
    err = 0;

    /* Verify basic file sanity... */
    if ((ehdr->e_ident[0] != 0x7f) || (ehdr->e_ident[1] != 'E') ||
        (ehdr->e_ident[2] != 'L') || (ehdr->e_ident[3] != 'F'))
        return(TFSERR_BADHDR);

    /* Store the section name string table base: */
    shname_strings = (char *)ehdr + shdr[ehdr->e_shstrndx].sh_offset;

    notproctot = 0;

    /* For each section header, relocate or clear if necessary... */
    for (i=0;!err && i<ehdr->e_shnum;i++,shdr++) {
        if ((size = shdr->sh_size) == 0)
            continue;

        if ((verbose) && (ehdr->e_shstrndx != SHN_UNDEF))
            printf("%-10s: ", shname_strings + shdr->sh_name);

        if (!(shdr->sh_flags & SHF_ALLOC)) {
            notproctot += size;
            if (verbose)
                printf("     %6d bytes not processed (tot=%d)\n",
                    size,notproctot);
            continue;
        }

        if (shdr->sh_type == SHT_NOBITS) {
            if (tfsmemset(shdr->sh_addr,0,size,verbose,verifyonly) != 0)
                err++;
        }
        else {
            if (tfsmemcpy(shdr->sh_addr,(int)ehdr+shdr->sh_offset,
                size,verbose,verifyonly) != 0)
                err++;
        }
    }

    if (verbose & !verifyonly)
        printf("entrypoint: 0x%x\n",ehdr->e_entry);

    if (err)
        return(TFSERR_MEMFAIL);

    /* Store entry point: */
    if (entrypoint)
        *entrypoint = (long)(ehdr->e_entry);

    return(TFS_OKAY);
}

/* struct tfsran:
    Used by tfsrunboot only.  No need to put this in tfs.h.
*/
struct tfsran {
    char name[TFSNAMESIZE+1];
};

/* tfsrunboot():
   This function is called at monitor startup.  It scans the list of
   files built by tfsreorder() and executes each file in the list that has
   the BRUN flag set.  As each file is run its name is added to the
   ranlist[] table.

   After each file is run, there is a check made to see if the flash has
   been modified.  If yes, then tfsreorder() is run again and we start 
   over at the top of the list of files organized by tfsreorder().  As
   we step through the tfsAlist[] array, if the file has a BRUN flag set
   but it is already in the ranlist[] table, it is not run again.
   
   This scheme allows a file in the initial list of BRUN files to modify
   the file list without confusing the list of files that are to be run.
   Files (even new BRUN files) can be added to the list by some other BRUN
   file, and these new files will be run.

   NOTE:
   This function is called at system startup, and may also be called after
   an application exits (see APP_EXIT in main.c).  This is because there
   may be more than one executable program in the list of auto-bootables,
   so after one returns (via appexit()), we must check to see if there
   are any others to be run.
*/
int
tfsrunboot()
{
    extern  int pollConsole(char *);
    static  int rancnt, pass;
    static  struct  tfsran *ranlist;
    char    *argv[2];
    int     aidx, ridx, err, fmodcnt;

    /* The argv[] array is used by tfsrun(); argv[0] is name of file to be  */
    /* executed, argv[1] must be nulled to indicate no command line args    */
    /* passed to the BRUN file/script.                                      */
    argv[1] = (char *)0;

    /* Keep a local copy of tfsFmodCount so that we can determine if flash  */
    /* was modified by one of the BRUN files executed.                      */
    fmodcnt = tfsFmodCount;

    /* Create list of file pointers (tfsAlist[]) in alphabetical order      */
    /* based on name...                                                     */
    if ((err = tfsreorder()) < 0) {
        printf("tfsrunboot() reorder1: %s\n",tfserrmsg(err));
        tfsrunbootDone = 1;
        return(-1);
    }

    /* On only the first call to tfsrun boot we clear the ranlist pointer.  */
    /* This pointer is the base address of a list of file names that have   */
    /* been run.                                                            */
    if (pass == 0) {
        rancnt = 0;
        ranlist = (struct tfsran *)0;
    }
    pass++;

restartloop:
    for (aidx=0;tfsAlist[aidx];aidx++) {
        char    fname[TFSNAMESIZE+1];
        int     alreadyran;
        struct  tfshdr *fp;
        struct  tfsran *rp;

        fp = tfsAlist[aidx];
        strcpy(fname,TFS_NAME(fp));

        /* If the file has no BRUN flag set, just continue.  If a BRUN flag */
        /* is set, then see if the file has already been run.  If yes, then */
        /* just continue; else run the file.                                */
        alreadyran = 0;
        if (fp->flags & (TFS_BRUN | TFS_QRYBRUN)) {
            for(ridx=0;ridx<rancnt;ridx++) {
                if (!strcmp(ranlist[ridx].name,fname)) {
                    alreadyran = 1;
                    break;
                }
            }
        }
        else
            continue;           /* No BRUN flag set. */

        if (alreadyran) {       /* BRUN flag set, but file has already      */
            continue;           /* been run.                                */
        }

        err = TFS_OKAY;
        argv[0] = fname;

        /* At this point we know the file is a BRUN type, so just see if    */
        /* the query should precede the run...                              */
        if (fp->flags & TFS_QRYBRUN) {
            char query[TFSNAMESIZE+8];

            sprintf(query,"%s?",fname);
            if (pollConsole(query))
                continue;
        }
        /* Increase the size of the ranlist[] table and add the file that   */
        /* is about to be run to that list...                               */
        rancnt++;
        rp = (struct tfsran*)realloc(ranlist,rancnt*sizeof(struct tfsran));
        if (!rp) {
            if (ranlist)
                free(ranlist);
            printf("tfsrunboot() runlist realloc failure\n");
            tfsrunbootDone = 1;
            return(-1);
        }
        ranlist = rp;
        strcpy(ranlist[rancnt-1].name,fname);

        /* Run the executable... */
        if ((err = tfsrun(argv,0)) != TFS_OKAY)
            printf("%s: %s\n",fname,tfserrmsg(err));

        /* If flash has been modified, then we must re-run tfsreorder() and */
        /* start over...                                                    */
        if (fmodcnt != tfsFmodCount) {
            if ((err = tfsreorder()) < 0) {
                printf("tfsrunboot() reorder2: %s\n",tfserrmsg(err));
                tfsrunbootDone = 1;
                return(err);
            }
            fmodcnt = tfsFmodCount;
            goto restartloop;
        }
    }
    if (ranlist)
        free(ranlist);
    tfsrunbootDone = 1;
    return(rancnt);
}

/* tfsreorder():
   Populate the tfsAlist[] array with the list of currently active file
   pointers, but put in alphabetical (lexicographical using strcmp()) order
   based on the filename.
   Note that after each file addition/deletion, this must be re-run.
*/
static int
tfsreorder(void)
{
    struct tfshdr *fp;
    int i, j, tot;

    /* Determine how many valid files exist, and create tfsAlist array: */
    tot = 0;
    fp = (struct tfshdr *)TFSSTART;
    while(validtfshdr(fp)) {
        if (fp->flags)
            tot++;
        fp = nextfp(fp);
    }

    /* If tfsAlist already exists, and is already big enough, then         */
    /* don't do any allocation; otherwise, create the array with one extra */
    /* slot for a NULL pointer used elsewhere as an end-of-list indicator. */
    if (tot > tfsAlistSize) {
        tfsAlist = (TFILE **)realloc(tfsAlist,(tot+1) * sizeof(TFILE **));
        if (!tfsAlist) {
            tfsAlistSize = 0;
            return(TFSERR_MEMFAIL);
        }
        tfsAlistSize = tot;
    }

    /* Clear the entire table (plus the extra one at the end): */
    for(i=0;i<=tot;i++)
        tfsAlist[i] = (TFILE *)0;

    /* Populate tfsAlist[] with a pointer to each active file */
    /* in flash as they exist in memory... */
    i = 0;
    fp = (TFILE *)TFSSTART;
    while(validtfshdr(fp)) {
        if (fp->flags) {
            tfsAlist[i++] = fp;
        }
        fp = nextfp(fp);
    }

    /* Now run a bubble sort on that list based on the lexicographical */
    /* ordering returned by strcmp... */
    for(i=1;i<tot;++i) {
        for(j=tot-1;j>=i;--j) {
            if (strcmp(TFS_NAME(tfsAlist[j-1]),TFS_NAME(tfsAlist[j])) > 0) {
                fp = tfsAlist[j-1];
                tfsAlist[j-1] = tfsAlist[j];
                tfsAlist[j] = fp;
            }
        }
    }
    return(tot);
}

/* tfscontinue():
    This function is called as a result of an application exit.  This
    occurs when application code calls mon_appexit().  The purpose is to
    support two things:

    1. Sequential execution of multiple executable binary files through
       tfsrunboot().
    2. Return from execution of a binary executable through a script.
*/
void
tfscontinue()
{
    if (tfsInaScript) {
        printf("tfscontinue() tfsscript...\n");
        tfsscript(0,0);
    }
    if (!tfsrunbootDone) {
        printf("tfscontinue() tfsrunboot...\n");
        tfsrunboot();
    }
}

/* tfsunopen():
    If the incoming file descriptor is valid, mark that file as no-longer
    opened and return TFS_OKAY; else return TFS_BADARG.
    descriptor.
*/
static long
tfsunopen(fd)
int fd;
{
    if ((fd < 0) || (fd >= TFS_MAXOPEN))
        return(TFSERR_BADARG);
    if (fileslots[fd].offset == -1)
        return(TFSERR_BADARG);
    fileslots[fd].offset = -1;
    return(TFS_OKAY);
}

/* tfstell():
    Return the offset into the file that is specified by the incoming
    descriptor.
*/
static long
tfstell(fd)
int fd;
{
    if ((fd < 0) || (fd >= TFS_MAXOPEN))
        return(TFSERR_BADARG);
    return(fileslots[fd].offset);
}

/* tfscompare():
    Compare the content of the file specified by tfp with the content pointed
    to by the remaining arguments.  If identical, return 0; else return -1.
*/
static int
tfscompare(TFILE *tfp,char *name, char *info, char *flags, uchar *src, int size)
{
    char flgbuf[16];

    /* Compare size, name, info field, flags and data: */

    /* Size... */
    if (TFS_SIZE(tfp) != size)
        return(-1);

    /* Name... */
    if (strcmp(name,TFS_NAME(tfp)))
        return(-1);

    /* Info field... */
    if (info) {
        if (strcmp(info,TFS_INFO(tfp)))
            return(-1);
    }
    else {
        if (TFS_INFO(tfp)[0] != 0)
            return(-1);
    }

    /* Flags... */
    tfsflagsbtoa(TFS_FLAGS(tfp),flgbuf);
    if (flags) {
        if (strcmp(flags,flgbuf))
            return(-1);
    }
    else if (flgbuf[0] != 0)
        return(-1);
    
    /* Data... */
    if (memcmp(TFS_BASE(tfp),(char *)src,size)) 
        return(-1);

    return(0);
}

/* tfsinit():
   Clear out all the flash that is dedicated to the file system.
   This removes all currently stored files and erases the flash.
   MONLIB NOTICE: this function is accessible through monlib.c.
*/
int
tfsinit()
{
    /* Erase all non-monitor flash space */
    if (tfsflasheraseall() < 0)
        printf("Erase failed\n");

    return(TFS_OKAY);
}

/* tfsadd():
   Add a file to the current list.
   If the file already exists AND everything is identical between the
   old and the new (flags, info and data), then return and do nothing;
   else remove the old file prior to adding the new one.
   MONLIB NOTICE: this function is accessible through monlib.c.
*/
int
tfsadd(char *name, char *info, char *flags, uchar *src, int size)
{
    struct tfshdr *fp, tf;
    int modnext, i, j, ftot, cleanupcount, err;
    ulong endoftfsflash;
    char *cp;

    /* printf("tfsadd(%s,%s,%s,0x%x,%d)\n", name,info,flags,src,size); */
    if (!size)
        return(TFSERR_BADARG);

    cleanupcount = 0;

tryagain:
    fp = (struct tfshdr *) TFSSTART;

    /* Find end of current storage: */
    ftot = 0;
    while (fp) {
        if (fp->hdrsize == ERASED16)
            break;
        if (fp->flags & TFS_AIPNOT) {
            if (!strcmp(TFS_NAME(fp),name)) {
                /* If file of the same name exists AND it is identical to   */
                /* the new file to be added, then return TFS_OKAY and be    */
                /* done; otherwise, remove the old one and continue.        */
                if (!tfscompare(fp,name,info,flags,src,size))
                    return(TFS_OKAY);
                
                err = tfsunlink(name);
                if (err == TFS_OKAY)
                    goto tryagain;
                else
                    return(err);
            }
            ftot++;
        }
        fp = nextfp(fp);
    }
    if (!fp)    /* If fp is 0, then nextfp() (above) detected corruption. */
        return (TFSERR_CORRUPT);

    /* Make sure that the space is available for writing to flash... */
    /* Remember that the end of useable flash space must take into */
    /* account the fact that some space must be left over for the */
    /* defragmentation state tables. */
    endoftfsflash = (TFSEND + 1) - ((ftot+1) * sizeof(struct defraghdr)) -
            (TFSSECTORCOUNT * sizeof(long)) - 16;

    if (((ulong)fp + TFSHDRSIZ + size) > endoftfsflash) {
#if TFS_AUTODEFRAG
        if (!cleanupcount) {
            tfsclean(0,0,0,0,0,1);
            cleanupcount++;
            goto tryagain;
        }
        else
#endif
            return(TFSERR_FLASHFULL);
    }

    memset(&tf,0,TFSHDRSIZ);

    /* If necessary, truncate name and info to TFSNAMESIZE. */
    strncpy(tf.name, name, TFSNAMESIZE);
    if (info)
        strncpy(tf.info, info, TFSNAMESIZE);
    tf.name[TFSNAMESIZE] = 0;
    tf.info[TFSNAMESIZE] = 0;
    tf.hdrsize = TFSHDRSIZ;
    tf.filsize = size;
    tf.flags = tfsflagsatob(flags);
    if (tf.flags == -1)
        tf.flags = 0;
    tf.flags |= (TFS_ACTIVE | TFS_AIPNOT);
    if (!(tf.flags & TFS_IPMOD))
        tf.filcrc = crc32(src, size);
    else
        tf.filcrc = 0xffffffff;

    tf.modtime = tfsGetLtime();
    tf.next = 0;
    tf.hdrcrc = 0;
    tf.hdrcrc = crc32(&tf,TFSHDRSIZ);

    /* Put next pointer on mod 16 address... */
    modnext = (int)(fp+1) + size;
    if (modnext & 0xf) {
        modnext += 16;
        modnext &= ~0xf;
    }
    if (modnext >= TFSEND)
        tf.next = (struct tfshdr *)0;
    else
        tf.next = (struct tfshdr *) modnext;

    /* Now copy the file and header to flash. */
    /* Note1: the header is copied AFTER the file has been */
    /* successfully copied.  If the header were written successfully, */
    /* then the data write failed, the header would be incorrectly */
    /* pointing to an invalid file. To avoid this, simply write the */
    /* data first. */
    /* Note2: if the file is in-place-modifiable, then there is no */
    /* file data to be written to the flash.  It will be left as all FFs */
    /* so that the flash can be modified by tfsipmod() later. */

    /* Write the file to flash if not TFS_IPMOD: */
    if (!(tf.flags & TFS_IPMOD)) {
        if (tfsflashwrite((char *)(fp+1),src,size) == -1)
            return(TFSERR_FLASHFAILURE);
    }

    /* Write the file header to flash: */
    if (tfsflashwrite(fp,&tf,TFSHDRSIZ) == -1)
        return(TFSERR_FLASHFAILURE);

    /* Double check the CRC now that it is in flash. */
    if (!(tf.flags & TFS_IPMOD)) {
        if (crc32(fp+1, size) != tf.filcrc)
            return(TFSERR_BADCRC);
    }
    tfslog(TFSLOG_ADD,name);
    return(TFS_OKAY);
}

/* tfsunlink():
    Delete a file from the current list of files. Note that there
    is no attempt to de-fragment the flash; it simply nulls out the flags
    field of the file.  If successful return 0; else return error number.
   MONLIB NOTICE: this function is accessible through monlib.c.
*/
tfsunlink(char *name)
{
    struct tfshdr *fp;
    ulong zero;

    fp = tfsstat(name);
    if (!fp)
        return(TFSERR_NOFILE);

    if (TFS_USRLVL(fp) > UserLevel)
        return(TFSERR_USERDENIED);

    zero = 0;
    if (tfsflashwrite(&fp->flags,&zero,sizeof(long)) < 0)
        return(TFSERR_FLASHFAILURE);

    tfslog(TFSLOG_DEL,name);
    return (TFS_OKAY);
}

/* tfsrun():
   Run the named file.  Based on the file flags, the file is either
   executed as a COFF/ELF file with all relocation data in the file
   or run as a simple script of monitor commands.
   MONLIB NOTICE: this function is accessible through monlib.c.
*/

tfsrun(char **arglist,int verbose)
{
    int i;
    struct tfshdr *fp;
    char    namebak[TFSNAMESIZE+8], *name;

    name = arglist[0];
    fp = tfsstat(name);
    if (!fp)
        return(TFSERR_NOFILE);

    if (TFS_USRLVL(fp) > UserLevel)
        return(TFSERR_USERDENIED);

    /* Store away the argument list so that it is accessible by the script  */
    /* or executable application about to be run:                           */
    for(i=0;arglist[i];i++)
        putargv(i,arglist[i]);
    putargv(i,(char *)0);

    /* If the incoming named file doesn't exist, and that incoming name is  */
    /* the TFS_RCFILE string, then try TFS_RCFILE.bak as an alternative.    */
    /* This allows the user to copy TFS_RCFILE to TFS_RCFILE.bak, then      */
    /* delete/reload TFS_RCFILE.  Note that usually TFS_RCFILE is "monrc".  */
    if (!fp) {
        if (!strcmp(name,TFS_RCFILE)) {
            sprintf(namebak,"%s.bak",TFS_RCFILE);
            fp = tfsstat(namebak);
            if (!fp)
                return(TFSERR_NOFILE);
            name = namebak;
            printf("Running %s...\n",namebak);
        }
        else
            return (TFSERR_NOFILE);
    }

    if (!(fp->flags & TFS_EXEC))
        return(TFSERR_NOTEXEC);

    if (!(fp->flags & TFS_IPMOD)) {
        if (crc32(TFS_BASE(fp), fp->filsize) != fp->filcrc)
            return(TFSERR_BADCRC);
    }
    /* Machine code or script... */
    if (fp->flags & (TFS_COFF | TFS_ELF | TFS_AOUT))
        return(tfsexec(fp,verbose));
    else
        return(tfsscript(fp,verbose));
}

/* tfsnext():
   Called to retrieve the "next" file in the tfs list.  If
   incoming argument is NULL then return the first file in the list.  If no
   more files, return NULL; else return the tfshdr structure pointer to the
   next (or first) file in the tfs.
   MONLIB NOTICE: this function is accessible through monlib.c.
*/
struct tfshdr *
tfsnext(struct tfshdr *fp)
{
    struct tfshdr *fpnext;

    if (!fp)
        fpnext = (struct tfshdr *) TFSSTART;
    else
        fpnext = nextfp(fp);
    while(validtfshdr(fpnext)) {
        if (fpnext->flags)
            return (fpnext);
        fpnext = fpnext->next;
    }
    return ((struct tfshdr *) 0);
}

/* tfsstat():
   Steps through the list of files until it finds the specified
   filename or reaches the end of the list.  If found, a pointer to that
   file's structure is returned; else return 0.
   MONLIB NOTICE: this function is accessible through monlib.c.
*/
struct tfshdr *
tfsstat(char *name)
{
    struct tfshdr *fp;

    fp = (struct tfshdr *) TFSSTART;
    while(validtfshdr(fp)) {
        if ((fp->flags) && (strcmp(name, fp->name) == 0))
            return(fp);
        fp = nextfp(fp);
    }
    return ((struct tfshdr *) 0);
}

/* tfsread():
   Similar to a standard read call to a file.
   MONLIB NOTICE: this function is accessible through monlib.c.
*/
int
tfsread(int fd, char *buf, int cnt)
{
    struct tfsdat *tdat;
    uchar *from;

    /* Verify valid range of incoming file descriptor. */
    if ((cnt < 1) || (fd < 0) || (fd >= TFS_MAXOPEN))
        return(TFSERR_BADARG);

    /* Make sure the file pointed to by the incoming descriptor is active. */
    if (fileslots[fd].offset == -1)
        return(TFSERR_BADARG);

    tdat = &fileslots[fd];

    if (tdat->offset == -1)
        return(TFSERR_BADFD);

    if (tdat->offset >= tdat->hdr.filsize)
        return(TFSERR_EOF);

    /* If request size is within the range of the file and current */
    /* then copy the data to the requestors buffer, increment offset */
    /* and return the count. */
    if ((tdat->offset + cnt) <= tdat->hdr.filsize) {
        from = (uchar *) tdat->base + tdat->offset;
        if (tfsmemcpy(buf, from, cnt,0,0) != 0)
            return(TFSERR_MEMFAIL);
    }
    /* If request size goes beyond the size of the file, then copy */
    /* to the end of the file and return that smaller count. */
    else {
        from = (uchar *) tdat->base + tdat->offset;
        cnt = tdat->hdr.filsize - tdat->offset;
        if (tfsmemcpy(buf, from, cnt, 0, 0) != 0)
            return(TFSERR_MEMFAIL);
    }
    tdat->offset += cnt;
    return(cnt);
}

/* tfswrite():
   Similar to a standard write call to a file.
   MONLIB NOTICE: this function is accessible through monlib.c.
*/
int
tfswrite(int fd, char *buf, int cnt)
{
    struct tfsdat *tdat;

    /* Verify valid range of incoming file descriptor. */
    if ((cnt < 1) || (fd < 0) || (fd >= TFS_MAXOPEN))
        return(TFSERR_BADARG);

    /* Make sure the file pointed to by the incoming descriptor is active. */
    if (fileslots[fd].offset == -1)
        return(TFSERR_BADARG);

    tdat = &fileslots[fd];

    /* Make sure file is not opened as read-only */
    if (tdat->flagmode & TFS_RDONLY)
        return(TFSERR_RDONLY);

    if (tfsmemcpy(tdat->wptr,buf,cnt,0,0) != 0)
        return(TFSERR_MEMFAIL);

    tdat->wptr += cnt;
    tdat->offset += cnt;
    return(TFS_OKAY);
}

/* tfsopen():
   Open a file for reading or creation.  If file is opened for writing,
   then the caller must provide a RAM buffer  pointer to be used for
   the file storage until it is transferred to flash by tfsclose().
   Note that the "buf" pointer is only needed for opening a file for
   creation or append (writing).
   MONLIB NOTICE: this function is accessible through monlib.c.
*/
int
tfsopen(char *file,long flagmode,char *buf)
{
    register int i;
    int     idx, errno, ival;
    long    fmode;
    TFILE   *fp;
    struct  tfsdat *slot;

    /* See if file exists... */
    fp = tfsstat(file);

    errno = TFS_OKAY;

    fmode = flagmode & (TFS_RDONLY | TFS_APPEND | TFS_CREATE);

    /* This switch verifies...
       - that the file exists if TFS_RDONLY or TFS_APPEND
       - that the file does not exist if TFS_CREATE
    */
    switch(fmode) {
    case TFS_RDONLY:    /* Read existing file only, no change to file at all. */
        if (!fp)
            errno = TFSERR_NOFILE;
        else {
            if ((fp->flags & TFS_UNREAD) && (TFS_USRLVL(fp) > UserLevel))
                errno = TFSERR_USERDENIED;
        }
        break;
    case TFS_APPEND:    /* Append to the end of the current file. */
        if (!fp)
            errno = TFSERR_NOFILE;
        else {
            if (TFS_USRLVL(fp) > UserLevel)
                errno = TFSERR_USERDENIED;
        }
        break;
    case TFS_CREATE:    /* Create a new file */
        if (fp)
            errno = TFSERR_FILEEXISTS;
        break;
    case (TFS_APPEND|TFS_CREATE):   /* If both mode bits are set, clear one */
        if (fp) {                   /* based on the presence of the file. */
            if (TFS_USRLVL(fp) > UserLevel)
                errno = TFSERR_USERDENIED;
            fmode = TFS_APPEND;
        }
        else
            fmode = TFS_CREATE;
        break;
    default:
        errno = TFSERR_BADARG;
        break;
    }

    if (errno != TFS_OKAY)
        return(errno);

    slot = fileslots;
    for (i=0;i<TFS_MAXOPEN;i++,slot++) {
        if (slot->offset == -1) {
            slot->offset = 0;
            slot->flagmode = flagmode;
            if (flagmode & TFS_CREATE) {
                strncpy(slot->hdr.name,file,TFSNAMESIZE);
                slot->base = (uchar *)buf;
                slot->wptr = (uchar *)buf;
            }
            else if (flagmode & TFS_APPEND) {
                strncpy(slot->hdr.name,file,TFSNAMESIZE);
                if (tfsmemcpy(buf,(uchar *)(TFS_BASE(fp)),fp->filsize,0,0) != 0)
                    return(TFSERR_MEMFAIL);
                slot->flagmode = fp->flags;
                slot->flagmode |= TFS_APPEND;
                slot->base = (uchar *)buf;
                slot->wptr = (uchar *)buf+fp->filsize;
                slot->offset = fp->filsize;
            }
            else {
                slot->base = (uchar *) (TFS_BASE(fp));
                slot->wptr = 0;
                slot->hdr = *fp;
            }
            break;
        }
    }
    if (i == TFS_MAXOPEN)
        return(TFSERR_NOSLOT);

    return(i);
}

/* tfsclose():
    If the file was opened for reading only, then just close out the 
    entry in the fileslots table.  If the file was opened for creation,
    then add it to the tfs list.  Note the additional argument is
    only needed for tfsclose() of a newly created file.
    info  = additional text describing the file.
    Note:
    At the point when tfsclose is called for a file that currently exists,
    the old file must be removed and a new one is put in its place.  This
    opens up the possibility of losing the file if a power-hit or reset was
    to occur between the point at which the old file was removed and the new
    one was put in its place.  To overcome this problem, TFS files have a
    flag called TFS_AIPNOT (Append-In-Progress).  It is a bit that is normally
    1, but cleared if in AIP mode (hence the name TFS_AIPNOT).  A file is
    in this mode only for a short time... the time it takes to write the
    new file that replaces the file that was put in AIP mode.
    Now, if a reset occurs after the file is in AIP mode, depending on 
    whether or not the new file was written, it will either be removed or
    used to recreate the original file because the write of the new file
    was chopped off by the power hit.  Refer to the function tfsaipcheck()
    for details on the recovery after a reset or powerhit.
   MONLIB NOTICE: this function is accessible through monlib.c.
*/
int
tfsclose(int fd,char *info)
{
    int     err;
    char    *aipfile;
    struct tfsdat *tdat;

    if ((fd < 0) || (fd >= TFS_MAXOPEN))
        return(TFSERR_BADARG);

    aipfile = (char *)0;
    tdat = &fileslots[fd];

    if (tdat->offset == -1)
        return(TFSERR_BADFD);

    /* If file was opened for append, delete the old one and change */
    /* mode to TFS_CREATE so that it is re-created. */
    if (tdat->flagmode & TFS_APPEND) {
        TFILE   *tfp;
        ulong   flags;

        tfp = tfsstat(tdat->hdr.name);
        flags = TFS_FLAGS(tfp) & ~TFS_AIPNOT;
        if (tfsflashwrite(&tfp->flags,&flags,sizeof(long)) < 0)
            return(TFSERR_FLASHFAILURE);

        aipfile = TFS_NAME(tfp);
        tdat->flagmode &= ~TFS_APPEND;
        tdat->flagmode |= TFS_CREATE;
    }

    /* If the file was opened for creation, then add it now. */
    if (tdat->flagmode & TFS_CREATE) {
        char    buf[16];

        err = tfsadd(tdat->hdr.name, info, tfsflagsbtoa(tdat->flagmode,buf),
            tdat->base, tdat->offset);
        if (err != TFS_OKAY) {
            printf("%s: %s\n",tdat->hdr.name,tfserrmsg(err));
            tdat->offset = -1;
            return(err);
        }
    }

    if (aipfile) {
        err = tfsunlink(aipfile);
        if (err != TFS_OKAY)
            printf("%s: %s\n",aipfile,tfserrmsg(err));
    }

    tdat->offset = -1;
    return(TFS_OKAY);
}

/* tfsseek():
   Adjust the current pointer into the specified file.
   MONLIB NOTICE: this function is accessible through monlib.c.
*/
int
tfsseek(int fd, int offset, int whence)
{
    struct tfsdat *tdat;

    if ((offset < 0) || (fd < 0) || (fd >= TFS_MAXOPEN))
        return(TFSERR_BADARG);

    tdat = &fileslots[fd];

    switch (whence) {
    case TFS_BEGIN:
        if (offset > tdat->hdr.filsize)
            return(TFSERR_EOF);
        
        tdat->offset = offset;
        if (tdat->flagmode && TFS_CREATE)
            tdat->wptr = tdat->base+offset;
        break;
    case TFS_CURRENT:
        if ((offset + tdat->offset) > tdat->hdr.filsize) {
            return(TFSERR_EOF);
        }
        tdat->offset += offset;
        if (tdat->flagmode && TFS_CREATE)
            tdat->wptr += offset;
        break;
    default:
        return(TFSERR_BADARG);
    }
    return(TFS_OKAY);
}

/* tfsgetline():
    Using tfsread() 1 character at a time, read into the buffer a block
    of characters upto the next CR or LF in the file.  After the CR/LF, or
    after max-1 chars are loaded, terminate with a NULL.
    Return the number of characters loaded.
    At end of file return 0.
   MONLIB NOTICE: this function is accessible through monlib.c.
*/
int
tfsgetline(int fd,char *bp,int max)
{
    int     i;

    max--;
    for (i=0;i<max;i++,bp++) {
        if (tfsread(fd,bp,1) != 1) {
            *bp = 0;
            return(i);
        }
        if ((*bp == '\r') || (*bp == '\n'))
            break;
    }
    *(bp+1) = 0;
    return(i+1);
}

/* tfsipmod():
   Modify "in-place" a portion of a file in TFS.
   This is a cheap and dirty way to modify a file...
   The idea is that a file is created with a lot of writeable flash space
   (data = 0xff).  This function can then be called to immediately modify
   blocks of space in that flash.  It will not do any tfsunlink/tfsadd, and
   it doesn't even require a tfsopen() tfsclose() wrapper.  Its a fast and
   efficient way to modify flash in the file system.
   Arguments:
    name    =   name of the file to be in-place-modified;
    buf     =   new data to be written to flash;
    offset  =   offset into file into which new data is to be written;
    size    =   size of new data (in bytes).

   With offset of -1, set offset to location containing first 0xff value.
   MONLIB NOTICE: this function is accessible through monlib.c.
*/
int
tfsipmod(char *name,char *buf,int offset,int size)
{
    TFILE   *fp;
    uchar   *cp;

    fp = tfsstat(name);
    if (!fp)
        return (TFSERR_NOFILE);
    if (!(fp->flags & TFS_IPMOD))
        return(TFSERR_NOTIPMOD);
    
    if (offset == -1) {
        cp = (uchar *)(TFS_BASE(fp));
        for (offset=0;offset<fp->filsize;offset++,cp++) {
            if (*cp == 0xff)
                break;
        }
    }
    else if (offset < -1)
        return(TFSERR_BADARG);
    
    if ((offset + size) > fp->filsize)
        return(TFSERR_WRITEMAX);
    
    if (tfsflashwrite((char *)(TFS_BASE(fp))+offset,buf,size) == -1)
        return (TFSERR_FLASHFAILURE);

    tfslog(TFSLOG_IPM,name);
    return(TFS_OKAY);
}

/* tfsctrl():
    Provides an ioctl-like interface to tfs.
    Requests supported:
        TFS_ERRMSG:     Return error message (char *) corresponding to
                        the incoming error number (arg1).
        TFS_MEMUSE:     Return the total amount of memory currently in use by
                        TFS.
        TFS_MEMAVAIL:   Return the amount of memory currently avaialable for
                        use in TFS.
        TFS_MEMDEAD:    Return the amount of memory currently in use by
                        dead files in TFS.
        TFS_DEFRAG:     Mechanism for the application to issue
                        a defragmentation request.
                        Arg1: if 1, then reset after defrag is complete.
                        Arg2: verbosity level.
        TFS_TELL:       Return the offset into the file specified by the
                        incoming file descriptor (arg1).
        TFS_FATOB:      Return the binary equivalent of the TFS flags string
                        pointed to by arg1.
        TFS_FBTOA:      Return the string equivalent of the TFS flags (long)
                        in arg1, destination buffer in arg2.
        TFS_UNOPEN:     In TFS, a the data is not actually written to FLASH
                        until the tfsclose() function is called.  This argument
                        to tfsctrl() allows a file to be opened and possibly
                        written to, then unopened without actually modifying
                        the FLASH.  The value of arg1 file descriptor to 
                        apply the "unopen" to.
        TFS_TIMEFUNCS:  This ctrl call is used to tell TFS what function
                        to call for time information...
                        Arg1 is a pointer to:
                            (long)getLtime(void)
                            - Get Long Time...
                            Returns a long representation of time.
                        Arg2 is a pointer to:
                            (char *)getAtime(long tval,char *buf).
                            - Get Ascii Time...
                            If tval is zero, the buf is loaded with a string
                            representing the current time;
                            If tval is non-zero, then buf is loaded with a
                            string conversion of the value of tval.
                        Note that since it is up to these functions to 
                        make the conversion between binary version of time
                        and ascii version, we don't define the exact meaning
                        of the value returne by getBtime().
        TFS_DOCOMMAND:  Allows the application to redefine the function
                        that is called to process each line of a script.
                        This is useful if the application has its own
                        command interpreter, but wants to use the scripting
                        facilities of the monitor.
                        Arg1 is a pointer to the docommand function to be
                        used instead of the standard;
                        Arg2 is a pointer to a location into which the current
                        docommand function pointer can be stored.
                        If arg1 is 0, load standard docommand;
                        if arg2 is 0, don't load old value.

   MONLIB NOTICE: this function is accessible through monlib.c.
*/

long
tfsctrl(int rqst,long arg1,long arg2)
{
    long    retval;

    switch(rqst) {
        case TFS_ERRMSG:
            retval = (long)tfserrmsg(arg1);
            break;
        case TFS_MEMUSE:
            retval = tfsmemuse();
            break;
        case TFS_MEMAVAIL:
            retval = (long)((TFSEND - TFSSTART + 1) - tfsmemuse());
            break;
        case TFS_MEMDEAD:
            retval = tfsmemdead();
            break;
        case TFS_DEFRAG:
            retval = tfsclean(0,0,0,0,(int)arg1,(int)arg2);
            break;
        case TFS_UNOPEN:
            retval = tfsunopen((int)arg1);
            break;
        case TFS_FATOB:
            retval = tfsflagsatob((char *)arg1);
            break;
        case TFS_FBTOA:
            retval = (long)tfsflagsbtoa(arg1,(char *)arg2);
            break;
        case TFS_TELL:
            retval = tfstell(arg1);
            break;
        case TFS_TIMEFUNCS:
            tfsGetLtime = (long(*)(void))arg1;
            tfsGetAtime = (char *(*)(long,char *,int))arg2;
            retval = TFS_OKAY;
            break;
        case TFS_DOCOMMAND:
            if (arg2)
                *(long *)arg2 = (long)tfsDocommand;
            if (arg1)
                tfsDocommand = (void(*)(char *,int))arg1;
            else
                tfsDocommand = docommand;
            retval = TFS_OKAY;
            break;
        default:
            retval = TFSERR_BADARG;
            break;
    }
    return(retval);
}

char *TfsHelp[] = {
    "Tiny File System Interface",
    "-[f:i:mv] operation [args]...",
    "",
    "Options:",
    " -f    flags (see below)",
    " -i    info",
    " -m    enable more throttle",
    " -v    enable verbosity",
    "",
    "Operations:",
    " init, check, ls [filter], ld[v] {name}, log {on|off} {msg}, rm {name}",
    " cat {name}, run {name}, freemem [var], clean[r] [addr]",
    " info {file} {var}, size {file} {var}, cp {from_name} {to_name}",
    " add {name} {src_addr} {size}",
    "",
    "Flags:",
#if INCLUDE_UNPACK
    " E=elf, A=aout, C=coff, e=executable, c=compressed",
#else
    " E=elf, A=aout, C=coff, e=executable",
#endif
    " b=run_at_boot, B=qry_run_at_boot, i=inplace_modifiable",
    " 0-3=usrlvl_0-3, u=ulvl_unreadable",
    0,
};

/* Tfs():
    Entry point for the tfs command through the monitor's command line
    interface.  This function provides access to most TFS functionality
    through the CLI.
*/

Tfs(argc, argv)
int argc;
char *argv[];
{
    extern  int optind;
    extern  char *optarg;
    struct  tfshdr *fp;
    long    size, addr;
    int     err, opt, verbose, i, more, retval;
    char    *src, *name, *info, *flags, *to, *from;

    more = 0;
    verbose = 0;
    info = (char *)0;
    flags = (char *)0;
    retval = 0;
    while ((opt = getopt(argc, argv, "vmf:i:")) != -1) {
        switch (opt) {
        case 'i':
            info = optarg;
            break;
        case 'f':
            flags = optarg;
            break;
        case 'm':
            more++;
            break;
        case 'v':
            verbose++;
            break;
        default:
            goto done;
        }
    }

    if (argc == optind) {
        retval = -1;
    }
    else if (strcmp(argv[optind], "init") == 0) {
        if (UserLevel < MAXUSRLEVEL)
            printf("%s\n",tfserrmsg(TFSERR_USERDENIED));
        else {
            tfsinit();
            tfsclear();
        }
    }
    else if (strcmp(argv[optind], "log") == 0) {
        if (UserLevel < MAXUSRLEVEL)
            printf("%s\n",tfserrmsg(TFSERR_USERDENIED));
        else {
            if (argc == optind + 3) {
                if (!strcmp(argv[optind+1],"on"))
                    tfslog(TFSLOG_ON,argv[optind+2]);
                else if (!strcmp(argv[optind+1],"off"))
                    tfslog(TFSLOG_OFF,argv[optind+2]);
                else
                    retval = -1;
            }
            else if (argc == optind + 1)
                printf("TFS logging %sabled\n",changeLog ? "en" : "dis");
            else
                retval = -1;
        }
    }
    else if (strcmp(argv[optind], "freemem") == 0) {
        int mem;
        char buf[16];

        mem = (TFSEND - TFSSTART + 1) - tfsmemuse();
        if (argc == optind + 1) {
            printf("0x%x (%d) bytes available to TFS\n", mem,mem);
        }
        else if (argc == optind + 2) {
            sprintf(buf,"0x%x",mem);
            setenv(argv[optind+1],buf);
        }
        else 
            retval = -1;
        goto done;
    }
    else if (strcmp(argv[optind], "info") == 0) {
        if (argc == optind + 3) {
            fp = tfsstat(argv[optind+1]);
            if ((!fp) ||
                ((fp->flags & TFS_UNREAD) && (TFS_USRLVL(fp) > UserLevel)))
                setenv(argv[optind+1],0);
            else
                setenv(argv[optind+2],fp->info);
        }
        else
            retval = -1;
    }
    else if (strcmp(argv[optind], "size") == 0) {
        char buf[32];

        if (argc == optind + 3) {
            fp = tfsstat(argv[optind+1]);
            if ((!fp) ||
                ((fp->flags & TFS_UNREAD) && (TFS_USRLVL(fp) > UserLevel)))
                setenv(argv[optind+1],0);
            else {
                sprintf(buf,"%d",fp->filsize);
                setenv(argv[optind+2],buf);
            }
        }
        else
            retval = -1;
    }
    else if (strcmp(argv[optind], "ls") == 0) {
        char *prefix;

        if (argc == optind + 2)
            prefix = argv[optind+1];
        else
            prefix = (char *)0;
        if (verbose > 1)
            err = tfsvlist(prefix,verbose,more);
        else
            err = tfsqlist(prefix,verbose,more);
        if (err != TFS_OKAY)
            printf("ls: %s\n",tfserrmsg(err));
    }
    else if (strcmp(argv[optind], "cp") == 0) {
        char    buf[16];

        if (argc == optind + 3) {
            from = argv[optind + 1];
            to = argv[optind + 2];
            if (tfscheckfile(from) == TFS_OKAY) {
                fp = tfsstat(from);
                if (!flags)
                    flags = tfsflagsbtoa(fp->flags,buf);
                if (!info)
                    info = fp->info;
                if (fp) {
                    if ((fp->flags & TFS_UNREAD) &&
                        (TFS_USRLVL(fp) > UserLevel))
                        printf("%s: %s\n",name,tfserrmsg(TFSERR_USERDENIED));
                    else {
                        err = tfsadd(to,info,flags,
                            (char *)(TFS_BASE(fp)),fp->filsize);
                        if (err != TFS_OKAY)
                            printf("%s: %s\n",to,tfserrmsg(err));
                    }
                }
                else
                    printf("%s: %s\n",from,tfserrmsg(TFSERR_NOFILE));
            }
        }
        else
            retval = -1;
    }
    else if (strcmp(argv[optind], "cat") == 0) {
        if (argc >= optind + 2) {
            for(i=optind+1;i<argc;i++) {
                name = argv[i];
                if (tfscheckfile(name) == TFS_OKAY) {
                    fp = tfsstat(name);
                    if (fp) {
                        if ((fp->flags & TFS_UNREAD) &&
                            (TFS_USRLVL(fp) > UserLevel))
                            printf("%s: %s\n",name,
                                tfserrmsg(TFSERR_USERDENIED));
                        else {
                            if (more)
                                tfscat(fp,10);
                            else
                                tfscat(fp,0);
                        }
                    }
                    else
                        printf("%s: %s\n",name,tfserrmsg(TFSERR_NOFILE));
                }
            }
        }
        else
            retval = -1;
    }
    else if (strcmp(argv[optind], "rm") == 0) {
        if (argc >= optind + 2) {
            for(i=optind+1;i<argc;i++) {
                err = tfsunlink(argv[i]);
                if (err != TFS_OKAY)
                    printf("%s: %s\n",argv[i],tfserrmsg(err));
            }
        }
        else
            retval = -1;
    }
    else if (strcmp(argv[optind], "fix") == 0) {
        tfsfixup(verbose);
    }
    else if ((strcmp(argv[optind], "clean") == 0) ||
             (strcmp(argv[optind], "cleanr") == 0)) {
        int reset;
        if (strcmp(argv[optind], "cleanr") == 0)
            reset = 1;
        else
            reset = 0;
#if DEFRAG_TEST_ENABLED
        if (argc == optind + 3) {
            ExitPoint = atoi(argv[optind+1]);
            ExitSector = atoi(argv[optind+2]);
            printf("Exitpoint=%d, Exitsector=%d\n",ExitPoint,ExitSector);
        }
        else {
            ExitPoint = ExitSector = 0;
        }
#endif
        tfsclean(0,0,0,0,reset,verbose+1);
    }
    else if (strcmp(argv[optind], "check") == 0) {
        tfscheck(verbose+1);
    }
#if INCLUDE_OLDTFSCLEAN
    else if (strcmp(argv[optind], "oclean") == 0) {
        if (argc == optind + 2)
            oldtfsclean(1,0,strtol(argv[optind+1],(char **)0,0),0);
        else
            oldtfsclean(1,1,0,0);
    }
#endif
    else if (!strcmp(argv[optind], "ld")) {
        if (argc == optind + 2) {
            name = argv[optind + 1];
            err = tfsld(name,verbose,0);
            if (err != TFS_OKAY)
                printf("%s: %s\n",name,tfserrmsg(err));
        }
        else
            retval = -1;
    }
    else if (!strcmp(argv[optind], "ldv")) {
        if (argc == optind + 2) {
            name = argv[optind + 1];
            err = tfsld(name,verbose,1);
            if (err != TFS_OKAY)
                printf("%s: %s\n",name,tfserrmsg(err));
        }
        else
            retval = -1;
    }
    else if (strcmp(argv[optind], "run") == 0) {
        if (argc >= optind + 2) {
            name = argv[optind + 1];
            err = tfsrun(&argv[optind+1],verbose);
            if (err != TFS_OKAY)
                printf("%s: %s\n",name,tfserrmsg(err));
        }
        else
            retval = -1;
    }
    else if (!(strcmp(argv[optind], "add"))) {
        if (argc == optind + 4) {
            name = argv[optind + 1];
            src = (char *) strtol(argv[optind + 2], (char **) 0, 0);
            size = strtol(argv[optind + 3], (char **) 0, 0);
            err = tfsadd(name, info, flags, src, size);
            if (err != TFS_OKAY)
                printf("%s: %s\n",name,tfserrmsg(err));
        }
        else
            retval = -1;
    }
    else
        retval = -1;
done:
    return(retval);
}

#else

void
tfsinit()
{
}

int
tfsadd()
{
    return(-1);
}

int
tfsunlink()
{
    return(-1);
}

int
tfsrun()
{
    return(-1);
}

struct tfshdr *
tfsnext()
{
    return ((struct tfshdr *) 0);
}

struct tfshdr *
tfsstat()
{
    return ((struct tfshdr *) 0);
}

int
tfsread()
{
    return(-1);
}

int
tfswrite()
{
    return(-1);
}

int
tfsopen()
{
    return(-1);
}

int
tfsclose()
{
    return(-1);
}

int
tfsseek()
{
    return(-1);
}

int
tfsgetline()
{
    return(-1);
}

int
tfsipmod()
{
    return(-1);
}

int
tfsctrl()
{
    return(-1);
}

int
tfserrmsg()
{
    return(-1);
}
#endif
