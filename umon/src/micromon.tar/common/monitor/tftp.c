/* tftp.c:
 *  This code supports the monitor's TFTP server.
 *  TFTP is covered under RFC 783.
 *
 *  General notice:
 *  This code is part of a boot-monitor package developed as a generic base
 *  platform for embedded system designs.  As such, it is likely to be
 *  distributed to various projects beyond the control of the original
 *  author.  Please notify the author of any enhancements made or bugs found
 *  so that all may benefit from the changes.  In addition, notification back
 *  to the author will allow the new user to pick up changes that may have
 *  been made by other users after this version of the code was distributed.
 *
 *  Note1: the majority of this code was edited with 4-space tabs.
 *  Note2: as more and more contributions are accepted, the term "author"
 *         is becoming a mis-representation of credit.
 *
 *  Original author:    Ed Sutter
 *  Email:              esutter@lucent.com
 *  Phone:              908-582-2351
 */
#include "config.h"
#if INCLUDE_TFTP
#include "endian.h"
#include "genlib.h"
#include "cpuio.h"
#include "ether.h"
#include "tfs.h"
#include "tfsprivate.h"
#include "monflags.h"
#include "stddefs.h"
#include "cli.h"

#define MODE_NULL       0
#define MODE_NETASCII   1
#define MODE_OCTET      2

void ShowTftpStats();
int SendTFTPData(struct ether_header *,ushort,uchar *,int);
int SendTFTPErr(struct ether_header *,short,char *,int);
int SendTFTPAck(struct ether_header *,ushort);
int SendTFTPRRQ(uchar *,uchar *,char *,char *,uchar *);


static ushort   tftpLastblock;  /* Keeps the value of the block number of
                                 * the last TFTP transaction.
                                 */
static int tftpRetry_delayloops;/* Number of times tftpStateCheck() must be
                                 * called to reach tftpRetry_delaysecs.
                                 */
static int tftpRetry_delaysecs; /* Number of seconds to wait prior to retry. */
static int tftpRetry_lastchance;/* Set if we are on the last retry and are
                                 * about to give up.
                                 */

static int TftpWrqMode;         /* Set to MODE_NETASCII, MODE_OCTET or
                                 * MODE_NULL based on the incoming WRQ
                                 * request
                                 */
static int TftpChopCount;       /* Number of characters chopped from the
                                 * incoming file because of NETASCII
                                 * conversion (remove 0x0d).
                                 */
static int TftpLastPktSize;
static uchar TftpLastPkt[TFTP_PKTOVERHEAD+TFTP_DATAMAX+4];
                                /* Storage of last packet sent.  This is
                                 * used if it is determined that the packet
                                 * most recently sent must be sent again.
                                 */

static long TftpRetryTimeout;   /* Count used during a TFTP transfer to
                                 * kick off a retransmission of a packet.
                                 * It is cleared each time a valid packet
                                 * is sent, and incremented by the
                                 * tftpStateCheck() function.
                                 */
static ushort TftpRmtPort;      /* Remote port of tftp transfer */
static uchar *TftpAddr;         /* Current destination address used for tftp
                                 * file transfer into local memory.
                                 */
static int  TftpCount;          /* Running total number of bytes transferred
                                 * for a particular tftp transaction.
                                 */
static int  TftpState;          /* Used to keep track of the current state
                                 * of a tftp transaction.
                                 */
static int  TftpTurnedOff;      /* If non-zero, then tftp is disabled. */
static char TftpErrString[32];  /* Used to post a tftp error message. */
static char TftpTfsFname[TFSNAMESIZE+64];   /* Store name of WRQ destination
                                             * file (plus flags & info).
                                             */
char *
tftpStringState(int state)
{
    switch(state) {
        case TFTPOFF:
            return("OFF");
        case TFTPIDLE:
            return("IDLE");
        case TFTPACTIVE:
            return("ACTIVE");
        case TFTPERROR:
            return("ERROR");
        case TFTPSENTRRQ:
            return("SENTRRQ");
        case TFTPTIMEOUT:
            return("TIMEOUT");
        default:
            return("???");
    }
}

int
tftpGotoState(int state)
{
    int ostate;

    ostate = TftpState;
    TftpState = state;
    if ((EtherVerbose & SHOW_TFTP) && (state != ostate))
        printf("  TFTP State change %s -> %s\n",
            tftpStringState(ostate), tftpStringState(state));
    return(ostate);
}

/* tftpGet():
 *  Return size of file if successful; else 0.
 */
int
tftpGet(ulong addr,char *tftpsrvr,char *mode, char *hostfile,char *tfsfile,
    char *tfsflags,char *tfsinfo)
{
    int     done;
    char    buf[32];
    uchar   binip[8], binenet[8], *enetaddr;

    setenv("TFTPGET",0);

    /* Convert IP address to binary: */
    if (IpToBin(tftpsrvr,binip) < 0)
        return(0);


    /* Get the ethernet address for the IP: */
    /* Give ARP the same verbosity (if any) set up for TFTP: */
    if (EtherVerbose & SHOW_TFTP)
        EtherVerbose |= SHOW_ARP;
    enetaddr = ArpEther(binip,binenet,0);
    EtherVerbose &= ~SHOW_ARP;
    if (!enetaddr) {
        printf("ARP failed for %s\n",tftpsrvr);
        return(0);
    }

    /* Initialize the retransmission delay calculator: */
    RetransmitDelay(DELAY_INIT_TFTP);

    printf("Retrieving %s from %s...",hostfile,tftpsrvr);
    if (EtherVerbose & SHOW_TFTP)
        printf("\n");

    /* Send the TFTP RRQ to initiate the transfer. */
    if (SendTFTPRRQ(binip,binenet,hostfile,mode,(uchar *)addr) < 0) {
        printf("RRQ failed\n");
        return(0);
    }

    /* Wait for TftpState to indicate that the transaction has completed... */
    done = 0;
    while(!done) {
        pollethernet();
        switch(TftpState) {
            case TFTPIDLE:
                printf(" %d bytes",TftpCount);
                done = 1;
                break;
            case TFTPERROR:
                printf(" host error: %s\n",TftpErrString);
                done = 2;
                break;
            case TFTPTIMEOUT:
                printf(" timing out (%d bytes rcvd)\n",TftpCount);
                done = 2;
                break;
            default:
                break;
        }
    }
    if (done == 2)
        return(0);

    if (tfsfile) {
        int err, filesize;

        filesize = TftpCount - TftpChopCount;
        printf("\nAdding %s (size=%d) to TFS...",tfsfile,filesize);
        err = tfsadd(tfsfile,tfsinfo,tfsflags,(uchar *)addr,filesize);
        if (err != TFS_OKAY)
            printf("%s: %s\n",tfsfile,(char *)tfsctrl(TFS_ERRMSG,err,0));
    }
    printf("\n");
    sprintf(buf,"%d",TftpCount);
    setenv("TFTPGET",buf);
    return(TftpCount);
}

/* tftpInit():
 *  Called by the ethenet initialization to initialize state variables.
 */
void
tftpInit()
{
    TftpCount = -1;
    TftpRmtPort = 0;
    TftpTurnedOff = 0;
    tftpGotoState(TFTPIDLE);
    TftpAddr = (uchar *)0;
}

/* storePktAndSend():
 *  The final stage in sending a TFTP packet...
 *  1. Compute IP and UDP checksums;
 *  2. Copy ethernet packet to a buffer so that it can be resent
 *      if necessary (by tftpStateCheck()).
 *  3. Store the size of the packet; 
 *  4. Send the packet out the interface.
 *  5. Reset the timeout count and re-transmission delay variables.
 */
void
storePktAndSend(struct ip *ipp, struct ether_header *epkt,int size)
{
    ipChksum(ipp);                          /* Compute csum of ip hdr */
    udpChksum(ipp);                         /* Compute UDP checksum */
                                            /* Copy packet to static buffer */
    memcpy((char *)TftpLastPkt,(char *)epkt,size);
    TftpLastPktSize = size;                 /* Copy size to static location */
    sendBuffer(size);                       /* Send buffer out ethernet i*/

    /* Clear the retry timeout counters and re-initialize the */
    /* re-transmission delay variables. */
    TftpRetryTimeout = 0;   
    tftpRetry_lastchance = 0;
    tftpRetry_delayloops = 0;
    RetransmitDelay(DELAY_INIT_TFTP);
}

/* getTftpSrcPort():
 *  Each time a TFTP RRQ goes out, use a new source port number.
 *  Cycle through a block of 256 port numbers...
 */
ushort
getTftpSrcPort(void)
{
    if (TftpSrcPort < (IPPORT_TFTPSRC+256))
        TftpSrcPort++;
    else
        TftpSrcPort = IPPORT_TFTPSRC;
    return(TftpSrcPort);
}

/* tftpStateCheck():
 *  Called by the pollethernet function to support the ability to retry
 *  on a TFTP transmission that appears to have terminated prematurely
 *  due to a lost packet.  If a packet is sent and the response is not
 *  received within about 1-2 seconds, the packet is re-sent.  The retry
 *  will repeat 8 times; then give up and set the TFTP state to idle.
 *
 *  Taken from RFC 1350 section 2 "Overview of the Protocol"...
 *  ... If a packet gets lost in the network, the intended recipient will
 *  timeout and may retransmit his last packet (which may be data or an
 *  acknowledgement), thus causing the sender of the lost packet to retransmit
 *  the lost packet.
 *
 *  Taken from RFC 1123 section 4.2.3.2 "Timeout Algorithms"...
 *  ... a TFTP implementation MUST use an adaptive timeout ...
 */

void
tftpStateCheck(void)
{
    uchar   *buf;
    ushort  tftp_opcode;
    struct  ip *ihdr;
    struct  Udphdr *uhdr;
    struct  ether_header *ehdr;

    switch(TftpState) {
        case TFTPIDLE:
        case TFTPTIMEOUT:
        case TFTPERROR:
            tftpRetry_lastchance = tftpRetry_delayloops = 0;
            return;
        default:
            break;
    }

    if (!tftpRetry_delayloops) {
        tftpRetry_delaysecs = RetransmitDelay(DELAY_OR_TIMEOUT_RETURN);
        tftpRetry_delayloops = tftpRetry_delaysecs * LoopsPerSecond;
    }
    
    /* If the value in TftpRetryTimeout reaches the tftpRetry_delayloops */
    /* value, then assume it is time to re-transmit a packet... */
    if (++TftpRetryTimeout < tftpRetry_delayloops)
        return;

    if (tftpRetry_lastchance) {
        if (EtherVerbose & SHOW_TFTP)
            printf("  TFTP_RETRY giving up\n");
        tftpGotoState(TFTPTIMEOUT);
        enableBroadcastReception();
        TftpRetryTimeout = 0;
        return;
    }

    /* Get a transmit buffer and copy the packet that was last sent.
     * Insert a new IP ID, recalculate the checksums and send it again...
     * If the opcode of the packet to be re-transmitted is RRQ, then
     * use a new port number.
     */
    buf = (uchar *)getXmitBuffer();
    memcpy((char *)buf,(char *)TftpLastPkt,TftpLastPktSize);
    ehdr = (struct ether_header *)buf;
    ihdr = (struct ip *)(ehdr + 1);
    uhdr = (struct Udphdr *)(ihdr + 1);
    tftp_opcode = *(ushort *)(uhdr + 1);
    ihdr->ip_id = ipId();
    if (tftp_opcode == ecs(TFTP_RRQ)) {
        uhdr->uh_sport = getTftpSrcPort();
        self_ecs(uhdr->uh_sport);
    }
    ipChksum(ihdr);
    udpChksum(ihdr);
    sendBuffer(TftpLastPktSize);

    if (EtherVerbose & SHOW_TFTP)
        printf("  TFTP_RETRY (%d secs)\n",tftpRetry_delaysecs);
    tftpRetry_delayloops = 0;
    if (RetransmitDelay(DELAY_INCREMENT) == RETRANSMISSION_TIMEOUT)
        tftpRetry_lastchance = 1;

    TftpRetryTimeout = 0;
    return;
}

/* tftpStartSrvrFilter():
 *  Called when either a TFTP_RRQ or TFTP_WRQ is received indicating that
 *  a client wants to start up a transfer.
 *  If TftpState is IDLE, ERROR or TIMEOUT, this means it is safe to start
 *  up a new transfer through the server; otherwise return 0. 
 */
int
tftpStartSrvrFilter(struct ether_header *ehdr,struct Udphdr *uhdr)
{
    if ((TftpState == TFTPIDLE) || (TftpState == TFTPERROR) ||
        (TftpState == TFTPTIMEOUT)) {
        TftpTfsFname[0] = 0;
        TftpRmtPort = ecs(uhdr->uh_sport);
        tftpGotoState(TFTPACTIVE);
        return(1);
    }
    /* If block is zero and the incoming WRQ request is from the same
     * port as was previously recorded, then assume the ACK sent back
     * to the requester was not received, and this is a WRQ that is
     * being re-sent.  That being the case, just send the Ack back.
     */
    else if ((tftpLastblock == 0) && (TftpRmtPort == uhdr->uh_sport)) {
        SendTFTPAck(ehdr,0);
        return(0);
    }
    else {
        printf("   (tftp busy)\n");
        /* Note: the value of TftpState is not changed (final arg to
         * SendTFTPErr is 0) to TFTPERROR.  This is because
         * we received a RRQ/WRQ request while processing a different
         * TFTP transfer.  We want to send the error response to the
         * sender, but we don't want to stay in an error state because
         * there is another valid TFTP transfer in progress.
         */
        SendTFTPErr(ehdr,0,"TFTP server busy.",0);
        return(0);
    }
}

/* processTFTP():
 *  This function handles the majority of the TFTP requests that a
 *  TFTP server must be able to handle.  There is no real robust 
 *  error handling, but it seems to work pretty well.
 *  Refer to Stevens' "UNIX Network Programming" chap 12 for details
 *  on TFTP.
 *  Note: During TFTP, promiscuity, broadcast & multicast reception
 *  are all turned off.  This is done to speed up the file transfer.
 */
int
processTFTP(struct ether_header *ehdr,ushort size)
{
    static  uchar   *oaddr;
    struct  ip *ihdr;
    struct  Udphdr *uhdr;
    uchar   *data;
    int     count, tmpcount;
    ushort  opcode, block, errcode;
    char    *comma, *tftpp, *filename, *mode, *errstring, msg[64];

    if (TftpTurnedOff)
        return(0);

    ihdr = (struct ip *)(ehdr + 1);
    uhdr = (struct Udphdr *)((char *)ihdr + IP_HLEN(ihdr));
    tftpp = (char *)(uhdr + 1);
    opcode = *(ushort *)tftpp;

    switch (opcode) {
    case ecs(TFTP_WRQ):
        filename = tftpp+2;
        if ((EtherVerbose & SHOW_TFTP) || (!MFLAGS_NOTFTPPRN()))
            printf("TFTP rcvd WRQ: file %s\n", filename);
        if (!tftpStartSrvrFilter(ehdr,uhdr))
            return(0);

        mode = filename;
        while(*mode)
            mode++;
        mode++;
        
        /* Destination of WRQ can be an address (0x...), environment
         * variable ($...) or a TFS filename...
         */
        if ((filename[0] == '$') && (getenv(&filename[1]))) {
            TftpAddr = (uchar *)strtol(getenv(&filename[1]),(char **)0,0);
        }
        else if ((filename[0] == '0') && (filename[1] == 'x')) {
            TftpAddr = (uchar *)strtol(filename,(char **)0,0);
        }
        else {
            if (MFLAGS_NOTFTPOVW() && tfsstat(filename)) {
                SendTFTPErr(ehdr,6,"File already exists.",1);
                return(0);
            }
            TftpAddr = (uchar *)getAppRamStart();
            strncpy(TftpTfsFname,filename,sizeof(TftpTfsFname)-1);
            TftpTfsFname[sizeof(TftpTfsFname)-1] = 0;
        }
        TftpCount = -1; /* not used with WRQ, so clear it */

        /* Convert mode to lower case... */
        strtolower(mode);
        if (!strcmp(mode,"netascii"))
            TftpWrqMode = MODE_NETASCII;
        else if (!strcmp(mode,"octet"))
            TftpWrqMode = MODE_OCTET;
        else {
            SendTFTPErr(ehdr,0,"Mode not supported.",1);
            TftpWrqMode = MODE_NULL;
            TftpCount = -1;
            return(0);
        }
        block = 0;
        tftpLastblock = block;
        oaddr = TftpAddr;
        TftpChopCount = 0;
        disableBroadcastReception();
        break;
    case ecs(TFTP_RRQ):
        filename = tftpp+2;
        if ((EtherVerbose & SHOW_TFTP) || (!MFLAGS_NOTFTPPRN()))
            printf("TFTP rcvd RRQ: file %s\n",filename);
        if (!tftpStartSrvrFilter(ehdr,uhdr))
            return(0);
        mode = filename;
        while(*mode) mode++;
        mode++;
        comma = strchr(filename,',');
        if (!comma) {
            TFILE   *tfp; 
            tfp = tfsstat(filename);
            if (!tfp) {
                SendTFTPErr(ehdr,0,"File not found, try 'address,count'",1);
                TftpCount = -1;
                return(0);
            }
            TftpAddr = (uchar *)TFS_BASE(tfp);
            TftpCount = TFS_SIZE(tfp);
        }
        else {
            comma++;
            TftpAddr = (uchar *)strtol(filename,(char **)0,0);
            TftpCount = strtol(comma,(char **)0,0);
        }
        if (strcmp(mode,"octet")) {
            SendTFTPErr(ehdr,0,"Must use binary mode",1);
            TftpCount = -1;
            return(0);
        }
        block = tftpLastblock = 1;
        disableBroadcastReception();
        tftpGotoState(TFTPACTIVE);
        SendTFTPData(ehdr,block,TftpAddr,TftpCount);
        return(0);
    case ecs(TFTP_DAT):
        block = ecs(*(ushort *)(tftpp+2));
        count = ecs(uhdr->uh_ulen) - (sizeof(struct Udphdr)+4);
        if (EtherVerbose & SHOW_TFTP)
            printf("  Rcvd TFTP_DAT (%d,blk=%d)\n",count,block);

        if (TftpState == TFTPSENTRRQ) {     /* See notes in SendTFTPRRQ() */
            tftpLastblock = 0;
            if (block == 1) {
                TftpRmtPort = ecs(uhdr->uh_sport);
                tftpGotoState(TFTPACTIVE);
            }
            else {
                SendTFTPErr(ehdr,0,"invalid block",1);
                return(0);
            }
        }
        /* Since we don't ACK the final TFTP_DAT from the server until after
         * the file has been written, it is possible that we will receive
         * a re-transmitted TFTP_DAT from the server.  This is ignored by
         * Sending another ACK...
         */
        else if ((TftpState == TFTPIDLE) && (block == tftpLastblock)) {
            SendTFTPAck(ehdr,block);    
            if (EtherVerbose & SHOW_TFTP)
                printf("  (packet ignored)\n");
            return(0);              
        }
        else if (TftpState != TFTPACTIVE) {
            SendTFTPErr(ehdr,0,"invalid state",1);
            return(0);
        }

        if (ecs(uhdr->uh_sport) != TftpRmtPort) {
            SendTFTPErr(ehdr,0,"invalid source port",0);
            return(0);
        }
        if (block == tftpLastblock) {   /* If block didn't increment, assume */
            SendTFTPAck(ehdr,block);    /* retry.  Ack it and return here.  */
            return(0);          /* Otherwise, if block != tftpLastblock+1, */
        }                       /* return an error, and quit now.   */
        else if (block != tftpLastblock+1) {
            SendTFTPErr(ehdr,0,"Unexpected block number",1);
            TftpCount = -1;
            return(0);
        }
        TftpCount += count;
        oaddr = TftpAddr;
        tftpLastblock = block;
        data = (uchar *)(tftpp+4);

        /* If count is less than TFTP_DATAMAX, this must be the last
         * packet of the transfer, so clean up state here.
         */
        if (count < TFTP_DATAMAX) {
            enableBroadcastReception();
            tftpGotoState(TFTPIDLE);
        }

        /* Copy data from enet buffer to TftpAddr location... */
        tmpcount = count;
        while(tmpcount) {       
            if (TftpWrqMode == MODE_NETASCII) {
                if (*data == 0x0d) {
                    data++;
                    tmpcount--;
                    TftpChopCount++;
                    continue;
                }
            }
                
            *TftpAddr = *data;
            if (*TftpAddr != *data) {
                sprintf(msg,"Write error at 0x%lx",(ulong)TftpAddr);
                SendTFTPErr(ehdr,0,msg,1);
                TftpCount = -1;
                return(0);
            }
            TftpAddr++;
            data++;
            tmpcount--;
        }

        /* Check for transfer complete (count < TFTP_DATAMAX)... */
        if (count < TFTP_DATAMAX) {
            if (TftpTfsFname[0]) {
                char *fcomma, *icomma, *flags, *info;
                int err;

                /* If the transfer is complete and TftpTfsFname[0]
                 * is non-zero, then write the data to the specified
                 * TFS file... Note that a comma in the filename is
                 * used to find the start of (if any) the TFS flags
                 * string.  A second comma, marks the info field.
                 */
                info = (char *)0;
                flags = (char *)0;
                fcomma = strchr(TftpTfsFname,',');
                if (fcomma) {
                    icomma = strchr(fcomma+1,',');
                    if (icomma) {
                        *icomma = 0;
                        info = icomma+1;
                    }
                    if (tfsctrl(TFS_FATOB,(long)(fcomma+1),0) != -1) {
                        *fcomma = 0;
                        flags = fcomma+1;
                    }
                    else {
                        SendTFTPErr(ehdr,0,"Invalid flag spec.",1);
                        TftpTfsFname[0] = 0;
                        break;
                    }
                }
                if ((EtherVerbose & SHOW_TFTP) || (!MFLAGS_NOTFTPPRN()))
                    printf("TFTP adding file: '%s' to TFS.\n",TftpTfsFname);
                err = tfsadd(TftpTfsFname,info,flags,
                    (char *)getAppRamStart(),TftpCount+1-TftpChopCount);
                if (err != TFS_OKAY) {
                    sprintf(msg,"TFS err: %s",
                        (char *)tfsctrl(TFS_ERRMSG,err,0));
                    SendTFTPErr(ehdr,0,msg,1);
                }
                TftpTfsFname[0] = 0;
            }
            else {
                int cnt;
                char *addr;

                /* If the transfer is complete and no file add is to
                 * be done, then we flush d-cache and invalidate
                 * i-cache across the memory space that was just
                 * copied to.  This is necessary in case the
                 * binary data that was just transferred is code.
                 */
                cnt = TftpCount + 1;
                addr = TftpAddr - cnt;
                flushDcache(addr,cnt);
                invalidateIcache(addr,cnt);
            }
            if ((EtherVerbose & SHOW_TFTP) || (!MFLAGS_NOTFTPPRN()))
                printf("TFTP transfer complete.\n");
        }
        break;
    case ecs(TFTP_ACK):
        block = ecs(*(ushort *)(tftpp+2));
        if (TftpState != TFTPACTIVE) {
            SendTFTPErr(ehdr,0,"Illegal server state for incoming TFTP_ACK",1);
            return(0);
        }
        if (EtherVerbose & SHOW_TFTP)
            printf("  Rcvd TFTP_ACK (blk#%d)\n",block);

        if (block == tftpLastblock) {
            if (TftpCount > TFTP_DATAMAX) {
                TftpCount -= TFTP_DATAMAX;
                TftpAddr += TFTP_DATAMAX;
                SendTFTPData(ehdr,block+1,TftpAddr,TftpCount);
                tftpLastblock++;
            }
            else if (TftpCount == TFTP_DATAMAX) {
                TftpCount = 0;
                tftpGotoState(TFTPIDLE);
                SendTFTPData(ehdr,block+1,TftpAddr,0);
                tftpLastblock++;
            }
            else {
                TftpAddr += TftpCount;
                TftpCount = 0;
                tftpGotoState(TFTPIDLE);
                enableBroadcastReception();
            }
        }
        else if (block == tftpLastblock-1) {
            SendTFTPData(ehdr,block+1,TftpAddr,TftpCount);
        }
        else {
            SendTFTPErr(ehdr,0,"Blockno confused",1);
            TftpCount = -1;
            return(0);
        }
        return(0);
    case ecs(TFTP_ERR):
        errcode = ecs(*(ushort *)(tftpp+2));
        errstring = tftpp+4;
        if (EtherVerbose & SHOW_TFTP)
            printf("  Rcvd TFTP_ERR #%d (%s)\n",errcode,errstring);
        TftpCount = -1;
        tftpGotoState(TFTPERROR);
        strncpy(TftpErrString,errstring,sizeof(TftpErrString)-1);
        TftpErrString[sizeof(TftpErrString)-1] = 0;
        return(0);
    default:
        if (EtherVerbose & SHOW_TFTP)
            printf("  Rcvd <%04x> unknown TFTP opcode\n", opcode);
        TftpCount = -1;
        return(-1);
    }
    SendTFTPAck(ehdr,block);
    return(0);
}

/* SendTFTPRRQ():
 *  Pass the ether and ip address of the TFTP server, along with the
 *  filename and mode to start up a target-initiated TFTP download.
 *  The initial TftpState value is TFTPSENTRRQ, this is done so that incoming
 *  TFTP_DAT packets can be verified...
 *   - If a TFTP_DAT packet is received and TftpState is TFTPSENTRRQ, then
 *     the block number should be 1.  If this is true, then that server's
 *     source port is stored away in TftpRmtPort so that all subsequent
 *     TFTP_DAT packets will be compared to the initial source port.  If no
 *     match, then respond with a TFTP error or ICMP PortUnreachable message.
 *   - If a TFTP_DAT packet is received and TftpState is TFTPSENTRRQ, then
 *     if the block number is not 1, generate a error.
 */
int
SendTFTPRRQ(uchar *ipadd,uchar *eadd,char *filename,char *mode,uchar *loc)
{
    uchar *tftpdat;
    ushort ip_len;
    struct ether_header *te;
    struct ip *ti;
    struct Udphdr *tu;

    TftpChopCount = 0;
    tftpGotoState(TFTPSENTRRQ);
    TftpAddr = loc;
    TftpCount = 0;

    /* Retrieve an ethernet buffer from the driver and populate the
     * ethernet level of packet:
     */
    te = (struct ether_header *) getXmitBuffer();
    memcpy((char *)&te->ether_shost,BinEnetAddr,6);
    memcpy((char *)&te->ether_dhost,eadd,6);
    te->ether_type = ecs(ETHERTYPE_IP);

    /* Move to the IP portion of the packet and populate it appropriately: */
    ti = (struct ip *) (te + 1);
    ti->ip_vhl = IP_HDR_VER_LEN;
    ti->ip_tos = 0;
    ip_len = sizeof(struct ip) +
        sizeof(struct Udphdr) + strlen(filename) + strlen(mode) + 4;
    ti->ip_len = ecs(ip_len);
    ti->ip_id = ipId();
    ti->ip_off = 0;
    ti->ip_ttl = UDP_TTL;
    ti->ip_p = IP_UDP;
    memcpy((char *)&ti->ip_src.s_addr,BinIpAddr,4);
    memcpy((char *)&ti->ip_dst.s_addr,ipadd,4);

    /* Now udp... */
    tu = (struct Udphdr *) (ti + 1);
    tu->uh_sport = getTftpSrcPort();
    self_ecs(tu->uh_sport);
    tu->uh_dport = ecs(TftpPort);
    tu->uh_ulen = ecs((ushort)(ip_len - sizeof(struct ip)));

    /* Finally, the TFTP specific stuff... */
    tftpdat = (uchar *)(tu+1);
    *(ushort *)(tftpdat) = ecs(TFTP_RRQ);
    strcpy(tftpdat+2,filename);
    strcpy(tftpdat+2+strlen(filename)+1,mode);

    if (!strcmp(mode,"netascii"))
        TftpWrqMode = MODE_NETASCII;
    else
        TftpWrqMode = MODE_OCTET;

    storePktAndSend(ti, te,TFTPACKSIZE+strlen(filename)+strlen(mode));

    if (EtherVerbose & SHOW_TFTP)
        printf("\n  Sent TFTP_RRQ (file=%s)\n",filename);

    return(0);
}

/* SendTFTPAck():
 */
int
SendTFTPAck(struct ether_header *re,ushort block)
{
    uchar *tftpdat;
    ushort ip_len;
    struct ether_header *te;
    struct ip *ti, *ri;
    struct Udphdr *tu, *ru;

    te = EtherCopy(re);

    ti = (struct ip *) (te + 1);
    ri = (struct ip *) (re + 1);
    ti->ip_vhl = ri->ip_vhl;
    ti->ip_tos = ri->ip_tos;
    ip_len = sizeof(struct ip) + sizeof(struct Udphdr) + 4;
    ti->ip_len = ecs(ip_len);
    ti->ip_id = ipId();
    ti->ip_off = ri->ip_off;
    ti->ip_ttl = UDP_TTL;
    ti->ip_p = IP_UDP;
    memcpy((char *)&(ti->ip_src.s_addr),(char *)&(ri->ip_dst.s_addr),
        sizeof(struct in_addr));
    memcpy((char *)&(ti->ip_dst.s_addr),(char *)&(ri->ip_src.s_addr),
        sizeof(struct in_addr));

    tu = (struct Udphdr *) (ti + 1);
    ru = (struct Udphdr *) (ri + 1);
    tu->uh_sport = ru->uh_dport;
    tu->uh_dport = ru->uh_sport;
    tu->uh_ulen = ecs((ushort)(ip_len - sizeof(struct ip)));

    tftpdat = (uchar *)(tu+1);
    *(ushort *)(tftpdat) = ecs(TFTP_ACK);
    *(ushort *)(tftpdat+2) = ecs(block);

    storePktAndSend(ti,te,TFTPACKSIZE);

    if (EtherVerbose & SHOW_TFTP)
        printf("  Sent TFTP_ACK (blk#%d)\n",block);
    return(0);
}

/* SendTFTPErr():
 */
int
SendTFTPErr(struct ether_header *re,short errno,char *errmsg,int changestate)
{
    short len, tftplen, hdrlen;
    uchar *tftpmsg;
    struct ether_header *te;
    struct ip *ti, *ri;
    struct Udphdr *tu, *ru;

    if (changestate)
        tftpGotoState(TFTPERROR);

    tftplen = strlen(errmsg) + 1 + 4;
    hdrlen = sizeof(struct ip) + sizeof(struct Udphdr);
    len = tftplen + hdrlen ;

    te = EtherCopy(re);

    ti = (struct ip *) (te + 1);
    ri = (struct ip *) (re + 1);
    ti->ip_vhl = ri->ip_vhl;
    ti->ip_tos = ri->ip_tos;
    ti->ip_len = ecs(len);
    ti->ip_id = ipId();
    ti->ip_off = ri->ip_off;
    ti->ip_ttl = UDP_TTL;
    ti->ip_p = IP_UDP;
    memcpy((char *)&(ti->ip_src.s_addr),(char *)&(ri->ip_dst.s_addr),
        sizeof(struct in_addr));
    memcpy((char *)&(ti->ip_dst.s_addr),(char *)&(ri->ip_src.s_addr),
        sizeof(struct in_addr));

    tu = (struct Udphdr *) (ti + 1);
    ru = (struct Udphdr *) (ri + 1);
    tu->uh_sport = ru->uh_dport;
    tu->uh_dport = ru->uh_sport;
    tu->uh_ulen = sizeof(struct Udphdr) + tftplen;
    self_ecs(tu->uh_ulen);

    tftpmsg = (uchar *)(tu+1);
    *(ushort *)(tftpmsg) = ecs(TFTP_ERR);
    * (ushort *)(tftpmsg+2) = ecs(errno);
    strcpy(tftpmsg+4,errmsg);

    storePktAndSend(ti,te,TFTPACKSIZE + strlen(errmsg) + 1);

    if (EtherVerbose & SHOW_TFTP)
        printf("  Sent TFTP Err#%d (%s) \n",errno,errmsg);

    return(0);
}

/* SendTFTPData():
 */
int
SendTFTPData(struct ether_header *re,ushort block,uchar *data,int count)
{
    int len, tftplen, hdrlen;
    uchar *tftpmsg;
    struct ether_header *te;
    struct ip *ti, *ri;
    struct Udphdr *tu, *ru;

    if (count > TFTP_DATAMAX)
        count = TFTP_DATAMAX;

    tftplen = count + 2 + 2; /* sizeof (data + opcode + blockno) */
    hdrlen = sizeof(struct ip) + sizeof(struct Udphdr);
    len = tftplen + hdrlen ;

    te = EtherCopy(re);

    ti = (struct ip *) (te + 1);
    ri = (struct ip *) (re + 1);
    ti->ip_vhl = ri->ip_vhl;
    ti->ip_tos = ri->ip_tos;
    ti->ip_len = ecs(len);
    ti->ip_id = ipId();
    ti->ip_off = ri->ip_off;
    ti->ip_ttl = UDP_TTL;
    ti->ip_p = IP_UDP;
    memcpy((char *)&(ti->ip_src.s_addr),(char *)&(ri->ip_dst.s_addr),
        sizeof(struct in_addr));
    memcpy((char *)&(ti->ip_dst.s_addr),(char *)&(ri->ip_src.s_addr),
        sizeof(struct in_addr));

    tu = (struct Udphdr *) (ti + 1);
    ru = (struct Udphdr *) (ri + 1);
    tu->uh_sport = ru->uh_dport;
    tu->uh_dport = ru->uh_sport;
    tu->uh_ulen = sizeof(struct Udphdr) + tftplen;
    self_ecs(tu->uh_ulen);

    tftpmsg = (uchar *)(tu+1);
    *(ushort *)(tftpmsg) = ecs(TFTP_DAT);
    *(ushort *)(tftpmsg+2) = ecs(block);
    memcpy(tftpmsg+4,data,count);

    len+=sizeof(struct ether_header);

    storePktAndSend(ti,te,len);

    if (EtherVerbose & SHOW_TFTP)
        printf("  Sent TFTP data blk#%d (%d bytes @ 0x%lx) \n",
            block,count,(ulong)data);
    return(0);
}

/* Tftp():
 *  Initiate a tftp transfer at the target (target is client).
 *  Command line:
 *      tftp [options] {IP} {get|put} {file|addr} [len]...
 *      tftp [options] {IP} get file dest_addr
 *      tftp [options] {IP} put addr dest_file len
 *  Currently, only "get" is supported.
 */

char *TftpHelp[] = {
    "Trivial file transfer protocol",
    "-[aF:f:i:nvV] [on|off|IP] {get filename [addr]}",
    " -a        use netascii mode",
    " -F {file} name of tfs file to copy to",
    " -f {flgs} file flags (see tfs)",
    " -i {info} file info (see tfs)",
    " -v        low verbosity",
    " -V        high verbosity",
    0,
};

int
Tftp(int argc,char *argv[])
{
    int     opt;
    char    *mode, *file, *info, *flags;
    ulong   addr;

    file = (char *)0;
    info = (char *)0;
    flags = (char *)0;
    mode = "octet";
    while ((opt=getopt(argc,argv,"aF:f:i:vV")) != -1) {
        switch(opt) {
        case 'a':
            mode = "netascii";
            break;
        case 'f':
            flags = optarg;
            break;
        case 'F':
            file = optarg;
            break;
        case 'i':
            info = optarg;
            break;
        case 'v':
            EtherVerbose |= SHOW_TFTP;
            break;
        case 'V':
            EtherVerbose = SHOW_TFTP | SHOW_INCOMING | SHOW_OUTGOING;
            break;
        default:
            return(CMD_PARAM_ERROR);
        }
    }
    if (argc < (optind+1))
        return(CMD_PARAM_ERROR);

    if (argc == optind+1) {
        if (!strcmp(argv[optind],"on"))
            TftpTurnedOff = 0;
        else if (!strcmp(argv[optind],"off")) {
            TftpTurnedOff = 1;
            tftpGotoState(TFTPIDLE);
        }
        else
            return(CMD_PARAM_ERROR);
        return(CMD_SUCCESS);
    }

    /* If either the info or flags field has been specified, but the */
    /* filename is not specified, error here... */
    if ((info || flags) && (!file)) {
        printf("Filename missing\n");
        return(CMD_FAILURE);
    }

    TftpTurnedOff = 0;
    if (!strcmp(argv[optind+1],"get")) {

        if (argc == optind+4)
            addr = (ulong)strtol(argv[optind+3],0,0);
        else if (argc == optind+3)
            addr = getAppRamStart();
        else
            return(CMD_PARAM_ERROR);

        tftpGet(addr,argv[optind],mode,argv[optind+2],file,flags,info);

        EtherVerbose = 0;
    }
    else if ((argc == optind+5) && !strcmp(argv[optind+1],"put")) {
        printf("tftp 'put' not yet supported\n");
    }
    else
        return(CMD_PARAM_ERROR);

    return(CMD_SUCCESS);
}

void
ShowTftpStats()
{
    printf("Current TFTP state: %s\n",tftpStringState(TftpState));
}

#endif
