#include "stddefs.h"
#include "monlib.h"

extern void main();

void
__main(void)
{
}

void
start(void)
{
    char    **argv;
    int     argc;

    /* Connect the application to the monitor.  This must be done */
    /* prior to the application making any other attempts to use the "mon_" */
    /* functions provided by the monitor. */
    monConnect((int(*)())(*(unsigned long *)0xffe00008),(void *)0,(void *)0);

    /* Extract argc/argv from structure and call main(): */
    mon_getargv(&argc,&argv);

    /* Call main, then return to monitor. */
    return(main(argc,argv));
}
