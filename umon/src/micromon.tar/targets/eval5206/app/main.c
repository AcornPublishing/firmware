#include "monlib.h"
#include "stddefs.h"


int
main(int argc,char *argv[])
{
    int i;

    for(i=0;i<argc;i++)
        mon_printf("argv[%d] = %s\n",i,argv[i]);

    if (mon_getenv("ABC"))
        mon_cprintf("ABC = %s\n",mon_getenv("ABC"));
    else
        mon_printf("Shellvar ABC not set.\n");
    return(0);
}
