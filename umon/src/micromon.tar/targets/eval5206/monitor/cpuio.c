#include "cpuio.h"
#include "genlib.h"
#include "stddefs.h"

int probe (NATURAL32,NATURAL32);

void
mcf5206_init ()
{

    /* Initialize System Protection Resources.  Software Watchdog   */
    /* disabled, and Bus Monitor enabled. */
    IMM->sim.SYPCR = ( 0
        | MCF5206_SIM_SYPCR_BME     /* yields bus error if no TA */
        | MCF5206_SIM_SYPCR_BM_1024
        ) ;

    /* Disable Bus monitor and SWT while CPU halted.  */
    IMM->sim.SIMR = ( 0
        | MCF5206_SIM_SIMR_FRZ1
        | MCF5206_SIM_SIMR_FRZ0
        ) ;

    /* Mask all interrupt sources, and ack all.  */
    IMM->sim.IMR = ( 0
        | MCF5206_SIM_IMR_UART2
        | MCF5206_SIM_IMR_UART1
        | MCF5206_SIM_IMR_MBUS
        | MCF5206_SIM_IMR_T2
        | MCF5206_SIM_IMR_T1
        | MCF5206_SIM_IMR_SWT
        | MCF5206_SIM_IMR_EINT7
        | MCF5206_SIM_IMR_EINT6
        | MCF5206_SIM_IMR_EINT5
        | MCF5206_SIM_IMR_EINT4
        | MCF5206_SIM_IMR_EINT3
        | MCF5206_SIM_IMR_EINT2
        | MCF5206_SIM_IMR_EINT1
        ) ;
    IMM->sim.IPR = ~0;

#if 0
    /* Init PPDDR to all inputs. */
    IMM->gpio.PPDDR = 0;

    /* Initialize PPDAT. */
    IMM->gpio.PPDAT = 0;
#endif

    /* Configure multiplexed pins
        - UART2 RTS
        - External interrupts pins are IRQs, not IPLs
        - 8bit Parallel Port I/O, not PST/DDATA
        - WE0, WE1, CS4, CS5
    ELS: WARNING! comment does not match manual. */
    IMM->sim.PAR = ( 0
        | MCF5206_SIM_PAR_PAR7_RTS2
        | MCF5206_SIM_PAR_PAR1  /* WE0, WE1, CS4, CS5 */
        ) ;

    /* Setup Interrupt Source Vectors */
    IMM->sim.ICR1 = ( 0
        | MCF5206_SIM_ICR_AVEC      /* IPL/IRQ 1 */
        | MCF5206_SIM_ICR_IL(1)
        | MCF5206_SIM_ICR_IP(1)
        ) ;

    IMM->sim.ICR2 = ( 0
        | MCF5206_SIM_ICR_AVEC      /* unusable */
        | MCF5206_SIM_ICR_IL(2)
        | MCF5206_SIM_ICR_IP(3)
        ) ;

    IMM->sim.ICR3 = ( 0
        | MCF5206_SIM_ICR_AVEC      /* unusable */
        | MCF5206_SIM_ICR_IL(2)
        | MCF5206_SIM_ICR_IP(2)
        ) ;

    IMM->sim.ICR4 = ( 0
        | MCF5206_SIM_ICR_IL(4)     /* IRQ 4, MC68HC901 */
        | MCF5206_SIM_ICR_IP(2)
        ) ;

    IMM->sim.ICR5 = ( 0
        | MCF5206_SIM_ICR_AVEC      /* unusable */
        | MCF5206_SIM_ICR_IL(2)
        | MCF5206_SIM_ICR_IP(1)
        ) ;

    IMM->sim.ICR6 = ( 0
        | MCF5206_SIM_ICR_AVEC      /* unusable */
        | MCF5206_SIM_ICR_IL(2)
        | MCF5206_SIM_ICR_IP(0)
        ) ;

    IMM->sim.ICR7 = ( 0
        | MCF5206_SIM_ICR_AVEC      /* IPL/IRQ 7, Abort/NMI */
        | MCF5206_SIM_ICR_IL(7)
        | MCF5206_SIM_ICR_IP(3)
        ) ;

    IMM->sim.ICR8 = ( 0
        | MCF5206_SIM_ICR_AVEC      /* Software Watchdog */
        | MCF5206_SIM_ICR_IL(7)
        | MCF5206_SIM_ICR_IP(2)
        ) ;

    IMM->sim.ICR9 = ( 0
        | MCF5206_SIM_ICR_AVEC      /* Timer 1 */
        | MCF5206_SIM_ICR_IL(5)
        | MCF5206_SIM_ICR_IP(3)
        ) ;

    IMM->sim.ICR10 = ( 0
        | MCF5206_SIM_ICR_AVEC      /* Timer 2 */
        | MCF5206_SIM_ICR_IL(5)
        | MCF5206_SIM_ICR_IP(2)
        ) ;

    IMM->sim.ICR11 = ( 0
        | MCF5206_SIM_ICR_AVEC      /* MBUS */
        | MCF5206_SIM_ICR_IL(3)
        | MCF5206_SIM_ICR_IP(0)
        ) ;

    IMM->sim.ICR12 = ( 0
        | MCF5206_SIM_ICR_AVEC      /* UART 1 */
        | MCF5206_SIM_ICR_IL(3)
        | MCF5206_SIM_ICR_IP(2)
        ) ;

    IMM->sim.ICR13 = ( 0
        | MCF5206_SIM_ICR_AVEC      /* UART 2 */
        | MCF5206_SIM_ICR_IL(3)
        | MCF5206_SIM_ICR_IP(1)
        ) ;

    /* Software Watchdog, not used since disabled above */
    IMM->sim.SWIVR = 0x0F;          /* uninitiliazed vector */
    IMM->sim.SWSR  = 0x55;
    IMM->sim.SWSR  = 0xAA;

    /* Reset timers and disable them */
    IMM->timer.TMR1 = ( 0
        | MCF5206_TIMER_TMR_CLK_STOP
        | MCF5206_TIMER_TMR_RST
        ) ;

    IMM->timer.TER1 = ( 0
        | MCF5206_TIMER_TER_REF
        | MCF5206_TIMER_TER_CAP
        ) ;

    IMM->timer.TMR2 = ( 0
        | MCF5206_TIMER_TMR_CLK_STOP
        | MCF5206_TIMER_TMR_RST
        ) ;

    IMM->timer.TER2 = ( 0
        | MCF5206_TIMER_TER_REF
        | MCF5206_TIMER_TER_CAP
        ) ;
}

void
mcf5206_cs_init()
{
    /* This routine initializes ChipSelects to setup peripherals
     * and other board memory devices.  */

    /*
     * ChipSelect 0 - Boot FLASH 29F010
     *
     * ChipSelect 0 is the global chip select coming out of system reset.
     * CS0 is asserted for every access until CSMR0 is written.  Therefore,
     * the entire ChipSelect must be properly set prior to asserting
     * CSCR0_V.
     */
    IMM->cs.CSAR0 = MCF5206_CS_CSAR_BASE(FLASH_ADDRESS);
    IMM->cs.CSCR0 = ( 0
        | MCF5206_CS_CSCR_WS(3)
        | MCF5206_CS_CSCR_AA        /* TA_ generated internally */
        | MCF5206_CS_CSCR_PS_16
        | MCF5206_CS_CSCR_WR
        | MCF5206_CS_CSCR_RD
        ) ;
    IMM->cs.CSMR0 = MCF5206_CS_CSMR_MASK_256K;

    /* ChipSelect 1 - IACK */
    IMM->cs.CSAR1 = MCF5206_IACK_ADDRESS;
    IMM->cs.CSMR1 = ( 0
        | MCF5206_IACK_MASK
        | MCF5206_CS_CSMR_SC
        | MCF5206_CS_CSMR_SD
        | MCF5206_CS_CSMR_UC
        | MCF5206_CS_CSMR_UD
        ) ;
    IMM->cs.CSCR1 = ( 0
        | MCF5206_CS_CSCR_PS_8
        | MCF5206_CS_CSCR_WR
        | MCF5206_CS_CSCR_RD
        ) ;

    /* ChipSelect 2 - MC68HC901 */
    IMM->cs.CSAR2 = MCF5206_CS_CSAR_BASE(MC68HC901_ADDRESS);
    IMM->cs.CSMR2 = ( 0
        | MCF5206_CS_CSMR_MASK_64K
        | MCF5206_CS_CSMR_SC
        | MCF5206_CS_CSMR_UC
        ) ;
    IMM->cs.CSCR2 = ( 0
        | MCF5206_CS_CSCR_PS_8
        | MCF5206_CS_CSCR_WR
        | MCF5206_CS_CSCR_RD
        ) ;

    /* ChipSelect 3 - ISA FPGA - Externally terminated */
    IMM->cs.CSAR3 = MCF5206_CS_CSAR_BASE(ISA_ADDRESS);
    IMM->cs.CSMR3 = ( 0
        | MCF5206_CS_CSMR_MASK_1M
        ) ;
    IMM->cs.CSCR3 = ( 0
        | MCF5206_CS_CSCR_PS_16
        | MCF5206_CS_CSCR_WR
        | MCF5206_CS_CSCR_RD
        ) ;

    /* ChipSelect 4,5,6 and 7 - Empty */
    IMM->cs.CSAR4 = 0;
    IMM->cs.CSMR4 = 0;
    IMM->cs.CSCR4 = 0;
    IMM->cs.CSAR5 = 0;
    IMM->cs.CSMR5 = 0;
    IMM->cs.CSCR5 = 0;
    IMM->cs.CSAR6 = 0;
    IMM->cs.CSMR6 = 0;
    IMM->cs.CSCR6 = 0;
    IMM->cs.CSAR7 = 0;
    IMM->cs.CSMR7 = 0;
    IMM->cs.CSCR7 = 0;

    /* Default Memory Configuration Register, DMCR.  Since Bus Monitor
       enabled above, and DMCR ignores default memory, we should get
       a bus error on accessing default memory.  */
    IMM->cs.DMCR = 0;
}

void
mcf5206_dramc_init()
{
    /* This routine initializes DRAM Controller and determines size
     * of installed DRAM.  */
    unsigned dram_size, bank_two, junk;


    /* DRAM Controller Refresh Register calculation:
     *
     * Refresh cycle time = RC * 16 * ( 1 / System Frequency )
     *
     * 15.6us = RC * 16 * ( 1 / 25MHz )
     *     24 = RC
     */
    IMM->dramc.DCRR = 24;

    /* IMM->dramc.DCTR = 0; */

    IMM->dramc.DCAR0 = MCF5206_DRAMC_DCAR_BASE(DRAM_ADDRESS);
    IMM->dramc.DCMR0 = MCF5206_DRAMC_DCMR_MASK_16M;
    IMM->dramc.DCCR0 = ( 0
        | MCF5206_DRAMC_DCCR_PS_32
        | MCF5206_DRAMC_DCCR_BPS_512B
        | MCF5206_DRAMC_DCCR_PM_BURSTPAGE
        | MCF5206_DRAMC_DCCR_WR
        | MCF5206_DRAMC_DCCR_RD
        ) ;

    IMM->dramc.DCAR1 = 0;
    IMM->dramc.DCMR1 = 0;
    IMM->dramc.DCCR1 = 0;

    /* Determine size of DRAM Bank 0 */
    if (probe(DRAM_ADDRESS,0x00800000))
    {
        dram_size = 0x01000000;
    }
    else
    {
        IMM->dramc.DCMR0 = MCF5206_DRAMC_DCMR_MASK_4M;
        if (probe(DRAM_ADDRESS,0x00100000))
        {
            dram_size = 0x00400000;
        }
        else
        {
            IMM->dramc.DCMR0 = MCF5206_DRAMC_DCMR_MASK_1M;
            dram_size = 0x00100000;
        }
    }

    /* Now check DRAM Bank 1 for existance by enabling identical
     * to DRAM Bank 0, and probing */
    IMM->dramc.DCCR1 = IMM->dramc.DCCR0;
    IMM->dramc.DCMR1 = IMM->dramc.DCMR0;
    IMM->dramc.DCAR1 = MCF5206_DRAMC_DCAR_BASE(dram_size);
    if (probe(DRAM_ADDRESS+dram_size,4))
        bank_two = 1;
    else
        bank_two = 0;

    IMM->dramc.DCAR1 = 0;
    IMM->dramc.DCMR1 = 0;
    IMM->dramc.DCCR1 = 0;

#ifdef CHANGE_DRAM_WIDTH
    {
    unsigned dccr, dcmr;
    dccr = IMM->dramc.DCCR0;
    dcmr = IMM->dramc.DCMR0;
    dccr &= ~MCF5206_DRAMC_DCCR_PS_MASK;
    switch (board_get_dramw())
    {
        case 8:
            dccr |= MCF5206_DRAMC_DCCR_PS_8;
            dcmr >>= 2;
            break;
        case 16:
            dccr |= MCF5206_DRAMC_DCCR_PS_16;
            dcmr >>= 1;
            break;
        case 32:
            dccr |= MCF5206_DRAMC_DCCR_PS_32;
            dcmr >>= 0;
            break;
    }
    IMM->dramc.DCCR0 = dccr;
    IMM->dramc.DCMR0 = dcmr;
    }
#endif

    /* Prime the pump, dummy reads */
    junk = *(NATURAL32 *)0x00000000;
    junk = *(NATURAL32 *)0x00000004;
    junk = *(NATURAL32 *)0x00000008;
    junk = *(NATURAL32 *)0x0000000C;
    junk = *(NATURAL32 *)0x00000010;
    junk = *(NATURAL32 *)0x00000014;
    junk = *(NATURAL32 *)0x00000018;
    junk = *(NATURAL32 *)0x0000001C;

    if (bank_two)
    {
        IMM->dramc.DCCR1 = IMM->dramc.DCCR0;
        IMM->dramc.DCMR1 = IMM->dramc.DCMR0;
        IMM->dramc.DCAR1 = MCF5206_DRAMC_DCAR_BASE(dram_size);

        /*
         * Prime the pump, dummy reads
         */
        junk = *(NATURAL32 *)(dram_size + 0x00000000);
        junk = *(NATURAL32 *)(dram_size + 0x00000004);
        junk = *(NATURAL32 *)(dram_size + 0x00000008);
        junk = *(NATURAL32 *)(dram_size + 0x0000000C);
        junk = *(NATURAL32 *)(dram_size + 0x00000010);
        junk = *(NATURAL32 *)(dram_size + 0x00000014);
        junk = *(NATURAL32 *)(dram_size + 0x00000018);
        junk = *(NATURAL32 *)(dram_size + 0x0000001C);
    }
}

#define PATTERN_1   (0xA55A9669)
#define PATTERN_2   (0xF0F0F0F0)

int
probe (NATURAL32 base, NATURAL32 offset)
{
    /* This routine non-destructively probes a memory address to
     * determine if physical memory exists, or if the address
     * is shadowed or non-existant at all.  A return value of 1
     * indicates physical memory (that is not shadowed) exists at
     * the address, a return value of 0 indicates that no physical
     * memory is present. */
    NATURAL32 base_orig;
    NATURAL32 offset_orig;
    NATURAL32 data;

    /* Step 1) Retain original values of address contents. */
    base_orig = *(NATURAL32 *)(base);
    asm ("  nop");

    offset_orig = *(NATURAL32 *)(base + offset);
    asm ("  nop");

    /* Step 2) Write Pattern 2 to 'offset' */
    *(NATURAL32 *)(base + offset) = PATTERN_2;
    asm ("  nop");

    /* Step 3) Pattern 1 'base' in order to detect shadow.  */
    *(NATURAL32 *)(base) = PATTERN_1;
    asm ("  nop");

    /* Step 4) Read 'offset' */
    data = *(NATURAL32 *)(base + offset);
    asm ("  nop");

    /* Step 5) Restore original values */
    *(NATURAL32 *)(base + offset) = offset_orig;
    asm ("  nop");

    *(NATURAL32 *)(base) = base_orig;
    asm ("  nop");

    if (data == PATTERN_2)
    {
        return 1;       /* Real physical memory exists at address */
    }
    else
    {
        return 0;       /* No physical memory exists at physical address */
    }
}

int (*remoteputchar)(), (*remotegetchar)(), (*remotegotachar)();
int (*remoterawon)(), (*remoterawoff)();
int ConsoleBaudRate;

void
InitUART(int baud)
{
    ushort  ubg;

    if (baud == 0)
        baud = ConsoleBaudRate;

    ConsoleBaudRate = baud;
    InitRemoteIO();

    /* UART1 reset: */
    IMM->uart1.UCR = 0x10;      /* Reset mode register pointer */
    IMM->uart1.UCR = 0x20;      /* Reset receiver */
    IMM->uart1.UCR = 0x30;      /* Reset transmitter */
    IMM->uart1.UCR = 0x40;      /* Reset error status */
    IMM->uart1.UCR = 0x50;      /* Reset break change interrupt */

    /* UART1 mode: */
    IMM->uart1.UMR = 0x13;      /* 8bit char, no parity */
    IMM->uart1.UMR = 0x07;      /* 1 stop bit */

    /* CLock select (UCSR): */
    IMM->uart1.USR = 0xdd;      /* Use internal clock */

    /* UART1 baudrate divisors: */
    ubg = CPU_CLOCK_FREQUENCY/32/baud;
    IMM->uart1.UBG1 =  (uchar)((ubg & 0xff00) >> 8);
    IMM->uart1.UBG2 =  (uchar)(ubg & 0x00ff);
    IMM->uart1.UCR = 0x05;      /* Enable xmt & rcv */
}

int
rputchar(char c)
{
    while((IMM->uart1.USR & 0x04) == 0);
    IMM->uart1.UBUF = c;
    return((int)c);
}

int
getchar(void)
{
    while((IMM->uart1.USR & 0x01) == 0);
    return((int)(IMM->uart1.UBUF));
}

int
gotachar()
{
    return(IMM->uart1.USR & 0x01);
}

void
initCPUio()
{
}

int
devInit(int baud)
{
    InitUART(baud);
    return(0);
}

void
rawon(void)
{
    if (remoterawon)
        remoterawon();
}

void
rawoff(void)
{
    if (remoterawoff)
        remoterawoff();
}

