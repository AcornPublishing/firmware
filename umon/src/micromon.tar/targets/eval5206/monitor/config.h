/* Monitor configuration file. */

#if PLATFORM_CFEVAL
#define PLATFORM_NAME       "EVAL_5206"
#else
#error "Platform name is not specified"
#endif

#define CPU_NAME    "ColdFire 5206"

#define FLASH_PROTECT_RANGE "0-4"

/* Flash bank configuration: */
#define FLASHBANKS              1
#define FLASH_BANK0_WIDTH       2
#define FLASH_BANK0_BASE_ADDR   0xFFE00000

/* TFS definitions:
    TFSSTART:       Base address in FLASH at which TFS starts.
    TFSEND:         End address of TFS in FLASH.
    TFSSPARE:       Location of sector that is used as the spare sector
                    by TFS for defragmentation.
    TFSSPARESIZE:   Size of the spare sector used by TFS for defragmentation.
    TFSSECTORCOUNT: Number of eraseable sectors that TFS covers, not including
                    the TFSSPARE sector.
*/
#define TFSNAMESIZE     23      /* Should be mod4 - 1 */
#define TFSSPARESIZE    0x8000
#define TFSSECTORCOUNT  2   
#define TFSSTART        0xffe28000
#define TFSEND          0xffe37fff
#define TFSSPARE        0xffe38000
#define TFS_EBIN_COFF   1

/* Width macros used by TFS and FLASH operations.
   Note that only one of WIDTH8, WIDTH16 and WIDTH32 should be set and the
   WIDTHXX_NOTUESD macros should reflect the opposite state of the WIDTH
   macros. */
#define WIDTH8      0
#define WIDTH16     1
#define WIDTH32     0
#define WIDTH8_NOTUSED  1
#define WIDTH16_NOTUSED 0
#define WIDTH32_NOTUSED 1

/* Specify the size of the memory block (in monitor space) that is to be
   allocated to malloc in the monitor.  Note that this size can be dynamically
   increased through the HEAPBASE and HEAPSTART shell variables.  */
#define ALLOCSIZE 64*1024

/* SYMFILE is the name of a file that, if present, the monitor uses to 
   process symbols on the command line.  A symbol is a whitespace delimited
   string prefixed by a percent sign (%).
*/
#define SYMFILE "symtbl"

/* Specify the type of COLDFIRE CPU here. Only one should be defined. */
#define CPU_5602    1

/* Specify inclusion of subsystems within the monitor here.
   The basic monitor includes the following commands as a minimum:

    flash, help, reset, setup, version, call

   Subsystems are included/excluded by defining a few macros to 1/0.
   Following are the subsystem groupings:

    INCLUDE_MEMCMDS:    dm, pm, cm, fm, sm
    INCLUDE_PIO:        pio
    INCLUDE_EDIT:       edit
    INCLUDE_DEBUG:      argv, at, dr, go, pr, ss, vfy, sleep
    INCLUDE_DISASSEMBLER:   dis
    INCLUDE_UNPACK:     unpack
    INCLUDE_ETHERNET:   ether
    INCLUDE_XMODEM:     xmodem

   Note that these INCLUDE macros allow the monitor to be built in a 
   variety of configurations; some of which may put extreme limitations
   on the capability of the monitor.  For example, it is recommended that
   at least INCLUDE_ETHERNET or INCLUDE_XMODEM be defined otherwise
   there is no download capability in the monitor.  The INCLUDE_TFS macro
   is also recommended.

   An absolute minimum practical configuration should include:
        ETHERNET or XMODEM.

   A minimum configuration that includes typical TFS capabilities should
   include: TFS, and {ETHERNET | XMODEM}.
*/
#define INCLUDE_MEMCMDS         1
#define INCLUDE_PIO             0
#define INCLUDE_EDIT            1
#define INCLUDE_DEBUG           0
#define INCLUDE_DISASSEMBLER    0
#define INCLUDE_UNPACK          0
#define INCLUDE_UNZIP           1
#define INCLUDE_ETHERNET        0
#define INCLUDE_TFTP            0
#define INCLUDE_TFS             1
#define INCLUDE_FLASH           1
#define INCLUDE_XMODEM          1
#define INCLUDE_LINEEDIT        1
#define INCLUDE_CRYPT           0
#define INCLUDE_DHCPBOOT        0
#define INCLUDE_TFSAPI          1
#define INCLUDE_TFSAUTODEFRAG   1
#define INCLUDE_TFSSYMTBL       0
#define INCLUDE_TFSSCRIPT       0
#define INCLUDE_TFSCLI          1
#define INCLUDE_EE              0
#define INCLUDE_GDB             0
#define INCLUDE_STRACE          0
#define INCLUDE_CAST            0
#define INCLUDE_EXCTEST         0
#define INCLUDE_IDEV            0
#define INCLUDE_REDIRECT        0
#define INCLUDE_QUICKMEMCPY     1
#define INCLUDE_PROFILER        0
#define INCLUDE_BBC             0
#define INCLUDE_MEMTRACE        0

#include "inc_check.h"
