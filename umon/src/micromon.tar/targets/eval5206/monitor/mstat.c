#include "config.h"
#include "cpu.h"
#include "genlib.h"
#include "stddefs.h"

extern  int getopt(), atoi(), printf();
extern  void InitUART();


void    mstatshow(void);
static  ushort  MonitorSTATUS;

void
trap_exception(void)
{
    register int d2, d3, d4, d5, d6, d7; 
    register int *a2, *a3, *a4, *a5, *a6; 

    d2 = 0xDDDD2222;
    d3 = 0xDDDD3333;
    d4 = 0xDDDD4444;
    d5 = 0xDDDD5555;
    d6 = 0xDDDD6666;
    d7 = 0xDDDD7777;
    a2 = (int *)0xAAAA2222;
    a3 = (int *)0xAAAA3333;
    a4 = (int *)0xAAAA4444;
    a5 = (int *)0xAAAA5555;
    a6 = (int *)0xAAAA6666;

    printf("Trap exception around 0x%lx\n",(ulong)trap_exception);
    asm(" trap #3 ");
}

char *MstatHelp[] = {
    "Monitor status",
    "-[b:]",
    " -b {baud}  set baud rate",
    " -x         trap #3 exception",
    0,
};

int
Mstat(int argc,char *argv[])
{
    int opt;

    /* If no args, just dump current status. */
    if (argc == 1) {
        mstatshow();
        return(0);
    }

    while ((opt=getopt(argc,argv,"b:x")) != -1) {
        switch(opt) {
        case 'b':
            InitUART(atoi(optarg));
            break;
        case 'x':
            trap_exception();
            break;
        default:
            return(0);
        }
    }
    if (argc != optind)
        return(-1);
    return(0);
}

void
InitMonSTATUS(ulong state)
{
    extern void putsr(ushort);

    MonitorSTATUS = state;
    putsr((ushort)MonitorSTATUS);
}

void
SetMonSTATUS(void)
{
    extern void putsr(ushort);

    putsr((ushort)MonitorSTATUS);
}

void
mstatshow(void)
{
    extern  ulong getsr(void);
    extern  ulong getsp(void);
    
    monHeader(0);
    mstatshowcom();
    printf("Monitor SR: 0x%04x\n",(ushort)getsr());
    printf("Monitor SP: 0x%08x\n",getsp());
}

