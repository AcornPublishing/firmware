/***************************************************************/
/* MCF5206 Eval Board by Arnewsh                               */
/***************************************************************/
#define DEFAULT_BAUD_RATE 57600
#define CPU_CLOCK_FREQUENCY 25000000        /* Clock = 25Mhz */
#define MCF5200
#define MCF5206
#define MYPRINTF
#define NETWORK
#define SYMBOL_MATCH_MASK   (0xFFFFFFFF)
#define FLASH_ADDRESS       (0xFFE00000)
#define DRAM_ADDRESS        (0x00000000)
#define IMM_ADDRESS         (0x10000000)
#define SRAM_ADDRESS        (0x20000000)
#define MC68HC901_ADDRESS   (0x30000000)
#define MC68HC901_IRQ       (0xF0)
#define ISA_ADDRESS         (0x40000000)

/* Macro which returns a pointer to the Internal Memory Map */ 
#define mcf5206_get_immp()     ((MCF5206_IMM *)(IMM_ADDRESS))

void ird (int, char **);
void irm (int, char **);

/* Defintions of the basic data types.  */

typedef unsigned char       BYTE;   /*  8 bits */
typedef unsigned short int  WORD;   /* 16 bits */
typedef unsigned long int   LONG;   /* 32 bits */

typedef signed char         SBYTE;  /*  8 bits */
typedef signed short int    SWORD;  /* 16 bits */
typedef signed long int     SLONG;  /* 32 bits */

typedef unsigned char       NATURAL8;  /*  8 bits */
typedef unsigned short int  NATURAL16; /* 16 bits */
typedef unsigned long int   NATURAL32; /* 32 bits */

typedef signed char         INTEGER8;   /*  8 bits */
typedef signed short int    INTEGER16;  /* 16 bits */
typedef signed long int     INTEGER32;  /* 32 bits */

#define ILLEGAL         0x4AFC          /* 68K illegal instruction */

/*
 * Definition of registers of the MCF5206.  Note that not all
 * the registers accessible on the MCF5206 are actually listed
 * here.  The reason for this is that not all registers on the
 * CPU are readable, thus it is up to the user to maintain a
 * readable/visible copy of the values contained in those
 * registers.
 */
typedef struct
{
    /* Order IS VERY IMPORTANT -- MOVEM instruction */
    NATURAL32   d0, d1, d2, d3, d4, d5, d6, d7;
    /* offset   00  04  08  12  16  20  24  28 */
    NATURAL32   a0, a1, a2, a3, a4, a5, a6, a7;
    /* offset   32  36  40  44  48  52  56  60 */
    NATURAL32   pc;
    /* offset   64 */
    NATURAL16   sr;
    /* offset   68 */
} REGISTERS;


#define MCF5206_SR_T            (0x8000)
#define MCF5206_SR_S            (0x2000)
#define MCF5206_SR_M            (0x1000)
#define MCF5206_SR_IPL          (0x0700)
#define MCF5206_SR_X            (0x0010)
#define MCF5206_SR_N            (0x0008)
#define MCF5206_SR_Z            (0x0004)
#define MCF5206_SR_V            (0x0002)
#define MCF5206_SR_C            (0x0001)

/* Definition of what the single exception stack frame looks like.  */
typedef struct
{
    NATURAL16   form_vector;
    NATURAL16   status_register;
    NATURAL32   program_counter;
} STACK_FRAME;

#define SF_FORMAT(a)    ((a->form_vector >> 12) & 0x00FF)
#define SF_VECTOR(a)    ((a->form_vector >>  2) & 0x00FF)
#define SF_SR(a)        (a->status_register)
#define SF_PC(a)        (a->program_counter)
#define SF_FS(a)  (((a->form_vector & 0x0C00)>>8) | (a->form_vector & 0x0003))

/* Cache and Access Control Register routines and defintions */
#define MCF5206_CACR_CENB       (0x80000000)
#define MCF5206_CACR_CFRZ       (0x08000000)
#define MCF5206_CACR_CINV       (0x01000000)
#define MCF5206_CACR_CMOD       (0x00000200)
#define MCF5206_CACR_CWRP       (0x00000020)
#define MCF5206_CACR_CLNF_00    (0x00000000)
#define MCF5206_CACR_CLNF_01    (0x00000001)
#define MCF5206_CACR_CLNF_10    (0x00000002)

#define MCF5206_ACR_BASE(a)     ((a)&0xFF000000)
#define MCF5206_ACR_MASK(a)     (((a)&0xFF000000) >> 8)
#define MCF5206_ACR_EN          (0x00008000)
#define MCF5206_ACR_S_USER      (0x00000000)
#define MCF5206_ACR_S_SUPER     (0x00002000)
#define MCF5206_ACR_S_IGNORE    (0x00006000)
#define MCF5206_ACR_ENIB        (0x00000080)
#define MCF5206_ACR_CM          (0x00000040)
#define MCF5206_ACR_WP          (0x00000004)

#define MCF5206_SRAMBAR_BASE(a)     ((a)&0xFFFFFE00)
#define MCF5206_SRAMBAR_WP          (0x00000100)
#define MCF5206_SRAMBAR_AS_CI       (0x00000080)
#define MCF5206_SRAMBAR_AS_SC       (0x00000040)
#define MCF5206_SRAMBAR_AS_SD       (0x00000020)
#define MCF5206_SRAMBAR_AS_UC       (0x00000004)
#define MCF5206_SRAMBAR_AS_UD       (0x00000002)
#define MCF5206_SRAMBAR_V           (0x00000001)

#define MCF5206_MBAR_BASE(a)            ((a)&0xFFFFFC00)
#define MCF5206_MBAR_SC                 (0x00000010)
#define MCF5206_MBAR_SD                 (0x00000008)
#define MCF5206_MBAR_UC                 (0x00000004)
#define MCF5206_MBAR_UD                 (0x00000002)
#define MCF5206_MBAR_V                  (0x00000001)

/* Memory-mapped System Integration registers */
typedef volatile struct
{
    NATURAL8    reserved0;
    NATURAL8    reserved1;
    NATURAL8    reserved2;
    NATURAL8    SIMR;
    NATURAL32   reserved3;
    NATURAL32   reserved4;
    NATURAL32   reserved5;
    NATURAL32   reserved6;
    NATURAL8    ICR1;
    NATURAL8    ICR2;
    NATURAL8    ICR3;
    NATURAL8    ICR4;
    NATURAL8    ICR5;
    NATURAL8    ICR6;
    NATURAL8    ICR7;
    NATURAL8    ICR8;
    NATURAL8    ICR9;
    NATURAL8    ICR10;
    NATURAL8    ICR11;
    NATURAL8    ICR12;
    NATURAL8    ICR13;
    NATURAL8    reserved7;
    NATURAL8    reserved8;
    NATURAL8    reserved9;
    NATURAL32   reserved10[4];
    NATURAL8    reserved11;
    NATURAL8    reserved12;
    NATURAL16   IMR;
    NATURAL16   reserved13;
    NATURAL16   IPR;
    NATURAL32   reserved14;
    NATURAL8    RSR;
    NATURAL8    SYPCR;
    NATURAL8    SWIVR;
    NATURAL8    SWSR;
    NATURAL8    reserved31[135];
    NATURAL8    PAR;
} MCF5206_SIM;

#define MCF5206_SIM_SIMR_FRZ1       (0x80)
#define MCF5206_SIM_SIMR_FRZ0       (0x40)
#define MCF5206_SIM_SIMR_BL         (0x01)

#define MCF5206_SIM_ICR_AVEC        (0x80)
#define MCF5206_SIM_ICR_IL(a)       (((a)&0x07)<<2)
#define MCF5206_SIM_ICR_IP(a)       (((a)&0x03))

#define MCF5206_SIM_IMR_UART2       (0x2000)
#define MCF5206_SIM_IMR_UART1       (0x1000)
#define MCF5206_SIM_IMR_MBUS        (0x0800)
#define MCF5206_SIM_IMR_T2          (0x0400)
#define MCF5206_SIM_IMR_T1          (0x0200)
#define MCF5206_SIM_IMR_SWT         (0x0100)
#define MCF5206_SIM_IMR_EINT7       (0x0080)
#define MCF5206_SIM_IMR_EINT6       (0x0040)
#define MCF5206_SIM_IMR_EINT5       (0x0020)
#define MCF5206_SIM_IMR_EINT4       (0x0010)
#define MCF5206_SIM_IMR_EINT3       (0x0008)
#define MCF5206_SIM_IMR_EINT2       (0x0004)
#define MCF5206_SIM_IMR_EINT1       (0x0002)

#define MCF5206_SIM_IPR_UART2       (0x2000)
#define MCF5206_SIM_IPR_UART1       (0x1000)
#define MCF5206_SIM_IPR_MBUS        (0x0800)
#define MCF5206_SIM_IPR_T2          (0x0400)
#define MCF5206_SIM_IPR_T1          (0x0200)
#define MCF5206_SIM_IPR_SWT         (0x0100)
#define MCF5206_SIM_IPR_EINT7       (0x0080)
#define MCF5206_SIM_IPR_EINT6       (0x0040)
#define MCF5206_SIM_IPR_EINT5       (0x0020)
#define MCF5206_SIM_IPR_EINT4       (0x0010)
#define MCF5206_SIM_IPR_EINT3       (0x0008)
#define MCF5206_SIM_IPR_EINT2       (0x0004)
#define MCF5206_SIM_IPR_EINT1       (0x0002)

#define MCF5206_SIM_RSR_HRST        (0x80)
#define MCF5206_SIM_RSR_SWTR        (0x20)

#define MCF5206_SIM_SYPCR_SWE       (0x80)
#define MCF5206_SIM_SYPCR_SWRI      (0x40)
#define MCF5206_SIM_SYPCR_SWT_2_9   (0x00)
#define MCF5206_SIM_SYPCR_SWT_2_11  (0x08)
#define MCF5206_SIM_SYPCR_SWT_2_13  (0x10)
#define MCF5206_SIM_SYPCR_SWT_2_15  (0x18)
#define MCF5206_SIM_SYPCR_SWT_2_18  (0x20)
#define MCF5206_SIM_SYPCR_SWT_2_20  (0x28)
#define MCF5206_SIM_SYPCR_SWT_2_22  (0x30)
#define MCF5206_SIM_SYPCR_SWT_2_24  (0x38)
#define MCF5206_SIM_SYPCR_BME       (0x04)
#define MCF5206_SIM_SYPCR_BM_1024   (0x00)
#define MCF5206_SIM_SYPCR_BM_512    (0x01)
#define MCF5206_SIM_SYPCR_BM_256    (0x02)
#define MCF5206_SIM_SYPCR_BM_128    (0x03)

#define MCF5206_SIM_SWIVR_SWIV(a)   ((a)&0x00FF)

#define MCF5206_SIM_PAR_PAR7        (0x80)
#define MCF5206_SIM_PAR_PAR7_RSTO   (0x00)
#define MCF5206_SIM_PAR_PAR7_RTS2   (0x80)
#define MCF5206_SIM_PAR_PAR6        (0x40)
#define MCF5206_SIM_PAR_PAR6_IRQ    (0x00)
#define MCF5206_SIM_PAR_PAR6_IPL    (0x40)
#define MCF5206_SIM_PAR_PAR5        (0x20)
#define MCF5206_SIM_PAR_PAR5_PP74   (0x00)
#define MCF5206_SIM_PAR_PAR5_PST    (0x20)
#define MCF5206_SIM_PAR_PAR4        (0x10)
#define MCF5206_SIM_PAR_PAR4_PP30   (0x00)
#define MCF5206_SIM_PAR_PAR4_DDATA  (0x10)
#define MCF5206_SIM_PAR_PAR3        (0x08)
#define MCF5206_SIM_PAR_PAR2        (0x04)
#define MCF5206_SIM_PAR_PAR1        (0x02)
#define MCF5206_SIM_PAR_PAR0        (0x01)

typedef volatile struct
{
    NATURAL8    reserved0[0x1C5];
    NATURAL8    PPDDR;
    NATURAL8    reserved34;
    NATURAL8    reserved35;
    NATURAL8    reserved36;
    NATURAL8    PPDAT;
} MCF5206_GPIO;

#define MCF5206_PP_PPDDR_DDR7_INPUT     (~0x80)
#define MCF5206_PP_PPDDR_DDR7_OUTPUT    ( 0x80)
#define MCF5206_PP_PPDDR_DDR6_INPUT     (~0x40)
#define MCF5206_PP_PPDDR_DDR6_OUTPUT    ( 0x40)
#define MCF5206_PP_PPDDR_DDR5_INPUT     (~0x20)
#define MCF5206_PP_PPDDR_DDR5_OUTPUT    ( 0x20)
#define MCF5206_PP_PPDDR_DDR4_INPUT     (~0x10)
#define MCF5206_PP_PPDDR_DDR4_OUTPUT    ( 0x10)
#define MCF5206_PP_PPDDR_DDR3_INPUT     (~0x08)
#define MCF5206_PP_PPDDR_DDR3_OUTPUT    ( 0x08)
#define MCF5206_PP_PPDDR_DDR2_INPUT     (~0x04)
#define MCF5206_PP_PPDDR_DDR2_OUTPUT    ( 0x04)
#define MCF5206_PP_PPDDR_DDR1_INPUT     (~0x02)
#define MCF5206_PP_PPDDR_DDR1_OUTPUT    ( 0x02)
#define MCF5206_PP_PPDDR_DDR0_INPUT     (~0x01)
#define MCF5206_PP_PPDDR_DDR0_OUTPUT    ( 0x01)

#define MCF5206_PP_PPDAT_DAT7       ( 0x80)
#define MCF5206_PP_PPDAT_DAT6       ( 0x40)
#define MCF5206_PP_PPDAT_DAT5       ( 0x20)
#define MCF5206_PP_PPDAT_DAT4       ( 0x10)
#define MCF5206_PP_PPDAT_DAT3       ( 0x08)
#define MCF5206_PP_PPDAT_DAT2       ( 0x04)
#define MCF5206_PP_PPDAT_DAT1       ( 0x02)
#define MCF5206_PP_PPDAT_DAT0       ( 0x01)

typedef volatile struct
{
    NATURAL32   reserved1[0x19];
    NATURAL16   CSAR0;
    NATURAL16   rsvd0;
    NATURAL32   CSMR0;
    NATURAL16   reserved2;
    NATURAL16   CSCR0;
    NATURAL16   CSAR1;
    NATURAL16   rsvd1;
    NATURAL32   CSMR1;
    NATURAL16   reserved4;
    NATURAL16   CSCR1;
    NATURAL16   CSAR2;
    NATURAL16   rsvd2;
    NATURAL32   CSMR2;
    NATURAL16   reserved6;
    NATURAL16   CSCR2;
    NATURAL16   CSAR3;
    NATURAL16   rsvd3;
    NATURAL32   CSMR3;
    NATURAL16   reserved8;
    NATURAL16   CSCR3;
    NATURAL16   CSAR4;
    NATURAL16   rsvd4;
    NATURAL32   CSMR4;
    NATURAL16   reserved10;
    NATURAL16   CSCR4;
    NATURAL16   CSAR5;
    NATURAL16   rsvd5;
    NATURAL32   CSMR5;
    NATURAL16   reserved12;
    NATURAL16   CSCR5;
    NATURAL16   CSAR6;
    NATURAL16   rsvd6;
    NATURAL32   CSMR6;
    NATURAL16   reserved14;
    NATURAL16   CSCR6;
    NATURAL16   CSAR7;
    NATURAL16   rsvd7;
    NATURAL32   CSMR7;
    NATURAL16   reserved16;
    NATURAL16   CSCR7;
    NATURAL16   reserved17;
    NATURAL16   DMCR;
} MCF5206_CS;

#define MCF5206_CS_CSAR_BASE(a)     (((a)&0xFFFF0000)>>16)

#define MCF5206_CS_CSMR_MASK_32M        (0x01FF0000)
#define MCF5206_CS_CSMR_MASK_16M        (0x00FF0000)
#define MCF5206_CS_CSMR_MASK_8M         (0x007F0000)
#define MCF5206_CS_CSMR_MASK_4M         (0x003F0000)
#define MCF5206_CS_CSMR_MASK_2M         (0x001F0000)
#define MCF5206_CS_CSMR_MASK_1M         (0x000F0000)
#define MCF5206_CS_CSMR_MASK_1024K      (0x000F0000)
#define MCF5206_CS_CSMR_MASK_512K       (0x00070000)
#define MCF5206_CS_CSMR_MASK_256K       (0x00030000)
#define MCF5206_CS_CSMR_MASK_128K       (0x00010000)
#define MCF5206_CS_CSMR_MASK_64K        (0x00000000)
#define MCF5206_CS_CSMR_SC              (0x00000010)
#define MCF5206_CS_CSMR_SD              (0x00000008)
#define MCF5206_CS_CSMR_UC              (0x00000004)
#define MCF5206_CS_CSMR_UD              (0x00000002)
#define MCF5206_CS_CSMR1_CPU            (0x00000020)

#define MCF5206_CS_CSCR_WS_MASK         (0x3C00)
#define MCF5206_CS_CSCR_WS(a)           (((a)&0x0F)<<10)
#define MCF5206_CS_CSCR_BRST            (0x0200)
#define MCF5206_CS_CSCR_AA              (0x0100)
#define MCF5206_CS_CSCR_PS_8            (0x0040)
#define MCF5206_CS_CSCR_PS_16           (0x0080)
#define MCF5206_CS_CSCR_PS_32           (0x0000)
#define MCF5206_CS_CSCR_EMAA            (0x0020)
#define MCF5206_CS_CSCR_ASET            (0x0010)
#define MCF5206_CS_CSCR_WRAH            (0x0008)
#define MCF5206_CS_CSCR_RDAH            (0x0004)
#define MCF5206_CS_CSCR_WR              (0x0002)
#define MCF5206_CS_CSCR_RD              (0x0001)

#define MCF5206_CS_DMCR_WS_MASK         (0x3C00)
#define MCF5206_CS_DMCR_WS(a)           (((a)&0x0F)<<10)
#define MCF5206_CS_DMCR_BRST            (0x0200)
#define MCF5206_CS_DMCR_AA              (0x0100)
#define MCF5206_CS_DMCR_PS_8            (0x0040)
#define MCF5206_CS_DMCR_PS_16           (0x0080)
#define MCF5206_CS_DMCR_PS_32           (0x0000)
#define MCF5206_CS_DMCR_EMAA            (0x0020)
#define MCF5206_CS_DMCR_WRAH            (0x0008)
#define MCF5206_CS_DMCR_RDAH            (0x0004)

#define MCF5206_IACK_ADDRESS    (MCF5206_CS_CSAR_BASE(0xFFFFFFE0))
#define MCF5206_IACK_MASK       (MCF5206_CS_CSMR_MASK_64K)

typedef volatile struct
{
    NATURAL16   reserved1[0x23];
    NATURAL16   DCRR;
    NATURAL16   reserved2;
    NATURAL16   DCTR;
    NATURAL16   DCAR0;
    NATURAL16   reserved4;
    NATURAL32   DCMR0;
    NATURAL8    reserved5[3];
    NATURAL8    DCCR0;
    NATURAL16   DCAR1;
    NATURAL16   reserved6;
    NATURAL32   DCMR1;
    NATURAL8    reserved7[3];
    NATURAL8    DCCR1;
} MCF5206_DRAMC;

#define MCF5206_DRAMC_DCRR_RC(a)    ((a)&0x0FFF)

#define MCF5206_DRAMC_DCTR_DAEM     (0x8000)
#define MCF5206_DRAMC_DCTR_EDO      (0x4000)
#define MCF5206_DRAMC_DCTR_RCD      (0x1000)
#define MCF5206_DRAMC_DCTR_RSH_1    (0x0000)
#define MCF5206_DRAMC_DCTR_RSH_2    (0x0200)
#define MCF5206_DRAMC_DCTR_RSH_3    (0x0400)
#define MCF5206_DRAMC_DCTR_CRP_15   (0x0000)
#define MCF5206_DRAMC_DCTR_CRP_25   (0x0020)
#define MCF5206_DRAMC_DCTR_CRP_35   (0x0040)
#define MCF5206_DRAMC_DCTR_CAS      (0x0008)
#define MCF5206_DRAMC_DCTR_CP       (0x0002)
#define MCF5206_DRAMC_DCTR_CSR      (0x0001)

#define MCF5206_DRAMC_DCAR_BASE(a)  (((a)&0xFFFE0000)>>16)

#define MCF5206_DRAMC_DCMR_MASK_128M    (0x07FE0000)
#define MCF5206_DRAMC_DCMR_MASK_64M     (0x03FE0000)
#define MCF5206_DRAMC_DCMR_MASK_32M     (0x01FE0000)
#define MCF5206_DRAMC_DCMR_MASK_16M     (0x00FE0000)
#define MCF5206_DRAMC_DCMR_MASK_8M      (0x007E0000)
#define MCF5206_DRAMC_DCMR_MASK_4M      (0x003E0000)
#define MCF5206_DRAMC_DCMR_MASK_2M      (0x001E0000)
#define MCF5206_DRAMC_DCMR_MASK_1M      (0x000E0000)
#define MCF5206_DRAMC_DCMR_MASK_1024K   (0x00060000)
#define MCF5206_DRAMC_DCMR_MASK_256K    (0x00020000)
#define MCF5206_DRAMC_DCMR_MASK_128K    (0x00000000)
#define MCF5206_DRAMC_DCMR_SC           (0x00000010)
#define MCF5206_DRAMC_DCMR_SD           (0x00000008)
#define MCF5206_DRAMC_DCMR_UC           (0x00000004)
#define MCF5206_DRAMC_DCMR_UD           (0x00000002)

#define MCF5206_DRAMC_DCCR_PS_32        (0x00)
#define MCF5206_DRAMC_DCCR_PS_16        (0xC0)
#define MCF5206_DRAMC_DCCR_PS_8         (0x40)
#define MCF5206_DRAMC_DCCR_PS_MASK      (0xC0)
#define MCF5206_DRAMC_DCCR_BPS_512B     (0x00)
#define MCF5206_DRAMC_DCCR_BPS_1K       (0x10)
#define MCF5206_DRAMC_DCCR_BPS_2K       (0x20)
#define MCF5206_DRAMC_DCCR_PM_NORMAL    (0x00)
#define MCF5206_DRAMC_DCCR_PM_BURSTPAGE (0x04)
#define MCF5206_DRAMC_DCCR_PM_FASTPAGE  (0x0C)
#define MCF5206_DRAMC_DCCR_WR           (0x02)
#define MCF5206_DRAMC_DCCR_RD           (0x01)

typedef volatile struct
{
    NATURAL8    reserved0[0x100];
    NATURAL16   TMR1;
    NATURAL16   reserved1;
    NATURAL16   TRR1;
    NATURAL16   reserved2;
    NATURAL16   TCR1;
    NATURAL16   reserved3;
    NATURAL16   TCN1;
    NATURAL16   reserved4;
    NATURAL8    reserved5;
    NATURAL8    TER1;
    NATURAL32   reserved6;
    NATURAL32   reserved7;
    NATURAL32   reserved8;
    NATURAL16   TMR2;
    NATURAL16   reserved9;
    NATURAL16   TRR2;
    NATURAL16   reserved10;
    NATURAL16   TCR2;
    NATURAL16   reserved11;
    NATURAL16   TCN2;
    NATURAL16   reserved12;
    NATURAL8    reserved13;
    NATURAL8    TER2;
} MCF5206_TIMER;

#define MCF5206_TIMER_TMR_PS(a)     (((a)&0x00FF)<<8)
#define MCF5206_TIMER_TMR_CE_ANY    (0x00C0)
#define MCF5206_TIMER_TMR_CE_RISE   (0x0080)
#define MCF5206_TIMER_TMR_CE_FALL   (0x0040)
#define MCF5206_TIMER_TMR_CE_NONE   (0x0000)
#define MCF5206_TIMER_TMR_OM        (0x0020)
#define MCF5206_TIMER_TMR_ORI       (0x0010)
#define MCF5206_TIMER_TMR_FRR       (0x0008)
#define MCF5206_TIMER_TMR_CLK_TIN   (0x0006)
#define MCF5206_TIMER_TMR_CLK_DIV16 (0x0004)
#define MCF5206_TIMER_TMR_CLK_MSCLK (0x0002)
#define MCF5206_TIMER_TMR_CLK_STOP  (0x0000)
#define MCF5206_TIMER_TMR_RST       (0x0001)

#define MCF5206_TIMER_TER_REF       (0x02)
#define MCF5206_TIMER_TER_CAP       (0x01)

typedef volatile struct
{
    NATURAL32   reserved1[0x140>>2];
    NATURAL8    UMR;
    NATURAL8    reserved2;
    NATURAL8    reserved3;
    NATURAL8    reserved4;
    NATURAL8    USR;
    NATURAL8    reserved5;
    NATURAL8    reserved6;
    NATURAL8    reserved7;
    NATURAL8    UCR;
    NATURAL8    reserved8;
    NATURAL8    reserved9;
    NATURAL8    reserved10;
    NATURAL8    UBUF;
    NATURAL8    reserved11;
    NATURAL8    reserved12;
    NATURAL8    reserved13;
    NATURAL8    UACR;
    NATURAL8    reserved14;
    NATURAL8    reserved15;
    NATURAL8    reserved16;
    NATURAL8    UIR;
    NATURAL8    reserved17;
    NATURAL8    reserved18;
    NATURAL8    reserved19;
    NATURAL8    UBG1;
    NATURAL8    reserved20;
    NATURAL8    reserved21;
    NATURAL8    reserved22;
    NATURAL8    UBG2;
    NATURAL32   reserved23[4];
    NATURAL8    UIVR;
    NATURAL8    reserved24;
    NATURAL8    reserved25;
    NATURAL8    reserved26;
    NATURAL8    UIP;
    NATURAL8    reserved27;
    NATURAL8    reserved28;
    NATURAL8    reserved29;
    NATURAL8    UOP1;
    NATURAL8    reserved30;
    NATURAL8    reserved31;
    NATURAL8    reserved32;
    NATURAL8    UOP0;
} MCF5206_UART1;

typedef volatile struct
{
    NATURAL32   reserved1[0x180>>2];
    NATURAL8    UMR;
    NATURAL8    reserved2;
    NATURAL8    reserved3;
    NATURAL8    reserved4;
    NATURAL8    USR;
    NATURAL8    reserved5;
    NATURAL8    reserved6;
    NATURAL8    reserved7;
    NATURAL8    UCR;
    NATURAL8    reserved8;
    NATURAL8    reserved9;
    NATURAL8    reserved10;
    NATURAL8    UBUF;
    NATURAL8    reserved11;
    NATURAL8    reserved12;
    NATURAL8    reserved13;
    NATURAL8    UACR;
    NATURAL8    reserved14;
    NATURAL8    reserved15;
    NATURAL8    reserved16;
    NATURAL8    UIR;
    NATURAL8    reserved17;
    NATURAL8    reserved18;
    NATURAL8    reserved19;
    NATURAL8    UBG1;
    NATURAL8    reserved20;
    NATURAL8    reserved21;
    NATURAL8    reserved22;
    NATURAL8    UBG2;
    NATURAL32   reserved23[4];
    NATURAL8    UIVR;
    NATURAL8    reserved24;
    NATURAL8    reserved25;
    NATURAL8    reserved26;
    NATURAL8    UIP;
    NATURAL8    reserved27;
    NATURAL8    reserved28;
    NATURAL8    reserved29;
    NATURAL8    UOP1;
    NATURAL8    reserved30;
    NATURAL8    reserved31;
    NATURAL8    reserved32;
    NATURAL8    UOP0;
} MCF5206_UART2;

#define MCF5206_UART_UMR1_RXRTS         (0x80)
#define MCF5206_UART_UMR1_RXIRQ         (0x40)
#define MCF5206_UART_UMR1_ERR           (0x20)
#define MCF5206_UART_UMR1_PM_MULTI_ADDR (0x1C)
#define MCF5206_UART_UMR1_PM_MULTI_DATA (0x18)
#define MCF5206_UART_UMR1_PM_NONE       (0x10)
#define MCF5206_UART_UMR1_PM_FORCE_HI   (0x0C)
#define MCF5206_UART_UMR1_PM_FORCE_LO   (0x08)
#define MCF5206_UART_UMR1_PM_ODD            (0x04)
#define MCF5206_UART_UMR1_PM_EVEN       (0x00)
#define MCF5206_UART_UMR1_BC_5          (0x00)
#define MCF5206_UART_UMR1_BC_6          (0x01)
#define MCF5206_UART_UMR1_BC_7          (0x02)
#define MCF5206_UART_UMR1_BC_8          (0x03)

#define MCF5206_UART_UMR2_CM_NORMAL         (0x00)
#define MCF5206_UART_UMR2_CM_ECHO           (0x40)
#define MCF5206_UART_UMR2_CM_LOCAL_LOOP     (0x80)
#define MCF5206_UART_UMR2_CM_REMOTE_LOOP    (0xC0)
#define MCF5206_UART_UMR2_TXRTS             (0x20)
#define MCF5206_UART_UMR2_TXCTS             (0x10)
#define MCF5206_UART_UMR2_STOP_BITS_1       (0x07)
#define MCF5206_UART_UMR2_STOP_BITS_15      (0x08)
#define MCF5206_UART_UMR2_STOP_BITS_2       (0x0F)

#define MCF5206_UART_USR_RB             (0x80)
#define MCF5206_UART_USR_FE             (0x40)
#define MCF5206_UART_USR_PE             (0x20)
#define MCF5206_UART_USR_OE             (0x10)
#define MCF5206_UART_USR_TXEMP          (0x08)
#define MCF5206_UART_USR_TXRDY          (0x04)
#define MCF5206_UART_USR_FFULL          (0x02)
#define MCF5206_UART_USR_RXRDY          (0x01)

#define MCF5206_UART_UCSR_9600_BPS      (0xBB)
#define MCF5206_UART_UCSR_19200_BPS     (0xCC)

#define MCF5206_UART_UCR_NONE           (0x00)
#define MCF5206_UART_UCR_STOP_BREAK     (0x70)
#define MCF5206_UART_UCR_START_BREAK    (0x60)
#define MCF5206_UART_UCR_RESET_BKCHGINT (0x50)
#define MCF5206_UART_UCR_RESET_ERROR    (0x40)
#define MCF5206_UART_UCR_RESET_TX       (0x30)
#define MCF5206_UART_UCR_RESET_RX       (0x20)
#define MCF5206_UART_UCR_RESET_MR       (0x10)
#define MCF5206_UART_UCR_TX_DISABLED    (0x08)
#define MCF5206_UART_UCR_TX_ENABLED     (0x04)
#define MCF5206_UART_UCR_RX_DISABLED    (0x02)
#define MCF5206_UART_UCR_RX_ENABLED     (0x01)

#define MCF5206_UART_UIPCR_COS          (0x10)
#define MCF5206_UART_UIPCR_CTS          (0x01)

#define MCF5206_UART_UACR_BRG           (0x80)
#define MCF5206_UART_UACR_CTMS_TIMER    (0x60)
#define MCF5206_UART_UACR_IEC           (0x01)

#define MCF5206_UART_UISR_COS           (0x80)
#define MCF5206_UART_UISR_DB            (0x04)
#define MCF5206_UART_UISR_RXRDY         (0x02)
#define MCF5206_UART_UISR_TXRDY         (0x01)

#define MCF5206_UART_UIMR_COS           (0x80)
#define MCF5206_UART_UIMR_DB            (0x04)
#define MCF5206_UART_UIMR_FFULL         (0x02)
#define MCF5206_UART_UIMR_TXRDY         (0x01)

typedef volatile struct
{
    NATURAL8    reserved1[0x1E0];
    NATURAL8    MADR;
    NATURAL8    reserved2;
    NATURAL8    reserved3;
    NATURAL8    reserved4;
    NATURAL8    MFDR;
    NATURAL8    reserved5;
    NATURAL8    reserved6;
    NATURAL8    reserved7;
    NATURAL8    MBCR;
    NATURAL8    reserved8;
    NATURAL8    reserved9;
    NATURAL8    reserved10;
    NATURAL8    MBSR;
    NATURAL8    reserved11;
    NATURAL8    reserved12;
    NATURAL8    reserved13;
    NATURAL8    MBDR;
} MCF5206_MBUS;

#define MCF5206_MBUS_MADR_ADDR(a)   ((a)&0xFE)

#define MCF5206_MBUS_MFDR_MBC(a)    ((a)&0x3F)

#define MCF5206_MBUS_MBCR_MEN       (0x80)
#define MCF5206_MBUS_MBCR_MIEN      (0x40)
#define MCF5206_MBUS_MBCR_MSTA      (0x20)
#define MCF5206_MBUS_MBCR_MTX       (0x10)
#define MCF5206_MBUS_MBCR_TXAK      (0x08)
#define MCF5206_MBUS_MBCR_RSTA      (0x04)

#define MCF5206_MBUS_MBSR_MCF       (0x80)
#define MCF5206_MBUS_MBSR_MAAS      (0x40)
#define MCF5206_MBUS_MBSR_MBB       (0x20)
#define MCF5206_MBUS_MBSR_MAL       (0x10)
#define MCF5206_MBUS_MBSR_SRW       (0x04)
#define MCF5206_MBUS_MBSR_MIF       (0x02)
#define MCF5206_MBUS_MBSR_RXAK      (0x01)

/* Here we put the modules together.  An example access for the UART mode
 * register would be: (assuming we have a pointer to the IMM):
 *                       imm->uart1.UMR
 */
typedef volatile union
{
    MCF5206_SIM     sim;
    MCF5206_GPIO    gpio;
    MCF5206_UART1   uart1;
    MCF5206_UART2   uart2;
    MCF5206_TIMER   timer;
    MCF5206_CS      cs;
    MCF5206_DRAMC   dramc;
    MCF5206_MBUS    mbus;
} MCF5206_IMM;

#define IMM ((MCF5206_IMM *)(0xf0000000))

/* Function prototypes */
void
mcf5206_write_cacr (NATURAL32);

void
mcf5206_write_acr0 (NATURAL32);

void
mcf5206_write_acr1 (NATURAL32);

void
mcf5206_write_vbr (NATURAL32);

void
mcf5206_write_srambar (NATURAL32);

void
mcf5206_write_mbar (NATURAL32);
