#define SR_TRACE    0x8000
#define SR_SUPER    0x2000

#define MONARGV0    "monCF"

#define VECTOR(v)   (*(ulong *)((v)*4))

#define JUMPTOSTART()   asm("   jmp coldstart")

#define EXCEPTION   1
#define BREAKPOINT  2
#define INITIALIZE  3
#define SSTEP       4
#define APPLICATION 5
#define MORESTART   6
#define BAILOUT     7
#define MISC        8
#define APP_EXIT    9

#define MONITOR_STATUS      0x2700

/* This size is dependent on the amount of memory on the board... */
#define SUPERVISOR_STACK    0x3fff0
#define USER_STACK      0x3fff0
#define RESET           (FLASH_BANK0_BASE_ADDR+0x4)
#define memcpyL         memcpy

/* LOOPS_PER_SECOND:
   Approximately the size of a loop that will cause a 1-second delay.
*/
#define LOOPS_PER_SECOND    45000
