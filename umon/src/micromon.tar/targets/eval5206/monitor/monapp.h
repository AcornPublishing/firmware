/* This header file is used by both the application and the monitor.
   It is the linkage used to establish a communication path between the 
   monitor and the application.
*/

#define STD_CMD     0
#define SU_CMD      1

struct  monCommand {            /* Monitor's command table structure */
    char    *name;          /* Name of command seen by user. */
    int     (*func)();      /* Function called when command is invoked. */
    char    **helptxt;      /* Help text. */
};

#define MONVEC 255
#define GLOBALINTBASE 99

#define CMDLINESIZE 128
#define ARGCNT      24
