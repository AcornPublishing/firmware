#define DEFAULT_BAUD_RATE   9600

extern unsigned char   in8(unsigned int);
extern void            out8(unsigned int, unsigned char value);
extern unsigned short  in16(unsigned int);
extern void            out16(unsigned int, unsigned short value);
extern unsigned long   in32(unsigned int);
extern void            out32(unsigned int, unsigned long value);
extern unsigned short  in16r(unsigned int);
extern void            out16r(unsigned int, unsigned short value);
extern unsigned long   in32r(unsigned int);
extern void            out32r(unsigned int, unsigned long value);

extern void dcache_flush(void *address, unsigned int count);
extern void dcache_invalidate(void *address, unsigned int count);

extern void ppcAbend(void);
extern void ppcDcbi(void *addr);
extern void ppcDcbf(void *addr);
extern void ppcDcbst(void *addr);
extern void ppcDcbz(void *addr);
extern void ppcHalt(void);
extern void ppcIcbi(void *addr);
extern void ppcIsync(void);
extern void ppcSync(void);
extern unsigned long ppcAndMsr(unsigned long value);
extern unsigned long ppcCntlzw(unsigned long value);
extern unsigned long ppcMfgpr1(void);
extern unsigned long ppcMfgpr2(void);
extern unsigned long ppcMfmsr(void);
extern unsigned long ppcMfsprg0(void);
extern unsigned long ppcMfsprg1(void);
extern unsigned long ppcMfsprg2(void);
extern unsigned long ppcMfsprg3(void);
extern unsigned long ppcMfsrr0(void);
extern unsigned long ppcMfsrr1(void);
extern unsigned long ppcMfpvr(void);
extern unsigned long ppcMfdccr(void);
extern unsigned long ppcMficcr(void);
extern unsigned long ppcMfevpr(void);
extern void ppcMftb();
extern void ppcMttb();
extern void ppcMtmsr(unsigned long msr_value);
extern void ppcMtsprg0(unsigned long sprg_value);
extern void ppcMtsprg1(unsigned long sprg_value);
extern void ppcMtsprg2(unsigned long sprg_value);
extern void ppcMtsprg3(unsigned long sprg_value);
extern void ppcMtsrr0(unsigned long srr0_value);
extern void ppcMtsrr1(unsigned long srr1_value);
extern unsigned long ppcOrMsr(unsigned long value);
extern void OcmDataConfig(unsigned long);
extern void ledToggle(void);
extern void pioset(char,int);
extern void pioclr(char,int);

#define GPIO0_OR                0xEF600700  /* GPIO output */
#define GPIO0_TCR               0xEF600704  /* GPIO 3-state ctrl */
#define GPIO0_ODR               0xEF600718  /* GPIO open drain */
#define GPIO0_IR                0xEF60071c  /* GPIO input */

/* GPIO-specific bits in CCR0: */
#define TRE     0x08000000
#define G10E    0x04000000
#define G11E    0x02000000
#define G12E    0x01000000
#define G13E    0x00800000
#define G14E    0x00400000
#define G15E    0x00200000
#define G16E    0x00100000
#define G17E    0x00080000
#define G18E    0x00040000
#define G19E    0x00020000
#define G20E    0x00010000
#define G21E    0x00008000
#define G22E    0x00004000
#define G23E    0x00002000

/* PIO-bit positions */
#define PIO1    0x40000000
#define PIO2    0x20000000
#define PIO3    0x10000000
#define PIO4    0x08000000
#define PIO5    0x04000000
#define PIO6    0x02000000
#define PIO7    0x01000000
#define PIO8    0x00800000
#define PIO9    0x00400000
#define PIO10   0x00200000
#define PIO11   0x00100000
#define PIO12   0x00080000
#define PIO13   0x00040000
#define PIO14   0x00020000
#define PIO15   0x00010000
#define PIO16   0x00008000
#define PIO17   0x00004000
#define PIO18   0x00002000
#define PIO19   0x00001000
#define PIO20   0x00000800
#define PIO21   0x00000400
#define PIO22   0x00000200
#define PIO23   0x00000100

/* Target-specific names... */
/* Bit position: */
#define REDLED_BIT  PIO9
#define ISPTDI_BIT  PIO8
#define ISPTMS_BIT  PIO7
#define ISPTCK_BIT  PIO6
#define ISPTDO_BIT  PIO5
#define WDI_BIT     PIO4
#define BRDID2_BIT  PIO3
#define BRDID1_BIT  PIO2
#define BRDID0_BIT  PIO1

/* Bit number: */
#define REDLED  9
#define ISPTDI  8
#define ISPTMS  7
#define ISPTCK  6
#define ISPTDO  5
#define WDI     4
#define BRDID2  3
#define BRDID1  2
#define BRDID0  1
