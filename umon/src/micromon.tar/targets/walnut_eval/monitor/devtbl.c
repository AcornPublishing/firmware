#include "devices.h"
#include "devtbl.h"

/* device table:
    This table should contain all of the device driver functions
    (cntrl/open/close/read/write) for each device in the system.
    This allows all devices to be accessed through read/write/ioctl
    functions; thus, making the application code somewhat independent
    of the underlying hardware.  This scheme is taken from XINU.
*/

struct device devtbl[] = {
 
    { tty0init, tty0ctrl, nodriver, nodriver,       /* TTY0 */
        tty0read,   tty0write, "PPC403_UARTA" },

    { tty1init, tty1ctrl,   nodriver,   nodriver,       /* TTY1 */
        tty1read,   tty1write, "PPC403_UARTB" },

    { 0,0,0,0,0,0,(char *)0 }
};
