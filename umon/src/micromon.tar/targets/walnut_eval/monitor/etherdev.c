/*
 * This source code has been made available to you by IBM on an AS-IS
 * basis.  Anyone receiving this source is licensed under IBM
 * copyrights to use it in any way he or she deems fit, including
 * copying it, modifying it, compiling it, and redistributing it either
 * with or without modifications.  No license under IBM patents or
 * patent applications is to be implied by the copyright license.
 *
 * Any user of this software should understand that IBM cannot provide
 * technical support for this software and will not be responsible for
 * any consequences resulting from the use of this software.
 *
 * Any person who transfers this source code or any derivative work
 * must include the IBM copyright notice, this paragraph, and the
 * preceding two paragraphs in the transferred software.
 *
 * COPYRIGHT   I B M   CORPORATION 1995
 * LICENSED MATERIAL  -  PROGRAM PROPERTY OF I B M
 *
 *  File Name:  etherdev.c (originally enetemac.c)
 *
 *  Function:   Device driver for the ethernet EMAC3 macro on the 405GP.
 *
 *  Author:     Mark Wisner
 *
 *  Change Activity-
 *
 *  Date        Description of Change                                      BY
 *  ---------   ---------------------
 *  05-May-99   Created                                                    MKW
 *  27-Jun-99   Clean up                                                   JWB
 *  16-Jul-99   Added MAL error recovery and better IP packet              MKW
                handling.
 *  29-Jul-99   Added Full duplex support                                  MKW
 *  06-Aug-99   Changed names for Mal CR reg                               MKW
 *  23-Aug-99   Turned off SYE when running at 10Mbs                       MKW
 *  24-Aug-99   Marked descriptor empty after call_xlc                     MKW
 *  07-Sep-99   Set MAL RX buffer size reg to ENET_MAX_MTU_ALIGNED / 16    MCG
 *              to avoid chaining maximum sized packets. Push starting
 *              RX descriptor address up to the next cache line boundary.
 *  19-Apr-00   Integrated enetemac.c (now etherdev.c) into MicroMonitor   ELS
 *              platform. Changed some register names to match the names
 *              used in the manual.
 *  26-Sep-00   Added PHY interface, auto-negotiation, and selftest.       ELS
 *              Also fixed a bug where the descriptor tables must start
 *              on an 8-byte boundary.
 *
 * General notice:
 * This code is part of a boot-monitor package developed as a generic base
 * platform for embedded system designs.  As such, it is likely to be
 * distributed to various projects beyond the control of the original
 * author.  Please notify the author of any enhancements made or bugs found
 * so that all may benefit from the changes.  In addition, notification back
 * to the author will allow the new user to pick up changes that may have
 * been made by other users after this version of the code was distributed.
 *
 * Author:  Ed Sutter
 * email:   esutter@lucent.com      (home: lesutter@worldnet.att.net)
 * phone:   908-582-2351            (home: 908-889-5161)
 *
 */

#include "config.h"
#include "genlib.h"
#include "stddefs.h"
#include "enetemac.h"
#include "cpuio.h"
#include "phy.h"
#include "ppcmal.h"
#include "ppcuic.h"
#include "ether.h"

#if INCLUDE_ETHERNET

/* defines for EtherSpeed status */
#define Is10BaseT       0x1
#define Is100BaseT      0x2
#define IsFullDuplex    0x4
#define AutoNeg         0x8
#define AutoNegFailed   0x10

/* Defines for number of buffers.  */
#define NUM_TX_BUFF 1
#define NUM_RX_BUFF 10

/* define the number of channels implemented */
#define EMAC_RXCHL      1
#define EMAC_TXCHL      1

/* definitions used to check link status */
#define LINK_NULL       0
#define LINK_UP         1
#define LINK_DOWN       2

/* Global variables. TX and RX descriptors and buffers.  */
static mal_desc_t *tx;
static mal_desc_t *rx;
static mal_desc_t tx_desctbl[NUM_TX_BUFF+2];
static mal_desc_t rx_desctbl[NUM_RX_BUFF+2];
static struct memblock *tx_buff;
static struct memblock *rx_buff;
static ulong xmit_buffer[(400*NUM_TX_BUFF)];
static ulong recv_buffer[(400*NUM_RX_BUFF)];

static int rx_slot;                 /* MAL Receive Slot */
static int rx_ready[NUM_RX_BUFF];   /* Receive Ready Queue */
static int tx_slot;                 /* MAL Transmit Slot */
static int tx_run[NUM_TX_BUFF];     /* Transmit Running Queue */

static ulong EtherSpeed;

/*
 * enreset():
 *  Reset the ethernet-related hardware.
 */
void
enreset(void)
{
    volatile int delay;

    /* PHY reset */
    phy_reset();

    /* MAL reset */
    ppcMtmalcr(MAL_CR_MMSR);

    /* Disable MAL interrupts: */
    ppcMtmalier(0);

    /* EMAC reset */
    *(ulong *)(EM0MR0) = EM0MR0_SRST;
    for (delay=0;delay<1000;delay++);
    *(ulong *)(EM0MR0) = *(ulong *)(EM0MR0) & ~EM0MR0_SRST;

    /* Disable EMAC interrupts: */
    *(ulong *)(EMAC_IER) = 0;
}

/*
 * eninit() - Initialize the Mal and the Emac macros.
 */
int
eninit(void)
{
    int     i;
    char    *p;
    ulong   reg, emac_ier;
    unsigned mode_reg;

    rx_slot = 0;                /* MAL Receive Slot */
    tx_slot = 0;                /* MAL Transmit Slot */

    /* The descriptor tables must be aligned on an 8-byte boundary
     * (least significant 3 bits must be 0).
     */
    tx = (mal_desc_t *)((ulong)(&tx_desctbl[1]) & 0xfffffff8);
    rx = (mal_desc_t *)((ulong)(&rx_desctbl[1]) & 0xfffffff8);

    /* Set MAL configuration reg:
     *  - Burst transactions enabled;
     *  - Lock OPB during xfers to/from the EMAC;
     *  - Handle errors in locked mode;
     */
    ppcMtmalcr(MAL_CR_PLBB|MAL_CR_OPBBL|MAL_CR_LEA|MAL_CR_PLBLT_DEFAULT);

    /* Set up the TX and RX descriptors */
    tx_buff = (struct memblock *)xmit_buffer;
    rx_buff = (struct memblock *)recv_buffer;

    for (i=0;i<NUM_TX_BUFF;i++) {
        tx[i].ctrl = 0;
        tx[i].data_len = 0;
        tx[i].data_ptr = (char *) &tx_buff[i];
        if ((NUM_TX_BUFF - 1) == i)
            tx[i].ctrl |= MAL_TX_CTRL_WRAP;
        tx_run[i] = -1;
    }

    for (i=0;i<NUM_RX_BUFF;i++) {
        rx[i].ctrl = 0;
        rx[i].data_len = 0;
        rx[i].data_ptr = (char *) &rx_buff[i];
        if ((NUM_RX_BUFF - 1) == i)
            rx[i].ctrl |= MAL_RX_CTRL_WRAP;
        rx[i].ctrl |=   MAL_RX_CTRL_EMPTY | MAL_RX_CTRL_INTR;
        rx_ready[i] = -1;
    }

    /* Write the ethernet address (6 bytes) into the EMAC Individual 
     * Address High and Low registers:
     */
    reg = 0;
    reg |= BinEnetAddr[0];
    reg = reg << 8;
    reg |= BinEnetAddr[1];
    *(ulong *)(EM0IAH) = reg;
    reg = 0;
    reg |= BinEnetAddr[2];
    reg = reg << 8;
    reg |= BinEnetAddr[3];
    reg = reg << 8;
    reg |= BinEnetAddr[4];
    reg = reg << 8;
    reg |= BinEnetAddr[5];
    *(ulong *)(EM0IAL) = reg;

    /* Setup MAL tx & rx channel pointers */
    ppcMtmaltxctp0r((int)tx);
    ppcMtmalrxctp0r((int)rx);

    /* Reset transmit and receive channels */
    ppcMtmalrxcarr(0x80000000);     /* 2 channels */
    ppcMtmaltxcarr(0x80000000);     /* 2 channels */

    /* Enable MAL transmit and receive channels */
    ppcMtmaltxcasr(0x80000000);     /* 1 channel */
    ppcMtmalrxcasr(0x80000000);     /* 1 channel */

    /* Set RX buffer size */
    ppcMtmalrcbs0(ENET_MAX_MTU_ALIGNED / 16);

    /* Set transmit enable & receive enable */
    *(ulong *)(EM0MR0) = (EM0MR0_TXE | EM0MR0_RXE);

    /* Set receive fifo to 4k and tx fifo to 2k */
    mode_reg = EM0MR1_RFS_4K | EM0MR1_TX_FIFO_2K;

    /* Set speed based on content of ETHERSPEED shell variable... */
    if ((p = getenv("ETHERSPEED")) == 0) {
        EtherSpeed = Is10BaseT;
        phy_write(PHY_BMCR,PHY_BMCR_10MB);
    } else {
        if(!strcmp(p, "10")) {
            EtherSpeed = Is10BaseT;
            phy_write(PHY_BMCR,PHY_BMCR_10MB);
        } else if(!strcmp(p, "100")) {
            EtherSpeed = Is100BaseT;
            phy_write(PHY_BMCR,PHY_BMCR_100MB);
        } else if(!strcmp(p, "10FULL")) {
            EtherSpeed = Is10BaseT | IsFullDuplex;
            phy_write(PHY_BMCR,PHY_BMCR_10MB | PHY_BMCR_FDPLX);
        } else if(!strcmp(p, "100FULL")) {
            EtherSpeed = Is100BaseT | IsFullDuplex;
            phy_write(PHY_BMCR,PHY_BMCR_100MB | PHY_BMCR_FDPLX);
        } else if (!strcmp(p, "AUTO")) {
            int is100BaseT, isFullDuplex;

            EtherSpeed = AutoNeg;
            isFullDuplex = is100BaseT = 1;
            if (phy_autoneg(0, &is100BaseT, &isFullDuplex)) {
                printf("Ethernet auto negotiate failed, ");
                printf("defaulting to 10BaseT half duplex.\n");
                EtherSpeed = AutoNegFailed | Is10BaseT;
                phy_write(PHY_BMCR,PHY_BMCR_10MB);
            } else {
                if(isFullDuplex && is100BaseT) {
                    EtherSpeed = Is100BaseT | IsFullDuplex;
                }
                else if(!isFullDuplex && is100BaseT) {
                    EtherSpeed = Is100BaseT;
                }
                else if(!isFullDuplex && !is100BaseT) {
                    EtherSpeed = Is10BaseT;
                }
                else if(isFullDuplex && is100BaseT) {
                    EtherSpeed = Is10BaseT | IsFullDuplex;
                }
            }
        } else {
            printf("ETHERSPEED not valid, defaulting to 10BaseT half duplex\n");
            EtherSpeed |= Is10BaseT;
            phy_write(PHY_BMCR,PHY_BMCR_10MB);
        }
    }

    if (EtherSpeed & Is100BaseT)
        mode_reg |= EM0MR1_MF_100MBPS;
    else
        mode_reg &= ~EM0MR1_MF_SPEED;   /* 10 MBPS */

    if(EtherSpeed & IsFullDuplex)
        mode_reg |= EM0MR1_FDE;

    /* Load EM0MR1: */
    *(ulong *)(EM0MR1) = mode_reg;

    /* Configure receive mode:
     *  - Accept broadcast addresses;
     *  - Accept individual address;
     *  - Allow runt packets (< 64 bytes);
     *  - Strip Frame Check Sequence and padding;
     */
    *(ulong *)(EM0RMR) = 
        (EMAC_RMR_BAE|EMAC_RMR_IAE|EMAC_RMR_ARRP|EMAC_RMR_SFCS|EMAC_RMR_SP);

    /* we probably need to set the tx mode1 reg? maybe at tx time */

    /* set transmit request threshold register */
    *(ulong *)(EMAC_TRTR) = 0x18000000; /* 256 byte threshold */

    /* set recieve  low/high water mark register */
    *(ulong *)(EMAC_RX_HI_LO_WMARK) = 0x0f002000;

    /* Frame gap set */
    *(ulong *)(EMAC_I_FRAME_GAP_REG) = 0x00000008;

    ppcMtmalier(MAL_IER_DE | MAL_IER_NE | MAL_IER_TE |
        MAL_IER_OPBE | MAL_IER_PLBE);

    emac_ier = EMAC_ISR_PTLE | EMAC_ISR_BFCS |
        EMAC_ISR_ORE | EMAC_ISR_IRE;

    if (EtherSpeed & Is100BaseT)
        emac_ier |= EMAC_ISR_SYE;

    *(ulong *)(EMAC_IER) = emac_ier;


    return (0);
}

int
EtherdevStartup(int verbose)
{
    /* Initialize local device error counts here. */

    /* Put ethernet controller in reset: */
    enreset();

    /* Initialize controller: */
    eninit();

    return(0);
}

void
disablePromiscuousReception(void)
{
    *(ulong *)(EM0RMR) = *(ulong *)(EM0RMR) & ~EMAC_RMR_PME;
}

void
enablePromiscuousReception(void)
{
    *(ulong *)(EM0RMR) = *(ulong *)(EM0RMR) | EMAC_RMR_PME;
}

void
disableBroadcastReception(void)
{
    *(ulong *)(EM0RMR) = *(ulong *)(EM0RMR) & ~EMAC_RMR_BAE;
}

void
enableBroadcastReception(void)
{
    *(ulong *)(EM0RMR) = *(ulong *)(EM0RMR) | EMAC_RMR_BAE;
}

/* 
 * enselftest():
 *  Do a simple read of the PHY ID register and verify that it is
 *  as expected.  Then put the PHY in loopback and verify that what
 *  is transmitted is what is received.
 *  Return 1 if passed, else -1.
 */
int
enselftest(int verbose)
{
    int     retval, timeout;
    uchar   *msg;
    ushort id1, id2;
    ulong mal_rx_eob, len;
    static uchar testmsg[] = 
        { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
          0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
          0x08, 0x00, 't', 'e', 's', 't' };

    
    retval = 1;
    if (verbose)
        printf("Self test ");

    /* First read the PHY ID registers and verify valid device ID.
     */
    phy_read(PHY_ID1,&id1);
    phy_read(PHY_ID2,&id2);
    if ((((ulong)id1 << 16) | (ulong)id2) != 0x20005c10) {
        if (verbose)
            printf("phy-id failed (%04x%04x)\n",id1,id2);
        retval = -1;
        goto done;
    }

    /* Next, put the PHY in loopback and send a packet to see if we receive
     * what we transmit...
     */
    phy_write(PHY_BMCR,PHY_BMCR_LOOP);
    msg = getXmitBuffer();
    memcpy(msg,testmsg,sizeof(testmsg));
    sendBuffer(sizeof(testmsg));

    /* Wait for the looped back message... */
    for(timeout=20000000;timeout > 0;timeout--) {
        mal_rx_eob = ppcMfmalrxeobisr();
        if ((mal_rx_eob & 0x80000000) == 0x80000000)
            break;
    }
    if (timeout == 0)
        goto failed;

    len = (ulong) rx[rx_slot].data_len;  /* Get len */
    ppcMtmalrxeobisr(mal_rx_eob);
    rx[rx_slot].ctrl |= MAL_RX_CTRL_EMPTY; 
    ppcMtmalrxeobisr(mal_rx_eob);
    if (!memcmp(rx[rx_slot].data_ptr,testmsg,len)) {
failed:
        if (verbose)
            printf("lbk failed\n");
        retval = -1;
        goto done;
    }

    if (verbose)
        printf("passed\n");

    /* Put things back to normal... */
done:
    enreset();
    eninit();
    return(retval);
}

void
ShowEtherdevStats(void)
{
    printf("Interface speed is %d Mbs, %s duplex.\n",
        EtherSpeed & Is100BaseT ? 100 : 10,
        EtherSpeed & IsFullDuplex ? "full" : "half");
#if 0
    printf(" EMAC DEBUG...\n");
    printf(" EM0MR0:    %lx \n", *(ulong *)(EM0MR0));
    printf(" EM0MR1:    %lx \n", *(ulong *)(EM0MR1));
    printf(" EMAC_TXM0: %lx \n", *(ulong *)(EMAC_TXM0));
    printf(" EMAC_TXM1: %lx \n", *(ulong *)(EMAC_TXM1));
    printf(" EM0RMR:    %lx \n", *(ulong *)(EM0RMR));
    printf(" EMAC_ISR:  %lx \n", *(ulong *)(EMAC_ISR));
    printf(" EMAC_IER:  %lx \n", *(ulong *)(EMAC_IER));
    printf(" EM0IAH:    %lx \n", *(ulong *)(EM0IAH));
    printf(" EM0IAL:    %lx \n", *(ulong *)(EM0IAL));
    printf(" EMAC_VLAN_TPID_REG: %lx \n", *(ulong *)(EMAC_VLAN_TPID_REG));
    printf(" MAL DEBUG...\n");
    printf(" MCR:      %lx\n", ppcMfmalcr());
    printf(" ESR:      %lx\n", ppcMfmalesr());
    printf(" IER:      %lx\n", ppcMfmalier());
    printf(" DBR:      %lx\n", ppcMfmaldbr());
    printf(" TXCASR:   %lx\n", ppcMfmaltxcasr());
    printf(" TXCARR:   %lx\n", ppcMfmaltxcarr());
    printf(" TXEOBISR: %lx\n", ppcMfmaltxeobisr());
    printf(" TXDEIR:   %lx\n", ppcMfmaltxdeir());
    printf(" RXCASR:   %lx\n", ppcMfmalrxcasr());
    printf(" RXCARR:   %lx\n", ppcMfmalrxcarr());
    printf(" RXEOBISR: %lx\n", ppcMfmalrxeobisr());
    printf(" RXDEIR:   %lx\n", ppcMfmalrxdeir());
    printf(" TXCTP0R:  %lx\n", ppcMfmaltxctp0r());
    printf(" TXCTP1R:  %lx\n", ppcMfmaltxctp1r());
    printf(" RXCTP0R:  %lx\n", ppcMfmalrxctp0r());
    printf(" RCBS0:    %lx\n", ppcMfmalrcbs0());
#endif
}

uchar *
getXmitBuffer(void)
{
    return((uchar *)tx_buff);
}

int
sendBuffer(int length)
{
    int timeout;

    if (EtherVerbose &  SHOW_OUTGOING)
        printPkt((struct ether_header *)tx_buff,length,ETHER_OUTGOING);

    if (length > ENET_MAX_MTU)
        length = ENET_MAX_MTU;
    if (length < ETHER_MINPKT)
        length = ETHER_MINPKT;

    /* set TX Buffer busy, and send it */
    tx[0].ctrl = (MAL_TX_CTRL_LAST | EMAC_TX_CTRL_GFCS | EMAC_TX_CTRL_GP) &
        ~(EMAC_TX_CTRL_ISA | EMAC_TX_CTRL_RSA);
    if ((NUM_TX_BUFF - 1) == tx_slot)
        tx[0].ctrl |= MAL_TX_CTRL_WRAP;

    tx[0].data_len = (short)length;
    tx[0].ctrl |= MAL_TX_CTRL_READY;

    *(ulong *)(EMAC_TXM0) = *(ulong *)(EMAC_TXM0) | EMAC_TXM0_GNP0;

    /* Poll unitl the packet is sent */
    timeout = 0;
    while (*(ulong *)(EMAC_TXM0) & EMAC_TXM0_GNP0) {
        if (++timeout == LoopsPerSecond) { 
            printf("sendBuffer(): poll giving up\n");
            break;
        }
    }
    EtherXFRAMECnt++;
    return(0);
}

void
enresetmmu(void)
{
}

void
DisableEtherdev(void)
{
    enreset();
}

char *
extGetIpAdd(void)
{
    return((char *)0);
}

char *
extGetEtherAdd(void)
{
    return((char *)0);
}

/*
 * polletherdev():
 * Called continuously by the monitor to determine if there is any incoming
 * ethernet packets.
 */
int
polletherdev(void)
{
    int pktcnt, i;
    ulong mal_rx_eob, mal_esr, len;

#if MONITOR_LINK
    static int linkstate;

    if (!phy_linkup()) {
        if (linkstate == LINK_UP) {
            printf("Ethernet link down\n");
            linkstate = LINK_DOWN;
        }
    }
    else {
        if (linkstate == LINK_DOWN)
            printf("Ethernet link up\n");
        linkstate = LINK_UP;
    }
#endif

    /* If ANY error status is set, just reset here... */
    mal_esr = ppcMfmalesr();
    if (mal_esr & MAL_ESR_ANY) {
        enreset();
        eninit();
        return(0);
    }

    pktcnt = 0;
    mal_rx_eob = ppcMfmalrxeobisr();
    if (mal_rx_eob & 0x80000000) {
        while(1) {
            i = rx_slot;
        
            if (rx[i].ctrl & MAL_RX_CTRL_EMPTY)
                break;
    
            rx_slot++;
            if (rx_slot == NUM_RX_BUFF)
                rx_slot = 0;
            len = (ulong) rx[i].data_len;  /* Get len */
            if (len) {
                if ((len > ENET_MAX_MTU) || (EMAC_RX_ERRORS & rx[i].ctrl))
                    len = 0;
                else {
                    pktcnt++;
                    EtherRFRAMECnt++;
                    processPACKET((struct ether_header *)rx[i].data_ptr,
                        len);
                }
            }
    
            /* Free the receive buffer. */
            rx[i].ctrl |= MAL_RX_CTRL_EMPTY; 
        }
        /* clear EOB */
        ppcMtmalrxeobisr(mal_rx_eob);
    }
    return(pktcnt);
}

#endif
