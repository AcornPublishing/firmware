/* main.c:
 *
 * General notice:
 * This code is part of a boot-monitor package developed as a generic base
 * platform for embedded system designs.  As such, it is likely to be
 * distributed to various projects beyond the control of the original
 * author.  Please notify the author of any enhancements made or bugs found
 * so that all may benefit from the changes.  In addition, notification back
 * to the author will allow the new user to pick up changes that may have
 * been made by other users after this version of the code was distributed.
 *
 * Author:  Ed Sutter
 * email:   esutter@lucent.com      (home: lesutter@worldnet.att.net)
 * phone:   908-582-2351            (home: 908-889-5161)
 *
 */
#include "config.h"
#include "cpu.h"
#include "tfs.h"
#include "tfsprivate.h"
#include "genlib.h"
#include "ether.h"
#include "monflags.h"
#include "stddefs.h"

ulong   Sys_clock_period, Ticks_per_sec;
int     StateOfMonitor, AppExitStatus;
void    init2(), reinit();

int
main(int argc,char *argv[])
{
    char    ename[48];

    /* Set user level to its max, then allow monrc file to adjust it. */
    initUsrLvl(MAXUSRLEVEL);

    if (StateOfMonitor == INITIALIZE) {
        reginit();      /* Init register data structures. */
        init2();        /* Second phase of hardware initialization. */
        init3();        /* Common system initialization stuff. */
    }

    switch(StateOfMonitor) {
    case INITIALIZE:
        break;
    case MISC:
    case SSTEP:
    case BAILOUT:
    case MORESTART:
    case BREAKPOINT:
#if INCLUDE_DEBUG
        regbackup();
#endif
        break;
    case APP_EXIT:
        reinit();
        printf("\nApplication Exit Status: %d (0x%x)\n",
            AppExitStatus,AppExitStatus);
        break;
    case EXCEPTION:
        reinit();
        printf("\nEXCEPTION: '%s'\n",ExceptionType2String(ExceptionType));
        printf("           Occurred near 0x%lx",ExceptionAddr);
        if (AddrToSym(-1,ExceptionAddr,ename,0))
            printf(" (within %s)",ename);
        printf("\n\n");
        exceptionAutoRestart(INITIALIZE);
        break;
    default:
        printf("Unexpected monitor state: 0x%x\n",StateOfMonitor);
        break;
    }   /* end switch StateOfMonitor */

    /* Enter the endless loop of command processing: */
    CommandLoop();

    /* Should not get here */
    return(0);
}

void
reinit()
{
    init1(0);       /* reinit hdware */
    init2();
#if INCLUDE_ETHERNET
    EthernetStartup(0,0);   /* reinit ethernet */
#endif
}

void
init2()
{
#if INCLUDE_FLASH
    FlashInit();        /* Init flashop data structures.  This MUST be */
                        /* done prior to turning on cache!!! */
#endif

    cacheInit();        /* Initialize cache. */

#if INCLUDE_ETHERNET
    enreset();          /* Clear the ethernet interface. */
#endif
#if INCLUDE_TFS
    tfsstartup();       /* Init tfs data structures. */
#endif
}

void
monrestart(int val)
{
    warmstart(val);
}

void
intsrestore(msr)
ulong     msr;
{
    return;
}

ulong
intsoff()
{
    return(0);
}

/* some stubs for now... */
void
ctxMON()
{
}

void
ctxAPP()
{
}

void
not_used()
{
    printf("WARNING: jump table entry not used\n");
}

void
appexit(val)
int val;
{
    intsoff();
    AppExitStatus = val;
#if INCLUDE_DEBUG
    removeatpoints();
#endif
    warmstart(APP_EXIT);
}

int
monState()
{
    return(StateOfMonitor);
}

/* tolower():
 * If arg is upper-case, return the lower-case, else return the arg.
 */
int
tolower(c)
register int c;
{
    if(c >= 'A' && c <= 'Z') {
    c -= 'A' - 'a';
    }
    return(c);
}

/* toupper():
 * If arg is lower-case, return upper-case, otherwise return arg.
 */
int
toupper(c)
register int c;
{
    if(c >= 'a' && c <= 'z') {
    c += 'A' - 'a';
    }
    return(c);
}

void
cacheInitForTarget()
{
    extern  void ppcMticcr();

    ppcMticcr(0x80000001);
}

/* extValidPassword():
    Refer to validPassword() in common/password.c for notes.
*/
int
extValidPassword(char *password, int ulvl)
{
    return(-1);
}
