/* ioLib/dcache.c, os_open_spru_iolib, osop_6m_spru 11/5/98 13:13:51 */
/*-----------------------------------------------------------------------------+
|
|       This source code has been made available to you by IBM on an AS-IS
|       basis.  Anyone receiving this source is licensed under IBM
|       copyrights to use it in any way he or she deems fit, including
|       copying it, modifying it, compiling it, and redistributing it either
|       with or without modifications.  No license under IBM patents or
|       patent applications is to be implied by the copyright license.
|
|       Any user of this software should understand that IBM cannot provide
|       technical support for this software and will not be responsible for
|       any consequences resulting from the use of this software.
|
|       Any person who transfers this source code or any derivative work
|       must include the IBM copyright notice, this paragraph, and the
|       preceding two paragraphs in the transferred software.
|
|       COPYRIGHT   I B M   CORPORATION 1992, 1996
|       LICENSED MATERIAL  -  PROGRAM PROPERTY OF I B M
+-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------+
|
|  File Name:   dcache.c
|
|  Function:    601 cache operations
|
|  Author:      Alan Booker
|
|  Change Activity-
|
|  Date        Description of Change                                       BY
|  ---------   ---------------------                                       ---
|  25-Aug-93   Created                                                     ajb
|  11-Jun-96   Copied to ZAPVM                                             MKW
|  06-Jul-96   Fixed bug - doing an extra line - fails at high mem         pag
|
+-----------------------------------------------------------------------------*/
extern void ppcDcbf(void *addr);
extern void ppcDcbi(void *addr);
extern void ppcSync(void);


#define SECTOR_SIZE     32      /* 32 byte cache line */
#define SECTOR_MASK 0x1F

/*-----------------------------------------------------------------------------+
| Function:     dcache_flush
|
| Description:  Flush the data cache
|
+-----------------------------------------------------------------------------*/
void dcache_flush(void *address, unsigned int count)
 {
  unsigned int lcl_addr = (unsigned int) address;
  unsigned int lcl_target;

    /* promote to nearest cache sector */
  lcl_target =  (lcl_addr + count + SECTOR_SIZE - 1) & ~SECTOR_MASK;
  lcl_addr &= ~SECTOR_MASK;
  while (lcl_addr != lcl_target)
   {
    ppcDcbf((void *)lcl_addr);
    lcl_addr += SECTOR_SIZE;
   }
   ppcSync();
 }
/*-----------------------------------------------------------------------------+
| Function:     dcache_invalidate
|
| Description:  Invalidate the data cache
|
+-----------------------------------------------------------------------------*/
void dcache_invalidate(void *address, unsigned int count)
 {
  unsigned int lcl_addr = (unsigned int) address;
  unsigned int lcl_target;

    /* promote to nearest cache sector */
  lcl_target =  (lcl_addr + count + SECTOR_SIZE - 1) & ~SECTOR_MASK;
  lcl_addr &= ~SECTOR_MASK;
  while (lcl_addr != lcl_target)
   {
    ppcDcbi((void *)lcl_addr);
    lcl_addr += SECTOR_SIZE;
   }
   ppcSync();
 }
