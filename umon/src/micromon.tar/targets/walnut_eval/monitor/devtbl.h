/* Device names used as their device number or descriptor: 
   NOTE: These entries should start at zero and increment by
    1 for each new device.
*/
#define TTY0        0   /* UARTA internal to the 405 processor */
#define TTY1        1   /* UARTB internal to the 405 processor */

/* Defined number of devices in the system:
   NOTE: This number should match the number of entries in the device
    table (devices.c).
*/
#define DEVTOT      2

/* Declarations for the driver functions for each device: */

/* Device TTY0: */
extern  int tty0init(unsigned long);
extern  int tty0ctrl(int, unsigned long, unsigned long);
extern  int tty0write(char *,int);
extern  int tty0read(char *,int);
extern  int tty1init(unsigned long);
extern  int tty1ctrl(int, unsigned long, unsigned long);
extern  int tty1write(char *,int);
extern  int tty1read(char *,int);
