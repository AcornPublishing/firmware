/* mstat.c:
    The mstat command is provided as a target-specific command for keeping
    track of various monitor-specific stuff... uart baud rate, malloc stats,
    chip-select configuration, etc...

    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com  (home: lesutter@worldnet.att.net)
    phone:  908-582-2351        (home: 908-889-5161)
*/
#include "config.h"
#include "cpu.h"
#include "cpuio.h"
#include "genlib.h"
#include "stddefs.h"

extern  void InitUART(), moreset();

void mstatshow(), SetMonSTATUS(), InitMonSTATUS();

static  ushort  MonitorSTATUS;

char *MstatHelp[] = {
    "Monitor status",
    "-[b:Hhs:]",
    " -b {baud}  set baud rate",
    " -c         dump chip-select info",
    " -s {val}   set monitor state",
    0,
};

int
Mstat(argc,argv)
int argc;
char    *argv[];
{
    extern  void ppcMticcr();
    extern void ConsoleBaudEnvSet(), CSInfo();
    int opt;

    /* If no args, just dump current status. */
    if (argc == 1) {
        mstatshow();
        return(0);
    }

    while ((opt=getopt(argc,argv,"xyb:cs:")) != -1) {
    switch(opt) {
        case 'y':
            break;
        case 'b':
            InitUART(atoi(optarg));
            ConsoleBaudEnvSet();            
            break;
        case 'c':
            CSInfo();
            return(0);
        case 's':
            InitMonSTATUS((ushort)strtol(optarg,0,0));
            break;
        default:
            return(0);
    }
    }
    if (argc != optind)
        return(-1);
    return(0);
}

void
InitMonSTATUS(state)
ulong   state;
{
    MonitorSTATUS = state;
/*    putmsr((ushort)MonitorSTATUS); */
}

void
SetMonSTATUS()
{
/*    putmsr((ushort)MonitorSTATUS); */
}

void
mstatshow()
{
    extern int monState();

    monHeader(0);
    mstatshowcom();
    printf("Current:\n");
    printf(" SP:   0x%08lx\n",ppcMfgpr1());
    printf(" MSR:  0x%08lx\n",ppcMfmsr());
    printf(" DCCR:   0x%08lx\n",ppcMfdccr());
    printf(" ICCR:   0x%08lx\n",ppcMficcr());
    printf(" EVPR:   0x%08lx\n",ppcMfevpr());
    printf("Monitor STATE: %d\n",monState());
}

