/*
 *
 * This source code has been made available to you by IBM on an AS-IS
 * basis.  Anyone receiving this source is licensed under IBM
 * copyrights to use it in any way he or she deems fit, including
 * copying it, modifying it, compiling it, and redistributing it either
 * with or without modifications.  No license under IBM patents or
 * patent applications is to be implied by the copyright license.
 *
 * Any user of this software should understand that IBM cannot provide
 * technical support for this software and will not be responsible for
 * any consequences resulting from the use of this software.
 *
 * Any person who transfers this source code or any derivative work
 * must include the IBM copyright notice, this paragraph, and the
 * preceding two paragraphs in the transferred software.
 *
 * COPYRIGHT   I B M   CORPORATION 1999
 * LICENSED MATERIAL  -  PROGRAM PROPERTY OF I B M
 *
 *
 *  File Name:   enetemac.h
 *
 *  Function:    Header file for the EMAC3 macro on the 405GP.
 *
 *  Author:      Mark Wisner 
 *
 *  Change Activity-
 *
 *  Date        Description of Change                                       BY
 *  ---------   ---------------------                                       ---
 *  29-Apr-99   Created                                                     MKW
 *  20-Apr-00   Integrated into MicroMonitor platform.                      ELS
 *              Changed some of the macro names to match the names
 *              used in the manual.
 *
 * General notice:
 * This code is part of a boot-monitor package developed as a generic base
 * platform for embedded system designs.  As such, it is likely to be
 * distributed to various projects beyond the control of the original
 * author.  Please notify the author of any enhancements made or bugs found
 * so that all may benefit from the changes.  In addition, notification back
 * to the author will allow the new user to pick up changes that may have
 * been made by other users after this version of the code was distributed.
 *
 * Author:  Ed Sutter
 * email:   esutter@lucent.com      (home: lesutter@worldnet.att.net)
 * phone:   908-582-2351            (home: 908-889-5161)
 *
 */
#ifndef _enetemac_h_
#define _enetemac_h_

#define ENET_MAX_MTU                    1518
#define ENET_MAX_MTU_ALIGNED            1536

struct memblock {
    char    data[ENET_MAX_MTU_ALIGNED];    /* room for max packet */
};

            /*Register addresses */
#define EMAC_BASE               0xEF600800
#define EM0MR0                  (EMAC_BASE)
#define EM0MR1                  (EMAC_BASE + 4)
#define EMAC_TXM0               (EMAC_BASE + 8)
#define EMAC_TXM1               (EMAC_BASE + 12)
#define EM0RMR                  (EMAC_BASE + 16)
#define EMAC_ISR                (EMAC_BASE + 20)
#define EMAC_IER                (EMAC_BASE + 24)
#define EM0IAH                  (EMAC_BASE + 28)
#define EM0IAL                  (EMAC_BASE + 32)
#define EMAC_VLAN_TPID_REG      (EMAC_BASE + 36)
#define EMAC_VLAN_TCI_REG       (EMAC_BASE + 40)
#define EMAC_PAUSE_TIME_REG     (EMAC_BASE + 44)
#define EMAC_IND_HASH_1         (EMAC_BASE + 48)
#define EMAC_IND_HASH_2         (EMAC_BASE + 52)
#define EMAC_IND_HASH_3         (EMAC_BASE + 56)
#define EMAC_IND_HASH_4         (EMAC_BASE + 60)
#define EMAC_GRP_HASH_1         (EMAC_BASE + 64)
#define EMAC_GRP_HASH_2         (EMAC_BASE + 68)
#define EMAC_GRP_HASH_3         (EMAC_BASE + 72)
#define EMAC_GRP_HASH_4         (EMAC_BASE + 76)
#define EMAC_LST_SRC_LOW        (EMAC_BASE + 80)
#define EMAC_LST_SRC_HI         (EMAC_BASE + 84)
#define EMAC_I_FRAME_GAP_REG    (EMAC_BASE + 88)
#define EMAC_STACR              (EMAC_BASE + 92)
#define EMAC_TRTR               (EMAC_BASE + 96)
#define EMAC_RX_HI_LO_WMARK     (EMAC_BASE + 100)

/* bit definitions */
/* MODE REG 0 */
#define EM0MR0_RXI              0x80000000
#define EM0MR0_TXI              0x40000000
#define EM0MR0_SRST             0x20000000
#define EM0MR0_TXE              0x10000000
#define EM0MR0_RXE              0x08000000
#define EM0MR0_WKE              0x04000000

/* MODE Reg 1 */
#define EM0MR1_FDE              0x80000000
#define EM0MR1_ILE              0x40000000
#define EM0MR1_VLE              0x20000000
#define EM0MR1_EIFC             0x10000000
#define EM0MR1_APP              0x08000000
#define EM0MR1_AEMI             0x02000000
#define EM0MR1_IST              0x01000000
#define EM0MR1_MF_SPEED         0x00C00000  /* 0's for 10MBPS */
#define EM0MR1_MF_1000MBPS      0x00800000
#define EM0MR1_MF_100MBPS       0x00400000
#define EM0MR1_RFS_4K           0x00300000  /* ~4k for 512 byte */
#define EM0MR1_RFS_2K           0x00200000
#define EM0MR1_RFS_1K           0x00100000
#define EM0MR1_TX_FIFO_2K       0x00080000  /* 0's for 512 byte */
#define EM0MR1_TX_FIFO_1K       0x00040000
#define EM0MR1_TR0_DEPEND       0x00010000  /* 0'x for single packet */
#define EM0MR1_TR0_MULTI        0x00008000
#define EM0MR1_TR1_DEPEND       0x00004000
#define EM0MR1_TR1_MULTI        0x00002000
#define EM0MR1_JUMBO_ENABLE     0x00001000

/* Transmit Mode Register 0 */
#define EMAC_TXM0_GNP0          0x80000000
#define EMAC_TXM0_GNP1          0x40000000
#define EMAC_TXM0_GNPD          0x20000000
#define EMAC_TXM0_FC            0x10000000

/* Receive Mode Register */
#define EMAC_RMR_SP             0x80000000
#define EMAC_RMR_SFCS           0x40000000
#define EMAC_RMR_ARRP           0x20000000
#define EMAC_RMR_ARP            0x10000000
#define EMAC_RMR_AROP           0x08000000
#define EMAC_RMR_ARPI           0x04000000
#define EMAC_RMR_PPP            0x02000000
#define EMAC_RMR_PME            0x01000000
#define EMAC_RMR_PMME           0x00800000
#define EMAC_RMR_IAE            0x00400000
#define EMAC_RMR_MIAE           0x00200000
#define EMAC_RMR_BAE            0x00100000
#define EMAC_RMR_MAE            0x00080000

/* Interrupt Status & enable Regs */
#define EMAC_ISR_OVR            0x02000000
#define EMAC_ISR_PP             0x01000000
#define EMAC_ISR_BP             0x00800000
#define EMAC_ISR_RP             0x00400000
#define EMAC_ISR_SE             0x00200000
#define EMAC_ISR_SYE            0x00100000
#define EMAC_ISR_BFCS           0x00080000
#define EMAC_ISR_PTLE           0x00040000
#define EMAC_ISR_ORE            0x00020000
#define EMAC_ISR_IRE            0x00010000
#define EMAC_ISR_DBDM           0x00000200
#define EMAC_ISR_DB0            0x00000100
#define EMAC_ISR_SE0            0x00000080
#define EMAC_ISR_TE0            0x00000040
#define EMAC_ISR_DB1            0x00000020
#define EMAC_ISR_SE1            0x00000010
#define EMAC_ISR_TE1            0x00000008
#define EMAC_ISR_MOS            0x00000002
#define EMAC_ISR_MOF            0x00000001


/* STA CONTROL REG */
#define EMAC_STACR_OC           0x00008000
#define EMAC_STACR_PHYE         0x00004000
#define EMAC_STACR_WRITE        0x00002000
#define EMAC_STACR_READ         0x00001000
#define EMAC_STACR_CLK_83MHZ    0x00000800  /* 0's for 50Mhz */
#define EMAC_STACR_CLK_66MHZ    0x00000400
#define EMAC_STACR_CLK_100MHZ   0x00000C00

/* Transmit Request Threshold Register */
#define EMAC_TRTR_256           0x18000000   /* 0's for 64 Bytes */
#define EMAC_TRTR_192           0x10000000 
#define EMAC_TRTR_128           0x01000000

/* the follwing defines are for the MadMAL status and control registers. */
/* For bits 0..5 look at the mal.h file                                  */
#define EMAC_TX_CTRL_GFCS   0x0200
#define EMAC_TX_CTRL_GP     0x0100
#define EMAC_TX_CTRL_ISA    0x0080
#define EMAC_TX_CTRL_RSA    0x0040
#define EMAC_TX_CTRL_IVT    0x0020
#define EMAC_TX_CTRL_RVT    0x0010

#define EMAC_TX_CTRL_DEFAULT (EMAC_TX_CTRL_GFCS |EMAC_TX_CTRL_GP)

#define EMAC_TX_ST_BFCS     0x0200
#define EMAC_TX_ST_BPP      0x0100
#define EMAC_TX_ST_LCS      0x0080
#define EMAC_TX_ST_ED       0x0040
#define EMAC_TX_ST_EC       0x0020
#define EMAC_TX_ST_LC       0x0010
#define EMAC_TX_ST_MC       0x0008
#define EMAC_TX_ST_SC       0x0004
#define EMAC_TX_ST_UR       0x0002
#define EMAC_TX_ST_SQE      0x0001

#define EMAC_TX_ST_DEFAULT    0x03F3 


/* madmal receive status / Control bits */

#define EMAC_RX_ST_OE       0x0200
#define EMAC_RX_ST_PP       0x0100
#define EMAC_RX_ST_BP       0x0080
#define EMAC_RX_ST_RP       0x0040
#define EMAC_RX_ST_SE       0x0020
#define EMAC_RX_ST_AE       0x0010
#define EMAC_RX_ST_BFCS     0x0008
#define EMAC_RX_ST_PTL      0x0004
#define EMAC_RX_ST_ORE      0x0002
#define EMAC_RX_ST_IRE      0x0001

/* all the errors we care about */
#define EMAC_RX_ERRORS      0x03FF

#endif /* _enetLib_h_ */
