/*
 *  This source code has been made available to you by IBM on an AS-IS
 *  basis.  Anyone receiving this source is licensed under IBM
 *  copyrights to use it in any way he or she deems fit, including
 *  copying it, modifying it, compiling it, and redistributing it either
 *  with or without modifications.  No license under IBM patents or
 *  patent applications is to be implied by the copyright license.
 *
 *  Any user of this software should understand that IBM cannot provide
 *  technical support for this software and will not be responsible for
 *  any consequences resulting from the use of this software.
 *
 *  Any person who transfers this source code or any derivative work
 *  must include the IBM copyright notice, this paragraph, and the
 *  preceding two paragraphs in the transferred software.
 *
 *  COPYRIGHT   I B M   CORPORATION 1999
 *  LICENSED MATERIAL  -  PROGRAM PROPERTY OF I B M
 *
 *  File Name:   phy.h
 *
 *  Function:    Include file for NS DP83843 PHY.
 *
 *  Author:      Mark Wisner 
 *
 *  Change Activity-
 *
 *  Date        Description of Change                                       BY
 *  ---------   ---------------------                                       ---
 *  04-May-99   Created                                                     MKW
 *  07-Jul-99   Added full duplex support                                   MKW
 *  20-Apr-00   Integrated into MicroMonitor                                ELS
 *  22-Sep-00   Converted from dp83843 to phy generic.                      ELS
 *
 * General notice:
 * This code is part of a boot-monitor package developed as a generic base
 * platform for embedded system designs.  As such, it is likely to be
 * distributed to various projects beyond the control of the original
 * author.  Please notify the author of any enhancements made or bugs found
 * so that all may benefit from the changes.  In addition, notification back
 * to the author will allow the new user to pick up changes that may have
 * been made by other users after this version of the code was distributed.
 *
 * Author:  Ed Sutter
 * email:   esutter@lucent.com      (home: lesutter@worldnet.att.net)
 * phone:   908-582-2351            (home: 908-889-5161)
 */

#ifndef _phy_h_
#define _phy_h_

int phy_read(unsigned long reg, unsigned short * value);
int phy_write(unsigned char reg, unsigned short value);
int phy_autoneg(int,int*,int *);
int phy_dump(void);
int phy_speed(void);
int phy_duplex(void);
int phy_linkup(void);
void phy_reset(void);
void phy_init(unsigned long);

/* PHY ID values (should be read from registers PHY_ID1/PHY_ID2): */
#define SMSC_OUI    0x02821c55          /* For the SMSC LAN83C180 */

/* phy seed setup */ 
#define AUTO            100
#define _100BASET       101
#define _10BASET        102
#define HALF            10
#define FULL            20

/* This is the address of the PHY on the MII (media-independent interface)
 * bus for the LDV405 hardware.
 */
#define PHY_ADDR        0x0001  

/* phy register offsets */
#define PHY_BMCR        0x00        /* Control reg */
#define PHY_BMSR        0x01        /* Status reg */
#define PHY_ID1         0x02        /* Identifier1 reg */
#define PHY_ID2         0x03        /* Identifier2 reg */
#define PHY_ANAR        0x04        /* AutoNeg Advertisement reg */
#define PHY_ANLPAR      0x05        /* AutoNeg LPA reg */
#define PHY_ANER        0x06        /* AutoNeg Expansion reg */
#define PHY_ANNPTR      0x07        /* */
#define PHY_PHYSTS      0x10        /* */
#define PHY_MIPSCR      0x11        /* */
#define PHY_MIPGSR      0x12        /* */
#define PHY_DCR         0x13        /* */
#define PHY_FCSCR       0x14        /* */
#define PHY_RECR        0x15        /* */
#define PHY_PCSR        0x16        /* */
#define PHY_LBR         0x17        /* */
#define PHY_10BTSCR     0x18        /* */
#define PHY_PHYCTRL     0x19        /* */

/* PHY BMCR */
#define PHY_BMCR_RESET      0x8000
#define PHY_BMCR_LOOP       0x4000
#define PHY_BMCR_100MB      0x2000
#define PHY_BMCR_10MB       0x0000      /* no bits set for 10MB */
#define PHY_BMCR_AUTON      0x1000
#define PHY_BMCR_POWD       0x0800
#define PHY_BMCR_ISO        0x0400
#define PHY_BMCR_RESTART    0x0200
#define PHY_BMCR_FDPLX      0x0100
#define PHY_BMCR_COL_TST    0x0080

/* phy BMSR */
#define PHY_BMSR_T4         0x8000
#define PHY_BMSR_100FDX     0x4000
#define PHY_BMSR_100HDX     0x2000
#define PHY_BMSR_10FDX      0x1000
#define PHY_BMSR_10HDX      0x0800
#define PHY_BMSR_PRE_SUP    0x0040
#define PHY_BMSR_AUTN_COMP  0x0020
#define PHY_BMSR_RFAULT     0x0010
#define PHY_BMSR_AUTN_ABLE  0x0008
#define PHY_BMSR_LS         0x0004
#define PHY_BMSR_JD         0x0002
#define PHY_BMSR_EXT        0x0001

/* phy ANLPAR */
#define PHY_ANLPAR_NP       0x8000
#define PHY_ANLPAR_ACK      0x4000
#define PHY_ANLPAR_RFAULT   0x2000
#define PHY_ANLPAR_T4       0x0200
#define PHY_ANLPAR_100FDX   0x0100
#define PHY_ANLPAR_100HDX   0x0080
#define PHY_ANLPAR_10FDX    0x0040
#define PHY_ANLPAR_10HDX    0x0020

/* phy ANAR */
#define PHY_ANAR_NP         0x8000
#define PHY_ANAR_RFAULT     0x2000
#define PHY_ANAR_TECHMASK   0x03e0
#define PHY_ANAR_T4         0x0200
#define PHY_ANAR_100FDX     0x0100
#define PHY_ANAR_100HDX     0x0080
#define PHY_ANAR_10FDX      0x0040
#define PHY_ANAR_10HDX      0x0020
#define PHY_ANAR_SELFLD     0x001f
#define PHY_ANAR_802_3      0x0001
#define PHY_ANAR_802_3_16T  0x0002

/* phy ANSTATR */
#define PHY_ANSTATR_POL     0x2000
#define PHY_ANSTATR_PAMASK  0x1f00
#define PHY_ANSTATR_DONE    0x0080
#define PHY_ANSTATR_FDX     0x0040
#define PHY_ANSTATR_100BT   0x0020
#define PHY_ANSTATR_AMATCH  0x0010
#define PHY_ANSTATR_STATE   0x000f
#endif
