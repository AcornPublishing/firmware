/* cpuio.c:
 * This file contains the generic serial port drivers and other
 * miscellaneous target specific functions.
 *
 * General notice:
 * This code is part of a boot-monitor package developed as a generic base
 * platform for embedded system designs.  As such, it is likely to be
 * distributed to various projects beyond the control of the original
 * author.  Please notify the author of any enhancements made or bugs found
 * so that all may benefit from the changes.  In addition, notification back
 * to the author will allow the new user to pick up changes that may have
 * been made by other users after this version of the code was distributed.
 *
 * Author:  Ed Sutter
 * email:   esutter@lucent.com      (home: lesutter@worldnet.att.net)
 * phone:   908-582-2351            (home: 908-889-5161)
 */
#include "config.h"
#include "cpuio.h"
#include "genlib.h"
#include "ether.h"
#include "stddefs.h"
#include "devices.h"
#include "devtbl.h"
#include "ppcuic.h"

int ConsoleBaudRate, ConsoleDevice;
int (*remoterawon)(), (*remoterawoff)();
int (*remoteputchar)(), (*remotegetchar)(), (*remotegotachar)();

/* InitUART():
 * This is the top-level UART initialization for the monitor. 
 */
int
InitUART(int baud)
{
    if (baud == 0)
        baud = ConsoleBaudRate;

    /* Keep track of the last baud rate, so that it can be used if the
     * incoming baudrate is NULL.
     */
    ConsoleBaudRate = baud;

    /* Null out the remote put/getchar functions. */
    InitRemoteIO();

    ConsoleDevice = TTY0;   
    
    return(0);
}

/* rawon() & rawoff():
 * Used primarily by xmodem.  When xmodem runs, it must be assured that
 * the interface is in RAW mode.  For the case of the monitor alone, it
 * will always be in a raw mode.  These functions are primarily for use
 * when an application has re-loaded the serial driver and may have put
 * it in a non-raw mode.  The mon_con() calls CHARFUNC_RAWMODEON and
 * CHARFUNC_RAWMODEOFF establish these pointers.
 */
void
rawon(void)
{
    if (remoterawon)
        remoterawon();
}

void
rawoff(void)
{
    if (remoterawoff)
        remoterawoff();
}

/* rputchar():
 * Raw put char.
 */
int
rputchar(char c)
{
    /* First check to see if the default rputchar() function has */
    /* been overridden... */
    if (remoteputchar) {
        remoteputchar(c);
        return((int)c);
    }

    write(ConsoleDevice,&c,1);

#if INCLUDE_ETHERNET
    SendIPMonChar(c,0);
#endif

    return((int)c);
}

/* gotachar():
 * Return 0 if no char is avaialable at UART rcv fifo; else 1.
 * Do NOT pull character out of fifo, just return status. 
 */
int
gotachar()
{
    if (remotegotachar)
        return(remotegotachar());

    return(ioctl(ConsoleDevice,GOTACHAR,0,0));
}

/* getchar():
 * Block on the Uart's status until a byte is available in the 
 * receive buffer, then return with it.
 */
int 
getchar()
{
    char    c;

    /* First check to see if the default getchar() function has */
    /* been overridden... */
    if (remotegetchar)
        return(remotegetchar());
    
    read(ConsoleDevice,&c,1);
    return((int)c);
}

/* Enable/Disable BreakInterrupt():
 * Called by monitor to simply enable or disable the processor's
 * ability to generate an interrupt when a break condition is detected
 * on SCC1 which is used as the debug port.
 */
void
EnableBreakInterrupt()
{
}

void
DisableBreakInterrupt()
{
}

/* NA here ... */
void
setTraceBit()
{
}

void
clrTraceBit()
{
}

void
CSInfo()
{
}

void
initCPUio()
{
    /*
     * Interrupt controller setup for the Walnut board.
     * Note: IRQ 0-15  405GP internally generated; active high; level sensitive
     *       IRQ 16    405GP internally generated; active low; level sensitive
     *       IRQ 17-24 RESERVED
     *       IRQ 25 (EXT IRQ 0) FPGA; active high; level sensitive
     *       IRQ 26 (EXT IRQ 1) SMI; active high; level sensitive
     *       IRQ 27 (EXT IRQ 2) Not Used                          
     *       IRQ 28 (EXT IRQ 3) PCI SLOT 3; active low; level sensitive
     *       IRQ 29 (EXT IRQ 4) PCI SLOT 2; active low; level sensitive
     *       IRQ 30 (EXT IRQ 5) PCI SLOT 1; active low; level sensitive
     *       IRQ 31 (EXT IRQ 6) PCI SLOT 0; active low; level sensitive
     * Note for Walnut board:
     *       An interrupt taken for the FPGA (IRQ 25) indicates that either   
     *       the Mouse, Keyboard, IRDA, or External Expansion caused the 
     *       interrupt. The FPGA must be read to determine which device
     *       caused the interrupt. The default setting of the FPGA clears
     *          
     */
    ppcMtuicsr(0xFFFFFFFF);          /* clear all ints */
    ppcMtuicer(0x00000000);          /* disable all ints */
    ppcMtuiccr(0x00000020);          /* set all but FPGA SMI to non-critical*/
    ppcMtuicpr(0xFFFFFFE0);          /* set int polarities */
    ppcMtuictr(0x10000000);          /* set int trigger levels */
    ppcMtuicvcr(0x00000001);         /* set vect base=0,INT0 highest priority*/
    ppcMtuicsr(0xFFFFFFFF);          /* clear all ints */
}
