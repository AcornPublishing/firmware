/* cpu.h:
    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
    phone:  908-582-2351            (home: 908-889-5161)
*/
#define MONARGV0    "monppc"

#define VECTOR(v)   (*(ulong *)(getvbr()+((v)*4)))

#define JUMPTOSTART()   coldstart()

/* These first four values are to maintain compatibility with VXWORKS. */
/* If a warmstart occurs and the StateOfMonitor value is less than 16, */
/* the monitor will assume that vxWorks invoked the warmstart and */
/* automatically autoboot (if NO_AUTOBOOT is not set). */
/* (copied these values from  target/h/sysLib.h) */
#define VXWORKS_BOOT_WARM_AUTOBOOT      0
#define VXWORKS_BOOT_WARM_NO_AUTOBOOT       1
#define VXWORKS_BOOT_COLD           2
#define VXWORKS_BOOT_WARM_QUICK_AUTOBOOT    4

/* Standard restart (warmstart) definitions used by monitor... */
#define EXCEPTION   (1<<4)
#define BREAKPOINT  (2<<4)
#define INITIALIZE  (3<<4)
#define SSTEP       (4<<4)
#define APPLICATION (5<<4)
#define MORESTART   (6<<4)
#define BAILOUT     (7<<4)
#define MISC        (8<<4)
#define APP_EXIT    (9<<4)

#define MONITOR_STATUS  0x1002

/* This size is dependent on the amount of memory on the board... */
#define APPLICATION_STACK   0x107fff0

#define RESET           (0xfffffffc)
#define RESETFUNC()     ((void(*)())RESET)
