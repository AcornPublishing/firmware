/* Monitor configuration file.
    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com  (home: lesutter@worldnet.att.net)
    phone:  908-582-2351        (home: 908-889-5161)
*/

#ifndef CONFIG_H
#define CONFIG_H

/*
 *  Processor and processor family definitions.  Used below to select the
 *  target processor.
 */

#if PLATFORM_WALNUT
#define PLATFORM_NAME       "IBM-WALNUT Evaluation Board"
#elif PLATFORM_NETDEC
#define PLATFORM_NAME       "LDV_NETDEC"
#else
error: No platform specified.
#endif

#define RAM_VECTOR_TABLE    0x01f00000

/* Baud-rate divisor definitions for common/cpu/uart_405.c: */
#define BRD_115200  0x06
#define BRD_57600   0x0c
#define BRD_38400   0x12
#define BRD_19200   0x24
#define BRD_9600    0x48

/* Specify CPU name for printf's in the code */
#define CPU_NAME        "PowerPC-405GP"
 
/* DEFAULT_ETHERADD & DEFAULT_IPADD:
 *  Refer to notes in ethernet.c function EthernetStartup() for details
 *  regarding the use of these definitions.
 */
#define     DEFAULT_ETHERADD "00:60:1d:02:08:00"
#define     DEFAULT_IPADD    "135.3.95.136"     
/* #define  DEFAULT_ETHERADD "00:60:1D:02:0b:fd" */
/* #define  DEFAULT_IPADD    "135.3.94.137"     */
/* #define  DEFAULT_IPADD    "DHCP"         */
/* #define  DEFAULT_IPADD    "BOOTP" */

/* LOOPS_PER_SECOND:
 * Approximately the size of a loop that will cause a 1-second delay.
 * This can be guestimated or modified with the sleep -c command at the
 * monitor command line.
 */

/* This value calibrated for instruction cache on, data cache on,
 * ethernet polling enabled.
 */
#define LOOPS_PER_SECOND    100000

/* Flash bank configuration: */
#define FLASHBANKS              1
#define FLASH_BANK0_WIDTH       1
#define FLASH_BANK0_BASE_ADDR   0xFFF80000
#define FLASH_BANK0_SIZE        0x00080000
#define FLASH_LARGEST_SECTOR    0x10000
#define FLASH_PROTECT_RANGE     "4-7"
#define WIDTH8                  1

/* TFS definitions:
 *  TFSSTART:       Base address in FLASH at which TFS starts.
 *  TFSEND:         Pointer to end of TFS space.
 *  TFSSPARE:       Location of sector that is used as the spare sector
 *                  by TFS for defragmentation.
 *  TFSSPARESIZE:   Size of the spare sector used by TFS for defragmentation.
 *  TFSSECTORCOUNT: Number of eraseable sectors that TFS covers, not including
 *                  the TFSSPARE sector.
*/
#define TFSSPARESIZE    0
#define TFSSECTORCOUNT  4
#define TFSSTART    (FLASH_BANK0_BASE_ADDR)
#define TFSEND      (FLASH_BANK0_BASE_ADDR+0x3ffff)
#define TFSSPARE    0
#define TFS_EBIN_ELF    1

/* SYMFILE is the name of a file that, if present, the monitor uses to 
 * process symbols on the command line.  A symbol is a whitespace delimited
 * string prefixed by a percent sign (%).
 */
#define SYMFILE "symtbl"

/* Specify the size of the memory block (in monitor space) that is to be
 * allocated to malloc in the monitor.  Note that this size can be dynamically
 * increased through the HEAPBASE and HEAPSTART shell variables.
 */
#define ALLOCSIZE 8*1024

/* Specify inclusion of subsystems within the monitor here.
 * The basic monitor includes the following commands as a minimum:
 *
 * flash, help, reset, setup, version, call (and a few others)
 *
 * Subsystems are included/excluded by defining a few macros to 1/0.
 * Following are the subsystem groupings:
 *
 *  INCLUDE_MEMCMDS:        dm, pm, cm, fm, sm
 *  INCLUDE_PIO:            pio
 *  INCLUDE_EDIT:           edit
 *  INCLUDE_DEBUG:          argv, at, dr, go, pr, ss, vfy, sleep
 *  INCLUDE_DISASSEMBLER:   dis
 *  INCLUDE_UNPACK:         unpack
 *  INCLUDE_ETHERNET:       ether
 *  INCLUDE_TFS:            tfs
 *  INCLUDE_MALLOC:         malloc
 *  INCLUDE_SHELLVAR:       set
 *  INCLUDE_XMODEM:         xmodem
 *
 * Note that these INCLUDE macros allow the monitor to be built in a 
 * variety of configurations; some of which may put extreme limitations
 * on the capability of the monitor.  For example, it is recommended that
 * at least INCLUDE_ETHERNET or INCLUDE_XMODEM be defined otherwise
 * there is no download capability in the monitor.  The INCLUDE_TFS macro
 * is also recommended.
 *
 * An absolute minimum practical configuration should include:
 *      ETHERNET or XMODEM.
 *
 * A minimum configuration that includes typical TFS capabilities should
 * include: TFS, SHELLVAR and {ETHERNET | XMODEM}.
 *
 * NOTICE that for this board (ATLAS) I have just about everything enabled.
 * This is because the monitor is allocated the entire 29F040, so I may as
 * well use the space...
 */
#define INCLUDE_MEMCMDS         1
#define INCLUDE_PIO             0
#define INCLUDE_EDIT            1
#define INCLUDE_DEBUG           0
#define INCLUDE_DISASSEMBLER    1
#define INCLUDE_UNPACK          0
#define INCLUDE_UNZIP           0
#define INCLUDE_ETHERNET        1
#define INCLUDE_TFTP            1
#define INCLUDE_DHCPBOOT        1
#define INCLUDE_TFS             1
#define INCLUDE_TFSCLI          1
#define INCLUDE_TFSAPI          1
#define INCLUDE_TFSAUTODEFRAG   0
#define INCLUDE_TFSSYMTBL       1
#define INCLUDE_TFSSCRIPT       1
#define INCLUDE_XMODEM          1
#define INCLUDE_LINEEDIT        1
#define INCLUDE_EE              0
#define INCLUDE_FLASH           1
#define INCLUDE_CRYPT           0
#define INCLUDE_EXCTEST         0
#define INCLUDE_IDEV            1
#define INCLUDE_STRACE          0
#define INCLUDE_CAST            0
#define INCLUDE_REDIRECT        0
#define INCLUDE_QUICKMEMCPY     1
#define INCLUDE_PROFILER        0
#define INCLUDE_BBC             0
#define INCLUDE_MEMTRACE        0
#define INCLUDE_SPRCMD          1
#define INCLUDE_DCRCMD          1
#define INCLUDE_TRAPCMD         0

/* Inclusion of this next file will make sure that all of the above
 * inclusions are legal; and adjust where necessary.
 */
#include "inc_check.h"

#endif  /* CONFIG_H */
