/* except.c:
    This code handles exceptions that are caught by the exception vectors
    that have been installed by the monitor through vinit().

    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
    phone:  908-582-2351            (home: 908-889-5161)
*/
#include "config.h"
#include "cpu.h"
#include "cpuio.h"
#include "genlib.h"
#include "stddefs.h"

ulong   ExceptionAddr;
int     ExceptionType;

extern  int getreg(), putreg();
extern  void putsr(ushort);

void
exception(void)
{
    ulong   vnum, pc;

    putsr(0x2700);
    getreg("D0",&vnum);
    vnum &= 0xff;
    getreg("PC",&pc);
    ExceptionAddr = pc;
    ExceptionType = vnum;
    monrestart(EXCEPTION);
}

void
vinit()
{
    extern void vbase(), vnext();
    extern ulong resetPC, resetSP;
    ulong   *vtab;
    ulong   vfunc;
    int i, delta;

    /* Vector table is first 0x400 bytes of RAM starting at zero... */
    vtab = (ulong *)0;

    /* Special case for vtab[0] and vtab[1]: */
    vtab[0] = resetSP;
    vtab[1] = resetPC;

    vfunc = (ulong)vbase;
    delta = (ulong)vnext - (ulong)vbase;
    for(i=2;i<256;i++) {
        vtab[i] = (ulong)vfunc;
        vfunc += delta;
    }
}
