/*********************************************************************
 *
 * Copyright:
 *  MOTOROLA, INC. All Rights Reserved.  
 *  You are hereby granted a copyright license to use, modify, and
 *  distribute the SOFTWARE so long as this entire notice is
 *  retained without alteration in any modified and/or redistributed
 *  versions, and that such modified versions are clearly identified
 *  as such. No licenses are granted by implication, estoppel or
 *  otherwise under any patents or trademarks of Motorola, Inc. This 
 *  software is provided on an "AS IS" basis and without warranty.
 *
 *  To the maximum extent permitted by applicable law, MOTOROLA 
 *  DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED, INCLUDING 
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR
 *  PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD TO THE 
 *  SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF) AND ANY 
 *  ACCOMPANYING WRITTEN MATERIALS.
 * 
 *  To the maximum extent permitted by applicable law, IN NO EVENT
 *  SHALL MOTOROLA BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING 
 *  WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS 
 *  INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY
 *  LOSS) ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.   
 * 
 *  Motorola assumes no responsibility for the maintenance and support
 *  of this software
 ********************************************************************/

#include "config.h"
#include "cpuio.h"
#include "ether.h"
#include "genlib.h"

#define M5272C3

/********************************************************************/

void    mcf5272_sim_init (MCF5272_IMM *);
void    mcf5272_gpio_init (MCF5272_IMM *);
void    mcf5272_cs_init (MCF5272_IMM *);
void    mcf5272_uart_init(MCF5272_IMM *);

/********************************************************************/

/*
 * Out of reset, the low-level assembly code calls this routine to
 * obtain the address at which to map the MBAR.
 */
void *
mcf5272_mbar (void)
{
    return (void *)IMM_ADDRESS;
}

/********************************************************************/

/*
 * Out of reset, the low-level assembly code calls this routine to
 * obtain the address at which to map the RAMBAR.
 */
void *
mcf5272_rambar (void)
{
    return (void *)INT_SRAM_ADDRESS;
}

/********************************************************************/

/*
 * Out of reset, the low-level assembly code calls this routine to
 * initialize the MCF5272 for this board. A temporary stack has been
 * setup in the internal SRAM, and the stack pointer will be changed
 * to point to SDRAM once this routine returns.
 */
void
mcf5272_init (MCF5272_IMM *imm)
{
    mcf5272_uart_init(imm);
    mcf5272_sim_init(imm);
    mcf5272_gpio_init(imm);
    mcf5272_cs_init(imm);

    /* Turn Instruction Cache ON
    mcf5272_wr_cacr(0x81000500);
     */
}

/****************************************************************/
void
mcf5272_sim_init (MCF5272_IMM *imm)
{
    /*******************************************************
    *
    * This routine executed upon reset to initialize
    * MCF5272 SIM registers.  An initial stack must have been setup
    * in the SRAM in order for this routine to work.
    *
    *******************************************************/

    /*
     * Initialize System Config Register
     * Setup Watch Dog Timeout
     */
    MCF5272_WR_SIM_SCR(imm,MCF5272_SIM_SCR_HWWD_1024);

    /*
     * Initialize System Protection Register
     * Enable all bus error exceptions
     */
    MCF5272_WR_SIM_SPR(imm,0
        | MCF5272_SIM_SPR_ADC | MCF5272_SIM_SPR_ADCEN
        | MCF5272_SIM_SPR_WPV | MCF5272_SIM_SPR_WPVEN
        | MCF5272_SIM_SPR_SMV | MCF5272_SIM_SPR_SMVEN
        | MCF5272_SIM_SPR_SBE | MCF5272_SIM_SPR_SBEEN
        | MCF5272_SIM_SPR_HWT | MCF5272_SIM_SPR_HWTEN
        | MCF5272_SIM_SPR_RPV | MCF5272_SIM_SPR_RPVEN
        | MCF5272_SIM_SPR_EXT | MCF5272_SIM_SPR_EXTEN
        | MCF5272_SIM_SPR_SUV | MCF5272_SIM_SPR_SUVEN
        ) ;

    /* 
     * Initilize Interrupt Control Registers
     * Mask all interrupt sources
     */
    MCF5272_WR_SIM_ICR1(imm,0x88888888);
    MCF5272_WR_SIM_ICR2(imm,0x88888888);
    MCF5272_WR_SIM_ICR3(imm,0x88888888);
    MCF5272_WR_SIM_ICR4(imm,0x88880000);

    /* 
     * Initialize Programmable Interrupt Transition Register
     * Make all external interrupts trigger on falling edge
     */ 
    MCF5272_WR_SIM_PITR(imm,MCF5272_SIM_PITR_NEG_EDGE);

    /*
     * Initialize Programmable Interrupt Vector Register
     * Place peripheral interrupt vectors beginning at vector 64
     */
    MCF5272_WR_SIM_PIVR(imm,MCF5272_SIM_PIVR_NORMAL);

}
/********************************************************************/
void 
mcf5272_gpio_init (MCF5272_IMM *imm)
{
    /*
     * Inititialize Port A
     */

    /* Enable USB signals */
    MCF5272_WR_GPIO_PACNT(imm,0x00001555);
    /* Configure all pins as inputs */
    MCF5272_WR_GPIO_PADDR(imm,0);

    /*
     * Inititialize Port B
     */

    /* Enable USART1 and FEC signals*/
    MCF5272_WR_GPIO_PBCNT(imm,0x55554155);
    /* Configure all GPIO pins as inputs */
    MCF5272_WR_GPIO_PADDR(imm,0);
    
    /*
     * Inititialize Port C
     * Since we are in 32-bit mode, Port C is not available!
     */

    /*
     * Inititialize Port D
     * Configure all signals as high impedence
     */
    MCF5272_WR_GPIO_PDCNT(imm,0);
}

/********************************************************************/
void
mcf5272_uart_init(MCF5272_IMM *imm)
{
    register uint16 ubgs;

    /* Initialize UART0 */
    
    /* Reset Transmitter */
    MCF5272_WR_UART0_UCR(imm,MCF5272_UART_UCR_RESET_TX);

    /* Reset Receiver */
    MCF5272_WR_UART0_UCR(imm,MCF5272_UART_UCR_RESET_RX);

    /* Reset Mode Register */
    MCF5272_WR_UART0_UCR(imm,MCF5272_UART_UCR_RESET_MR);

    /* No parity, 8-bits per character */
    MCF5272_WR_UART0_UMR(imm, 0
        | MCF5272_UART_UMR1_PM_NONE
        | MCF5272_UART_UMR1_BC_8 );

    /* No echo or loopback, 1 stop bit */
    MCF5272_WR_UART0_UMR(imm, 0
        | MCF5272_UART_UMR2_CM_NORMAL
        | MCF5272_UART_UMR2_STOP_BITS_1);

    /* Set Rx and Tx baud by timer */
    MCF5272_WR_UART0_UCSR(imm, 0
        | MCF5272_UART_UCSR_RCS(0xD)
        | MCF5272_UART_UCSR_TCS(0xD));

    /* Mask all USART interrupts */
    MCF5272_WR_UART0_UIMR(imm, 0);
                 
    /* Calculate baud settings */
    ubgs = (uint16)((SYSTEM_CLOCK*1000000)/(UART_BAUD * 32));

    MCF5272_WR_UART0_UBG1(imm, (uint8)((ubgs & 0xFF00) >> 8));
    MCF5272_WR_UART0_UBG2(imm, (uint8)(ubgs & 0x00FF));

    /* Enable receiver and transmitter */
    MCF5272_WR_UART0_UCR(imm, 0
        | MCF5272_UART_UCR_TX_ENABLED
        | MCF5272_UART_UCR_RX_ENABLED);

    /* Disable UART1 */
    MCF5272_WR_UART1_UCR(imm, 0
        | MCF5272_UART_UCR_TX_DISABLED
        | MCF5272_UART_UCR_RX_DISABLED);
}

/********************************************************************/
void
mcf5272_cs_init (MCF5272_IMM *imm)
{
    /* This routine initializes ChipSelects to setup memory devices */

    /* ChipSelect 0 - 2MB FLASH */
#if defined(M5272C3)
    MCF5272_WR_CS_CSBR0(imm, 0
        | MCF5272_CS_BR_BASE(FLASH_ADDRESS)
        | MCF5272_CS_BR_SRAM
        | MCF5272_CS_BR_PS_16
        | MCF5272_CS_BR_EN);    
#elif defined(HSEVB)
    MCF5272_WR_CS_CSBR0(imm, 0
        | MCF5272_CS_BR_BASE(FLASH_ADDRESS)
        | MCF5272_CS_BR_SRAM_8  
        | MCF5272_CS_BR_EN);    
#else
#error "Must define BOARD variable"
#endif
    MCF5272_WR_CS_CSOR0(imm, 0
        | MCF5272_CS_OR_MASK_2M
        | MCF5272_CS_OR_WS(5));

    /* Chip Select 2 - 512KB SRAM - see schematic */
#if defined(M5272C3)
    MCF5272_WR_CS_CSBR2(imm, 0
        | MCF5272_CS_BR_BASE(EXT_SRAM_ADDRESS)
        | MCF5272_CS_BR_SRAM
        | MCF5272_CS_BR_PS_32
        | MCF5272_CS_BR_EN);
    MCF5272_WR_CS_CSOR2(imm, 0
        | MCF5272_CS_OR_MASK_512K
        | MCF5272_CS_OR_WS(0));
#endif

    /* ChipSelect 7 - 4MB SDRAM */
    MCF5272_WR_CS_CSBR7(imm, 0
        | MCF5272_CS_BR_BASE(SDRAM_ADDRESS)
        | MCF5272_CS_BR_SDRAM 
        | MCF5272_CS_BR_PS_LINE 
        | MCF5272_CS_BR_EN);
    MCF5272_WR_CS_CSOR7(imm, 0
        | MCF5272_CS_OR_MASK_4M
        | MCF5272_CS_OR_WS(0x1F));

    /* Do not initialize SDRAM if already running in SDRAM */
    if (!(MCF5272_RD_SDRAMC_SDCCR(imm) & MCF5272_SDRAMC_SDCCR_ACT))
    {
        switch (SYSTEM_CLOCK)
        {
            case 48:
                MCF5272_WR_SDRAMC_SDCTR(imm, 0
                    | MCF5272_SDRAMC_SDCTR_RTP_48MHz
                    | MCF5272_SDRAMC_SDCTR_RC(1)
                    | MCF5272_SDRAMC_SDCTR_RP(1)
                    | MCF5272_SDRAMC_SDCTR_RCD(1)
                    | MCF5272_SDRAMC_SDCTR_CLT_2
                    );
                break;
            case 33:
                MCF5272_WR_SDRAMC_SDCTR(imm, 0
                    | MCF5272_SDRAMC_SDCTR_RTP_33MHz
                    | MCF5272_SDRAMC_SDCTR_RC(1)
                    | MCF5272_SDRAMC_SDCTR_RP(1)
                    | MCF5272_SDRAMC_SDCTR_RCD(1)
                    | MCF5272_SDRAMC_SDCTR_CLT_2
                    );
                break;
            case 25:
                MCF5272_WR_SDRAMC_SDCTR(imm, 0
                    | MCF5272_SDRAMC_SDCTR_RTP_25MHz
                    | MCF5272_SDRAMC_SDCTR_RC(1)
                    | MCF5272_SDRAMC_SDCTR_RP(1)
                    | MCF5272_SDRAMC_SDCTR_RCD(1)
                    | MCF5272_SDRAMC_SDCTR_CLT_2
                    );
                break;
            case 66:
            default:
                MCF5272_WR_SDRAMC_SDCTR(imm, 0
                    | MCF5272_SDRAMC_SDCTR_RTP_66MHz
                    | MCF5272_SDRAMC_SDCTR_RC(1)
                    | MCF5272_SDRAMC_SDCTR_RP(3)
                    | MCF5272_SDRAMC_SDCTR_RCD(2)
                    | MCF5272_SDRAMC_SDCTR_CLT_2
                    );
                break;
        }

#if defined (M5272C3)
        MCF5272_WR_SDRAMC_SDCCR(imm, 0
            | MCF5272_SDRAMC_SDCCR_MCAS_A9
            | MCF5272_SDRAMC_SDCCR_BALOC_A21
            | MCF5272_SDRAMC_SDCCR_REG
            | MCF5272_SDRAMC_SDCCR_INIT
            );
#elif defined(HSEVB)
        MCF5272_WR_SDRAMC_SDCCR(imm, 0
            | MCF5272_SDRAMC_SDCCR_MCAS_A10
            | MCF5272_SDRAMC_SDCCR_BALOC_A21
            | MCF5272_SDRAMC_SDCCR_REG
            | MCF5272_SDRAMC_SDCCR_INIT
            );
#else
#error "Must define BOARD variable"
#endif
    }

    /* ChipSelect 1,3,4,5 and 6 - Empty */
    MCF5272_WR_CS_CSBR1(imm, 0);
    MCF5272_WR_CS_CSOR1(imm, 0);
#if defined (HSEVB)
    MCF5272_WR_CS_CSBR3(imm, 0
        | MCF5272_CS_BR_BASE(BOARD_REG_ADDRESS)
        | MCF5272_CS_BR_PS_8 
        | MCF5272_CS_BR_SRAM_8 
        | MCF5272_CS_BR_EN);
    MCF5272_WR_CS_CSOR3(imm, 0
        | MCF5272_CS_OR_MASK_4K
        | MCF5272_CS_OR_WS(4));
#else
    MCF5272_WR_CS_CSBR3(imm, 0);
    MCF5272_WR_CS_CSOR3(imm, 0);
#endif
    MCF5272_WR_CS_CSBR4(imm, 0);
    MCF5272_WR_CS_CSOR4(imm, 0);
    MCF5272_WR_CS_CSBR5(imm, 0);
    MCF5272_WR_CS_CSOR5(imm, 0);
    MCF5272_WR_CS_CSBR6(imm, 0);
    MCF5272_WR_CS_CSOR6(imm, 0);
}

void
InitUART(int baud)
{
}

void
initCPUio()
{
}

int
devInit(int baud)
{
/*  InitUART(baud); */
    InitRemoteIO();
    return(0);
}

int ConsoleBaudRate;

int
getchar (void)
{
    MCF5272_IMM *imm;

    if (remotegetchar) {
        return(remotegetchar());
    }

    imm = mcf5272_get_immp();

    /* Wait until character has been received */
    while (!(MCF5272_RD_UART0_USR(imm) & MCF5272_UART_USR_RXRDY)) {
#if INCLUDE_ETHERNET
        polletherdev();
#endif
    }
    return MCF5272_RD_UART0_URB(imm);
}

int
rputchar(char ch)
{
    MCF5272_IMM *imm;

    if (remoteputchar) {
        return(remoteputchar(ch));
    }

    imm = mcf5272_get_immp();

    /* Wait until space is available in the FIFO */
    while (!(MCF5272_RD_UART0_USR(imm) & MCF5272_UART_USR_TXRDY));

    /* Send the character */
    MCF5272_WR_UART0_UTB(imm, (uint8)ch);

#if INCLUDE_ETHERNET
    SendIPMonChar(ch,0);
#endif

    return(ch);
}

int
gotachar (void)
{
    MCF5272_IMM *imm;

    if (remotegotachar) {
        return(remotegotachar());
    }

    imm = mcf5272_get_immp();

    return (MCF5272_RD_UART0_USR(imm) & MCF5272_UART_USR_RXRDY);
}

void
rawon(void)
{
}

void
rawoff(void)
{
}
/********************************************************************/