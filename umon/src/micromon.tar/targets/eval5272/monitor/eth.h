/*********************************************************************
 *
 * Copyright:
 *  MOTOROLA, INC. All Rights Reserved.  
 *  You are hereby granted a copyright license to use, modify, and
 *  distribute the SOFTWARE so long as this entire notice is
 *  retained without alteration in any modified and/or redistributed
 *  versions, and that such modified versions are clearly identified
 *  as such. No licenses are granted by implication, estoppel or
 *  otherwise under any patents or trademarks of Motorola, Inc. This 
 *  software is provided on an "AS IS" basis and without warranty.
 *
 *  To the maximum extent permitted by applicable law, MOTOROLA 
 *  DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED, INCLUDING 
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR
 *  PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD TO THE 
 *  SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF) AND ANY 
 *  ACCOMPANYING WRITTEN MATERIALS.
 * 
 *  To the maximum extent permitted by applicable law, IN NO EVENT
 *  SHALL MOTOROLA BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING 
 *  WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS 
 *  INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY
 *  LOSS) ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.   
 * 
 *  Motorola assumes no responsibility for the maintenance and support
 *  of this software
 ********************************************************************/

/*
 * File:        eth.h
 * Purpose:     Definitions for Ethernet Frames.
 *
 * Modifications:
 */

#ifndef _ETH_H
#define _ETH_H

/*******************************************************************/

/* 48-bit Ethernet Addresses */
typedef uint8 ETH_ADDR[6];

/* 16-bit Ethernet Frame Type, ie. Protocol */
typedef uint16 ETH_FTYPE;

/* Defined Ethernet Frame Types */
#define FRAME_IP    (0x0800)
#define FRAME_ARP   (0x0806)
#define FRAME_RARP  (0x8035)

/* Maximum and Minimum Ethernet Frame Size (Data Field) */
#define ETH_MAX_SIZE    (1500)
#define ETH_MIN_SIZE    (46)

/* Ethernet Frame definition */
typedef struct
{
    ETH_ADDR dest;
    ETH_ADDR src;
    ETH_FTYPE type;
    uint8 data[ETH_MAX_SIZE];
} eth_frame_hdr;

/* Offset and size of protocol headers */
#define ETH_HDR_OFFSET  0   /* ethernet header at the top of the frame */
#define ETH_HDR_SIZE    14

/*******************************************************************/

#endif  /* _ETH_H */
