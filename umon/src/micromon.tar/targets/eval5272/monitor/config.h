/* Monitor configuration file. */

#define DEFAULT_ETHERADD    "00:11:22:33:44:55"
#define DEFAULT_IPADD       "1.2.3.4"

#define FORCE_BSS_INIT

#if PLATFORM_CFEVAL
#define PLATFORM_NAME       "Coldfire 5272 Evaluation Board"
#else
#error "Platform name is not specified"
#endif

#define CPU_NAME    "ColdFire 5272"

#define FLASH_PROTECT_RANGE "0-4"

/* Flash bank configuration:
 */
#define FLASHBANKS              1
#define FLASH_BANK0_WIDTH       2
#define FLASH_BANK0_BASE_ADDR   0xFFE00000

/* TFS definitions:
 */
#define TFSNAMESIZE     23      /* Should be mod4 - 1 */
#define TFSSPARESIZE    0x40000
#define TFSSECTORCOUNT  2   
#define TFSSTART        0xfff40000
#define TFSEND          0xfffbffff
#define TFSSPARE        0xfffc0000
#define TFS_EBIN_COFF   1

/* Specify the size of the memory block (in monitor space) that
 * is to be allocated to malloc in the monitor.  Note that this
 * size can be dynamically increased using the heap command at
 * runtime.
 */
#define ALLOCSIZE 64*1024

/* SYMFILE is the name of a file that, if present, the monitor uses to 
 * process symbols on the command line.  A symbol is a whitespace delimited
 * string prefixed by a percent sign (%).
 */
#define SYMFILE "symtbl"

/* INCLUDE_XXX Macros:
 * The sanity of this list is tested through the inclusion of
 * "inc_check.h" at the bottom of this list...
 */
#define INCLUDE_MEMCMDS         1
#define INCLUDE_PIO             0
#define INCLUDE_EDIT            1
#define INCLUDE_DEBUG           0
#define INCLUDE_DISASSEMBLER    0
#define INCLUDE_UNPACK          0
#define INCLUDE_UNZIP           0
#define INCLUDE_ETHERNET        1
#define INCLUDE_TFTP            1
#define INCLUDE_TFS             1
#define INCLUDE_FLASH           1
#define INCLUDE_XMODEM          1
#define INCLUDE_LINEEDIT        1
#define INCLUDE_CRYPT           0
#define INCLUDE_DHCPBOOT        1
#define INCLUDE_TFSAPI          1
#define INCLUDE_TFSAUTODEFRAG   1
#define INCLUDE_TFSSYMTBL       1
#define INCLUDE_TFSSCRIPT       1
#define INCLUDE_TFSCLI          1
#define INCLUDE_EE              0
#define INCLUDE_GDB             0
#define INCLUDE_STRACE          0
#define INCLUDE_CAST            0
#define INCLUDE_EXCTEST         0
#define INCLUDE_IDEV            0
#define INCLUDE_REDIRECT        0
#define INCLUDE_QUICKMEMCPY     0
#define INCLUDE_PROFILER        0
#define INCLUDE_BBC             0
#define INCLUDE_MEMTRACE        0

#include "inc_check.h"
