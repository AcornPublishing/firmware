/* main.c:
 *
 *  General notice:
 *  This code is part of a boot-monitor package developed as a generic base
 *  platform for embedded system designs.  As such, it is likely to be
 *  distributed to various projects beyond the control of the original
 *  author.  Please notify the author of any enhancements made or bugs found
 *  so that all may benefit from the changes.  In addition, notification back
 *  to the author will allow the new user to pick up changes that may have
 *  been made by other users after this version of the code was distributed.
 *
 *  Author: Ed Sutter
 *  email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
 *  phone:  908-582-2351            (home: 908-889-5161)
 *
 */
#include "config.h"
#include "cpu.h"
#include "tfs.h"
#include "tfsprivate.h"
#include "genlib.h"
#include "ether.h"
#include "monflags.h"
#include "flash.h"
#include "stddefs.h"

extern  void putsr(ulong), InitMonSTATUS();
extern  ulong getsr(void);

extern  int ExceptionType;
extern  ulong   ExceptionAddr;
extern  ulong   APPLICATION_RAMSTART;
int     StateOfMonitor, AppExitStatus;
void    init2(), reinit();

int
main(int argc,char *argv[])
{
    int fault;

    /* Set user level to its max, then allow monrc file to adjust it. */
    initUsrLvl(MAXUSRLEVEL);

    if (StateOfMonitor == INITIALIZE) {
        InitMonSTATUS(getsr());
        /* Init register data structures. */
        reginit();
        /* Second phase of hardware initialization. */
        init2();
        /* Common system initialization stuff... */
        init3();
    }

    switch(StateOfMonitor) {
    case INITIALIZE:
        break;
    case MISC:
    case SSTEP:
    case BAILOUT:
    case MORESTART:
    case BREAKPOINT:
#if INCLUDE_DEBUG
        regbackup();
#endif
        break;
    case APP_EXIT:
        reinit();
        printf("\nApplication Exit Status: %d (0x%x)\n",
            AppExitStatus,AppExitStatus);
        break;
    case EXCEPTION:
        reinit();
        /* Certain exception types indicate that the PC defines the location 
         * of the faulting instruction (fault = 1) and others indicate that
         * the PC is the address of the next instruction (fault = 0).
         * See section 3.3 of MCF5206 User's Manual.
         */
        switch(ExceptionType) {
            case 2:             /* Access error */
            case 3:             /* Address error */
            case 4:             /* Illegal instruction */
            case 8:             /* Privilege violation */
            case 10:            /* Unimplemented line-a opcode */
            case 11:            /* Unimplemented line-f opcode */
            case 14:            /* Format error */
                fault = 1;
                break;
            default:
                fault = 0;
                break;
        }
        printf("\nEXCEPTION #%d, ",ExceptionType);
        if (fault)
            printf("fault at 0x%lx\n\n",ExceptionAddr);
        else
            printf("next instruction at 0x%lx\n\n",ExceptionAddr);
        showregs();
        exceptionAutoRestart(INITIALIZE);
        break;
    default:
        printf("Unexpected monitor state: 0x%x\n",StateOfMonitor);
        break;
    }   /* end switch StateOfMonitor */

    /* Enter the endless loop of command processing: */
    CommandLoop();
    return(0);
}

void
reinit(void)
{
    init1(0);
    init2();
#if INCLUDE_ETHERNET
    EthernetStartup(0,0);   /* reinit ethernet */
#endif
}

void
init2()
{
#if INCLUDE_FLASH
    FlashInit();        /* Init flashop data structures.  This MUST be */
                /* done prior to turning on cache!!! */
#endif

    cacheInit();        /* Initialize cache. */

#if INCLUDE_ETHERNET
    enreset();          /* Clear the ethernet interface. */
#endif

#if INCLUDE_TFS
    tfsstartup();       /* Init tfs data structures. */
#endif
}

void
monrestart(int val)
{
    warmstart(val);
}

void
intsrestore(sr)
ulong     sr;
{
/*
    putsr(sr);
*/
}

ulong
intsoff()
{
/*
    ushort  sr;

    sr = getsr();
    putsr(sr|0x0700);
    return((int)sr);
*/
    return(0);
}

/* some stubs for now... */
void
ctxMON()
{
}

void
ctxAPP()
{
}

void
appexit(int val)
{
    intsoff();
    AppExitStatus = val;
#if INCLUDE_DEBUG
    removeatpoints();
#endif
    warmstart(APP_EXIT);
}

int
monState()
{
    return(StateOfMonitor);
}

void
cacheInitForTarget()
{
    extern void mcf5272_wr_cacr();

    /* Enable instruction cache. */
    mcf5272_wr_cacr(0x81000500);
}

/* extValidPassword():
    Refer to validPassword() in common/password.c for notes.
*/
int
extValidPassword(char *password, int ulvl)
{
    return(-1);
}

void
DisableBreakInterrupt()
{
}

void
EnableBreakInterrupt()
{
}

void
pioclr(char port, int bit)
{
}

void
pioset(char port, int bit)
{
}

int
pioget(char port, int bit)
{
    return(0);
}
