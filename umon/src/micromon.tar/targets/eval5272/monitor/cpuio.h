/*********************************************************************
 *
 * Copyright:
 *  MOTOROLA, INC. All Rights Reserved.  
 *  You are hereby granted a copyright license to use, modify, and
 *  distribute the SOFTWARE so long as this entire notice is
 *  retained without alteration in any modified and/or redistributed
 *  versions, and that such modified versions are clearly identified
 *  as such. No licenses are granted by implication, estoppel or
 *  otherwise under any patents or trademarks of Motorola, Inc. This 
 *  software is provided on an "AS IS" basis and without warranty.
 *
 *  To the maximum extent permitted by applicable law, MOTOROLA 
 *  DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED, INCLUDING 
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR
 *  PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD TO THE 
 *  SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF) AND ANY 
 *  ACCOMPANYING WRITTEN MATERIALS.
 * 
 *  To the maximum extent permitted by applicable law, IN NO EVENT
 *  SHALL MOTOROLA BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING 
 *  WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS 
 *  INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY
 *  LOSS) ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.   
 * 
 *  Motorola assumes no responsibility for the maintenance and support
 *  of this software
 ********************************************************************/

/*
 * File:        cpuio.h
 * Purpose:     Function prototypes and memory map information.
 *
 * Notes:
 */

#ifndef _INIT_H
#define _INIT_H

#include "mcf5272.h"


/********************************************************************
 * M5272C3 Evaluation Board Definitions
 ********************************************************************/

/* System Bus Clock Info */
#define SYSTEM_CLOCK            66      /* system bus frequency in MHz */
#define PERIOD                  15.15   /* system bus period in ns */
#define UART_BAUD               19200   /* 115200 */
#define DEFAULT_BAUD_RATE       UART_BAUD

/* Memory Map Info */
#define IMM_ADDRESS             (0x10000000)
#define FLASH_ADDRESS           (0xFFE00000)
#define FLASH_SIZE              (0x00200000)
#define SDRAM_ADDRESS           (0x00000000)
#define EXT_SRAM_ADDRESS        (0x30000000)
#define EXT_SRAM_SIZE           (0x00080000)
#define INT_SRAM_ADDRESS        (0x20000000)
#define INT_SRAM_SIZE           (0x00001000)
#define BOARD_REG_ADDRESS       (0x40000000)

/********************************************************************
 *  Global Macros
 ********************************************************************/

/* Return a pointer to the Internal Memory Map */
#define mcf5272_get_immp()     ((MCF5272_IMM *)(IMM_ADDRESS))

/********************************************************************
 *  Timer period info
 ********************************************************************/

#define TIMER_NETWORK_PERIOD    1000000000/0xFFFF   /* 1 sec / max timeout */
#define TIMER_BENCHMARK_PERIOD  0

/********************************************************************
 *  Interrupt Controller Definitions
 ********************************************************************/

#define TIMER_NETWORK_LEVEL     3
#define TIMER_BENCHMARK_LEVEL   7
#define FEC_LEVEL               4
#define USB_EP0_LEVEL           6
#define USB_EP1_LEVEL           5
#define USB_EP2_LEVEL           5
#define USB_EP3_LEVEL           5
#define USB_EP4_LEVEL           5
#define USB_EP5_LEVEL           5
#define USB_EP6_LEVEL           5
#define USB_EP7_LEVEL           5

/********************************************************************
 *  Function Prototypes
 ********************************************************************/

#ifndef ASSEMBLY_ONLY
void    mcf5272_wr_vbr (uint32);
void    mcf5272_wr_cacr (uint32);
void    mcf5272_wr_acr0 (uint32);
void    mcf5272_wr_acr1 (uint32);
void    mcf5272_wr_rambar (uint32);
void    mcf5272_wr_mbar (uint32);
void    mcf5272_wr_sr (uint32);
void    mcf5272_wr_movem_line(uint32*, uint32);
void    mcf5272_irq_enable(void);
void    mcf5272_irq_disable(void);
void    mcf5272_sim_init (MCF5272_IMM *);
void    mcf5272_gpio_init (MCF5272_IMM *);
void    mcf5272_cs_init (MCF5272_IMM *);
void    mcf5272_sdramc_init (MCF5272_IMM *);
void    mcf5272_uart_init (MCF5272_IMM *);
int     in_char (void);
void    out_char (int);
int     char_present (void);
void    exception_handler (void *);
void    irq_handler (void);
void    user_spurious_handler (void);
void    ext_irq1_handler (void);
void    ext_irq2_handler (void);
void    ext_irq3_handler (void);
void    ext_irq4_handler (void);
void    timer0_handler (void);
void    timer1_handler (void);
void    timer2_handler (void);
void    timer3_handler (void);
void    usart0_handler (void);
void    usart1_handler (void);
void    pli_periodic_handler (void);
void    pli_asynchronous_handler (void);
void    usb_endpoint0_handler (void);
void    usb_endpoint1_handler (void);
void    usb_endpoint2_handler (void);
void    usb_endpoint3_handler (void);
void    usb_endpoint4_handler (void);
void    usb_endpoint5_handler (void);
void    usb_endpoint6_handler (void);
void    usb_endpoint7_handler (void);
void    dma_controller_handler (void);
void    ethernet_rx_handler (void);
void    ethernet_tx_handler (void);
void    ethernet_handler (void);
void    qspi_handler (void);
void    ext_irq5_handler (void);
void    ext_irq6_handler (void);
void    watchdog_handler (void);
#endif
    
/********************************************************************/

#endif /* _INIT_H */
