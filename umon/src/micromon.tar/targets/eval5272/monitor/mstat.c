#include "config.h"
#include "genlib.h"
#include "stddefs.h"

char *MstatHelp[] = {
    "Monitor status",
    "-[b:]",
    " -b {baud}  set baud rate",
    0,
};

int
Mstat(int argc,char *argv[])
{
    extern  int InitUART(int);
    void    mstatshow(void);
    int     opt;

    /* If no args, just dump current status. */
    if (argc == 1) {
        mstatshow();
        return(0);
    }

    while ((opt=getopt(argc,argv,"b:")) != -1) {
        switch(opt) {
        case 'b':
            InitUART(atoi(optarg));
            break;
        default:
            return(0);
        }
    }
    if (argc != optind)
        return(-1);
    return(0);
}

void
InitMonSTATUS(ulong state)
{
}

void
SetMonSTATUS(void)
{
}

void
mstatshow(void)
{
    monHeader(0);
    mstatshowcom();
}

