/*********************************************************************
 *
 * Copyright:
 *  MOTOROLA, INC. All Rights Reserved.  
 *  You are hereby granted a copyright license to use, modify, and
 *  distribute the SOFTWARE so long as this entire notice is
 *  retained without alteration in any modified and/or redistributed
 *  versions, and that such modified versions are clearly identified
 *  as such. No licenses are granted by implication, estoppel or
 *  otherwise under any patents or trademarks of Motorola, Inc. This 
 *  software is provided on an "AS IS" basis and without warranty.
 *
 *  To the maximum extent permitted by applicable law, MOTOROLA 
 *  DISCLAIMS ALL WARRANTIES WHETHER EXPRESS OR IMPLIED, INCLUDING 
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR
 *  PURPOSE AND ANY WARRANTY AGAINST INFRINGEMENT WITH REGARD TO THE 
 *  SOFTWARE (INCLUDING ANY MODIFIED VERSIONS THEREOF) AND ANY 
 *  ACCOMPANYING WRITTEN MATERIALS.
 * 
 *  To the maximum extent permitted by applicable law, IN NO EVENT
 *  SHALL MOTOROLA BE LIABLE FOR ANY DAMAGES WHATSOEVER (INCLUDING 
 *  WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS 
 *  INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY
 *  LOSS) ARISING OF THE USE OR INABILITY TO USE THE SOFTWARE.   
 * 
 *  Motorola assumes no responsibility for the maintenance and support
 *  of this software
 ********************************************************************/

/*
 * File:        nif.h
 * Purpose:     Definition of a Network InterFace.
 *
 * Notes:
 *
 *
 * Modifications:
 *
 */

#ifndef _NIF_H
#define _NIF_H

/********************************************************************/
/* Include Ethernet standards definitions and network buffer specifics */

#include "eth.h"
#include "nbuf.h"

/********************************************************************/

extern uint8 TIMER_NETWORK;

/* Maximum number of supported protoocls: IP, ARP, RARP */
#define MAX_SUP_PROTO   (3)

typedef struct
{
    uint16  protocol;
    void    (*handler)(void *   /* nif */, NBUF *   /* buffer */);
    void    *info;  /* pointer to protocol defined config info */
} SUP_PROTO;

typedef
uint8   HWA_ADDR_P[];

typedef struct NIF_t
{
    char        name[16];
    ETH_ADDR    hwa;    /* ethernet card hardware address */
    ETH_ADDR    broadcast;  /* ethernet broadcast address */
    int         hwa_size;
    int         mtu;    /* hardware maximum transmission unit */

    SUP_PROTO   protocol[MAX_SUP_PROTO];
    unsigned short  num_protocol;

    int     (*reset)(struct NIF_t *);
    void    (*start)(struct NIF_t *);
    void    (*stop)(struct NIF_t *);
    int     (*send)(struct NIF_t *, HWA_ADDR_P, HWA_ADDR_P, uint16, NBUF *);
    void    (*receive)(struct NIF_t *);
    NBUF*   (*rx_alloc)(void);
    NBUF*   (*tx_alloc)(void);
    void    (*rx_free)(NBUF *);
    void    (*tx_free)(NBUF *);

    void    *nic;   /* base address of NIC chipset */
    int     vector; /* vector used by device */
    unsigned int    next_receive;   /* needed by the SEEQ */

    unsigned int    f_rx;
    unsigned int    f_tx;
    unsigned int    f_rx_err;
    unsigned int    f_tx_err;
    unsigned int    f_err;
} NIF;


/********************************************************************/

NIF *
nif_init (NIF *, char *);

int
nif_protocol_exist (NIF *, uint16);

void
nif_protocol_handler (NIF *, uint16, NBUF *);

void *
nif_get_protocol_info (NIF *, uint16);

int
nif_bind_protocol (NIF *, uint16, void *, void *);

/********************************************************************/

#endif /* _NIF_H */
