/* regs.c:
    Allow the user to display/modify CPU registers that are locally cached
    when a breakpoint is hit.  The local cache is then loaded back into the
    CPU context when program execution resumes.  Note that this may or may
    not be supported for all targets on which the monitor runs.

    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
    phone:  908-582-2351            (home: 908-889-5161)
*/

#include "config.h"
#include "cpu.h"
#include "genlib.h"
#include "ctype.h"

typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned long ulong;

/* regnames[] & regtbl[]...
    Structures containing register name and register value.
    NOTE: if these tables are changed, then code in breakpt.s must
    also be changed.
*/
static char  *regnames[] = {
        "R0", "R1", "R2", "R3", "R4", "R5", "R6", "R7",
        "R8", "R9", "R10", "R11", "R12", "R13", "R14", 
        "PC", "CPSR"
};

#define REGTOT  (sizeof regnames/sizeof(char *))
ulong regtbl[REGTOT];
ulong regtblbak[REGTOT];

int putreg(char *name, ulong value);
int getreg(char *name, ulong *value);

char *PrHelp[] = {
        "Put (modify) register",
        "{regname} {value}",
        0
};

int
Pr(argc,argv)
int argc;
char    *argv[];
{
    int i;

    if ((argc == 2) && !strcmp(argv[1],"restore")) {
        for(i=0;i<REGTOT;i++)
            regtbl[i] = regtblbak[i];
        return(0);
    }

    if (argc != 3)
        return(-1);

    putreg(argv[1],strtol(argv[2],(char **)0,0));

    return 0;
}

void
regbackup()
{
    int i;

    for(i=0;i<REGTOT;i++)
        regtblbak[i] = regtbl[i];
}

char *DrHelp[] = {
        "Display registers",
        "[regname]",
        0,
};

int
Dr(argc,argv)
int argc;
char    *argv[];
{
    ulong   reg;

    if (argc == 1) {
        showregs();
        return(0);
    }

    if (getreg(argv[1],&reg) == 0)
        printf("%s = 0x%x\n",argv[1],reg);
    else
        printf("Illegal Register: '%s'\n",argv[1]);
    return(0);
}

int
putreg(name,value)
char    *name;
ulong   value;
{
    int i;
    char    *p;

    p = name;
    while(*p) {
        *p = toupper(*p);
        p++;
    }

    /* Handle aliases */
    if (!strcmp(name,"SP"))
        name="R13";
    if (!strcmp(name,"LR"))
        name="R14";
    if (!strcmp(name,"R15"))
        name="PC";

    for(i=0; i<REGTOT; i++) {
        if (!strcmp(name,regnames[i])) {
            regtbl[i] = value;
            return(0);
        }
    }
    printf("Illegal Register: '%s'\n",name);
    return(-1);
}

int
getreg(name,value)
char    *name;
ulong   *value;
{
    int i;
    char    *p;

    p = name;
    while(*p) {
        *p = toupper(*p);
        p++;
    }

    /* Handle aliases */
    if (!strcmp(name,"SP"))
        name="R13";
    if (!strcmp(name,"LR"))
        name="R14";
    if (!strcmp(name,"R15"))
        name="PC";

    for(i=0;i<REGTOT;i++) {
        if (!strcmp(name,regnames[i])) {
            *value = regtbl[i];
            return(0);
        }
    }
    printf("Illegal Register: '%s'\n",name);

    return(-1);
}

void
showregs()
{
    int i, j;

    for(i=0;i<REGTOT;) {
        for(j=0;((j<4) && (i<REGTOT));j++,i++)
            printf("%4s=0x%08x ",regnames[i],regtbl[i]);
        printf("\n");
    }
}

void
reginit()
{
    int i;

    for(i=0;i<REGTOT;i++)
        regtbl[i] = 0;
}
