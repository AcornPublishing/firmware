#include "config.h"
#include "cpu.h"
#include "stddefs.h"
#include "genlib.h"

extern  void InitUART(), CSInfo(), InitMonSTATUS();

static  ulong   MonitorSTATUS;

void mstatshow();

char *MstatHelp[] = {
    "Monitor status",
    "-[b:Hhcs:]",
    " -b {baud}  set baud rate",
    " -c         dump chip-select info",
    " -s {val}   set monitor state",
    0,
};

int
Mstat(int argc,char **argv)
{
    int opt;

    /* If no args, just dump current status. */
    if (argc == 1) {
        mstatshow();
        return(0);
    }

    while ((opt=getopt(argc,argv,"b:cs:x:")) != -1) {
        switch(opt) {
        case 'b':
            InitUART(atoi(optarg));
            break;
        case 'c':
            CSInfo();
            return(0);
        case 's':
            InitMonSTATUS((ushort)strtol(optarg,0,0));
            break;
        case 'x':
            return(0);
        default:
            return(0);
        }
    }
    if (argc != optind)
        return(-1);
    return(0);
}

/*
 * Set the Current Program Status Register.
 */
void
putpsr(ulong psr)
{
    /*
     * The first argument is in R0.
     */
    asm("   msr CPSR_c, r0");
}

/*
 * Return the Current Program Status Register.
 */
ulong
getpsr()
{
    /*
     * The return values are placed in R0.
     */
    asm("   mrs r0, CPSR");
}

ulong
getsp()
{
    /*
     * The stack pointer is register 13 (R13)
     */
    asm("   mov r0, r13");
}

void
InitMonSTATUS(ulong state)
{
    MonitorSTATUS = state;
    putpsr((ulong)MonitorSTATUS);
}

void
SetMonSTATUS()
{
    putpsr((ulong)MonitorSTATUS);
}

void
mstatshow()
{
    extern  int monState();

    monHeader(0);
    mstatshowcom();
    printf("Current:\n");
    printf(" SP:   0x%08x\n",(ulong)getsp());
    printf(" CPSR: 0x%08x\n",(ulong)getpsr());
    printf("Monitor STATE: %d\n",monState());
}
