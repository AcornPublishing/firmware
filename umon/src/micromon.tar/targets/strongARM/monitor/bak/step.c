/* step.c:
   This is not a complete implementation of single stepping for the SH2.
   Currently, only basic stepping works... If the instruction is a jump
   or a branch then the stepper gets confused.  I need to implement the code
   that will determine the branch address based on the opcode and flags. 
*/
#include "config.h"
#include "cpu.h"
#if INCLUDE_DEBUG

#error "NOT IMPLEMENTED YET: Coppied form ppc860 port"

typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned char uchar;

extern  int StateOfMonitor, optind;
extern  void setTraceBit(), clrTraceBit(), resume(), installatpoints();
extern  void removeatpoints(), monrestart();
extern  int getopt(), disass(), printf(), settrap();
extern  long strtol(), getreg();

int StepCount, StepQuiet;
extern  ushort *AddrAfterBP, InstAfterBP;

char *SsHelp[] = {
        "Single step",
        "-[o] [count]",
        " -o   step over function",
        0,
};

Ss(argc,argv)
int argc;
char    *argv[];
{
    ulong   pc;
    int opt, StepOver;

    StepOver = 0;
    StepQuiet = 0;
    while((opt=getopt(argc,argv,"oq")) != -1) {
        switch(opt) {
        case 'o':
            StepOver = 1;
            break;
        case 'q':
            StepQuiet = 1;
            break;
        default:
            return(0);
        }
    }
    if (argc-(optind-1) == 2)
        StepCount = strtol(argv[optind],(char **)0,0);
    else
        StepCount = 1;

    if (StepOver)
        StepCount = 1;

    getreg("PC",&AddrAfterBP);
    if (StepOver) 
        AddrAfterBP++;
    AddrAfterBP++;
    InstAfterBP = settrap(AddrAfterBP);
    StateOfMonitor = SSTEP;
    resume();
}

didStep(ulong pc)
{
#if INCLUDE_DISASSEMBLER
    if (!StepQuiet)
        disass(pc,1,1);
#endif
    StepCount--;
    if (StepCount) {
        AddrAfterBP = (ushort *)(pc+2);
        InstAfterBP = settrap(AddrAfterBP);
        resume();
    }
    monrestart(SSTEP);
}

#endif
