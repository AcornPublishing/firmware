/* Monitor configuration file.
*/

/* DEFAULT_ETHERADD & DEFAULT_IPADD:
   Refer to notes in ethernet.c function EthernetStartup() for details
   regarding the use of these definitions.  */
#define     DEFAULT_ETHERADD "00:23:45:67:89:ab"
#define     DEFAULT_IPADD    "192.168.1.233"
/* #define  DEFAULT_IPADD    "DHCP" */
/* #define  DEFAULT_IPADD    "BOOTP" */

/* XBUFCNT & RBUFCNT:
    Number of transmit and receive buffers allocated to ethernet.
    The total of XBUFCNT+RBUFCNT should not exceed MAXEBDS (defined in 
    mpc860.h. */
#define XBUFCNT 8
#define RBUFCNT 8

/* CLOCK_FREQUENCY:
   Frequency of the built-in clock in cycles per second.
   This is the frequency of the clock that drives the timer used to
   calibrate the LOOPS_PER_SECOND variable. If no such clock is available
   set it to 0 and configure LOOPS_PER_SECOND manually */
#define CLOCK_FREQUENCY     3686400

/* LOOPS_PER_SECOND: 
   Approximately the size of a loop that will cause
   a 1-second delay.  This can be guestimated or modified with the
   sleep -c command at the monitor command line. */
#define LOOPS_PER_SECOND    1500000

/* DHCP_RETRYCOUNT is used as a timeout for DHCP or BOOTP startup. */
/* It is kept in the cpu.h file because it is target dependent loop time. */
#define DHCP_RETRYCOUNT     500000

/* Base address used by Network Interface Modules. */
#define NIM_BASE_ADDR       0x40000000

/* Base address used by DRAM TYPE register. */
#define DRAMTYPE_BASE_ADDR  0xa0000000

/* Flash bank configuration:
    In our board there is only one bank configured for flash.
    There are two (2) 28F128J3A Intel Strata Flash, in parallel,
    and provide 32bit access. There in Bank 0.
*/
   
#define FLASHBANKS              1
#define FLASH_BANK0_WIDTH       4
#define FLASH_BANK0_BASE_ADDR   0x00000000
#define FLASH_LARGEST_SECTOR    0x40000

/* TFS definitions:
    TFSSTART:       Base address in FLASH at which TFS starts.
    TFSEND:         End address of TFS in FLASH.
    TFSSPARE:       Location of sector that is used as the spare sector
                    by TFS for defragmentation.
    TFSSPARESIZE:   Size of the spare sector used by TFS for defragmentation.
    TFSSECTORCOUNT: Number of eraseable sectors that TFS covers, not including
                    the TFSSPARE sector.
*/
#define TFSSPARESIZE    FLASH_LARGEST_SECTOR
#define TFSSECTORCOUNT  9   /* Only 10 are used by TFS, and 1 is the spare */
#define TFS_DEVTOT      1
#define TFSSTART        (FLASH_BANK0_BASE_ADDR + 0x80000) /* the umon itself */
#define TFSEND          (FLASH_BANK0_BASE_ADDR + 0x2BFFFF) /* + 9*256k */
#define TFSSPARE        (FLASH_BANK0_BASE_ADDR + 0x2C0000) /* the spare 10th */
#define TFS_EBIN_ELF    1

/* FLASH_PROTECT_SIZE is used by the flash code to determine how much of the
   boot flash is software-protected.  It is usually something to
   cover the size of the monitor executable. */
#define FLASH_PROTECT_SIZE  0x80000

/* SYMFILE is the name of a file that, if present, the monitor uses to 
   process symbols on the command line.  A symbol is a whitespace delimited
   string prefixed by a percent sign (%).  */
#define SYMFILE "symtbl"

/* Specify CPU/PLATFORM type and name so that common code can be used
   for a similar cpu, on different platforms.
   The 'TYPE' definition is used for ifdefs in the code and the 'NAME'
   is used for printfs in the code. */
#define CPU_TYPE        SA1110
#define CPU_NAME        "StrongARM-1110"
#define PLATFORM_TYPE   IAN_OR
#define PLATFORM_NAME   "inAccess Networks BlueArch"
#define CPU_LE  1

/* Specify the size of the memory block (in monitor space) that is to be
   allocated to malloc in the monitor.  Note that this size can be dynamically
   increased using the heap extension option in the heap command.  */
#define ALLOCSIZE 128*1024

/* Specify inclusion of subsystems within the monitor here.
   Subsystems are included/excluded by defining a few macros to 1/0.
   Following are the subsystem groupings based on commands and/or capability:

    INCLUDE_MEMCMDS:        dm, pm, cm, fm, sm, mt
    INCLUDE_PIO:            pio
    INCLUDE_EDIT:           edit
    INCLUDE_DEBUG:          argv, at, dr, go, pr, ss, vfy
    INCLUDE_DISASSEMBLER:   dis
    INCLUDE_UNPACK:         unpack and huffman file decompression
    INCLUDE_ETHERNET:       ether
    INCLUDE_TFS:            tfs
    INCLUDE_MALLOC:         malloc
    INCLUDE_SHELLVAR:       set and shell variables
    INCLUDE_XMODEM:         xmodem
    INCLUDE_UNZIP:          unzip and zlib file decompression
    INCLUDE_EE:             let (expression evaluator)
    INCLUDE_FLASH:          flash operations (required by TFS)
    INCLUDE_CRYPT:          unix-crypt instead of my own "cheap crypt"
                            (see common/crypt.c)
    INCLUDE_LINEEDIT:       vi-like line editor for command line interface
                            and edit.

   Note that these INCLUDE macros allow the monitor to be built in a 
   variety of configurations; some of which may put extreme limitations
   on the capability of the monitor.  For example, it is recommended that
   at least INCLUDE_ETHERNET or INCLUDE_XMODEM be defined otherwise
   there is no download capability in the monitor.  The primary function
   of these macros is to limit complexity during monitor installation on 
   a new system and to save flash space if a particular module is of no
   value.

   A starting point for building a monitor must include:
        SHELLVAR, MALLOC & XMODEM
*/
#define INCLUDE_MEMCMDS         1
#define INCLUDE_PIO             1
#define INCLUDE_EDIT            1
#define INCLUDE_DEBUG           0
#define INCLUDE_DISASSEMBLER    1
#define INCLUDE_UNPACK          0
#define INCLUDE_UNZIP           0
#define INCLUDE_ETHERNET        1
#define INCLUDE_TFTP            1
#define INCLUDE_DHCPBOOT        1
#define INCLUDE_TFS             1
#define INCLUDE_TFSCLI          1
#define INCLUDE_TFSAPI          1
#define INCLUDE_TFSSAFEDEFRAG   1
#define INCLUDE_TFSSCRIPT       1
#define INCLUDE_TFSSYMTBL       1
#define INCLUDE_XMODEM          1
#define INCLUDE_LINEEDIT        1
#define INCLUDE_EE              0
#define INCLUDE_FLASH           1
#define INCLUDE_FPGA            1
#define INCLUDE_CRYPT           1
#define INCLUDE_EXCTEST         0
#define INCLUDE_IDEV            0
#define INCLUDE_STRACE          0
#define INCLUDE_CAST            0

/* Inclusion of this next file will make sure that all of the above
 * inclusions are legal; and adjust where necessary.
 */
#include "inc_check.h"
