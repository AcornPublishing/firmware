/* tfsdev.h:
    This file is ONLY included by tfs.c.  It is seperate from tfs.h because
    it is target-specific.  It is not part of config.h because it includes
    the declaration of the tfsdevtbl[].
    A prefix in the name of the file determines what device is used to store
    that file.  If no prefix is found the the first device in the table is
    used as a default.  The syntax of the prefix is "//STRING/" where STRING
    is user-definable, but the initial // and final / are required by tfs
    code.
*/

struct tfsdev tfsdevtbl[] = {
    {   "//800/",
        TFSSTART,
        TFSEND,
        TFSSPARE,
        TFSSPARESIZE,
        TFSSECTORCOUNT,
        TFS_DEVTYPE_FLASH, },

#if 0   /* We may want to use part of the 040 boot device for TFS... */
        /* (this can only be used if the monitor is not using the space) */
    {   "//040/",
        0x80040000,
        0x8006ffff,
        0x80070000,
        0x10000,
        3,
        TFS_DEVTYPE_FLASH, },
#endif

#if 0   /* This allows us to make some of the DRAM TFS space (just to try). */
        /* If we were using this, then config.h would have 3 flash banks. */

    {   "//RAM/",
        FLASHRAM_BASE,
        FLASHRAM_END-FLASHRAM_SSIZE,
        FLASHRAM_END-FLASHRAM_SSIZE+1,
        FLASHRAM_SSIZE,
        (FLASHRAM_SIZE/FLASHRAM_SSIZE)-1,
        TFS_DEVTYPE_RAM },
#endif
    { 0, TFSEOT,0,0,0,0,0 }
};
