#include "config.h"
#include "cpuio.h"
#include "stddefs.h"
#include "ether.h"
#include "genlib.h"
#include "SA-1100.h"

int (*remoteputchar)(), (*remotegetchar)(), (*remotegotachar)();
int (*remoterawon)(), (*remoterawoff)();

int ConsoleBaudRate;

void
InitUART(int baud)
{
    int brd;
    
    if (baud == 0)
        baud = ConsoleBaudRate;

    /* Keep track of the last baud rate, so that it can be used if the */
    /* incoming baudrate is NULL. */
    ConsoleBaudRate = baud;

    /*
     * ARM specific SERIAL port initialization stuff.
     */
    /* Theory of operations:
     * - Flush the output buffer
     * - switch receiver and transmitter off
     * - clear all sticky bits in control register 3
     * - set the port to sensible defaults (no break, no interrupts,
     *   no parity, 8 databits, 1 stopbit, transmitter and
     *   receiver enabled
     * - set the baudrate to the requested value
     * - turn the receiver and transmitter back on
     *  BAUD  RATE(bps)
     *    11  19200
     *    23   9600
     *    47   4800
     *    95   2400
     *   191   1200
     */
    /*
     * Given the baudrate calculate the baud rate divisor.
     * See SA-1110 Developer's Manual pg.11-115.
     */
    brd = (int)((3686400/(16*baud))-1);
#if defined USE_SERIAL1
    while(Ser1UTSR1 & UTSR1_TBY);
    Ser1UTCR3 = 0x00;
    Ser1UTSR0 = 0xff;
    Ser1UTCR0 = ( UTCR0_1StpBit | UTCR0_8BitData );
    Ser1UTCR1 = 0;
    Ser1UTCR2 = (unsigned long)brd;
    Ser1UTCR3 = ( UTCR3_RXE | UTCR3_TXE );
#elif defined USE_SERIAL3
    while(Ser3UTSR1 & UTSR1_TBY);
    Ser3UTCR3 = 0x00;
    Ser3UTSR0 = 0xff;
    Ser3UTCR0 = ( UTCR0_1StpBit | UTCR0_8BitData );
    Ser3UTCR1 = 0;
    Ser3UTCR2 = (unsigned long)brd;
    Ser3UTCR3 = ( UTCR3_RXE | UTCR3_TXE );
#else
#error "Configuration error: No serial port used at all!"
#endif

    /* Null out the remote "CHARFUNC_" functions. */
    InitRemoteIO();
}

int
devInit(int baud)
{
    InitUART(baud);
    return(0);
}

/* rawon() & rawoff():
    Used primarily by xmodem.  When xmodem runs, it must be assured that
    the interface is in RAW mode.  For the case of the monitor alone, it
    will always be in a raw mode.  These functions are primarily for use
    when an application has re-loaded the serial driver and may have put
    it in a non-raw mode.  The mon_con() calls CHARFUNC_RAWMODEON and
    CHARFUNC_RAWMODEOFF establish these pointers.
*/
void
rawon(void)
{
    if (remoterawon)
        remoterawon();
}

void
rawoff(void)
{
    if (remoterawoff)
        remoterawoff();
}

/* rputchar():
    Raw put char.
*/
int
rputchar(char c)
{
    /* First check to see if the default rputchar() function has */
    /* been overridden... */
    if (remoteputchar) {
        remoteputchar(c);
        return(c);
    }

    /* wait for room in the tx FIFO */
#if defined USE_SERIAL1
    while((Ser1UTSR0 & UTSR0_TFS) == 0);
#elif defined USE_SERIAL3       
    while((Ser3UTSR0 & UTSR0_TFS) == 0);
#else
#error "Configuration error: No serial port used at all!"
#endif

#if INCLUDE_ETHERNET
    SendIPMonChar(c,0);
#endif

    /* write the character */
#if defined USE_SERIAL1
    Ser1UTDR = c;
#elif defined USE_SERIAL3       
    Ser3UTDR = c;
#else
#error "Configuration error: No serial port used at all!"
#endif

    return((int)c);
}

/* getchar():
    Block on the Uart's status until a byte is available in the 
    receive buffer, then return with it.
*/
int 
getchar()
{
    char    c;
    int     err;

    /* First check to see if the default getchar() function has */
    /* been overridden... */
    if (remotegetchar)
        return(remotegetchar());
    
    /* Wait for character present: */
#if defined USE_SERIAL1
    while((Ser1UTSR1 & UTSR1_RNE) == 0) {
#elif defined USE_SERIAL3
    while((Ser3UTSR1 & UTSR1_RNE) == 0) {
#else
#error "Configuration error: No serial port at all"
#endif

#if INCLUDE_ETHERNET
        pollethernet();
#endif
    }

    /* Retrieve character */
#if defined USE_SERIAL1
        err = Ser1UTSR1 & (UTSR1_PRE | UTSR1_FRE | UTSR1_ROR);
        c = (char)Ser1UTDR;
#elif defined USE_SERIAL3
        err = Ser3UTSR1 & (UTSR1_PRE | UTSR1_FRE | UTSR1_ROR);
        c = (char)Ser3UTDR;
#else
#error "Configuration error: No serial port at all"
#endif

    /* Check status bits ... */
    if(err & UTSR1_PRE)
        rputchar('@');
    else if(err & UTSR1_FRE)
        rputchar('#');
    else if(err & UTSR1_ROR)
        rputchar('$');

    return((int)c);
}

/*
 * Return 1 if there is at least one char in RX fifo,
 * else return 0.
 */
int
gotachar()
{
#if defined USE_SERIAL1
    if(Ser1UTSR1 & UTSR1_RNE)
#elif defined USE_SERIAL3
    if(Ser3UTSR1 & UTSR1_RNE)
#else
#error "Configuration error: No serial port at all"
#endif
        return(1);
    else
        return(0);
}

/* Enable/Disable BreakInterrupt():
   Called by monitor to simply enable or disable the processor's
   ability to generate an interrupt when a break condition is detected
   on SCC1 which is used as the debug port.
*/
void
EnableBreakInterrupt()
{
    /* ??? */
}

void
DisableBreakInterrupt()
{
    /* ??? */
}

/* assignputchar():
   This allows the default rputchar function to be overridden with another
   function.  This is particularly useful for this processor because if an
   application uses it's own serial port driver, then all of the buffer
   descriptor stuff in the monitor is overridden so a call to rputchar() after
   the application has taken over and re-loaded the buffer descriptors would
   not work.  Being able to assign a remote rputchar() function allows the
   application to take over the uart, but still allows it to call monitor
   functions that may call rputchar() (which would be directed back to the
   application's putchar function).
*/

void
assignputchar(func)
int (*func)();
{
    remoteputchar = func;
}

void
assigngetchar(func)
int (*func)();
{
    remotegetchar = func;
}


/* NA here ... */
void
setTraceBit()
{
    /* ??? */
}

void
clrTraceBit()
{
    /* ??? */
}

char *
portSize(unsigned long ps)
{
    /* ??? */
    switch(ps) {
        case 0x00000c00:
            return("rsvd");
        case 0x00000000:
            return("32");
        case 0x00000400:
            return(" 8");
        case 0x00000800:
            return("16");
    }
    return("???");
}

char *
CSDeviceNames[] = {
    "Boot Flash (29F040)",
    "DRAM Bank 1",
    "DRAM Bank 2",
    "Secondary Flash (29F800)",
    "Network Interface Modules",
    "DRAM Type Register",
    "Bus Expansion",
    "Bus Expansion",
};

void
CSInfo()
{
    /* ??? */
}

void
cpu_reset (void)
{
    RSRR = 1;
}

void
delayInit (void)
{
    register int i;

    /* autocalibrate LoopsPerSecond */
    if (CLOCK_FREQUENCY) {
        i = 0;
        OSCR = 0x0;
        while (OSCR < CLOCK_FREQUENCY) {
            i++;
        }
        LoopsPerSecond = i;
    }

}

void
initCPUio()
{

}
