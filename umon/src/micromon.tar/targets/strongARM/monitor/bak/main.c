/* main.c:

    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
    phone:  908-582-2351            (home: 908-889-5161)
*/

#include "config.h"
#include "info.h"
#include "cpu.h"
#include "tfs.h"
#include "tfsprivate.h"
#include "monapp.h"
#include "monflags.h"
#include "ether.h"
#include "genlib.h"
#include "stddefs.h"
#include "except.h"

/************************************************************************/

extern  void putpsr(ulong);
extern  ulong getpsr();
extern  void InitMonSTATUS(ulong);

int     StateOfMonitor, AppExitStatus;
extern  ulong   APPLICATION_RAMSTART;
extern  void init1(), init2(), init3();
void    reinit();

/************************************************************************/

int
main(int argc,char *argv[])
{
    /* Set user level to its max, then allow monrc file to adjust it. */
    initUsrLvl(MAXUSRLEVEL);

    switch(StateOfMonitor) {
    case INITIALIZE:
        InitMonSTATUS(getpsr());
        /* Second phase of hardware initialization. */
        init2();
        /* Init register data structures. */
        reginit();         
        /* Initialize target-independent stuff. */
        init3();
        break;
    case MISC:
    case SSTEP:
    case BAILOUT:
    case MORESTART:
    case BREAKPOINT:
#if INCLUDE_DEBUG
        regbackup();
#endif
        break;
    case APP_EXIT:
        reinit();
        printf("\nApplication Exit Status: %d (0x%x)\n",
            AppExitStatus,AppExitStatus);
        break;
    case EXCEPTION:
        reinit();
        printf("\nEXCEPTION occurred near 0x%lx\n\n",ExceptionAddr);
        showregs();
        exceptionAutoRestart(INITIALIZE);
        break;
    default:
        printf("Unexpected monitor state: 0x%x\n",StateOfMonitor);
        break;
    }

    /* Enter the endless loop of command processing: */
    CommandLoop();

    return(0); /* make gcc happy */
}

/************************************************************************/

void
reinit()
{
    init1(0);                   /* reinit hardware */
    init2();
#if INCLUDE_ETHERNET
    EthernetStartup(0,0);       /* reinit ethernet, without DHCP/BOOTP */
#endif
}

/************************************************************************/

void
init2()
{
#if INCLUDE_FLASH
    FlashInit();        /* Init flashop data structures.  This MUST be */
                        /* done prior to turning on cache!!! */
#endif

    cacheInit();        /* Initialize cache. */

    delayInit();

#if INCLUDE_ETHERNET
    enreset();          /* Clear the ethernet interface. */
#endif
    /* ??? */
#if INCLUDE_TFS
    tfsstartup();       /* Init tfs data structures. */
#endif
}

/************************************************************************/

void
monrestart(int val)
{
    warmstart(val);
}

void
monreset(int val)
{
    lukewarmstart(val);
}

void
monreboot(int val)
{
    coldstart();
}

/************************************************************************/

void
intsrestore(psr)
ulong     psr;
{
    putpsr(psr);
}

/*
 * Read the program status register (CPSR)
 * and set the FIQ and IRQ bits.
 */
ulong
intsoff()
{
    ulong  psr;

    psr = getpsr();

    /*
     * Set bit 6, bit 7 to disable interrupts.
     */
    putpsr(psr | 0x000000c0);
    return(psr);
}

/************************************************************************/

/* some stubs for now... */
void
ctxMON()
{
}

void
ctxAPP()
{
}

/************************************************************************/

void
appexit(int val)
{
    intsoff();

    AppExitStatus = val;
#if INCLUDE_DEBUG
    removeatpoints();
#endif
    SWI_APP_EXIT;
}

/************************************************************************/

ulong
monState()
{
    return(StateOfMonitor);
}

/************************************************************************/

/* cacheInitForTarget():
    Enable instruction cache only...
*/
void
cacheInitForTarget()
{
    asm("   MRC p15, 0, r0, c1, c0, 0");
    asm("   ORR r0, r0, #0x1000");  /* bit 12 is ICACHE enable*/
    asm("   MCR p15, 0, r0, c1, c0, 0");

    /* Flush instruction cache */
    asm("   MCR p15, 0, r0, c7, c5, 0");
}

/************************************************************************/

/* extValidPassword():
    Refer to validPassword() in common/password.c for notes.
*/
int
extValidPassword(char *password, int ulvl)
{
    return(-1);
}

/************************************************************************/
