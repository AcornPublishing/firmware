/* etherdev.c:
 *  Micromonitor Ethernet support 
 *  for the NE2000 compatible AX88196 FE MAC controller.
 *
 *  Based on the respective polling driver for mpc860.
 *  and on the NE2000 driver for Linux by D.Becker.
 *  
 *  TODO: statistics not yet implemented properly.
 *
 *  by Thomas E. Arvanitis (tharvan@inaccessnetworks.com)
 */

#include "config.h"
#if INCLUDE_ETHERNET
#include "cpuio.h"
#include "ether.h"
#include "stddefs.h"
#include "genlib.h"
#include "8390.h"
#include "SA-1100.h"

extern void docommand(char *cmdline,int verbose);

int EtherRLCnt, EtherDEFCnt, EtherLCCnt, EtherDRVRETRYCnt;
int eninit();
int txbuf_lock;

long    e8390_base = NE_BASE;
static  uchar txbuf[1600];
static  uchar rxbuf[RBUFCNT][1600];
int     rx_index;

/*
 * Routines for easy acces to the data fifo.
 * They assume that the 8390 is in 68000 mode.
 * i.e. |   LSB   |   MSB   |
 *      15       8 7         0
 * Len in bytes.
 */
inline static void memcpy_to_dataport(unsigned int port, const void *from, int len)
{
    register int i;
    register const unsigned short *f = from;
    register volatile unsigned short *t = (unsigned short *)port;

    for (i = 0; i < len / 2; i++) {
        *t = *f;
        f++;
    }
}

inline static void memcpy_from_dataport(unsigned int port, void *to, int len)
{
    register int i;
    register volatile unsigned short *f = (unsigned short *)port;
    register unsigned short *t = to;

    for (i = 0; i < len / 2; i++) {
        *t = *f;
        t++;
    }
}

/* ShowEtherdevStats():
   Called by the command "ether stat" on the monitor's command line.
   This function and a common ShowEthernetStats() are used to dump
   generic as well as device-specific ethernet driver statistics.
*/
void
ShowEtherdevStats()
{
    printf("Driver retry count:      %d\n",EtherDRVRETRYCnt);
    printf("Retry-count exceeded:    %d times\n",EtherRLCnt);
    printf("Late-collision count:    %d\n",EtherLCCnt);
    printf("Defer-indication count:  %d\n",EtherDEFCnt);
}

/* EtherdevStartup():
    Called by EthernetStartup().  Initialize all device-specific 
    counters, reset and initialized the ethernet device.
*/
int
EtherdevStartup(int verbose)
{
    EtherRLCnt = 0;
    EtherLCCnt = 0;
    EtherDEFCnt = 0;
    EtherDRVRETRYCnt = 0;

    /* Put ethernet controller in reset: */
    enreset();

    /* Initialize controller: */
    eninit();

    return(0);
}

/* DisableEtherdev():
    Called by DisableEthernet() to do the device-specific portion of 
    the turn-down.
*/
void
DisableEtherdev()
{
    enreset();
}

void
enreset()
{
    volatile int i;
    int timeout;
    ulong msk;

    /*
     * Issue the timeout command to the controller, and then wait
     * for the completion.
     * Should make the timeout configurable (or simply a define?)
     */
    outb(inb(NE_BASE + NE_RESET), NE_BASE + NE_RESET);
    timeout = 500000;
    while ((inb(NE_BASE+EN0_ISR) & ENISR_RESET) == 0) {
        timeout--;
        if (timeout <=0)
            break;
    }

    /* 
     * Ack intr. 
     */
    outb(ENISR_RESET, NE_BASE + EN0_ISR);
    
    /*
     * inAccess Networks BlueArch board specific.
     * Toggle the reset pin of both the MAC and PHY.
     */
    msk = 0x00000001UL << 3;
    msk &= 0x0FFFFFFF;
    GPDR |= msk;
    GPCR = msk;
    for (i = 0; i < 100000; i++);
    GPDR |= msk;
    GPSR = msk;
    msk = 0x00000001UL << 13;
    msk &= 0x0FFFFFFF;
    GPDR |= msk;
    GPCR = msk;
    for (i = 0; i < 100000; i++);
    GPDR |= msk;
    GPSR = msk;
}

/* 
 * eninit():
 *  These is following the guidelines of National App. Note 874
 *  along with what D.Becker has done on the respective Linux driver.
 */
int
eninit()
{
    int i;
    int endcfg;
    ulong msk;

    if (sizeof(struct e8390_pkt_hdr)!=4) {
        printf("etherdev.c: header struct mispacked\n");
        return(-1);
    }

    /* 
     * inAccess Networks BlueArch board specific.
     * Initialize clocks for xilinx 
     * and then call xlnx to program the xilinx.
     * It expects an oprouter.bit file in TFS.
     */
    msk = 0x00000001UL << 26;
    msk &= 0x0FFFFFFF;
    GAFR |= msk;
    GPDR |= msk;
    outl(0x80000000, 0x90030008);

    docommand("xlnx -f oprouter.bit", 0);
    
    /*
     * Follow National Semi's recommendations for initing the DP8390.
     */

    /*
     * Select Page 0
     */
    outb(E8390_NODMA+E8390_PAGE0+E8390_STOP, e8390_base+E8390_CMD); /* 0x21 */

    /* 
     * Select: word-wide DMA transfers,  68k byte order.
     */
    endcfg = 0x3;
    outb(endcfg, e8390_base + EN0_DCFG); 

    /*
     * Clear the remote byte count registers.
     */
    outb(0x00,  e8390_base + EN0_RCNTLO);
    outb(0x00,  e8390_base + EN0_RCNTHI);

    /*
     * Initialize Receive Configuration Register
     * Just set to monitor mode.
     */
    outb(E8390_RXOFF, e8390_base + EN0_RXCR); /* 0x20 */

    /* 
     * Initialize Trasnmit Configuration Register
     * Just set to internal loopback mode.
     */
    outb(E8390_TXOFF, e8390_base + EN0_TXCR); /* 0x02 */
    
    /* 
     * Set the transmit page and receive ring. 
     */
    outb(NESM_TX_START_PG, e8390_base + EN0_TPSR);
    outb(NESM_RX_START_PG, e8390_base + EN0_STARTPG);
    outb(NESM_RX_START_PG, e8390_base + EN0_BOUNDARY);
    outb(NESM_RX_STOP_PG, e8390_base + EN0_STOPPG);

    /* 
     * Clear the pending interrupts and mask. 
     */
    outb(0xff, e8390_base + EN0_ISR);
    outb(0x00,  e8390_base + EN0_IMR);

    /*
     * Copy the station address into the DS8390 registers. 
     */
    outb(E8390_NODMA + E8390_PAGE1 + E8390_STOP, e8390_base+E8390_CMD); /* 0x61 */
    for(i = 1; i < 7; i++) {
        outb(BinEnetAddr[i-1], e8390_base + EI_SHIFT(i));
        if(inb(e8390_base + EI_SHIFT(i))!=BinEnetAddr[i-1])
            printf("Hw. address read/write mismap %d\n",i);
    }

    /*
     * Finally initialize the Current page reg;
     */
    outb(NESM_RX_START_PG+1, e8390_base + EN1_CURPAG);
    outb(E8390_NODMA+E8390_PAGE0+E8390_STOP, e8390_base+E8390_CMD);
    rx_index = 0;

    /*
     * Clear ISR, mask all in IMR, issue start and enable tx and rx.
     */
    outb(0xff,  e8390_base + EN0_ISR);
    outb(0x00,  e8390_base + EN0_IMR);
    outb(E8390_NODMA+E8390_PAGE0+E8390_START, e8390_base+E8390_CMD);
    outb(E8390_TXCONFIG, e8390_base + EN0_TXCR); /* xmit on. */
    outb(E8390_RXCONFIG, e8390_base + EN0_RXCR); /* rx on,  */
    
    return(0);
}

/* enselftest():
    1. Enable ethernet interface.
    2. Put the PHY in loopback.
    3. Send a packet, and see if that packet is received.
    4. Disable the ethernet interface.
    Return 1 if passed, else -1.

    Curently not implemented.
*/
int
enselftest(int verbose)
{
    if (verbose)
        printf("Self test not available\n");

    return(1);
}

/* geteinbuf():
    Get ethernet input buffer...
    Do whatever is necessary to pull the packet out of the ethernet device
    and pass that packet (along with the size of the packet) to the
    processPACKET() function.
*/
static int
geteinbuf()
{
    int rx_pkt_count;
    int pkt_len, pkt_stat;
    unsigned short  current_offset;
    struct e8390_pkt_hdr    rx_frame_hdr;
    register unsigned char  rxing_page, this_frame, next_frame;

    rx_pkt_count = 0;

    while (1) {
        /* 
         * Get the rx page (incoming packet pointer). 
         */
        outb(E8390_NODMA+E8390_PAGE1, e8390_base + E8390_CMD);
        rxing_page = inb(e8390_base + EN1_CURPAG);
        outb(E8390_NODMA+E8390_PAGE0, e8390_base + E8390_CMD);

        /* 
         * Remove one frame from the ring.
         * Boundary is always a page behind.
         */
        this_frame = inb(e8390_base + EN0_BOUNDARY) + 1;
        if (this_frame >= NESM_RX_STOP_PG)
            this_frame = NESM_RX_START_PG;
        
        /* 
         * Read all the frames?
         * Done for now...
         */
        if (this_frame == rxing_page)
            break;

        current_offset = this_frame << 8;
        
        /*
         * Get a pick on the ethernet packet header
         * to read the size.
         */
        outb(E8390_NODMA+E8390_PAGE0+E8390_START, e8390_base+ NE_CMD);
        outb(sizeof(struct e8390_pkt_hdr), e8390_base + EN0_RCNTLO);
        outb(0, e8390_base + EN0_RCNTHI);
        outb(0, e8390_base + EN0_RSARLO);       /* On page boundary */
        outb(this_frame, e8390_base + EN0_RSARHI);
        outb(E8390_RREAD+E8390_START, e8390_base + NE_CMD);

        memcpy_from_dataport(NE_BASE + NE_DATAPORT, (void *)&rx_frame_hdr, sizeof(struct e8390_pkt_hdr));

        outb(ENISR_RDC, e8390_base + EN0_ISR);  /* Ack intr. */

        pkt_len = rx_frame_hdr.count - sizeof(struct e8390_pkt_hdr);
        pkt_stat = rx_frame_hdr.status;

        if (pkt_len < 60  ||  pkt_len > 1518) {
            printf("etherdev: bogus packet size: %d!\n",pkt_len);
        } 
        else if ((pkt_stat & 0x0F) == ENRSR_RXOK) {
            int offset;

            offset = current_offset + sizeof(rx_frame_hdr);
            
            outb(E8390_NODMA+E8390_PAGE0+E8390_START, e8390_base+ NE_CMD);
            outb(pkt_len & 0xff, e8390_base + EN0_RCNTLO);
            outb(pkt_len >> 8, e8390_base + EN0_RCNTHI);
            outb(offset & 0xff, e8390_base + EN0_RSARLO);
            outb(offset >> 8, e8390_base + EN0_RSARHI);
            outb(E8390_RREAD+E8390_START, e8390_base + NE_CMD);

            rx_index++;

            memcpy_from_dataport(NE_BASE + NE_DATAPORT, rxbuf[rx_index], pkt_len);

            if (pkt_len & 0x01) {
                rxbuf[rx_index][pkt_len - 1] = inb(NE_BASE + NE_DATAPORT);
            }

            outb(ENISR_RDC, e8390_base + EN0_ISR);  /* Ack intr. */
        
            next_frame = rx_frame_hdr.next;
                
            /* 
             * This _should_ never happen....
             */
            if (next_frame >= NESM_RX_STOP_PG) {
                printf("etherdev: next frame inconsistency, %#2x\n", next_frame);
                next_frame = NESM_RX_START_PG;
            }
    
            outb(next_frame-1, e8390_base+EN0_BOUNDARY);
            
            processPACKET((struct ether_header *)rxbuf[rx_index], pkt_len);
            rx_index--;
        }
        else {
            printf("etherdev: bogus packet: status=0x%02x nxpg=0x%02x size=%d\n", \
                rx_frame_hdr.status, rx_frame_hdr.next, rx_frame_hdr.count);
        }

        rx_pkt_count++;
        
    }

    return rx_pkt_count;
}

/* polletherdev():
    Called by pollethernet() to do the device-specific portion of the
    ethernet polling.  This code is the first step in processing incoming
    ethernet packets.  If a packet is available, the functino geteinbuf()
    (get ethernet input buffer) is called to pass the packet to the higher
    level processPACKET() function.
    IMPORTANT NOTE:
    This function MUST be re-entrant.  There is a possibility that the
    processPACKET() function will ultimately call polletherdev() again.
    This means that once the packet has been detected in the device, it 
    is important that this code do whatever is necessary to assure that
    the same packet will not be seen as available to the nested caller.
    In other words...
    clear the packet from the device prior to calling processPACKET().
*/
int
polletherdev()
{
    register uchar  isr;

    /*
     * Get the status
     */ 
    isr = inb(NE_BASE + EN0_ISR);
    
    if (isr & ENISR_OVER) {
        printf("ISR: we have OVERRUN!!\n");
        outb(ENISR_OVER , NE_BASE + EN0_ISR);
    }

    if (isr & ENISR_RX) {
        /* Clear the ENISR_RX bit */
        outb(ENISR_RX , NE_BASE + EN0_ISR);

        return geteinbuf();
    }

    return 0;
}

/* getXmitBuffer():
    Called by various points in the IP/UDP/ICMP code for a buffer that
    will ultimately be the next output packet.
*/
uchar *
getXmitBuffer()
{
    /*
     * I am only using one buffer for the momment.
     */
    return(txbuf);
}

/* sendBuffer():
*/
int
sendBuffer(int length)
{
    static int busy = 0;

    if (EtherVerbose &  SHOW_OUTGOING)
        printPkt((struct ether_header *)txbuf,length,ETHER_OUTGOING);

    if (busy) {
        /*  
         * wait until sending the previous packet finishes
         * and then ack the interrupt.
         */ 
        while ((inb(e8390_base+EN0_ISR) & (ENISR_TX | ENISR_TX_ERR)) == 0);
        outb(ENISR_TX | ENISR_TX_ERR, e8390_base + EN0_ISR);
        busy = 0;
    }
    
    /* Keep stats: */
    if (EtherXFRAMECnt) {
        /*
        if (prevtbptr->status & BD_DEF)
            EtherDEFCnt++;
        if (prevtbptr->status & BD_LC)
            EtherLCCnt++;
        if (prevtbptr->status & BD_RL)
            EtherRLCnt++;
        */
    }

    EtherXFRAMECnt++;

    /*
     * Now the normal output.
     * First we round up for word writes.
     */
    if (length & 0x01)
        length++;

    /*
     * Be sure that we are already in page 0.
     */
    outb(E8390_NODMA+E8390_PAGE0+E8390_START, e8390_base+E8390_CMD); /* 0x22 */
            
    /*
     * Do the remote transfer
     */
    outb(length & 0xff, e8390_base + EN0_RCNTLO);
    outb(length >> 8, e8390_base + EN0_RCNTHI);
    outb(0x0, e8390_base + EN0_RSARLO);
    outb(NESM_TX_START_PG , e8390_base + EN0_RSARHI);
    outb(E8390_RWRITE+E8390_START, e8390_base + NE_CMD);

    /*
     * Transfer the whole buffer to the data port
     * in chunks of 16bits.
     */
    memcpy_to_dataport(NE_BASE + NE_DATAPORT, txbuf, length);

    /* 
     * Then write the length to TCNT, and update TPSR
     */
    outb(length & 0xff, e8390_base + EN0_TCNTLO);
    outb(length >> 8, e8390_base + EN0_TCNTHI);
    outb(NESM_TX_START_PG, e8390_base + EN0_TPSR);

    /*
     * Issue transmit command.
     */ 
    outb(E8390_NODMA+E8390_TRANS+E8390_START, e8390_base + NE_CMD);
    busy = 1;

    return(0);
}

/* Disable/Enable either broadcast or promiscuous mode... */

void
enableBroadcastReception()
{
    uchar rcr;

    outb(E8390_NODMA+E8390_PAGE0+E8390_STOP, e8390_base+E8390_CMD); /* 0x21 */
    rcr = inb(e8390_base+EN0_RXCR);
    rcr |= E8390_RCR_AB;
    outb(rcr, e8390_base+EN0_RXCR);
    outb(E8390_NODMA+E8390_PAGE0+E8390_START, e8390_base+E8390_CMD); /* 0x22 */
}

void
disableBroadcastReception()
{
    uchar rcr;

    outb(E8390_NODMA+E8390_PAGE0+E8390_STOP, e8390_base+E8390_CMD); /* 0x21 */
    rcr = inb(e8390_base+EN0_RXCR);
    rcr &= ~E8390_RCR_AB;
    outb(rcr, e8390_base+EN0_RXCR);
    outb(E8390_NODMA+E8390_PAGE0+E8390_START, e8390_base+E8390_CMD); /* 0x22 */
}

void
enablePromiscuousReception()
{
    uchar rcr;

    outb(E8390_NODMA+E8390_PAGE0+E8390_STOP, e8390_base+E8390_CMD); /* 0x21 */
    rcr = inb(e8390_base+EN0_RXCR);
    rcr |= E8390_RCR_PRO;
    outb(rcr, e8390_base+EN0_RXCR);
    outb(E8390_NODMA+E8390_PAGE0+E8390_START, e8390_base+E8390_CMD); /* 0x22 */
}

void
disablePromiscuousReception()
{
    uchar rcr;

    outb(E8390_NODMA+E8390_PAGE0+E8390_STOP, e8390_base+E8390_CMD); /* 0x21 */
    rcr = inb(e8390_base+EN0_RXCR);
    rcr &= ~E8390_RCR_PRO;
    outb(rcr, e8390_base+EN0_RXCR);
    outb(E8390_NODMA+E8390_PAGE0+E8390_START, e8390_base+E8390_CMD); /* 0x22 */
}

void
enresetmmu()
{}

/* extGetIpAdd() & extGetEtherAdd():
    These two functions are stubs that allow a user to insert an external
    interface into the standard mechanism that MicroMonitor uses to 
    retrieve its IP and MAC address.  If not used, they simply return NULL.
    If used, they should return an ascii string that represents either the
    IP or MAC address to be assigned to this target.
*/
char *
extGetIpAdd()
{
    return((char *)0);
}

char *
extGetEtherAdd()
{
    return((char *)0);
}

#endif
