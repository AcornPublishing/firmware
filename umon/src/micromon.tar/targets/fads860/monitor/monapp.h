/* This header file is used by both the application and the monitor.
   It is the linkage used to establish a communication path between the 
   monitor and the application.
*/
#include "monlib.h"

#define STD_CMD     0
#define SU_CMD      1

#define MONVEC 255
#define GLOBALINTBASE 99

#define CMDLINESIZE 128
#define ARGCNT      24
