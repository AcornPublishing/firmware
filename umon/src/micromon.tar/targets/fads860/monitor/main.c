/* main.c:

    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
    phone:  908-582-2351            (home: 908-889-5161)
*/
#include "config.h"
#include "cpu.h"
#include "tfs.h"
#include "tfsprivate.h"
#include "monapp.h"
#include "monflags.h"
#include "masks860.h"
#include "ether.h"
#include "genlib.h"
#include "stddefs.h"
#include "arch_ppc.h"


int     StateOfMonitor, AppExitStatus;
extern  ulong   APPLICATION_RAMSTART;
extern  void init1(), init2(), init3();
void    reinit();

int
main(int argc,char *argv[])
{
    char    ename[48];

    /* Set user level to its max, then allow monrc file to adjust it. */
    initUsrLvl(MAXUSRLEVEL);

    switch(StateOfMonitor) {
    case INITIALIZE:
        /* Second phase of hardware initialization. */
        init2();
        /* Init register data structures. */
        reginit();
        /* Initialize target-independent stuff. */
        init3();
        break;
    case MISC:
    case SSTEP:
    case BAILOUT:
    case MORESTART:
    case BREAKPOINT:
#if INCLUDE_DEBUG
        regbackup();
#endif
        break;
    case APP_EXIT:
        reinit();
        printf("\nApplication Exit Status: %d (0x%x)\n",
            AppExitStatus,AppExitStatus);
        break;
    case EXCEPTION:
        reinit();
        printf("\nEXCEPTION: '%s'\n Occurred near 0x%lx",
            ExceptionType2String(ExceptionType),ExceptionAddr);
        if (AddrToSym(-1,ExceptionAddr,ename,0))
            printf(" (within %s)",ename);
        printf("\n\n");
/*      showregs(); */
        exceptionAutoRestart(INITIALIZE);
        break;
    default:
        printf("Unexpected monitor state: 0x%x\n",StateOfMonitor);
        break;
    }

    /* Enter the endless loop of command processing: */
    CommandLoop();

    /* Should not get here. */
    return(0);
}

void
reinit()
{
    init1(0);                   /* reinit hdware */
    init2();
#if INCLUDE_ETHERNET
    EthernetStartup(0,0);       /* reinit ethernet, without DHCP/BOOTP */
#endif
}

void
init2()
{
#if INCLUDE_FLASH
    FlashInit();        /* Init flashop data structures.  This MUST be */
                        /* done prior to turning on cache!!! */
#endif

    cacheInit();        /* Initialize cache. */

#if INCLUDE_ETHERNET
    enreset();          /* Clear the ethernet interface. */
#endif
#if INCLUDE_TFS
    tfsstartup();       /* Init tfs data structures. */
#endif
}

void
monrestart(int val)
{
    warmstart(val);
}

void
intsrestore(ulong msr)
{
    ppcMtmsr(msr);
}

ulong
intsoff()
{
    ulong  msr;

    msr = ppcMfmsr();
    ppcMtmsr(msr & ~0x8000);
    return(msr);
}

/* some stubs for now... */
void
ctxMON()
{
}

void
ctxAPP()
{
}

void
appexit(int val)
{
    extern  void flush_console(void);

    intsoff();
    flush_console();
    AppExitStatus = val;
#if INCLUDE_DEBUG
    removeatpoints();
#endif
    warmstart(APP_EXIT);
}

ulong
monState()
{
    return(StateOfMonitor);
}

/* cacheInitForTarget():
    Enable instruction cache only...
*/
void
cacheInitForTarget()
{
    asm(".equ   r3,3");
    asm(".equ   IC_CST,560");

    asm("   mfspr   r3,IC_CST");    
    asm("   lis     r3,0x0200");
    asm("   mtspr   IC_CST,r3");
    asm("   isync");
}

/* extValidPassword():
    Refer to validPassword() in common/password.c for notes.
*/
int
extValidPassword(char *password, int ulvl)
{
    return(-1);
}
