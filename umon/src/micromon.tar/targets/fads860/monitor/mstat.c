#include "config.h"
#include "cpu.h"
#include "stddefs.h"
#include "genlib.h"
#include "arch_ppc.h"

extern  void InitUART(), CSInfo(), InitMonSTATUS(), init_slot();

static  ushort  MonitorSTATUS;

void mstatshow();

char *MstatHelp[] = {
    "Monitor status",
    "-[b:Hhs:]",
    " -b {baud}  set baud rate",
    " -c         dump chip-select info",
    " -I         initialize ATLAS slots",
    " -s {val}   set monitor state",
    0,
};

int
Mstat(int argc,char **argv)
{
    int opt;

    /* If no args, just dump current status. */
    if (argc == 1) {
        mstatshow();
        return(0);
    }

    while ((opt=getopt(argc,argv,"b:cs:x:")) != -1) {
        switch(opt) {
        case 'b':
            InitUART(atoi(optarg));
            break;
        case 'c':
            CSInfo();
            return(0);
        case 's':
            InitMonSTATUS((ushort)strtol(optarg,0,0));
            break;
        case 'x':
            return(0);
        default:
            return(0);
        }
    }
    if (argc != optind)
        return(-1);
    return(0);
}

void
InitMonSTATUS(ulong state)
{
    MonitorSTATUS = state;
    ppcMtmsr((ushort)MonitorSTATUS);
}

void
SetMonSTATUS()
{
    ppcMtmsr((ushort)MonitorSTATUS);
}

void
mstatshow()
{
    extern  int monState();

    monHeader(0);
    mstatshowcom();
    printf("Current:\n");
    printf(" SP:  0x%08x\n",(ulong)ppcMfsp());
    printf(" MSR: 0x%08x\n",(ulong)ppcMfmsr());
    printf(" PVR: 0x%08x\n",ppcMfpvr());
    printf("Monitor STATE: %d\n",monState());
}
