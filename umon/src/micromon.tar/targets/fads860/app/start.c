#include "stddefs.h"
#include "arch_ppc.h"

ulong   myStack[512];

__eabi()
{
}

start()
{
    char    **argv;
    int argc;

    /* Adjust the stack pointer to be at the top of the myStack array.
     * This works because the assembler function that this is calling
     * only needs the link register to return.
     */
    ppcMtsp((ulong)&myStack[510]);

    /* Connect the application to the monitor.  This must be done
     * prior to the application making any other attempts to use the
     * "mon_" functions provided by the monitor.
     */
    monConnect((int(*)())(*(unsigned long *)0x02800004),(void *)0,(void *)0);

    /* Extract argc/argv from structure and call main():
     */
    mon_getargv(&argc,&argv);

    /* Call main, then return to monitor. */
    return(main(argc,argv));
}
