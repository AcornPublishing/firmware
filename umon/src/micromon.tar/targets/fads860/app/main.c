#include "tfs.h"
#include "monlib.h"
#include "stddefs.h"

volatile int Test_Variable;

struct test_struct {
    long    longval;
    short   shortval;
    char    array[14];
};

volatile struct test_struct Test_Structure;

void
func2(int i)
{
    mon_printf("func2(%d)\n",i);

    mon_printf("OK, by now the exception occured, type 'strace'.  This will\n");
    mon_printf("dump the function nesting at the time of the exception.\n");

    mon_printf("Issue the command: 'dm -4d %%Test_Variable 1', it\n");
    mon_printf("has been set to 14.\n");

    mon_printf("Issue the command: 'cast Test_Struct %%Test_Structure'.\n");
    mon_printf("It has been initialized to recognizable data.\n");

    mon_printf("Or just run the script 'post_exception'.\n");

    /* Setting this shell variable will tell the monitor NOT to
     * automatically restart after the exception.
     */
    mon_setenv("NO_EXCEPTION_RESTART","TRUE");

    /* Force a SYSTEM_CALL exception:
     */
    __asm__(" sc ");
}

void
func1(void)
{
    int i;

    i = mon_printf("func1()\n");
    func2(i);
}

void
nested_syscall(void)
{
    mon_printf("nested_syscall()\n");
    func1();
}

main(int argc,char *argv[])
{

    /* If this is called from the monitor command line with
     * the argument "debug", then we will do some stuff to 
     * demonstrate the monitor's capabilities...
     */
    if ((argc == 2) && (!strcmp(argv[1],"debug"))) {
        Test_Variable = 14;
        Test_Structure.longval = 0xDEADBEEF;
        Test_Structure.shortval = 0x1234;
        strcpy(Test_Structure.array,"abracadabra!");
        nested_syscall();
    }
    else {
        mon_printf("hello world\n");
        mon_printf("Type: 'app debug' at the uMON> prompt.\n");
    }
    mon_appexit(0);
}
