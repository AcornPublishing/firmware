/* cpuio.c:

    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
    phone:  908-582-2351            (home: 908-889-5161)
*/
#include "config.h"
#include "cpu.h"
#include "cpuio.h"
#include "genlib.h"
#include "ether.h"
#include "stddefs.h"

int (*remoteputchar)(), (*remotegetchar)(), (*remotegotachar)();
int (*remoterawon)(), (*remoterawoff)();
int ConsoleBaudRate;

/* InitUART():
    This function is called at startup, application exit, or by the 
    mstat -b BAUD command.
    For startup and mstat, the baud rate will be specified and used; for
    application exit, it will be 0 to indicate that whatever baud rate was
    used prior by mstat or startup should be used again.
*/
void
InitUART(baud)
int baud;
{
    int i, nn, brr;

    if (baud == 0)
        baud = ConsoleBaudRate;

    /* Keep track of the last baud rate, so that it can be used if the */
    /* incoming baudrate is NULL. */
    ConsoleBaudRate = baud;

    /* Disable the transmitter and receiver and all SCI interrupts */
    /* clear TE and RE bits and select the clock source */
    *SCR0 = 0x00;

    if (baud == DEFAULT_BAUD_RATE) {
        *BRR0 = SCI_BRR_VALUE;
        *SMR0 = 0+SCI_SCR_N_VALUE;
    }
    else {
        /* Select Bit rate counter */
        for (nn=0;nn<4;nn++) {
            brr = ((2*MON_CPU_CLOCK/32/(1<<(2*nn))/baud+1)/2-1);
            if (brr  < 256) {
                *BRR0 = (uchar)brr;
                /* Select the communications format */
                /* xxxxxxnn internal system clock phi from 300cpu.h */
                /* xxxxx0xx disable the multiprocessor function */
                /* xxxx0xxx stop bit length=> 1 bit */
                /* xxx0xxxx even parity */
                /* xx0xxxxx no parity bit is added */
                /* x0xxxxxx 8 bit character length in asynchrounous mode */
                /* 0xxxxxxx asynchrounous mode */
                *SMR0 = 0+nn;
                break;
            }
        }
        if (nn == 4) {
            *BRR0 = SCI_BRR_VALUE;
            *SMR0 = 0+SCI_SCR_N_VALUE;
        }
    }

    for (i=0;i<100000;i++); /* wait >= 1 bit time */

    /* Enable transmitter and receiver and receive interrupts */
    /* xxxxxx00 CKE0 internal clock, SCK pin available for generic i/o */
    /* xxxxx0xx CKE1 disables transmit end interrupts */
    /* xxxx0xxx MPIE disables multiprocessor interrupts */
    /* xxx1xxxx RE enable the receiver */
    /* xx1xxxxx TE enable the transmitter */
    /* x0xxxxxx RIE enable receive-data-full interrupts and receive-error int */
    /* 0xxxxxxx TIE enable disables transmit-data-empty interrupts */
    *SCR0 = (SCI_RE | SCI_TE);

    remoteputchar = (int(*)())0;
    remotegetchar = (int(*)())0;
    remotegotachar = (int(*)())0;
    remoterawon = (int(*)())0;
    remoterawoff = (int(*)())0;
}

/* The common version of start.c calls devInit(baud) instead of the older 
 * InitUART(baud).  To become compatible with this, we encapsulate InitUART()
 * with devInit() here... 
 */
int
devInit(int baud)
{
    InitUART(baud);
    return(0);
}

/* rawon() & rawoff():
    Used primarily by xmodem.  When xmodem runs, it must be assured that
    the interface is in RAW mode.  For the case of the monitor alone, it
    will always be in a raw mode.  These functions are primarily for use
    when an application has re-loaded the serial driver and may have put
    it in a non-raw mode.  The mon_con() calls CHARFUNC_RAWMODEON and
    CHARFUNC_RAWMODEOFF establish these pointers.
*/
void
rawon(void)
{
    if (remoterawon)
        remoterawon();
}

void
rawoff(void)
{
    if (remoterawoff)
        remoterawoff();
}

/* Enable/Disable BreakInterrupt():
   Called by monitor to simply enable or disable the processor's
   ability to generate an interrupt when a break condition is detected
   on SCC1 which is used as the debug port.
*/
void
EnableBreakInterrupt()
{
}

void
DisableBreakInterrupt()
{
}

void
initCPUio()
{
    /* Initialize the interrupt control registers: */
    *IPRA = 0;
    *IPRB = 0;
    *IPRC = 0;
    *IPRD = 0;
    *IPRE = 0;
    *IPRF = 0;
    *IPRG = 0;
    *IPRH = 0;
    *ICR = 0;
    *ISR = 0;
}

/* rputchar():
    Raw put char.
*/
int
rputchar(char c)
{
    uchar   ssr0;

    /* First check to see if the default rputchar() function has */
    /* been overridden... */
    if (remoteputchar) {
        remoteputchar(c);
        return((int)c);
    }

    /* Wait for empty tx buffer. */
    /* (check for errors) */
    while(1) {
        ssr0 = *SSR0;
        if (ssr0 & SCI_TDRE)
            break;
    }

    /* write data into TDR */
    *TDR0 = c;

    /* Read and clear TDRE in SSR */
    *SSR0 &= ~SCI_TDRE;

#if INCLUDE_ETHERNET
    SendIPMonChar(c,0);
#endif
    return((int)c);
}

/* getchar():
    Block on the Uart's status until a byte is available in the 
    receive buffer, then return with it.
*/
int
getchar()
{
    uchar   ssr0;
    char    ch;

    /* First check to see if the default getchar() function has */
    /* been overridden... */
    if (remotegetchar)
        return(remotegetchar());
    
    /* Wait for incoming character */
    while(1) {
        ssr0 = *SSR0;
        if (ssr0 & SCI_RDRF)
            break;
        if (ssr0 & SCI_ORER)        /* Overrun, framing or parity error? */
            *SSR0 = ~SCI_ORER;      /* Clear bit if necessary. */
        if (ssr0 & SCI_FER)
            *SSR0 = ~SCI_FER;
        if (ssr0 & SCI_PER)
            *SSR0 = ~SCI_PER;
#if INCLUDE_ETHERNET
        pollethernet();
#endif
    }

    /* read char */
    ch = *RDR0;

    /* clear rx interrupt to allow next char */
    *SSR0 &= ~SCI_RDRF;

    return((int)ch);
}

int
gotachar()
{
    /* First check to see if the default gotachar() function has */
    /* been overridden... */
    if (remotegotachar)
        return(remotegotachar());

    if(*SSR0 & SCI_RDRF)
        return(1);
    else
        return(0);
}

void
ledsOn()
{
    *PEDR &= ~0xD800;
}

void
ledsOff()
{
    *PEDR |= 0xD800;
    *PEDR &= ~0x2000;   /* Enable LAN activity LED */
}

void
ledBlink(int count)
{
    int i;

    while(count) {
        for(i=0;i<50000;i++);
        ledsOn();
        for(i=0;i<50000;i++);
        ledsOff();
        count--;
    }
}

/* NA for SH2... */
void
setTraceBit()
{
}

void
clrTraceBit()
{
}

void
CSInfo()
{
}
