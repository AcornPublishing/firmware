/* Monitor configuration file.

    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
    phone:  908-582-2351            (home: 908-889-5161)
*/

/* DEFAULT_ETHERADD & DEFAULT_IPADD:
   Refer to notes in ethernet.c function EthernetStartup() for details
   regarding the use of these definitions.  */
#define     DEFAULT_ETHERADD "00:60:1D:02:08:0b"
#define     DEFAULT_IPADD    "135.17.115.215"
/* #define  DEFAULT_IPADD    "DHCP"         */
/* #define  DEFAULT_IPADD    "BOOTP"        */

/* LOOPS_PER_SECOND:
   Approximately the size of a loop that will cause a 1-second delay.
   This can be guestimated or modified with the sleep -c command at the
   monitor command line.  */
#define LOOPS_PER_SECOND    800000

/* Flash bank configuration: */
#define FLASHBANKS              1
#define FLASH_BANK0_WIDTH       2
#define FLASH_BANK0_BASE_ADDR   0x000000

/* TFS definitions:
    TFSSTART:       Base address in FLASH at which TFS starts.
    TFSEND:         End address of TFS in FLASH.
    TFSSPARE:       Location of sector that is used as the spare sector
                    by TFS for defragmentation.
    TFSSPARESIZE:   Size of the spare sector used by TFS for defragmentation.
    TFSSECTORCOUNT: Number of eraseable sectors that TFS covers, not including
                    the TFSSPARE sector.
*/
#define TFSSTART        0x28000
#define TFSEND          0x37fff
#define TFSSPARE        0x38000
#define TFSSPARESIZE    0x8000
#define TFSSECTORCOUNT  2   
#define TFS_EBIN_COFF   1

/* Width macros used by TFS and FLASH operations.
   Note that only one of WIDTH8, WIDTH16 and WIDTH32 should be set and the
   WIDTHXX_NOTUESD macros should reflect the opposite state of the WIDTH
   macros. */
#define WIDTH8      0
#define WIDTH16     1
#define WIDTH32     0
#define WIDTH8_NOTUSED  1
#define WIDTH16_NOTUSED 0
#define WIDTH32_NOTUSED 1

/* FLASH_PROTECT_RANGE:
    These sectors are configured to be software-protected by the monitor's
    flash command.  Note this is a "software" protection mechanism, not
    hardware!
*/
#define FLASH_PROTECT_RANGE "0-4"

/* SYMFILE is the name of a file that, if present, the monitor uses to 
   process symbols on the command line.  A symbol is a whitespace delimited
   string prefixed by a percent sign (%). */
#define SYMFILE "symtbl"

/* Specify the type of SH2 CPU here. Only one should be defined.
   Not applicable for all platforms, used to allow CPUs within a family
   to share common target-specific code. */
#define CPU_7042        1
#define CPU_7043        0

/* Specify CPU/PLATFORM type and name so that common code can be used */
/* for a similar cpu, on different platforms. */
/* The 'TYPE' definition is used for ifdefs in the code and the 'NAME' */
/* is used for printfs in the code. */
#define CPU_TYPE        CPU_7042
#define CPU_NAME        "Hitachi SH2 (7042)"
#define PLATFORM_TYPE   PPA_SH2
#define PLATFORM_NAME   "SH2 Evaluation Board"

/* Specify the size of the memory block (in monitor space) that is to be
   allocated to malloc in the monitor.  Note that this size can be dynamically
   increased using the heap extension option in the heap command.  */
#define ALLOCSIZE 64*1024

/* Specify inclusion of subsystems within the monitor here.
   Subsystems are included/excluded by defining a few macros to 1/0.
   Following are the subsystem groupings based on commands and/or capability:

    INCLUDE_MEMCMDS:        dm, pm, cm, fm, sm, mt
    INCLUDE_PIO:            pio
    INCLUDE_EDIT:           edit
    INCLUDE_DEBUG:          argv, at, dr, go, pr, ss, vfy
    INCLUDE_DISASSEMBLER:   dis
    INCLUDE_UNPACK:         unpack and huffman file decompression
    INCLUDE_ETHERNET:       ether
    INCLUDE_TFS:            tfs
    INCLUDE_MALLOC:         malloc
    INCLUDE_SHELLVAR:       set and shell variables
    INCLUDE_XMODEM:         xmodem
    INCLUDE_UNZIP:          unzip and zlib file decompression
    INCLUDE_EE:             let (expression evaluator)
    INCLUDE_FLASH:          flash operations (required by TFS)
    INCLUDE_CRYPT:          unix-crypt instead of my own "cheap crypt"
                            (see common/crypt.c)
    INCLUDE_LINEEDIT:       vi-like line editor for command line interface
                            and edit.

   Note that these INCLUDE macros allow the monitor to be built in a 
   variety of configurations; some of which may put extreme limitations
   on the capability of the monitor.  For example, it is recommended that
   at least INCLUDE_ETHERNET or INCLUDE_XMODEM be defined otherwise
   there is no download capability in the monitor.  The primary function
   of these macros is to limit complexity during monitor installation on 
   a new system and to save flash space if a particular module is of no
   value.
*/
#define INCLUDE_MEMCMDS         0
#define INCLUDE_PIO             0
#define INCLUDE_EDIT            0
#define INCLUDE_DEBUG           0
#define INCLUDE_DISASSEMBLER    0
#define INCLUDE_UNPACK          0
#define INCLUDE_UNZIP           1
#define INCLUDE_ETHERNET        0
#define INCLUDE_TFTP            0
#define INCLUDE_DHCPBOOT        0
#define INCLUDE_TFS             1
#define INCLUDE_TFSAPI          0
#define INCLUDE_TFSAUTODEFRAG   0
#define INCLUDE_TFSSYMTBL       0
#define INCLUDE_TFSSCRIPT       0
#define INCLUDE_TFSCLI          0
#define INCLUDE_XMODEM          1
#define INCLUDE_LINEEDIT        0
#define INCLUDE_EE              0
#define INCLUDE_FLASH           1
#define INCLUDE_CRYPT           0
#define INCLUDE_GDB             0
#define INCLUDE_STRACE          0
#define INCLUDE_CAST            0
#define INCLUDE_EXCTEST         0
#define INCLUDE_IDEV            0
#define INCLUDE_REDIRECT        0
#define INCLUDE_QUICKMEMCPY     1
#define INCLUDE_PROFILER        0
#define INCLUDE_BBC             0
#define INCLUDE_MEMTRACE        0

#include "inc_check.h"
