/* main.c:
    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
    phone:  908-582-2351            (home: 908-889-5161)
*/
#include "config.h"
#include "info.h"
#include "cpu.h"
#include "tfs.h"
#include "tfsprivate.h"
#include "monapp.h"
#include "monflags.h"
#include "genlib.h"
#include "stddefs.h"
#include "ether.h"

extern  int atinit();
extern  int SetMonSTATUS(), cacheInit(), getvbr();
extern  int ledsOff(), putsr();
extern  int InitMonitorFlags(), getsr();

void    init2(), reinit();

int     StateOfMonitor, AppExitStatus;

extern  ulong   APPLICATION_RAMSTART;
extern  int     moncom();

int
main(int argc,char *argv[])
{
    ledsOff();

    /* Set user level to its max, then allow monrc file to adjust it. */
    initUsrLvl(MAXUSRLEVEL);

    if (StateOfMonitor == INITIALIZE) {
        /* Init register data structures. */
        reginit();
        /* Second phase of hardware initialization. */
        init2();
        /* Common system initialization stuff... */
        init3();
    }

    switch(StateOfMonitor) {
    case INITIALIZE:
        break;
    case MISC:
    case SSTEP:
    case BAILOUT:
    case MORESTART:
    case BREAKPOINT:
#if INCLUDE_DEBUG
        regbackup();
#endif
        break;
    case APP_EXIT:
        reinit();
        printf("\nApplication Exit Status: %d (0x%x)\n",
            AppExitStatus,AppExitStatus);
        break;
    case EXCEPTION:
        reinit();
        exceptionAutoRestart(INITIALIZE);
        break;
    default:
        printf("Unexpected monitor state: 0x%x\n",StateOfMonitor);
        break;
    }

    /* Enter the endless loop of command processing: */
    CommandLoop();

    /* Should not get here */
    return(0);
}

void
reinit()
{
    init1(0);       /* reinit hdware */
    init2();
#if INCLUDE_ETHERNET
    EthernetStartup(0,0);   /* reinit ethernet */
#endif
}

void
init2()
{
#if INCLUDE_FLASH
    FlashInit();        /* Init flashop data structures.  This MUST be */
                        /* done prior to turning on cache!!! */
#endif

    cacheInit();        /* Initialize cache. */

#if INCLUDE_ETHERNET
    enreset();          /* Clear the ethernet interface. */
#endif
#if INCLUDE_TFS
    tfsstartup();       /* Init tfs data structures. */
#endif

    VECTOR(MONVEC) = (ulong)moncom;
}

/* monrestart():
    Called by various points in the code to get back to a known point in
    the monitor.  Note that this is also called by the exception handler
    which may actually call this prior to the setjmp() function being
    called.  If this is the case, then query the user to reset.  If the
    user responds with any keystroke, the reset is not done and we
    simply jump into the command loop; else call coldstart.
*/
void
monrestart(int val)
{
    warmstart(val);
}

void
intsrestore(unsigned long sr)
{
    putsr(sr);
}

ulong
intsoff()
{
    ulong  sr;

    sr = getsr();
    putsr(sr | 0x00f0);
    return(sr);
}

/* some stubs for now... */

void
ctxMON()
{
}

void
ctxAPP()
{
}

void
appexit(val)
int val;
{
    intsoff();
    AppExitStatus = val;
#if INCLUDE_DEBUG
    removeatpoints();
#endif
    warmstart(APP_EXIT);
}

int
monState()
{
    return(StateOfMonitor);
}

/* extValidPassword():
    Refer to validPassword() in common/password.c for notes.
*/
int
extValidPassword(char *password, int ulvl)
{
    return(-1);
}
