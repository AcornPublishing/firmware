/* etherdev.c:
    This file, along with common/ethernet.c supports the ethernet interface.
    It is the lowest layer of code supporting the monitor's IP, ICMP & UDP
    services.  This file is specific to one particular ethernet device
    and provides the hooks needed by common/ethernet.c to initialize,
    and transmit/receive packets in a polled environment.

    The common vs device-specific code is generally noted by a naming 
    convention where ...Ethernet... is common and ...Etherdev... is device-
    specific.

    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
    phone:  908-582-2351            (home: 908-889-5161)
*/
#include "config.h"
#if INCLUDE_ETHERNET
#include "smc91c94.h"
#include "cpuio.h"
#include "ether.h"
#include "stddefs.h"
#include "genlib.h"

#define INCLUDE_FDUMP 0
#define USE_AUTORELEASE 1

static int EtherRXOVRNCnt;
static int EtherALGNERRCnt, EtherBADCRCCnt, EtherTOOLONGCnt;
static int EtherTOOSHORTCnt, EtherWFATMTCnt, EtherWFTTMTCnt;

ushort  smcBank;

static ulong Ercvbuf[400];  /* Ethernet receive buffer word aligned */
static ulong Exmtbuf[400];  /* Ethernet transmit buffer word aligned */

/* ShowEtherdevStats():
    Called by the command "ether stat" on the monitor's command line.
    This function and a common ShowEthernetStats() are used to dump
    generic as well as device-specific ethernet driver statistics.
*/
void
ShowEtherdevStats()
{
    showSmcRevision();
    printf("Receiver overrun errors: %d\n",EtherRXOVRNCnt);
    printf("Alignment errors:        %d\n",EtherALGNERRCnt);
    printf("Bad CRC errors:          %d\n",EtherBADCRCCnt);
    printf("Packet too long errors:  %d\n",EtherTOOLONGCnt);
    printf("Packet too short errors: %d\n",EtherTOOSHORTCnt);
    printf("Wait-for-alloc timeouts: %d\n",EtherWFATMTCnt);
    printf("Wait-for-xmit timeouts:  %d\n",EtherWFTTMTCnt);
}

/* smcRead() & smcWrite():
   Interface functions used to access the SMC chip.  Note that the function
   is wrapped around a critical section because the bank selection and 
   register read/modification should be atomic.
*/
ushort
smcRead(int smcreg)
{
    ushort  reg;

    /* Set up the appropriate bank: */
    if (smcBank != (smcreg & SMCBANKMASK)) {
        *(vushort *)(SMCADDR + SMCBSR) &= ~SMCBANKMASK;
        *(vushort *)(SMCADDR + SMCBSR) |= ((ushort)smcreg & SMCBANKMASK);
        smcBank = smcreg & SMCBANKMASK;
    }

    /* Retrieve the register value: */
    reg = (*(vushort *)(SMCADDR + (smcreg & ~SMCBANKMASK)));
    return(reg);
}

uchar
smcReadByte(int smcreg)
{
    uchar   reg;

    /* Set up the appropriate bank: */
    if (smcBank != (smcreg & SMCBANKMASK)) {
        *(vushort *)(SMCADDR + SMCBSR) &= ~SMCBANKMASK;
        *(vushort *)(SMCADDR + SMCBSR) |= ((ushort)smcreg & SMCBANKMASK);
        smcBank = smcreg & SMCBANKMASK;
    }

    if (!(smcreg & 1))
        smcreg |= 0x10000;      /* For even byte access, set a17 */

    /* Retrieve the register value: */
    reg = (*(vuchar *)(SMCADDR + (smcreg & ~SMCBANKMASK)));
    return(reg);
}

void
smcWrite(int smcreg, ushort value)
{
    /* Set up the appropriate bank: */
    if (smcBank != (smcreg & SMCBANKMASK)) {
        *(vushort *)(SMCADDR + SMCBSR) &= ~SMCBANKMASK;
        *(vushort *)(SMCADDR + SMCBSR) |= ((ushort)smcreg & SMCBANKMASK);
        smcBank = smcreg & SMCBANKMASK;
    }

    /* Put value to the register: */
    *(vushort *)(SMCADDR + (smcreg & ~SMCBANKMASK)) = value;
}

void
smcWriteByte(int smcreg, uchar value)
{
    /* Set up the appropriate bank: */
    if (smcBank != (smcreg & SMCBANKMASK)) {
        *(vushort *)(SMCADDR + SMCBSR) &= ~SMCBANKMASK;
        *(vushort *)(SMCADDR + SMCBSR) |= ((ushort)smcreg & SMCBANKMASK);
        smcBank = smcreg & SMCBANKMASK;
    }

    if (!(smcreg & 1))
        smcreg |= 0x10000;

    /* Put value to the register: */
    *(vuchar *)(SMCADDR + (smcreg & ~SMCBANKMASK)) = value;
}


/* BankSelect():
    Establish the active register bank, and return the old active
    register bank.
*/
int
bankSelect(int bank)
{
    int oldbank;

    oldbank = (int)((*(vushort *)(SMCBSR) >> 8) & 7);
    *(vushort *)(SMCBSR) &= ~0x0700;
    *(vushort *)(SMCBSR) |= (ushort)((bank & 7) << 8);
    return(oldbank);
}

void
showSmcRevision(void)
{
    ushort  revid;
    char    *chip;

    revid = smcRead(SMCREV);

    switch(revid & 0xf000) {
    case LAN91C90_92:
        chip = "91C90/92";
        break;
    case LAN91C94_96:
        if ((revid & 0x0f00) < 0x0600)
            chip = "91C94";
        else
            chip = "91C96";
        break;
    case LAN91C95:
        chip = "91C95";
        break;
    case LAN91C100:
        chip = "91C100";
        break;
    case LAN91C100FD:
        chip = "91C100FD";
        break;
    default:
        chip = 0;
        break;
    }
    if (chip)
        printf("SMC Part: %s, rev %d\n",chip,(revid & 0x0f00) >> 8);
    else
        printf("SMC RevID: %04x\n",revid & 0x0f00);
}

/* EtherdevStartup():
    Called by EthernetStartup().  Initialize all device-specific 
    counters, reset and initialized the ethernet device.
*/
int
EtherdevStartup(int verbose)
{
    int eninit();

    /* Initialize device-driver counters: */
    EtherRXOVRNCnt = 0;
    EtherALGNERRCnt = 0;
    EtherBADCRCCnt = 0;
    EtherTOOLONGCnt = 0;
    EtherTOOSHORTCnt = 0;
    EtherWFATMTCnt = 0;

    /* Put ethernet controller in reset: */
    enreset();

    /* Initialize controller: */
    eninit();

    /* Enable transceiver: */
    smcWrite(SMCTCR,smcRead(SMCTCR) | TXENA);
    smcWrite(SMCRCR,smcRead(SMCRCR) | RXEN);

    return(0);
}

/* enselftest():
    Return 1 if passed, else -1.
*/
int
enselftest(int verbose)
{
    if (verbose)
        printf("Self test not available\n");
    return(1);
}

/* DisableEtherdev():
    Called by DisableEthernet() to do the device-specific portion of 
    the turn-down.
*/
void
DisableEtherdev()
{
    enreset();
}

void
DisableErcv()
{
    smcWrite(SMCRCR,smcRead(SMCRCR) & ~RXEN);
}

void
EnableErcv()
{
    smcWrite(SMCRCR,smcRead(SMCRCR) | RXEN);
}

void
enresetmmu()
{
    smcWrite(SMCMMUCMD,MMUCMD_RESETMMU);
}

void
enreset()
{
    /* Reset the device: */
    smcWrite(SMCRCR,SOFT_RST);
    smcWrite(SMCRCR,0);

    /* Reset MMU and TX fifos: */
    smcWrite(SMCMMUCMD,MMUCMD_RESETMMU);
    smcWrite(SMCMMUCMD,MMUCMD_RESETTXFIFOS);
}

int
eninit()
{
    smcBank = SMCBANKNULL;

    smcWrite(SMCTCR,PAD_EN|FDUPLX);
    smcWrite(SMCRCR,FILT_CAR|STRIP_CRC);
    smcWrite(SMCCONFIG,0);

    /* Reserve 1.5K for Xmit... */
    smcWrite(SMCMCR,0x0600);

    /* Store the ethernet address. */
    smcWrite(SMCIA01,*(ushort *)BinEnetAddr);
    smcWrite(SMCIA23,*(ushort *)&BinEnetAddr[2]);
    smcWrite(SMCIA45,*(ushort *)&BinEnetAddr[4]);

#if USE_AUTORELEASE
    smcWrite(SMCCTRL,smcRead(SMCCTRL) | AUTO_REL);
#else
    smcWrite(SMCCTRL,smcRead(SMCCTRL));
#endif
    return(0);
}

/* geteinbuf():
   Retrieve the incoming ethernet packet.  The first word of the packet is 
   receive frame status word, the second is the byte count of the incoming
   frame.   
   Incoming data format:

        WORD1:      Receive Frame Status Word (RFSW).
        WORD2:      Byte count (includes RFSW, bytecount, data and control).
        WORDS3->N:  Actual ethernet packet (data).
        WORDN+1:    Control byte and possibly last byte of data if odd length.

   The length of the incoming packet must be adjusted prior to passing it to
   any packet processing....  Deduct 2 for the size of the RFSW, 2 for the
   size of the bytecount, 1 for the control byte and one more if the ODD
   bit is not set.  If the ODD bit is set, then the byte in the lower half
   of the final word is part of the actual packet.
*/
int
geteinbuf()
{
    ushort  rfsw, pktsize, count, *data, i;

    smcWrite(SMCPOINTER,PTR_RCV|PTR_AUTOINC|PTR_READ);
    for(i=0;i<10;i++);                  /* delay necessary between POINTER */
                                        /* and DATA access. */
    rfsw = smcRead(SMCDATA1);           /* Receive frame status word */
    count = smcRead(SMCDATA2);          /* Byte count. */
    count = SWAP16(count);
    count &= 0x7ff;                     /* Upper 5 bits are reserved. */
    count -= 4;                         /* Deduct for RFSW and ByteCount */
    if (!(rfsw & RFSW_ODD_LEN))         /* Deduct for CTRL byte and possibly */
        pktsize = count - 2;            /* one more because len != odd. */
    else
        pktsize = count - 1;
    data = (ushort *)Ercvbuf;
    if (count >= sizeof(Ercvbuf)) {
        printf("\007geteinbuf() overflow (cnt=0x%04x)\n",count);
        enreset();
        eninit();
        smcWrite(SMCTCR,smcRead(SMCTCR) | TXENA);
        smcWrite(SMCRCR,smcRead(SMCRCR) | RXEN);
        return(-1);
    }

    if (count & 1) count++;
    while(count > 0) {
        *data++ = smcRead(SMCDATA1);
        count -= 2;
    }

    smcWrite(SMCMMUCMD,MMUCMD_RMRELRXFRAME);
    if (rfsw & (ALGN_ERR | BADCRC | TOOLNG | TOOSHORT)) {
        if (rfsw & ALGN_ERR) {
            EtherALGNERRCnt++;
            printf("Frame alignment error!\n");
        }
        if (rfsw & BADCRC) {
            EtherBADCRCCnt++;
            printf("Bad CRC!\n");
        }
        if (rfsw & TOOLNG) {
            EtherTOOLONGCnt++;
            printf("Frame too long!\n");
        }
        if (rfsw & TOOSHORT) {
            EtherTOOSHORTCnt++;
            printf("Frame too short!\n");
        }
        return(-1);
    }
    processPACKET((struct ether_header *)Ercvbuf,pktsize);
    return(0);
}

/* polletherdev():
    Called by pollethernet() to do the device-specific portion of the
    ethernet polling.  This code is the first step in processing incoming
    ethernet packets.  If a packet is available, the functino geteinbuf()
    (get ethernet input buffer) is called to pass the packet to the higher
    level processPACKET() function.
    IMPORTANT NOTE:
    This function MUST be re-entrant.  There is a possibility that the
    processPACKET() function will ultimately call polletherdev() again.
    This means that once the packet has been detected in the device, it 
    is important that this code do whatever is necessary to assure that
    the same packet will not be seen as available to the nested caller.
    In other words...
    clear the packet from the device prior to calling processPACKET().
*/
int
polletherdev()
{
    ushort  istat;
    int     pcnt;

    pcnt = 0;
    istat = smcRead(SMCINT);
    if (istat & RXOVRN_INT) {
        smcWrite(SMCMMUCMD,MMUCMD_RESETMMU);
        smcWrite(SMCINT,RXOVRN_INT);
        EtherRXOVRNCnt++;
    }
    else if (istat & RCV_INT) {
        while((smcRead(SMCFIFOPORT) & RCVFIFO_EMPTY) == 0) {
            EtherRFRAMECnt++;
            pcnt++;
            geteinbuf();
        }
    }
    /* Enable transceiver: */
    smcWrite(SMCTCR,smcRead(SMCTCR) | TXENA);
    smcWrite(SMCRCR,smcRead(SMCRCR) | RXEN);
    return(pcnt);
}

/* getXmitBuffer():
    Called by various points in the IP/UDP/ICMP code for a buffer that
    will ultimately be the next output packet.
*/
uchar *
getXmitBuffer()
{
    return((uchar *)Exmtbuf);
}

/* sendBuffer():
   Set the flag within the current transmit buffer descriptor indicating
   that it is ready to be transmitted.  Then increment the BD pointer to 
   the next buffer descriptor.
*/
int
sendBuffer(int len)
{
    ushort  pnrarr, nbits, *sptr, i;
    int     origlen;
    ulong   timeout;

    if (EtherVerbose &  SHOW_OUTGOING)
        printPkt((struct ether_header *)Exmtbuf,len,ETHER_OUTGOING);

    origlen = len;
    nbits = (ushort)(len >> 8);
    if (nbits > 5) {
        printf("sendBuffer(): len too long\n");
        return(-1);
    }

    /* Allocate the space and wait for the allocation to succeed. */
again:
    smcWrite(SMCMMUCMD,MMUCMD_ALLOCTXMEM | SWAP16(nbits));
    for(timeout=250000;timeout>0;timeout--) {
#if 0
        istat = smcRead(SMCINT);
        if (istat & ALLOC_INT) {
            pnrarr = smcRead(SMCPNRARR);
            if (pnrarr & ALLOC_FAILED) {
                printf("sendBuffer(%d) alloc failed 1\n",len);
                EtherdevStartup(0);
                return(-1);
            }
        }
#else
        pnrarr = (smcRead(SMCPNRARR) & ALLOC_FAILED);
        if (!(pnrarr & ALLOC_FAILED))
            break;
#endif
    }
    if (!timeout) {
        printf("sendBuffer(%d) wait-for-alloc timeout\n",len);
        EtherWFATMTCnt++;
        smcWrite(SMCMMUCMD,MMUCMD_RESETMMU);
        goto again;
//      EtherdevStartup(0);
//      return(-1);
    }

    smcWrite(SMCPNRARR,ARRTOPNR(pnrarr));
    smcWrite(SMCPOINTER,PTR_AUTOINC);
    for(i=0;i<10;i++);                  /* delay necessary between POINTER */
                                        /* and DATA access. */

    smcWrite(SMCDATA1,0);                           /* control word */
    smcWrite(SMCDATA2,SWAP16((ushort)(len+6)));     /* byte count */
    sptr = (ushort *)Exmtbuf;
    while(1) {
        if (len > 1) {
            smcWrite(SMCDATA1,*sptr++);
            len -= 2;
        }
        else if (len == 1) {
            smcWrite(SMCDATA1,(*sptr & 0xff00) | ODD_LENGTH);
            break;
        }
        else {
            smcWrite(SMCDATA1,0);
            break;
        }
    }
    smcWrite(SMCMMUCMD,MMUCMD_ENQUEUETXPKT);
#ifndef USE_AUTORELEASE
    for(timeout=250000;timeout>0;timeout--) {
        istat = smcRead(SMCINT);
        if (istat & TX_INT) {
            smcWrite(SMCINT,TX_INT);
            smcWrite(SMCPNRARR,smcRead(SMCFIFOPORT));
            smcWrite(SMCMMUCMD,MMUCMD_RELEASEPKT);
            break;
        }
    }
    if (!timeout) {
        printf("\007sendBuffer(%d) wait-for-tx_int timeout\n",origlen);
        EtherWFTTMTCnt++;
        EtherdevStartup(0);
        return(-1);
    }
#endif
    EtherXFRAMECnt++;
    return(0);
}

#if INCLUDE_FDUMP
int
EtherStatToFile(char *prefix)
{
    static  char buf[512];
    int     i;
    char    *bp, fname[32];

    if (EtherIPERRCnt | EtherUDPERRCnt | EtherRXOVRNCnt | EtherALGNERRCnt |
        EtherWFTTMTCnt |
        EtherBADCRCCnt | EtherTOOLONGCnt | EtherTOOSHORTCnt | EtherWFATMTCnt)
    {
        bp = buf;
        sprintf(bp,"%s\n",prefix);
        bp += strlen(bp);
        sprintf(bp,"Transmitted frames:      %d\n",EtherXFRAMECnt);
        bp += strlen(bp);
        sprintf(bp,"Received frames:         %d\n",EtherRFRAMECnt);
        bp += strlen(bp);
        sprintf(bp,"Receiver overrun errors: %d\n",EtherRXOVRNCnt);
        bp += strlen(bp);
        sprintf(bp,"IP hdr cksum errors:     %d\n",EtherIPERRCnt);
        bp += strlen(bp);
        sprintf(bp,"UDP pkt cksum errors:    %d\n",EtherUDPERRCnt);
        bp += strlen(bp);
        sprintf(bp,"Alignment errors:        %d\n",EtherALGNERRCnt);
        bp += strlen(bp);
        sprintf(bp,"Bad CRC errors:          %d\n",EtherBADCRCCnt);
        bp += strlen(bp);
        sprintf(bp,"Packet too long errors:  %d\n",EtherTOOLONGCnt);
        bp += strlen(bp);
        sprintf(bp,"Packet too short errors: %d\n",EtherTOOSHORTCnt);
        bp += strlen(bp);
        sprintf(bp,"Wait-for-xmit timeouts: %d\n",EtherWFTTMTCnt);
        bp += strlen(bp);
        sprintf(bp,"Wait-for-alloc timeouts: %d\n",EtherWFATMTCnt);
        bp += strlen(bp);
        
        for(i=0;i<10;i++) {
            sprintf(fname,"estat%d",i);
            if (!tfsstat(fname))
                break;
        }
        if (i < 10)
            tfsadd(fname,"estat",0,buf,bp - buf);
    }
    return(0);
}
#endif

/* Disable/Enable either broadcast or promiscuous mode... */

void
enablePromiscuousReception()
{
}

void
disablePromiscuousReception()
{
}

void
enableBroadcastReception()
{
}

void
disableBroadcastReception()
{
}

/* extGetEtherAdd() & extGetIpAdd():
    These two functions return a char * to a string that represents an
    IP or MAC address.  If they return NULL, then it is assumed by the
    calling function that there is no target specific hardware that
    contains the IP and/or MAC address.
*/
char *
extGetEtherAdd()
{
    return((char *)0);
}
char *
extGetIpAdd()
{
    return((char *)0);
}
#endif
