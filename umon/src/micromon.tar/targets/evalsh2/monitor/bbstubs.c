/* stubs to keep the linkage of bootblock code clean without adding a lot */
/* of #ifdefs all over the monitor code... */
vinit()
{}
bailout()
{}
InitMonSTATUS()
{}
pollethernet()
{}
SendIPMonChar()
{}
moncom()
{}
