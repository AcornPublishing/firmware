/* ** SH2-7043 **

    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
    phone:  908-582-2351            (home: 908-889-5161)
*/

#define WCR1        ((volatile unsigned short *)(0xFFFF8624)) /* Wait state control register */
#define WCR2        ((volatile unsigned short *)(0xFFFF8626)) /* Wait state control register */
#define BCR1        ((volatile unsigned short *)(0xFFFF8620)) /* Bus control register 1 */
#define BCR2        ((volatile unsigned short *)(0xFFFF8622)) /* Bus control register 2 */
#define DCR         ((volatile unsigned short *)(0xFFFF862A))
#define RTCSR       ((volatile unsigned short *)(0xFFFF862C))
#define RTCNT       ((volatile unsigned short *)(0xFFFF862E))
#define RTCOR       ((volatile unsigned short *)(0xFFFF8630))
#define PAIORH      ((volatile unsigned short *)(0xFFFF8384))
#define PAIORL      ((volatile unsigned short *)(0xFFFF8386))
#define PACRH       ((volatile unsigned short *)(0xFFFF8388))
#define PACRL1      ((volatile unsigned short *)(0xFFFF838C))
#define PACRL2      ((volatile unsigned short *)(0xFFFF838E))
#define PBIOR       ((volatile unsigned short *)(0xFFFF8394))
#define PBCR1       ((volatile unsigned short *)(0xFFFF8398))
#define PBCR2       ((volatile unsigned short *)(0xFFFF839A))
#define PCIOR       ((volatile unsigned short *)(0xFFFF8396))
#define PCCR        ((volatile unsigned short *)(0xFFFF839c))
#define PDIORH      ((volatile unsigned short *)(0xFFFF83A4))
#define PDIORL      ((volatile unsigned short *)(0xFFFF83A6))
#define PDCRH1      ((volatile unsigned short *)(0xFFFF83A8))
#define PDCRH2      ((volatile unsigned short *)(0xFFFF83AA))
#define PDCRL       ((volatile unsigned short *)(0xFFFF83AC))
#define PEIOR       ((volatile unsigned short *)(0xFFFF83B4))
#define PECR1       ((volatile unsigned short *)(0xFFFF83B8))
#define PECR2       ((volatile unsigned short *)(0xFFFF83BA))
#define IPRA        ((volatile unsigned short *)(0xFFFF8348)) /* Int priority level reg A */
#define IPRB        ((volatile unsigned short *)(0xFFFF834A)) /* Int priority level reg B */
#define IPRC        ((volatile unsigned short *)(0xFFFF834C)) /* Int priority level reg C */
#define IPRD        ((volatile unsigned short *)(0xFFFF834E)) /* Int priority level reg D */
#define IPRE        ((volatile unsigned short *)(0xFFFF8350)) /* Int priority level reg E */
#define IPRF        ((volatile unsigned short *)(0xFFFF8352)) /* Int priority level reg F */
#define IPRG        ((volatile unsigned short *)(0xFFFF8354)) /* Int priority level reg G */
#define IPRH        ((volatile unsigned short *)(0xFFFF8356)) /* Int priority level reg H */
#define ICR         ((volatile unsigned short *)(0xFFFF8358)) /* Int control register */
#define ISR         ((volatile unsigned short *)(0xFFFF835A)) /* Int status register */
#define PADRH       ((volatile unsigned short *)(0xFFFF8380))
#define PADRL       ((volatile unsigned short *)(0xFFFF8382))
#define PBDR        ((volatile unsigned short *)(0xFFFF8390))
#define PCDR        ((volatile unsigned short *)(0xFFFF8392))
#define PDDRH       ((volatile unsigned short *)(0xFFFF83a0))
#define PDDRL       ((volatile unsigned short *)(0xFFFF83a2))
#define PEDR        ((volatile unsigned short *)(0xFFFF83B0))
#define PFDR        ((volatile unsigned short *)(0xFFFF83B3))

#define MON_RESET_ENTRY             0
#define MON_GENERAL_ILLEGAL_ENTRY   4
#define MON_INVALID_SLOT_ENTRY      6
#define MON_CPU_ADDRESS_ERROR_ENTRY 9
#define MON_DMA_ADDRESS_ERROR_ENTRY 10
#define MON_NMI_ENTRY               11
#define MON_UBC_ENTRY               12

/* Serial port 0 control registers: */
#define SMR0    (volatile unsigned char *)0xFFFF81A0
#define BRR0    (volatile unsigned char *)0xFFFF81A1
#define SCR0    (volatile unsigned char *)0xFFFF81A2
#define TDR0    (volatile unsigned char *)0xFFFF81A3
#define SSR0    (volatile unsigned char *)0xFFFF81A4
#define RDR0    (volatile unsigned char *)0xFFFF81A5

/* Serial port 1 control registers: */
#define SMR1    (volatile unsigned char *)0xFFFF81B0
#define BRR1    (volatile unsigned char *)0xFFFF81B1
#define SCR1    (volatile unsigned char *)0xFFFF81B2
#define TDR1    (volatile unsigned char *)0xFFFF81B3
#define SSR1    (volatile unsigned char *)0xFFFF81B4
#define RDR1    (volatile unsigned char *)0xFFFF81B5

/* Serial mode register bits: */
#define SCI_SYNC_MODE       0x80
#define SCI_SEVEN_BIT_DATA  0x40
#define SCI_PARITY_ON       0x20
#define SCI_ODD_PARITY      0x10
#define SCI_STOP_BITS_2     0x08
#define SCI_ENABLE_MULTIP   0x04

/* Serial control register bits: */
#define SCI_TIE         0x80    /* Transmit interrupt enable */
#define SCI_RIE         0x40    /* Receive interrupt enable */
#define SCI_TE          0x20    /* Transmit enable */
#define SCI_RE          0x10    /* Receive enable */
#define SCI_MPIE        0x08    /* Multiprocessor interrupt enable */
#define SCI_TEIE        0x04    /* Transmit end interrupt enable */
#define SCI_CKE1        0x02    /* Clock enable 1 */
#define SCI_CKE0        0x01    /* Clock enable 0 */

/* Serial status register bits: */
#define SCI_TDRE        0x80    /* Transmit data register empty */
#define SCI_RDRF        0x40    /* Receive data register full */
#define SCI_ORER        0x20    /* Overrun error */
#define SCI_FER         0x10    /* Framing error */
#define SCI_PER         0x08    /* Parity error */
#define SCI_TEND        0x04    /* Transmit end */
#define SCI_MPB         0x02    /* Multiprocessor bit */
#define SCI_MPBT        0x01    /* Multiprocessor bit transfer */

/*
 * SCI BRR,CKE(n) value calculation
 * BRR depends on SCI:CKE(n), OSC(phi/2), and desired baud(baud)
 * round calculation up 1/2 to adjust for integer divide for min. error
 *
 * NOTE: There may be some problems with defining the BRR stuff in common.
 *  For example, the H8/3437 has a PHI/2 mode option when n>0
 *  which can throw off the calculation. This can be either modified
 *  by adjusting the clock/baud desired or making the below calculations
 *  CPU specific.
 */
#define DEFAULT_BAUD_RATE       115200
#define MON_CPU_CLOCK   (7159090*4) /* phi = 7.159Mhz */

#define _SETBRR_(osc,n,baud) ((2*osc/32/(1<<(2*n))/baud+1)/2-1)

#if _SETBRR_( MON_CPU_CLOCK,0,DEFAULT_BAUD_RATE ) < 256
    #define SCI_BRR_VALUE _SETBRR_( MON_CPU_CLOCK,0,DEFAULT_BAUD_RATE)
    #define SCI_SCR_N_VALUE 0
#elif _SETBRR_( MON_CPU_CLOCK,1,DEFAULT_BAUD_RATE) < 256
    #define SCI_BRR_VALUE _SETBRR_( MON_CPU_CLOCK,0,DEFAULT_BAUD_RATE)
    #define SCI_SCR_N_VALUE 1
#elif _SETBRR_( MON_CPU_CLOCK,2,DEFAULT_BAUD_RATE) < 256
    #define SCI_BRR_VALUE _SETBRR_( MON_CPU_CLOCK,0,DEFAULT_BAUD_RATE)
    #define SCI_SCR_N_VALUE 2
#elif _SETBRR_( MON_CPU_CLOCK,3,DEFAULT_BAUD_RATE) < 256
    #define SCI_BRR_VALUE _SETBRR_( MON_CPU_CLOCK,0,DEFAULT_BAUD_RATE)
    #define SCI_SCR_N_VALUE 3
#else
    Error!
#endif


#define CACHEN_CS0      0x0001
#define CACHEN_CS1      0x0002
#define CACHEN_CS2      0x0004
#define CACHEN_CS3      0x0008
#define CACHEN_DRAM     0x0010
#define CCR     (volatile unsigned short *)0xFFFF8740
#define CAAWRS  (volatile unsigned short *)0xFFFFF000
#define CDAWRS  (volatile unsigned short *)0xFFFFF400

/* Compare Match Timer stuff... */
#define CPUFREQ 28636363

/* See page 529 (chap 16) of 7040 Series Hardware manual). */
#define CMSTR   0xffff83d0
#define CMCSR0  0xffff83d2
#define CMCNT0  0xffff83d4
#define CMCOR0  0xffff83d6
#define CMCSR1  0xffff83d8
#define CMCNT1  0xffff83da
#define CMCOR1  0xffff83dc

#define STARTTMR0()     (*(unsigned short *)CMSTR |= 0x0001)
#define STOPTMR0()      (*(unsigned short *)CMSTR &= ~0x0001)
#define STARTTMR1()     (*(unsigned short *)CMSTR |= 0x0002)
#define STOPTMR1()      (*(unsigned short *)CMSTR &= ~0x0002)

#define CLEARCMF0()     (*(unsigned short *)CMCSR0 &= ~0x0080)
#define CLEARCMF1()     (*(unsigned short *)CMCSR1 &= ~0x0080)
#define GETCMF0()       (*(unsigned short *)CMCSR0 & 0x0080)
#define GETCMF1()       (*(unsigned short *)CMCSR1 & 0x0080)
#define ENABLECMI0()    (*(unsigned short *)CMCSR0 |= 0x0040)
#define ENABLECMI1()    (*(unsigned short *)CMCSR1 |= 0x0040)
#define DISABLECMI0()   (*(unsigned short *)CMCSR0 &= ~0x0040)
#define DISABLECMI1()   (*(unsigned short *)CMCSR1 &= ~0x0040)

#define GETCMCNT0()     (*(unsigned short *)CMCNT0)
#define GETCMCNT1()     (*(unsigned short *)CMCNT1)

#define SETCMCOR0(n)    (*(unsigned short *)CMCOR0 = n)
#define SETCMCOR1(n)    (*(unsigned short *)CMCOR1 = n)

#define CLEARCKS0()     (*(unsigned short *)CMCSR0 &= ~0xfffc)
#define CLEARCKS1()     (*(unsigned short *)CMCSR1 &= ~0xfffc)

#define DIVBY8CKS0()    (*(unsigned short *)CMCSR0 |= 0x0000)
#define DIVBY32CKS0()   (*(unsigned short *)CMCSR0 |= 0x0001)
#define DIVBY128CKS0()  (*(unsigned short *)CMCSR0 |= 0x0002)
#define DIVBY512CKS0()  (*(unsigned short *)CMCSR0 |= 0x0003)
#define DIVBY8CKS1()    (*(unsigned short *)CMCSR1 |= 0x0000)
#define DIVBY32CKS1()   (*(unsigned short *)CMCSR1 |= 0x0001)
#define DIVBY128CKS1()  (*(unsigned short *)CMCSR1 |= 0x0002)
#define DIVBY512CKS1()  (*(unsigned short *)CMCSR1 |= 0x0003)

