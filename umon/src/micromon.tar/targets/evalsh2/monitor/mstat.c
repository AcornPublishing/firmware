/* mstat.c:
    The mstat command is provided as a target-specific command for keeping
    track of various monitor-specific stuff... uart baud rate, malloc stats,
    chip-select configuration, etc...

    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
    phone:  908-582-2351            (home: 908-889-5161)
*/
#include "config.h"
#include "cpu.h"
#include "genlib.h"
#include "stddefs.h"

extern  void InitUART(), moreset();
extern  void ConsoleBaudEnvSet(), CSInfo();
void mstatshow();
void InitMonSTATUS(unsigned long);

extern int optind;
extern char *optarg;

static  ushort  MonitorSTATUS;

char *MstatHelp[] = {
    "Monitor status",
    "-[b:cs:]",
    " -b {baud}  set baud rate",
    " -c         dump chip-select info",
    " -s {val}   set monitor state",
    0,
};

int
Mstat(argc,argv)
int argc;
char    *argv[];
{
    int opt;

    /* If no args, just dump current status. */
    if (argc == 1) {
        mstatshow();
        return(0);
    }

    while ((opt=getopt(argc,argv,"b:cs:")) != -1) {
        switch(opt) {
        case 'b':
            InitUART(atoi(optarg));
            ConsoleBaudEnvSet();
            break;
        case 'c':
            CSInfo();
            return(0);
        case 's':
            InitMonSTATUS((ushort)strtol(optarg,0,0));
            break;
        default:
            return(0);
        }
    }
    if (argc != optind)
        return(-1);
    return(0);
}

void
putvbr(vbr)
ulong vbr;
{
    __asm__("mov.l @r14,r0");
    __asm__("ldc r0,vbr");
}

void
putpr(pr)
ulong pr;
{
    __asm__("mov.l @r14,r0");
    __asm__("lds r0,pr");
}

void
putsr(sr)
ulong sr;
{
    __asm__("mov.l @r14,r0");
    __asm__("ldc r0,sr");
}

int
getvbr()
{
    __asm__("stc vbr,r0");
}

int
getgbr()
{
    __asm__("stc gbr,r0");
}

int
getsr()
{
    __asm__("stc sr,r0");
}

int
getsp()
{
    __asm__("mov r15,r0");
}

void
InitMonSTATUS(ulong state)
{
    MonitorSTATUS = state;
    putsr((ushort)MonitorSTATUS);
}

void
SetMonSTATUS()
{
    putsr((ushort)MonitorSTATUS);
}

void
mstatshow()
{
    extern  int monState();

    monHeader(0);
    mstatshowcom();
    printf("Current:\n SR:  0x%04x\n",(ushort)getsr());
    printf(" SP:  0x%08lx\n",(ulong)getsp());
    printf(" GBR: 0x%08lx\n",(ulong)getgbr());
    printf(" VBR: 0x%08lx\n",(ulong)getvbr());
    printf("Monitor STATE: %d\n",monState());
}

void
prHex(int size,uchar *cp,char *prefix, char *suffix)
{
    uchar   *end;
    static  char *hexdigits = "0123456789abcdef";

    if (prefix) {
        while(*prefix)
            putchar(*prefix++);
    }
    end = cp + size;
    while(cp < end) {
        rputchar(hexdigits[(int)((*cp&0xf0)>>4)]);
        rputchar(hexdigits[(int)(*cp&0x0f)]);
        cp++;
    }
    if (suffix) {
        while(*suffix)
            putchar(*suffix++);
    }
}
