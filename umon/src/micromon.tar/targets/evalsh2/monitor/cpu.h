/* cpu.h:

    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
    phone:  908-582-2351            (home: 908-889-5161)
*/
#define MONARGV0    "monsh2"

#define VECTOR(v)   (*(ulong *)(getvbr()+((v)*4)))

#define JUMPTOSTART()   coldstart()

#define EXCEPTION   1
#define BREAKPOINT  2
#define INITIALIZE  3
#define SSTEP       4
#define APPLICATION 5
#define MORESTART   6
#define BAILOUT     7
#define MISC        8
#define APP_EXIT    9

#define MONITOR_STATUS      0x00f0

/* This size is dependent on the amount of memory on the board... */
#define APPLICATION_STACK   0x107fff0


#define RESET                   (FLASH_BANK0_BASE_ADDR)
#define RESETFUNC()             ((void(*)())(*(ulong *)RESET))

/* TRAP stuff used by at.c: */
#define TRAPNUM     32      
#define TRAPU       0xc3
#define TRAPL       TRAPNUM
#define ATVECTOR    32
