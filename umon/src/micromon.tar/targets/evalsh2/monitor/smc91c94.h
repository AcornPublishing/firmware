/*  smc91c94.h:

    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
    phone:  908-582-2351            (home: 908-889-5161)
*/
#define SMCADDR 0x400000

#define SWAP16(val) ((((val) & 0x00ff) << 8) | (((val) & 0xff00) >> 8))

#define SMCBANKMASK 0x0700
#define SMCBANK0    0x0000
#define SMCBANK1    0x0100
#define SMCBANK2    0x0200
#define SMCBANK3    0x0300
#define SMCBANKNULL 0x0400

#define SMCBSR      (0xe)               /* Bank Select Register (all banks) */

/* Bank 0 registers: */
#define SMCTCR      (SMCBANK0|0)        /* Transmit Control */
#define SMCEPHSTAT  (SMCBANK0|2)        /* EPH Status */
#define SMCRCR      (SMCBANK0|4)        /* Receive Control */
#define SMCCOUNTER  (SMCBANK0|6)        /* Counter */
#define SMCMIR      (SMCBANK0|8)        /* Memory Information */
#define SMCMCR      (SMCBANK0|10)       /* Memory Configuration */

/* Bank 1 registers: */
#define SMCCONFIG   (SMCBANK1|0)        /* Configuration */
#define SMCBASE     (SMCBANK1|2)        /* Base Address */
#define SMCIA01     (SMCBANK1|4)        /* Individual Address 0-1 */
#define SMCIA23     (SMCBANK1|6)        /* Individual Address 2-3 */
#define SMCIA45     (SMCBANK1|8)        /* Individual Address 4-5 */
#define SMCGENERAL  (SMCBANK1|10)       /* General Purpose */
#define SMCCTRL     (SMCBANK1|12)       /* Control */

/* Bank 2 registers: */
#define SMCMMUCMD   (SMCBANK2|0)        /* MMU Command */
#define SMCPNRARR   (SMCBANK2|2)        /* Pkt Number/Allocation Rslt */
#define SMCFIFOPORT (SMCBANK2|4)        /* FIFO Ports */
#define SMCPOINTER  (SMCBANK2|6)        /* Pointer */
#define SMCDATA1    (SMCBANK2|8)        /* Data */
#define SMCDATA2    (SMCBANK2|10)       /* Data */
#define SMCINT      (SMCBANK2|12)       /* Interrupt Control */

/* Bank 3 registers: */
#define SMCMT01     (SMCBANK3|0)        /* Multicast Tbl 0-1 */
#define SMCMT23     (SMCBANK3|2)        /* Multicast Tbl 2-3 */
#define SMCMT45     (SMCBANK3|4)        /* Multicast Tbl 4-5 */
#define SMCMT67     (SMCBANK3|6)        /* Multicast Tbl 6-7 */
#define SMCMGMT     (SMCBANK3|8)        /* Management */
#define SMCREV      (SMCBANK3|10)       /* Revision */
#define SMCERCV     (SMCBANK3|12)       /* Early Receive */

/* SMC Chip ID: */
#define LAN91C90_92 0x3000
#define LAN91C94_96 0x4000  /* Rev < 6 == 91C94, Rev >= 6 == 91C96 */
#define LAN91C95    0x5000
#define LAN91C100   0x7000
#define LAN91C100FD 0x8000


/* Bit masks for registers: */
/* Note that bytes are swapped */

/* TCR bits: */
#define PAD_EN      0x8000
#define FORCOL      0x0400
#define LOOP        0x0200
#define TXENA       0x0100
#define EPH_LOOP    0x0020
#define STP_SQET    0x0010
#define FDUPLX      0x0008
#define MON_CSN     0x0004
#define NOCRC       0x0001

/* RCR bits: */
#define ALMUL       0x0400
#define PRMS        0x0200
#define RX_ABORT    0x0100
#define SOFT_RST    0x0080
#define FILT_CAR    0x0040
#define STRIP_CRC   0x0002
#define RXEN        0x0001

/* MIR bits: */
#define MSM()       ((smcRead(SMCMCR) & 0x000E) >> 1)
#define MRX()       (((smcRead(SMCMCR) & 0xFF00) >> 8) * 256 * MSM())

/* MCR bits: */
#define FREEMEM()       ((smcRead(SMCMIR) & 0x00FF) * 256 * MSM())
#define MEMSIZE()       (((smcRead(SMCMIR) & 0xFF00) >> 8) * 256 * MSM())

/* CONFIG bits: */
#define BIT_16      0x8000
#define DIS_LINK    0x4000
#define INT_SEL1    0x0400
#define INT_SEL0    0x0200
#define NO_WAIT     0x0010
#define FULL_STEP   0x0004
#define SET_SQLCH   0x0002
#define AUI_SELECT  0x0001

/* CONTROL bits: */
#define LE_ENABLE   0x8000
#define CR_ENABLE   0x4000
#define TE_ENABLE   0x2000
#define EEPROM_SEL  0x0400
#define RELOAD      0x0200
#define STORE       0x0100
#define RCV_BAD     0x0040
#define PWRDN       0x0020
#define AUTO_REL    0x0008

/* MMU COMMAND bits: */
#define MMU_CMD_MASK            0xe000
#define N2                      0x0400
#define N1                      0x0200
#define N0_BUSY                 0x0100
#define MMUCMD_NOOP             0x0000  /* NO OP */
#define MMUCMD_ALLOCTXMEM       0x2000  /* Allocate Memory for TX */
#define MMUCMD_RESETMMU         0x4000  /* Reset MMU to initial state */
#define MMUCMD_RMRXFRAME        0x6000  /* Remove frame from top of RX fifo */
#define MMUCMD_RMRELRXFRAME     0x8000  /* Remove and release top of RX fifo */
#define MMUCMD_RELEASEPKT       0xa000  /* Release specific packet */
#define MMUCMD_ENQUEUETXPKT     0xc000  /* Enqueue packet into TX fifo */
#define MMUCMD_RESETTXFIFOS     0xe000  /* Reset TX fifos */

/* Receive frame status word bits: */
#define ALGN_ERR        0x0080
#define BROADCAST       0x0040
#define BADCRC          0x0020
#define ODDFRM          0x0010
#define TOOLNG          0x0008
#define TOOSHORT        0x0004
#define MULT_CAST       0x0100

/* Interrupt Register bits: */
#define ERCV_INT        0x4000
#define EPH_INT         0x2000
#define RXOVRN_INT      0x1000
#define ALLOC_INT       0x0800
#define TXEMPTY_INT     0x0400
#define TX_INT          0x0200
#define RCV_INT         0x0100

/* FifoPort bits: */
#define RCVFIFO_EMPTY   0x0080
#define XMTFIFO_EMPTY   0x8000

/* Pointer Register bits: */
#define PTR_RCV         0x0080
#define PTR_AUTOINC     0x0040
#define PTR_READ        0x0020
#define PTR_ETEN        0x0010

/* Allocation Result Register bits: */
#define ALLOC_FAILED    0x0080
#define ARRTOPNR(arr)   ((arr << 8) & 0xff00)

/* Frame Control Byte bits: */
#define ODD_LENGTH      0x0020

/* Receive Frame Status Register bits: */
#define RFSW_ODD_LEN    0x0010
#define RFSW_BCAST      0x0040

unsigned short smcRead(int);
void smcWrite(int, unsigned short);
void showSmcRevision(void);
int SendBuffer(char *,int);
