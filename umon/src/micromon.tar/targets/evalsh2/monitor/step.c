/* step.c:
   This is not a complete implementation of single stepping for the SH2.
   Currently, only basic stepping works... If the instruction is a jump
   or a branch then the stepper gets confused.  I need to implement the code
   that will determine the branch address based on the opcode and flags. 

    General notice:
    This code is part of a boot-monitor package developed as a generic base
    platform for embedded system designs.  As such, it is likely to be
    distributed to various projects beyond the control of the original
    author.  Please notify the author of any enhancements made or bugs found
    so that all may benefit from the changes.  In addition, notification back
    to the author will allow the new user to pick up changes that may have
    been made by other users after this version of the code was distributed.

    Author: Ed Sutter
    email:  esutter@lucent.com      (home: lesutter@worldnet.att.net)
    phone:  908-582-2351            (home: 908-889-5161)
*/
#include "config.h"
#include "cpu.h"
#include "stddefs.h"
#if INCLUDE_DEBUG

extern  int StateOfMonitor, optind;
extern  void setTraceBit(), clrTraceBit(), resume(), installatpoints();
extern  void removeatpoints(), monrestart();
extern  int getopt(), disass(), printf(), settrap();
extern  long strtol(), getreg();

int StepCount, StepQuiet;
extern  ushort *AddrAfterBP, InstAfterBP;

char *SsHelp[] = {
        "Single step",
        "-[o] [count]",
        " -o   step over function",
        0,
};

Ss(argc,argv)
int argc;
char    *argv[];
{
    ulong   pc;
    int opt, StepOver;

    StepOver = 0;
    StepQuiet = 0;
    while((opt=getopt(argc,argv,"oq")) != -1) {
        switch(opt) {
        case 'o':
            StepOver = 1;
            break;
        case 'q':
            StepQuiet = 1;
            break;
        default:
            return(0);
        }
    }
    if (argc-(optind-1) == 2)
        StepCount = strtol(argv[optind],(char **)0,0);
    else
        StepCount = 1;

    if (StepOver)
        StepCount = 1;

    getreg("PC",&AddrAfterBP);
    if (StepOver) 
        AddrAfterBP++;
    AddrAfterBP++;
    InstAfterBP = settrap(AddrAfterBP);
    StateOfMonitor = SSTEP;
    resume();
}

didStep(ulong pc)
{
#if INCLUDE_DISASSEMBLER
    if (!StepQuiet)
        disass(pc,1,1);
#endif
    StepCount--;
    if (StepCount) {
        AddrAfterBP = (ushort *)(pc+2);
        InstAfterBP = settrap(AddrAfterBP);
        resume();
    }
    monrestart(SSTEP);
}

#endif
