#include "monlib.h"
#include "stddefs.h"

int
getvbr()
{
    __asm__("stc vbr,r0");
}

int
getsr()
{
    __asm__("stc sr,r0");
}

putsr(sr)
ulong sr;
{
    __asm__("mov.l @r14,r0");
    __asm__("ldc r0,sr");
}

/* Compare Match Timer stuff... */
#define CPUFREQ 28636363

/* See page 529 (chap 16) of 7040 Series Hardware manual). */
#define CMSTR   0xffff83d0
#define CMCSR0  0xffff83d2
#define CMCNT0  0xffff83d4
#define CMCOR0  0xffff83d6
#define CMCSR1  0xffff83d8
#define CMCNT1  0xffff83da
#define CMCOR1  0xffff83dc

#define STARTTMR0()     (*(unsigned short *)CMSTR |= 0x0001)
#define STOPTMR0()      (*(unsigned short *)CMSTR &= ~0x0001)
#define STARTTMR1()     (*(unsigned short *)CMSTR |= 0x0002)
#define STOPTMR1()      (*(unsigned short *)CMSTR &= ~0x0002)

#define CLEARCMF0()     (*(unsigned short *)CMCSR0 &= ~0x0080)
#define CLEARCMF1()     (*(unsigned short *)CMCSR1 &= ~0x0080)
#define GETCMF0()       (*(unsigned short *)CMCSR0 & 0x0080)
#define GETCMF1()       (*(unsigned short *)CMCSR1 & 0x0080)
#define ENABLECMI0()    (*(unsigned short *)CMCSR0 |= 0x0040)
#define ENABLECMI1()    (*(unsigned short *)CMCSR1 |= 0x0040)
#define DISABLECMI0()   (*(unsigned short *)CMCSR0 &= ~0x0040)
#define DISABLECMI1()   (*(unsigned short *)CMCSR1 &= ~0x0040)

#define GETCMCNT0()     (*(unsigned short *)CMCNT0)
#define GETCMCNT1()     (*(unsigned short *)CMCNT1)

#define SETCMCOR0(n)    (*(unsigned short *)CMCOR0 = n)
#define SETCMCOR1(n)    (*(unsigned short *)CMCOR1 = n)

#define CLEARCKS0()     (*(unsigned short *)CMCSR0 &= ~0x0003)
#define CLEARCKS1()     (*(unsigned short *)CMCSR1 &= ~0x0003)

#define DIVBY8CKS0()    (*(unsigned short *)CMCSR0 |= 0x0000)
#define DIVBY32CKS0()   (*(unsigned short *)CMCSR0 |= 0x0001)
#define DIVBY128CKS0()  (*(unsigned short *)CMCSR0 |= 0x0002)
#define DIVBY512CKS0()  (*(unsigned short *)CMCSR0 |= 0x0003)
#define DIVBY8CKS1()    (*(unsigned short *)CMCSR1 |= 0x0000)
#define DIVBY32CKS1()   (*(unsigned short *)CMCSR1 |= 0x0001)
#define DIVBY128CKS1()  (*(unsigned short *)CMCSR1 |= 0x0002)
#define DIVBY512CKS1()  (*(unsigned short *)CMCSR1 |= 0x0003)


/* Interrupt registers: (pg 79) */
#define IPRA    0xffff8348
#define IPRB    0xffff834a
#define IPRC    0xffff834c
#define IPRD    0xffff834e
#define IPRE    0xffff8350
#define IPRF    0xffff8352
#define IPRG    0xffff8354
#define IPRH    0xffff8356
#define ICR     0xffff8358
#define ISR     0xffff835a

int Systick;

void
Ctick()
{
    CLEARCMF0();
    Systick++;
}

int
main(int argc,char *argv[])
{
    register int zero, one, two, three, four, five, six, seven, eight;
    register int nine, ten, eleven, twelve, thirteen, fourteen, fifteen;
    int i, sr, *vbr, osystick;
    extern  int tick();

    for(i=0;i<argc;i++)
        mon_printf("argv[%d] = %s\n",i,argv[i]);

    if (mon_getenv("ABC"))
        mon_cprintf("ABC = %s\n",mon_getenv("ABC"));
    else
        mon_printf("Shellvar ABC not set.\n");


    zero = 0;
    one = 1;
    two = 2;
    three = 3;
    four = 4;
    five = 5;
    six = 6;
    seven = 7;
    eight = 8;
    nine = 9;
    ten = 10;
    eleven = 11;
    twelve = 12;
    thirteen = 13;
    fourteen = 14;
    fifteen = 15;

    CLEARCMF0();
    CLEARCKS0();
    DIVBY512CKS0();         /* Divide 28636363hz clock by 512 to get */
                            /* a 55930hz tick. */
    SETCMCOR0(CPUFREQ/512); /* Set CMCOR0 to 55930 to get a 1hz tick rate. */

    STARTTMR0();            /* Run timer in polled mode and see that the */
    for(i=0;i<3;) {         /* dots come out at a rate of 1 per second.  */
        if (GETCMF0()) {
            i++;
            mon_printf(".");
            CLEARCMF0();
        }
    }
    STOPTMR0();


    /* Set up the proper vector... */
    vbr = (int *)getvbr();
    mon_printf("VBR=0x%x\n",vbr);
    vbr[144] = (int)tick;
    mon_printf("vbr[144] = 0x%x\n",vbr[144]);

    /* Lower interrupt level... */
    sr = getsr();
    sr &= ~0x000000e0;
    putsr(sr);


    /* Assign interrupt level of CMT0 timer... */
    *(unsigned short *)IPRG = 0x0080;

    osystick = Systick = 0;
    STARTTMR0();
    ENABLECMI0();
    while(1) {
        if ((zero != 0) || (one != 1) || (two != 2) || (three != 3) ||
           (four != 4) || (five != 5) || (six != 6) || (seven != 7) ||
           (eight != 8) || (nine != 9) || (ten != 10) || (eleven != 11) ||
           (twelve != 12) || (thirteen != 13) ||
           (fourteen != 14) || (fifteen != 15)) {
            mon_printf("BUMMER!\n");
            mon_printf("0x%x\n",zero);
            mon_printf("0x%x\n",one);
            mon_printf("0x%x\n",two);
            mon_printf("0x%x\n",three);
            mon_printf("0x%x\n",four);
            mon_printf("0x%x\n",five);
            mon_printf("0x%x\n",six);
            mon_printf("0x%x\n",seven);
            mon_printf("0x%x\n",eight);
            mon_printf("0x%x\n",nine);
            mon_printf("0x%x\n",ten);
            mon_printf("0x%x\n",eleven);
            mon_printf("0x%x\n",twelve);
            mon_printf("0x%x\n",thirteen);
            mon_printf("0x%x\n",fourteen);
            mon_printf("0x%x\n",fifteen);
            break;
        }
        if (osystick != Systick) {
            mon_putchar('!');
            osystick = Systick;
        }
        if (mon_gotachar())
            break;
    }
    DISABLECMI0();
    mon_printf("\n");
    return(0);
}
